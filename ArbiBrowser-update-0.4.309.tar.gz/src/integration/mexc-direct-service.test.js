'use strict';
const test = require('node:test');
const assert = require('node:assert');
const m = require('./mexc-order-page');

const H = (c) => c.repeat(32);
const USDT = H('e');
const LIST = [{ vn: 'USDC', cd: H('1'), mcd: USDT, ps: 4 }, { vn: 'WOJAK', cd: H('2'), mcd: USDT, ps: 11 }];

// Подставной профиль: вкладка MEXC, список рынков и ответ биржи на заявку; sent — тела ушедших заявок.
function fakeProfile() {
  const sent = [];
  const ctx = { on: () => {}, pages: () => [page] };
  const page = {
    context: () => ctx,
    isClosed: () => false,
    url: () => 'https://www.mexc.com/ru-RU/exchange/USDC_USDT',
    evaluate: async (_fn, arg) => {
      if (!arg) return LIST; // список рынков
      sent.push(JSON.parse(arg.body));
      return { status: 200, code: 200, data: `C02__${sent.length}` };
    },
  };
  return { ctx, page, sent };
}
const capture = (page, pair, side, body) => m._rememberDirect(page, pair, side, {
  allHeaders: async () => ({ 'x-mxc-sign': 's', cookie: 'c' }), headers: () => ({}), url: () => 'https://www.mexc.com/api/platform/spot/order/place',
  postData: () => JSON.stringify(body),
});
const BASE_BODY = { currencyId: H('1'), marketCurrencyId: USDT, tradeType: 'BUY', price: '0.5', quantity: '3', p0: 'x', k0: 'y' };
const intent = (o) => ({ type: 'limit', hints: { direct: true }, side: 'sell', symbol: 'WOJAK/USDT', price: '0.00000005', quantity: '1000', ...o });

test('sideAs: написание подписи сохраняется', () => {
  assert.strictEqual(m.sideAs('BUY', 'sell'), 'SELL');
  assert.strictEqual(m.sideAs('buy', 'sell'), 'sell');
  assert.strictEqual(m.sideAs('Sell', 'buy'), 'Buy');
  assert.strictEqual(m.sideAs(1, 'sell'), 2);
  assert.strictEqual(m.sideAs('2', 'buy'), '1');
  assert.strictEqual(m.sideAs('LIMIT', 'buy'), null);
});

test('tryDirect: служебная подпись профиля — currencyId и сторона заявки, цена и количество свои', async () => {
  const { ctx, page, sent } = fakeProfile();
  await capture(page, 'USDC_USDT', 'buy', BASE_BODY);
  const r = await m.tryDirect(ctx, intent(), () => {});
  assert.deepStrictEqual(r, { ok: true, orderId: 'C02__1', direct: true });
  assert.strictEqual(sent[0].currencyId, H('2'));
  assert.strictEqual(sent[0].tradeType, 'SELL');
  assert.strictEqual(sent[0].price, '0.00000005');
  assert.strictEqual(sent[0].quantity, '1000');
  assert.strictEqual(sent[0].p0, 'x'); // подписные поля — как в подписи
});

test('tryDirect: подпись другого профиля не используется (#88); выключатель — только своя подпись', async () => {
  const a = fakeProfile();
  const b = fakeProfile();
  await capture(a.page, 'USDC_USDT', 'buy', BASE_BODY);
  assert.strictEqual(await m.tryDirect(b.ctx, intent(), () => {}), null);
  process.env.ARBI_MEXC_SERVICE_DIRECT = '0';
  try { assert.strictEqual(await m.tryDirect(a.ctx, intent(), () => {}), null); } finally { delete process.env.ARBI_MEXC_SERVICE_DIRECT; }
  assert.strictEqual(a.sent.length + b.sent.length, 0);
});

test('tryDirect: USDT подписи ≠ USDT списка или монеты нет — форма (null), заявка не уходит', async () => {
  const { ctx, page, sent } = fakeProfile();
  await capture(page, 'USDC_USDT', 'buy', { ...BASE_BODY, marketCurrencyId: H('9') });
  assert.strictEqual(await m.tryDirect(ctx, intent(), () => {}), null);
  assert.strictEqual(await m.tryDirect(ctx, intent({ symbol: 'NOPE/USDT' }), () => {}), null);
  assert.strictEqual(sent.length, 0);
});

test('tryDirect: без флага direct от терминала — прямой путь не трогается', async () => {
  const { ctx, page, sent } = fakeProfile();
  await capture(page, 'USDC_USDT', 'buy', BASE_BODY);
  assert.strictEqual(await m.tryDirect(ctx, intent({ hints: {} }), () => {}), null);
  assert.strictEqual(sent.length, 0);
});

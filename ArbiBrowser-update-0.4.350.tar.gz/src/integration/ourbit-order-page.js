'use strict';

/**
 * ourbit-order-page.js — исполнитель Ourbit через сайт (оператор 2026-11-16: «ourbit не даёт торговать спот
 * по api, делаем все токены через arbibr»).
 *
 * API Ourbit даёт ключам только чтение истории, поэтому заявки, отмены, открытые ордера и балансы — запросы
 * самого сайта из залогиненной вкладки профиля (fetch из страницы, cookie сессии). Проба 2 (0.4.322):
 * заявка без x-ourbit-sign/nonce принимается — подпись не нужна, формы нет, ≈0,3 с на заявку.
 * Остальные заголовки сайта (luminex-uid, language, …) берутся из любого его запроса к /api/ — значения
 * нигде не пишутся.
 *
 * ⛔ МОНЕТА ПО КОНТРАКТУ (оператор 16.11: «лучше не исполнить заявку и пропустить сделку, чем купить
 * однофамильца»). Заявка сайта называет монету тикером (`currency`). Тикер берётся ТОЛЬКО из intent.symbol,
 * и заявка уходит, только если терминал приложил сверку: hints.ourbit.ticker = этот тикер, и либо
 * verified (контракты, по которым Ourbit сам называет этот тикер; сверено ≤10 мин назад), либо manual
 * (ручная заявка человека с экрана — разрешено оператором). После постановки — проверка в открытых
 * ордерах, что встала та же монета; иначе отмена.
 */

const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { formatDecimal, isPlainPositive } = require('./order-utils');
const ourbitSign = require('./ourbit-sign');
const ourbitCaptcha = require('./ourbit-captcha');
const { withdrawViaForm, prewarmForm, ensureCaptcha, setBusy, wdTab } = require('./ourbit-withdraw-page');

const ORIGIN = 'https://www.ourbit.com';
const SKIP_HDR = /^(cookie|host|content-length|content-type|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|cache-control|sec-|:|x-ourbit-(sign|nonce)$)/i;
const VERIFY_MAX_MS = 10 * 60_000;
const OPEN_PATH = '/api/platform/spot/order/current/orders/v2?orderTypes=1,2,3,4,5,100&pageNum=1&pageSize=100&states=0,1,3';

const hdrOf = new WeakMap(); // context → заголовки последнего запроса сайта к /api/ (без подписи и cookie)
const authOf = new WeakMap(); // context → заголовок authorization запроса check_risk страницы (только в памяти)
const attached = new WeakSet();

/**
 * authorization запроса check_risk страницы: значение — только в памяти; на диск — лишь ОТКУДА оно берётся (имя cookie
 * или заголовка), чтобы после перезапуска ArbiBrowser первый прямой вывод тоже шёл с check_risk.
 */
let authLogged = false;
async function learnAuth(context, auth) {
  authOf.set(context, auth);
  if (ourbitCaptcha.learned().authTpl) return;
  const src = { 'uc:ucenter-token': ourbitCaptcha.headersOf(context)['ucenter-token'] };
  for (const c of await context.cookies(ORIGIN).catch(() => [])) src[`cookie:${c.name}`] = c.value;
  const hit = Object.entries(src).find(([, v]) => v && v.length >= 16 && auth.includes(v));
  const tpl = hit ? auth.replace(hit[1], `{${hit[0]}}`) : '';
  if (hit && !/[A-Za-z0-9]{12,}/.test(tpl.replace(/\{[^}]+\}/, ''))) {
    ourbitCaptcha.learnedSet({ authTpl: tpl });
    console.log(`[ourbit-exec] заголовок authorization запроса check_risk разобран: «${tpl}»`);
  } else if (!authLogged) {
    authLogged = true;
    console.log(`[ourbit-exec] заголовок authorization запроса check_risk: источник не найден (длина ${auth.length}) — после перезапуска первый прямой вывод пойдёт без check_risk`);
  }
}
async function authFor(context) {
  const a = authOf.get(context);
  if (a) return a;
  const tpl = ourbitCaptcha.learned().authTpl;
  const m = tpl && tpl.match(/\{(uc|cookie):([^}]+)\}/);
  if (!m) return '';
  const v = m[1] === 'uc' ? ourbitCaptcha.headersOf(context)[m[2]] : ((await context.cookies(ORIGIN).catch(() => [])).find((c) => c.name === m[2]) || {}).value;
  return v ? tpl.replace(m[0], v) : '';
}

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('response', (resp) => {
    try {
      ourbitCaptcha.onResponse(page, resp);
    } catch { /* закрыта */ }
  });
  page.on('request', (req) => {
    try {
      ourbitCaptcha.onRequest(page, req);
      if (!req.url().startsWith(`${ORIGIN}/api/`) || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      const h = {};
      for (const [k, v] of Object.entries(req.headers() || {})) if (!SKIP_HDR.test(k)) h[k] = v;
      if (h['device-id']) rememberDevice(page, h['device-id'], h['luminex-uid']);
      delete h['device-id'];
      if (h.authorization) { if (/risk_material/.test(req.url())) learnAuth(page.context(), h.authorization).catch(() => {}); delete h.authorization; }
      if (h['luminex-uid']) hdrOf.set(page.context(), h);
      const raw = req.headers() || {};
      const sent = takeSent(page, req.url().slice(ORIGIN.length));
      if (raw['luminex-trace-id'] && !sent) noteTrace(page, raw['luminex-trace-id']);
      if (!sent && req.method() === 'POST' && raw['x-ourbit-sign'] && WD_STEP_RE.test(req.url())) notePostHdr(page.context(), raw);
      if (/\/withdraw\/submit_withdraw\//.test(req.url())) noteSubmit(page, req, sent).catch(() => {});
      if (req.method() === 'POST' && (req.headers() || {})['x-ourbit-sign']) ourbitSign.probe(page, req, (m) => console.log('[ourbit-exec] ' + m)).catch(() => {});
    } catch { /* страница закрыта */ }
  });
}

/** Следить за запросами сайта Ourbit во всех вкладках профиля (для заголовков). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

const toPair = (symbol) => String(symbol || 'BTC/USDT').toUpperCase().replace('/', '_');
const usable = (pg, context) => { try { return !!pg && !pg.isClosed() && pg.context() === context && pg.url().startsWith(ORIGIN); } catch { return false; } };

const opening = new WeakMap();
/** Живая вкладка Ourbit профиля; нет — одна новая на страницу пары (навигация не параллелится). */
async function ensurePage(context, symbol, log) {
  let pages = [];
  try { pages = context.pages(); } catch { pages = []; }
  // Вкладку вывода (OURBIT-WD) не берём: она перезагружается под каждый вывод — запрос оборвался бы.
  const pg = pages.find((p) => p.__arbiDuty === 'OURBIT' && usable(p, context)) || pages.find((p) => usable(p, context) && p.__arbiDuty !== 'OURBIT-WD');
  if (pg) return pg;
  if (opening.has(context)) return opening.get(context);
  const p = (async () => {
    const page = await context.newPage();
    page.__arbiDuty = 'OURBIT';
    onPage(page);
    const url = `${ORIGIN}/exchange/${toPair(symbol)}`;
    log(`открываю вкладку ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    return page;
  })();
  opening.set(context, p);
  try { return await p; } finally { opening.delete(context); }
}

async function headers(context, waitMs = 8000) {
  const t0 = Date.now();
  while (!hdrOf.get(context) && Date.now() - t0 < waitMs) await new Promise((r) => setTimeout(r, 200));
  return { ...(hdrOf.get(context) || {}) };
}

async function call(page, method, path, hdr, body, rel) {
  if (rel) markSent(page, path, hdr);
  return page.evaluate(async ({ url, method, hdr, body, rel }) => {
    try {
      // Предел 12 с: зависший запрос сайта держал намерение по 20 с (журнал 16.11).
      const init = { method, headers: hdr, body: body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)), credentials: 'include', signal: AbortSignal.timeout(12_000) };
      if (rel) init.cache = 'no-store';
      const res = await fetch(url, init);
      const txt = await res.text();
      let j = null;
      try { j = JSON.parse(txt); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, data: j ? j.data : null, time: j ? j.time : undefined, success: j ? j.success : undefined, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: rel ? path : ORIGIN + path, method, hdr, body, rel: !!rel }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
}

/*
 * ЗАПРОС ВЫВОДА «КАК У СТРАНИЦЫ» (16.11, журналы 0.4.346–0.4.347). Опыт дважды показал: сайт отклоняет (60008) наш
 * submit_withdraw и тут же принимает такой же запрос страницы на ТУ ЖЕ подготовку — при тех же именах заголовков, теле
 * и формуле подписи. Пауза, check_risk, время сервера в подписи (страница подписывает часами компьютера) — не причина.
 * Остаются значения заголовков и способ отправки, поэтому запросы вывода собираются точно как у страницы:
 *   · адрес без домена (rel) — запрос проходит те же перехватчики страницы (sentry добавляет baggage / sentry-trace);
 *   · набор и значения заголовков — из последнего подписанного запроса САМОЙ страницы (postHdrOf: accept и прочие);
 *   · luminex-trace-id — продолжение ряда страницы: общая часть двух её последних id сохраняется, меняется хвост;
 *   · перед подтверждением — свой ping, как у страницы.
 * И сверка: наш submit и submit страницы сравниваются по заголовкам (значения — только у несекретных, у остальных
 * 4 знака хэша и длина) — в журнале видно, чем они отличаются.
 */
// Наши запросы вывода среди запросов вкладки: пометка «сейчас уйдёт запрос на этот путь» (журнал 0.4.348: страница
// переписывает luminex-trace-id нашего запроса — по нему свой запрос не узнать, сверка не напечаталась).
const sentOf = new WeakMap(); // page → [{ path, hdr, at }]
function markSent(page, path, hdr) {
  const list = (sentOf.get(page) || []).filter((x) => Date.now() - x.at < 5000);
  list.push({ path, hdr, at: Date.now() });
  sentOf.set(page, list);
}
/** Заголовки, с которыми МЫ отправили запрос на этот путь (пометка снимается), либо null — запрос страницы. */
function takeSent(page, path) {
  const list = sentOf.get(page) || [];
  const i = list.findIndex((x) => x.path === path && Date.now() - x.at < 5000);
  return i < 0 ? null : list.splice(i, 1)[0].hdr;
}
const WD_STEP_RE = /\/withdraw\/(match_chain|check_chain|save_withdraw|submit_withdraw)\b|withdraw_check_address/; // шаги вывода страницы
const traceOf = new WeakMap(); // page → [предпоследний, последний] trace-id страницы
const bumpOf = new WeakMap(); // page → сколько своих id выдали по счётчику страницы
const postHdrOf = new WeakMap(); // context → заголовки подписанного запроса страницы (без секретов и разовых)
const POST_SKIP = /^(cookie|host|content-length|user-agent|origin|referer|accept-encoding|accept-language|connection|priority|cache-control|sec-|:|x-ourbit-(sign|nonce)$|device-id$|authorization$|baggage$|sentry-trace$|luminex-trace-id$|luminex-uid$)/i;
const HDR_PLAIN = ['accept', 'content-type', 'pragma', 'language']; // несекретное — можно в файл

const shapeOfId = (v) => String(v).replace(/[0-9]/g, '9').replace(/[a-f]/g, 'h').replace(/[g-z]/g, 'a').replace(/[A-F]/g, 'H').replace(/[G-Z]/g, 'A');
let traceShapeLogged = false;
function noteTrace(page, id) {
  const cur = traceOf.get(page) || [];
  if (cur[1] === id) return;
  traceOf.set(page, [cur[1], id]);
  if (traceShapeLogged || !cur[1]) return;
  traceShapeLogged = true;
  let n = 0; while (n < id.length && n < cur[1].length && id[n] === cur[1][n]) n += 1;
  console.log(`[ourbit-exec] trace-id страницы: вид «${shapeOfId(id)}», у двух запросов подряд совпадают первые ${n} из ${id.length} знаков`);
}
function notePostHdr(context, raw) {
  // Только JSON-запросы шагов вывода: при загрузке страница шлёт подписанные запросы с другим content-type — с ним
  // наша проверка получала «Invalid Content-Type» (журнал 0.4.348: отказ каждого второго вывода).
  if (!/^application\/json/i.test(String(raw['content-type'] || ''))) return;
  const h = {};
  for (const [k, v] of Object.entries(raw)) if (!POST_SKIP.test(k)) h[k] = v;
  postHdrOf.set(context, h);
  const plain = {};
  for (const k of HDR_PLAIN) if (h[k]) plain[k] = h[k];
  if (JSON.stringify(plain) !== JSON.stringify(ourbitCaptcha.learned().pageHdr || {})) ourbitCaptcha.learnedSet({ pageHdr: plain });
}
/** Следующий trace-id в ряду страницы: её сеанс (общая часть) + счётчик дальше; ряда не видно — случайный того же вида. */
function nextTrace(page, fallback) {
  const [a, b] = traceOf.get(page) || [];
  const src = b || fallback || '';
  const m = a && b && b.match(/^(.*?)(\d{1,6})$/);
  if (m && a.startsWith(m[1])) {
    const k = (bumpOf.get(page) || 0) + 1;
    bumpOf.set(page, k);
    return m[1] + String((Number(m[2]) + 100 + k) % 10 ** m[2].length).padStart(m[2].length, '0');
  }
  let n = 0;
  if (a && b) while (n < a.length && n < b.length && a[n] === b[n]) n += 1;
  return src.slice(0, n) + freshTrace(src.slice(n));
}

/** Сверка подтверждений: отпечаток запроса — значения несекретных заголовков, у остальных 4 знака хэша и длина. */
const FP_PLAIN = /^(accept|accept-language|accept-encoding|content-type|cache-control|pragma|priority|language|origin|sec-fetch-(site|mode|dest)|:method|:path|:scheme|:authority)$/;
const FP_VOLATILE = /^(x-ourbit-sign|x-ourbit-nonce|luminex-trace-id|sentry-trace|baggage)$/; // у каждого запроса свои
const tagOf = (v) => `#${crypto.createHash('md5').update(String(v)).digest('hex').slice(0, 4)}/${String(v).length}`;
async function fpOf(req) {
  const out = {};
  for (const [k, v] of Object.entries(await req.allHeaders())) {
    if (k === 'cookie') { for (const c of String(v).split(/;\s*/)) { const i = c.indexOf('='); if (i > 0) out[`cookie «${c.slice(0, i)}»`] = tagOf(c.slice(i + 1)); } continue; }
    if (k === 'referer') { try { out[k] = new URL(v).pathname; } catch { out[k] = tagOf(v); } continue; }
    out[k] = FP_PLAIN.test(k) ? String(v) : FP_VOLATILE.test(k) ? 'есть' : tagOf(v);
  }
  out['тело'] = tagOf(req.postData() || '');
  return out;
}
function fpDiff(mine, page) {
  const d = [];
  for (const k of new Set([...Object.keys(mine), ...Object.keys(page)])) {
    if (mine[k] === page[k]) continue;
    d.push(mine[k] == null ? `нет у нас: ${k} (у страницы ${page[k]})` : page[k] == null ? `лишнее у нас: ${k} (${mine[k]})` : `${k}: у нас ${mine[k]}, у страницы ${page[k]}`);
  }
  return d.length ? d.slice(0, 30).join('; ') : 'отличий нет (кроме подписи, метки времени и trace-id — они у каждого запроса свои)';
}
const lastSubmit = new WeakMap(); // context → { mine, page, reported }
async function noteSubmit(page, req, sent) {
  const ctx = page.context();
  const wire = await req.allHeaders();
  const fp = await fpOf(req);
  const st = lastSubmit.get(ctx) || {};
  st[sent ? 'mine' : 'page'] = { fp, at: Date.now() };
  lastSubmit.set(ctx, st);
  if (sent) {
    // Что перехватчик страницы сделал с нашим запросом по дороге (только имена заголовков).
    const changed = Object.keys(sent).filter((k) => wire[k] != null && wire[k] !== sent[k]);
    const dropped = Object.keys(sent).filter((k) => wire[k] == null);
    console.log(`[ourbit-exec] вывод: СВЕРКА — страница в нашем подтверждении ${changed.length || dropped.length ? `изменила: [${changed.join(', ')}]${dropped.length ? `, убрала: [${dropped.join(', ')}]` : ''}` : 'ничего не изменила'}`);
  } else {
    const same = await ourbitSign.matches(page, req).catch(() => null);
    if (same != null) console.log(`[ourbit-exec] вывод: СВЕРКА — подпись страницы на подтверждении ${same ? 'сходится' : 'НЕ СХОДИТСЯ'} с нашей формулой и ключом`);
  }
  if (st.mine && st.page && Math.abs(st.mine.at - st.page.at) < 60_000 && st.reported !== st.mine.at) {
    st.reported = st.mine.at;
    console.log(`[ourbit-exec] вывод: СВЕРКА подтверждений (наше ↔ страницы): ${fpDiff(st.mine.fp, st.page.fp)}`);
  }
}

/** Свой ping из вкладки — страница шлёт его перед каждым подписанным запросом. */
async function ping(c) {
  const h = stepHdr(c);
  delete h['content-type']; delete h.language; // у ping страницы их нет
  return call(c.page, 'GET', '/api/common/ping', h, null, true);
}

/** POST с подписью сайта (ourbit-sign.js): тело сериализуется ОДИН раз — подписывается ровно оно. rel — адрес без домена. */
async function signedPost(page, path, hdr, body, rel) {
  const str = JSON.stringify(body);
  return call(page, 'POST', path, { ...hdr, ...(await ourbitSign.signFor(page, str)) }, str, rel);
}
/**
 * POST формой (application/x-www-form-urlencoded), подпись — по строке формы. Так страница шлёт ПОДТВЕРЖДЕНИЕ вывода
 * (сверка 17.11: у страницы content-type формы и тело 63 знака, у нас был JSON 73 знака — отсюда 60008 «неверный
 * код» с первой версии прямого вывода: сайт не находил requestId в теле). Остальные шаги вывода страница шлёт JSON.
 */
async function signedForm(page, path, hdr, params) {
  const str = new URLSearchParams(params).toString();
  return call(page, 'POST', path, { ...hdr, 'content-type': 'application/x-www-form-urlencoded', ...(await ourbitSign.signFor(page, str)) }, str, true);
}

const ok = (r) => !!r && r.status === 200 && (r.code === 200 || r.code === 0);
const noLogin = (r) => !!r && (r.status === 401 || r.code === 401 || /log ?in|登录|未登录|session/i.test(String(r.msg || '')));
const fail = (what, r) => (noLogin(r)
  ? { ok: false, loginRequired: true, error: `Ourbit: нет входа в аккаунт в ArbiBrowser — ${what} не выполнено. Войдите в окне профиля.` }
  : { ok: false, error: `Ourbit: ${what} — отказ сайта (HTTP ${r && r.status != null ? r.status : '-'} code=${r && r.code != null ? r.code : '-'} «${(r && (r.msg || r.error)) || ''}»)` });

/** Проверка, которую обязан пройти каждый боевой ордер: монета подтверждена терминалом. null — можно. */
function coinGate(intent) {
  const base = String(intent.symbol || '').split('/')[0].toUpperCase();
  const g = intent.hints && intent.hints.ourbit;
  if (!g || String(g.ticker || '').toUpperCase() !== base) return 'терминал не подтвердил монету';
  if (g.manual === true) return null;
  if (!Array.isArray(g.verified) || !g.verified.length) return 'монета не сверена по контракту';
  const lag = Number(intent.createdAt) - Number(g.at);
  if (!(Number(g.at) > 0) || !(lag >= -60_000 && lag <= VERIFY_MAX_MS)) return 'сверка по контракту устарела';
  return null;
}

let loggedKeys = false;
const rowId = (x) => String((x && (x.id != null ? x.id : x.orderId)) || '');
const rowCoin = (x) => String((x && (x.currency || String(x.symbol || '').split(/[_/]/)[0])) || '').toUpperCase();

async function openRows(page, hdr) {
  const r = await call(page, 'GET', OPEN_PATH, hdr);
  if (!ok(r)) return { r };
  const rows = Array.isArray(r.data && r.data.resultList) ? r.data.resultList : [];
  return { rows };
}

async function cancel(page, hdr, orderId) {
  return call(page, 'DELETE', `/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(orderId)}`, hdr);
}

async function placeOrder(context, intent, log) {
  const why = coinGate(intent);
  if (why) return { ok: false, error: `Ourbit: ${why} — заявка не отправлена` };
  if (intent.type !== 'limit') return { ok: false, error: 'Ourbit: через сайт — только лимитные заявки (рыночная = агрессивная лимитка терминала)' };
  const [base, quote = 'USDT'] = String(intent.symbol).toUpperCase().split('/');
  const price = formatDecimal(intent.price);
  const quantity = formatDecimal(intent.quantity);
  if (!isPlainPositive(price) || !isPlainPositive(quantity)) return { ok: false, error: `Ourbit: цена/объём не числа (${intent.price} / ${intent.quantity})` };
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = { ...(await headers(context)), 'content-type': 'application/json' };
  const body = { currency: base, market: quote, tradeType: intent.side === 'sell' ? 'SELL' : 'BUY', price, quantity, orderType: 'LIMIT_ORDER' };
  const t0 = Date.now();
  const r = await call(page, 'POST', '/api/platform/spot/order/place', hdr, body);
  const ms = Date.now() - t0;
  if (r.error || (r.status >= 500)) return { ok: false, error: `Ourbit: ответа на заявку нет (${r.error || `HTTP ${r.status}`}) — заявка МОГЛА встать, проверьте открытые ордера` };
  const orderId = ok(r) && typeof r.data === 'string' && r.data ? r.data : null;
  if (!orderId) return fail(`заявка ${base}/${quote}`, r);
  log(`Ордер выставлен: ${orderId} — ${intent.side} ${quantity} ${base} @ ${price}, ответ ${ms} мс${intent.hints.ourbit.manual ? ' (ручная, без сверки контракта)' : ''}`);
  // Встала та же монета? Не нашли строку (уже исполнилась) — тело заявки и так несло подтверждённый тикер.
  const { rows } = await openRows(page, { ...hdr });
  const row = (rows || []).find((x) => rowId(x) === orderId);
  if (row && !loggedKeys) { loggedKeys = true; log(`поля открытого ордера сайта: ${Object.keys(row).join(',')}`); }
  const coin = row ? rowCoin(row) : '';
  if (coin && coin !== base) {
    const c = await cancel(page, hdr, orderId);
    return { ok: false, error: `Ourbit поставил заявку по ${coin} вместо ${base} — ${ok(c) ? 'заявка отменена' : `⚠ ОТМЕНИТЬ НЕ УДАЛОСЬ, снимите заявку ${orderId} руками`}` };
  }
  return { ok: true, orderId, direct: true };
}

// Сеть сайта (chainName «Solana(SOL)», walletType «SOL») → канон терминала (как canonChain в CEX exchange/ourbit.ts).
function canonChain(raw) {
  const s = String(raw || '').toLowerCase();
  if (s.includes('bep20') || s === 'bsc' || s === 'bnb' || s.includes('bnb smart')) return 'BSC';
  if (s.includes('erc20') || s === 'eth' || s === 'ethereum') return 'ETH';
  if (s.includes('trc20') || s === 'tron' || s === 'trx') return 'TRX';
  if (s === 'sol' || s.startsWith('solana')) return 'SOL';
  if (s === 'base' || s.startsWith('base(') || s.startsWith('base ')) return 'BASE';
  if (s.startsWith('arbitrum') || s === 'arb') return 'ARBITRUM';
  if (s.startsWith('polygon') || s === 'matic') return 'POLYGON';
  return String(raw || '').toUpperCase();
}

/**
 * Сеть монеты по справочнику сайта (`spot/currency/v3`, как страницы депозита и вывода). У сети своя «монета сайта»
 * (`currency`: USDT-BNB, USDT-ETH; USDT = TRC20), и адрес депозита выдаётся ПО НЕЙ (запись 16.11) — запрос с общим
 * «USDT» и сетью BSC давал адрес TRON. Ровно одна сеть под запрошенную, иначе отказ.
 */
const chainsMemo = new Map(); // монета → { at, r } — справочник сетей монеты (для вывода: до 5 мин, решает всё равно сайт)
async function chainOf(page, hdr, coin, chain, maxAgeMs = 0) {
  const hit = chainsMemo.get(coin);
  const r = hit && Date.now() - hit.at < maxAgeMs ? hit.r
    : await call(page, 'GET', `/api/platform/asset/api/asset/spot/currency/v3?currency=${encodeURIComponent(coin)}`, hdr);
  if (!ok(r) || !r.data || !Array.isArray(r.data.chains)) return { r };
  if (!hit || hit.r !== r) chainsMemo.set(coin, { at: Date.now(), r });
  const want = canonChain(chain);
  const hits = r.data.chains.filter((n) => canonChain(n.walletType) === want || canonChain(n.chainName) === want);
  if (hits.length !== 1) return { why: `у ${coin} на Ourbit ${hits.length ? 'несколько сетей' : 'нет сети'} ${chain} (есть: ${r.data.chains.map((n) => n.chainName).join(', ') || '—'})` };
  return { c: hits[0], available: r.data.available };
}

const fmtOf = (a) => (/^0x[0-9a-fA-F]{40}$/.test(a) ? 'EVM' : /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a) ? 'TRON' : /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a) ? 'base58' : 'другой');

const deviceOf = new WeakMap(); // context → заголовок device-id сайта (его шлёт только подтверждение вывода)

/*
 * device-id сайта (16.11): без него подтверждение быстрого вывода отвечает 60008 «неверный код» — сайт шлёт его только
 * в submit_withdraw. Запоминаем на диске по аккаунту Ourbit (luminex-uid) — переживает перезапуск ArbiBrowser, и один
 * раз ищем, где страница его хранит (в журнал — только ИМЯ ключа хранилища, не значение).
 */
const DEV_FILE = () => path.join(config.reportsDir, 'ourbit-device.json');
function devStore() { try { return JSON.parse(fs.readFileSync(DEV_FILE(), 'utf8')) || {}; } catch { return {}; } }
const devLogged = new Set();
function rememberDevice(page, dev, uid) {
  deviceOf.set(page.context(), dev);
  if (!uid) return;
  const st = devStore();
  if (st[uid] !== dev) {
    st[uid] = dev;
    try { fs.mkdirSync(path.dirname(DEV_FILE()), { recursive: true }); fs.writeFileSync(DEV_FILE(), JSON.stringify(st)); } catch { /* не записали — живёт до перезапуска */ }
  }
  if (devLogged.has(uid)) return;
  devLogged.add(uid);
  page.evaluate((v) => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (String(localStorage.getItem(k) || '').includes(v)) out.push(`localStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); if (String(sessionStorage.getItem(k) || '').includes(v)) out.push(`sessionStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (const c of document.cookie.split(';')) { const [k, ...r] = c.split('='); if (r.join('=').includes(v)) out.push(`cookie «${k.trim()}»`); } } catch { /* нет доступа */ }
    return out;
  }, dev).then((where) => console.log(`[ourbit-exec] device-id сайта запомнен (${dev.length} симв.); на странице — ${where.length ? where.join(', ') : 'не найден в хранилищах'}`))
    .catch(() => {});
}

/**
 * БЫСТРЫЙ ВЫВОД: сеть и check_chain/v3 — запросом (сайт сам говорит isQuickWithdraw: адрес в белом списке Ourbit,
 * сумма в лимите; иначе он попросит коды почты/Google — вывод не начинаем), дальше — форма сайта (ourbit-withdraw-page).
 */
const WD = '/api/platform/asset/api/withdraw';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const codeOf = (r) => (r ? (r.code ?? r.error ?? r.status ?? '-') : '-');

/**
 * Свежий luminex-trace-id того же вида, что у страницы: страница ставит новый на каждый запрос, а мы до 0.4.345
 * повторяли один перехваченный на всех шагах вывода (и на опросах) — для сайта это повтор уже виденного запроса.
 * Цифры → случайные цифры, буквы a–f → случайные a–f, прочие буквы → случайные буквы, 13 цифр времени → текущее.
 */
function freshTrace(v) {
  const now = String(Date.now());
  const rnd = (abc) => abc[Math.floor(Math.random() * abc.length)];
  return String(v || '').split(/(\d{13})/).map((part) => (/^\d{13}$/.test(part) && part.slice(0, 3) === now.slice(0, 3) ? now
    : part.replace(/[0-9]/g, () => rnd('0123456789')).replace(/[a-f]/g, () => rnd('abcdef')).replace(/[g-z]/g, () => rnd('ghijklmnopqrstuvwxyz'))
      .replace(/[A-F]/g, () => rnd('ABCDEF')).replace(/[G-Z]/g, () => rnd('GHIJKLMNOPQRSTUVWXYZ')))).join('');
}
/** Заголовки одного запроса вывода: как у подписанного запроса самой страницы + trace-id в её ряду. */
function stepHdr(c, extra) {
  const h = { ...c.hdr, ...(postHdrOf.get(c.context) || ourbitCaptcha.learned().pageHdr || {}), ...extra };
  delete h.baggage; delete h['sentry-trace']; // их добавит перехватчик страницы
  delete h.pragma; delete h['cache-control']; // pragma дописывает перехватчик страницы, cache-control — браузер (сверка 17.11: у нас выходило задвоение)
  h['luminex-trace-id'] = nextTrace(c.page, h['luminex-trace-id']);
  if (!h['luminex-trace-id']) delete h['luminex-trace-id'];
  return h;
}

async function withdraw(page, context, hdr0, s, log) {
  const coin = String(s.coin || '').toUpperCase();
  const address = String(s.address || '').trim();
  const amount = formatDecimal(s.amount);
  if (!address || !isPlainPositive(amount)) return { ok: false, error: 'Ourbit: вывод без адреса или суммы' };
  const n = await chainOf(page, hdr0, coin, s.chain, 5 * 60_000);
  if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
  if (!n.c) return fail('справочник сетей', n.r);
  if (n.c.enableWithdraw === false) return { ok: false, error: `Ourbit: вывод ${coin} в сети ${n.c.chainName} закрыт` };
  const chainName = String(n.c.chainName);
  const uh = ourbitCaptcha.headersOf(context);
  const hdr = { ...hdr0, 'content-type': 'application/json' };
  if (!hdr.language && uh.language) hdr.language = uh.language; // страница шлёт language на каждом шаге вывода
  const want = { coin, chainName, address, amount };
  const ctx = { page, context, hdr, uh, want, log };
  // Прямому выводу на уровне «с капчей» нужна свежая капча вкладки вывода: нет — открыть или обновить вкладку и
  // дождаться (≈4–6 с) — это всё равно быстрее формы.
  if ((ourbitCaptcha.learned().level || 0) >= 1 && ourbitCaptcha.known() && !ourbitCaptcha.hasFresh(context)) {
    const t = Date.now();
    const got = await ensureCaptcha(context, coin, 12_000);
    log(`вывод: свежей капчи не было — ${got ? `получена за ${Date.now() - t} мс` : 'не получена за 12 с'}`);
  }
  const d = await withdrawDirect(ctx);
  if (d && !d.form) {
    if (d.usedCaptcha) prewarmForm(context, coin, true).catch(() => {}); // капча израсходована — сразу новая, к следующему выводу
    return d;
  }
  // Запасной путь — ФОРМА сайта: капчу проходит сама страница, сверка суммы/адреса/сети — по её запросу (16.11).
  // Проверка сайта «без кодов?» идёт одновременно с заполнением формы — ответ нужен только перед «Отправить».
  const ccP = d && d.cc ? Promise.resolve(d.cc) : checkChain(ctx);
  return withdrawViaForm(context, want, log, {
    gate: async () => {
      const cc = await ccP;
      // Не ответ сайта по существу (сеть, «Invalid Content-Type») — не повод отменять вывод: страница проверит сама.
      if (!ok(cc) && !noLogin(cc) && (cc.error || cc.status !== 200 || cc.code === 400)) { log(`вывод: своя проверка не ответила (code=${codeOf(cc)} «${cc.msg || ''}») — проверит страница`); return null; }
      return quickRefusal(cc, want);
    },
  });
}

const checkChain = (c) => signedPost(c.page, `${WD}/check_chain/v3`, stepHdr(c), { amount: c.want.amount, address: c.want.address, chainName: c.want.chainName, currency: c.want.coin }, true);
/** Запрос страницы перед проверкой и перед подтверждением; у него свой заголовок authorization (в памяти). Нет его — не шлём. */
const checkRisk = async (c) => {
  const a = await authFor(c.context);
  if (!a) return null;
  const h = stepHdr(c, { authorization: a });
  delete h['content-type']; // у страницы его здесь нет
  return call(c.page, 'GET', '/api/customer/risk_material/check_risk', h, null, true);
};
const saveReq = (c) => signedPost(c.page, `${WD}/save_withdraw/v4`, stepHdr(c), {
  amount: c.want.amount, address: c.want.address, chain: c.want.chainName, currency: c.want.coin, isQuickWithdraw: true,
  drawImageRequest: { backGroundColor: { colorR: 248, colorG: 248, colorB: 249 }, fontColor: { colorR: 27, colorG: 28, colorB: 29 }, fontSize: 28, width: 616, alignRight: true },
}, true);
/** Подтверждение — формой, с device-id страницы (его шлёт только этот шаг). */
const submitReq = (c, dev, requestId) => signedForm(c.page, `${WD}/submit_withdraw/v3`, stepHdr(c, { 'device-id': dev }), { isQuickWithdraw: 'true', requestId: String(requestId) });
/** Отказ по проверке сайта (нет ответа / просит коды) либо null — вывод без кодов возможен. */
function quickRefusal(cc, want) {
  if (!ok(cc) || !cc.data) return fail(`проверка вывода ${want.coin} ${want.chainName}`, cc);
  if (cc.data.isQuickWithdraw !== true) {
    return { ok: false, error: 'Ourbit просит коды почты/Google для этого вывода (сумма больше лимита быстрого вывода или адрес не в белом списке Ourbit) — сделайте вывод на сайте' };
  }
  return null;
}

const GAP_MS = 1200; // пауза страницы между подготовкой и подтверждением (журнал 16.11: ≥1,1 с)
/**
 * Что сайту нужно перед подтверждением сверх подготовки — по нарастающей. learned.level — наименьший уровень, на
 * котором подтверждение прошло; с него начинается следующий вывод.
 */
const LEVELS = ['без капчи', 'с капчей', 'с капчей, check_risk и ping', 'как страница: ещё и пауза 1,2 с'];

/**
 * ПРЯМОЙ ВЫВОД (оператор 16.11: «меньше секунды»). Запросы страницы вывода без формы, из вкладки сайта, адрес без
 * домена (как у страницы): check_chain и save_withdraw (JSON) → submit_withdraw (ФОРМА, device-id страницы).
 * До 0.4.349 подтверждение уходило JSON и получало 60008; всё, что добавлялось по дороге (капча robot, check_risk,
 * ping, пауза), проверялось с негодным телом — что из этого сайту действительно нужно, неизвестно. Поэтому уровни:
 * вывод начинает с известного уровня (сначала 0 — только проверка и подготовка); отказ 60008 — определённое «нет»,
 * подготовку он не сжигает (журнал 0.4.346) — добавляем следующий шаг и подтверждаем ТУ ЖЕ подготовку ещё раз.
 * Уровень, на котором прошло, запоминается. Отказ на всех уровнях → вывод формой.
 * Возврат: итог (+ usedCaptcha) | { form: true, cc }. Подтверждение без ответа — «мог пройти», ничего не повторяем.
 */
async function withdrawDirect(c) {
  const { context, hdr, uh, want, log } = c;
  const dev = deviceOf.get(context) || devStore()[hdr['luminex-uid']] || '';
  if (!dev) { log('вывод: device-id подтверждения ещё не известен — этот вывод формой (он его запомнит)'); return { form: true }; }
  const st = ourbitCaptcha.learned();
  if ((st.directFails || 0) >= 2) { log('вывод: прямой вывод отказан на всех уровнях дважды — до следующей версии выводы формой'); return { form: true }; }
  const start = Math.min(st.level || 0, LEVELS.length - 1);
  const d = { ...c, page: wdTab(context) || c.page }; // вкладка вывода, нет её — вкладка торгов
  const t0 = Date.now();
  let usedCaptcha = false;
  // Шаг капчи: решённая вкладкой вывода капча → robot.assets.withdraw. false — капчи нет или сайт её не принял.
  const robot = async () => {
    const cap = ourbitCaptcha.known() && uh['ucenter-token'] ? ourbitCaptcha.take(context) : null;
    if (!cap) { log('вывод: шаг капчи пропущен — нет свежей капчи вкладки вывода'); return false; }
    usedCaptcha = true;
    const rb = await call(cap.page, 'GET', ourbitCaptcha.ROBOT_PATH, stepHdr({ ...c, page: cap.page }, { ...uh, 'captcha-token': cap.token }), null, true);
    const good = ok(rb) && rb.success !== false && rb.data == null; // данные в ответе = сайт просит показать капчу
    if (!good) log(`вывод: капча не принята (code=${codeOf(rb)}, success=${rb.success}, данные ${rb.data == null ? 'нет' : 'есть'})`);
    return good;
  };
  setBusy(true);
  try {
    // Всё, что нужно на стартовом уровне, — одновременно с подготовкой.
    const ccP = checkChain(d);
    const rbP = start >= 1 ? robot() : null;
    const sv = await saveReq(d);
    const [cc] = await Promise.all([ccP, rbP]);
    const tSave = Date.now() - t0;
    const refusal = quickRefusal(cc, want);
    if (refusal) return refusal;
    if (!ok(sv) || !sv.data || !sv.data.requestId) { log(`вывод: подготовка отказана (code=${codeOf(sv)} «${sv.msg || ''}») — формой`); return { form: true, cc, usedCaptcha }; }
    const savedAt = Date.now();
    const pre = async (lvl) => { // шаги уровня lvl перед подтверждением (капча уровня 1 при старте уже ушла вместе с подготовкой)
      if (lvl >= 3) await sleep(Math.max(0, GAP_MS - (Date.now() - savedAt)));
      if (lvl >= 2) { await checkRisk(d); await ping(d); }
    };
    await pre(start);
    let level = start;
    const tried = [];
    for (;;) {
      const sb = await submitReq(d, dev, sv.data.requestId);
      if (sb.error || sb.status == null) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true, usedCaptcha };
      if (ok(sb)) {
        if (sb.data && sb.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit', usedCaptcha };
        if (level !== st.level || st.directFails) ourbitCaptcha.learnedSet({ level, directFails: 0 });
        log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён прямым запросом (${LEVELS[level]}${tried.length ? `; отказано: ${tried.join(', ')}` : ''}): подготовка ${tSave} мс, всего ${Date.now() - t0} мс`);
        return { ok: true, withdrawId: String((sb.data && sb.data.withdrawId) || ''), usedCaptcha };
      }
      if (sb.code !== 60008) return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.code} «${sb.msg || ''}»)`, usedCaptcha };
      tried.push(LEVELS[level]);
      level += 1;
      if (level >= LEVELS.length) break;
      if (level === 1) await robot(); else await pre(level);
    }
    ourbitCaptcha.learnedSet({ directFails: (st.directFails || 0) + 1 });
    log(`вывод: подтверждение отказано 60008 на всех уровнях (${tried.join(', ')}; ${Date.now() - t0} мс) — формой`);
    return { form: true, cc, usedCaptcha };
  } finally { setBusy(false); }
}

async function siteCall(context, intent, log) {
  const t0 = Date.now();
  const r = await siteCallInner(context, intent, log);
  const ms = Date.now() - t0;
  if (ms > 3000) log(`запрос сайта ${intent.site && intent.site.op} шёл ${ms} мс${r && r.error ? ` (ошибка: ${String(r.error).slice(0, 80)})` : ''}`);
  return r;
}

async function siteCallInner(context, intent, log) {
  const s = intent.site || {};
  const t0 = Date.now();
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = await headers(context);
  if (Date.now() - t0 > 3000) log(`вкладка/заголовки сайта готовы за ${Date.now() - t0} мс`);
  if (s.op === 'cancel') {
    if (!s.orderId) return { ok: false, error: 'Ourbit: отмена без номера заявки' };
    const r = await cancel(page, hdr, s.orderId);
    return ok(r) ? { ok: true, canceled: s.orderId } : fail(`отмена ${s.orderId}`, r);
  }
  if (s.op === 'open') {
    const { rows, r } = await openRows(page, hdr);
    return rows ? { ok: true, rows } : fail('открытые ордера', r);
  }
  if (s.op === 'depositAddress') {
    const coin = String(s.coin || '').toUpperCase();
    const n = await chainOf(page, hdr, coin, s.chain);
    if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
    if (!n.c) return fail('справочник сетей', n.r);
    if (n.c.supportMemo === true) return { ok: false, error: `Ourbit: сеть ${n.c.chainName} с memo — адрес с сайта не выдаю, возьмите адрес и memo на сайте` };
    const vcoin = String(n.c.currency || coin);
    let address = String(n.c.address || '');
    if (!address) {
      const r = await call(page, 'POST', '/api/platform/deposit/address/create', { ...hdr, 'content-type': 'application/json' }, { currency: vcoin, chainName: n.c.chainName });
      if (!ok(r) || !r.data || !r.data.address) return fail(`адрес депозита ${vcoin} ${n.c.chainName}`, r);
      // Перепроверка: тот же адрес сайт показывает у ЭТОЙ сети монеты.
      const again = await chainOf(page, hdr, coin, s.chain);
      if (!again.c || String(again.c.address || '') !== String(r.data.address)) {
        return { ok: false, error: `Ourbit: выданный адрес ${vcoin} не совпал с адресом сети ${n.c.chainName} в списке сайта — адрес не показан` };
      }
      address = String(r.data.address);
    }
    log(`адрес депозита ${coin}: просили ${s.chain} → сеть сайта «${n.c.chainName}» (${vcoin}), адрес формата ${fmtOf(address)}`);
    return { ok: true, address, vcoin, chainName: n.c.chainName, enableDeposit: n.c.enableDeposit !== false };
  }
  if (s.op === 'withdraws') {
    prewarmForm(context).catch(() => {}); // панель вывода открыта в терминале — форма вывода ждёт заранее
    const r = await call(page, 'GET', '/api/platform/withdraw/latest', hdr);
    if (!ok(r)) return fail('история выводов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      id: String(x.id || ''), coin: String(x.vcoinName || '').toUpperCase(), chain: canonChain(x.walletType), address: String(x.address || ''),
      amount: String(x.amount || '0'), fee: x.fee != null ? String(x.fee) : undefined, txHash: String(x.txid || ''),
      state: String(x.state || ''), time: Number(x.createTime) || 0, updated: Number(x.updateTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'wdConfig') {
    const r = await call(page, 'GET', '/api/platform/asset/api/withdraw/query/config/v3', hdr);
    if (!ok(r) || !r.data) return fail('настройки вывода', r);
    return { ok: true, quick: r.data.quickWithdrawEnabled === true, perWithdraw: Number(r.data.perWithdrawAmount) || 0, whiteList: r.data.whiteListEnabled === true };
  }
  if (s.op === 'withdraw') return withdraw(page, context, hdr, s, log);
  if (s.op === 'deposits') {
    const r = await call(page, 'GET', '/api/platform/asset/api/deposit/v2/latest', hdr);
    if (!ok(r)) return fail('история депозитов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      coin: String(x.vcoinName || x.currency || '').toUpperCase(), chain: canonChain(x.walletType || x.chainName),
      amount: String(x.amount || '0'), txHash: String(x.transactionHash || String(x.txid || '').split(':')[0] || ''),
      confirmations: Number(x.confirmations) || 0, required: Number(x.requireConfirmations) || 0,
      state: String(x.state || ''), time: Number(x.receiptTime || x.createTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'balances') {
    // Список монет спота — из сводки, точные «доступно / в заявках» — запросом по этим монетам.
    const o = await call(page, 'GET', '/api/platform/asset/api/asset/overview/convert/v2', hdr);
    if (!ok(o)) return fail('балансы', o);
    const coins = (Array.isArray(o.data) ? o.data : []).filter((x) => Number(x && x.spot) > 0).map((x) => String(x.currency || '').toUpperCase()).filter(Boolean);
    if (!coins.includes('USDT')) coins.push('USDT');
    const b = await call(page, 'GET', `/api/platform/spot/asset/currency/balances?currency=${coins.map(encodeURIComponent).join(',')}`, hdr);
    if (!ok(b)) return fail('балансы', b);
    const rows = (Array.isArray(b.data) ? b.data : []).map((x) => ({ currency: String(x.currency || '').toUpperCase(), available: String(x.available || '0'), frozen: String(x.frozen || '0') }));
    return { ok: true, rows };
  }
  return { ok: false, error: `Ourbit: неизвестный запрос сайта ${s.op}` };
}

async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  attach(context);
  if (intent.site) return siteCall(context, intent, log);
  if (intent.warmup) { await ensurePage(context, intent.symbol, log); return { ok: true, warmed: true }; }
  if (intent.loginCheck || intent.closeStale || intent.balance || intent.orders || intent.cancelAll) {
    return intent.loginCheck || intent.closeStale ? { ok: true, skipped: true } : { ok: false, error: 'Ourbit: этот вид намерения не поддержан (балансы/ордера — запросом сайта)' };
  }
  return placeOrder(context, intent, log);
}

module.exports = { attach, executeIntent, toPair, _coinGate: coinGate, _rowCoin: rowCoin, _canonChain: canonChain, _withdrawDirect: withdrawDirect, _deviceOf: deviceOf, _freshTrace: freshTrace, _authOf: authOf, _nextTrace: nextTrace, _traceOf: traceOf, _fpDiff: fpDiff, _notePostHdr: notePostHdr, _stepHdr: stepHdr, _markSent: markSent, _takeSent: takeSent };

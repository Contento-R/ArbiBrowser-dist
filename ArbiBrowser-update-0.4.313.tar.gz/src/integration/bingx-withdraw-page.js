'use strict';

/**
 * bingx-withdraw-page.js — ОТМЕНА ВЫВОДА НА САЙТЕ BingX (оператор 2026-10-18: у BingX
 * нет API отмены вывода, терминал отвечал «отменить по API нельзя»).
 *
 * Открываем фоновую вкладку страницы вывода монеты (там же список последних выводов
 * с кнопкой «Отменить» у тех, что на рассмотрении), находим ЭТОТ вывод и нажимаем:
 *   • кандидаты — строки с кнопкой «Отменить/Cancel», в тексте которых есть монета;
 *   • один кандидат по монете — он; несколько — нужен ровно один по сумме (и адресу,
 *     если на странице видно его начало/конец). Иначе НЕ нажимаем ничего: в ответе —
 *     тексты строк (для разбора), страница закрывается.
 *   • после нажатия — подтверждение в окне, если биржа его спросила; затем ждём, что
 *     кнопка у строки пропала или статус стал «Отменён». Не дождались — так и говорим.
 * Деньги при ошибке не уходят: отмена оставляет монету на бирже. Худший промах —
 * отмена другого вывода той же монеты и суммы, поэтому неоднозначность = отказ.
 * Адрес страницы — ARBI_BINGX_WITHDRAW_URL ({coin}). Сначала — БЫСТРЫЙ ПУТЬ (FAST ниже):
 * вызов API-клиента сайта из уже открытой вкладки BingX; кнопка — запасной путь.
 */
const { newBackgroundPage, markOwned } = require('./pair-tabs');
const { loginRequiredError } = require('./page-driver');

const ORIGIN = process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com';
const URL_TMPL = process.env.ARBI_BINGX_WITHDRAW_URL || `${ORIGIN}/ru/assets/withdraw?coin={coin}`;
const CANCEL_RE = /^(отменить|отмена|cancel|revoke)$/i;
const CONFIRM_RE = /^(подтвердить|подтверждаю|ок|ok|confirm|да|yes|отменить вывод|cancel withdrawal)$/i;

function scrubUrl(u) {
  try { const x = new URL(u); return x.origin + x.pathname; } catch { return String(u).slice(0, 120); }
}

/** Строки списка выводов с кнопкой «Отменить» по монете; ровно одна подходящая — помечается. */
const SCAN = ({ coin, amount, addr, reSrc }) => {
  const re = new RegExp(reSrc, 'i');
  const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
  const own = (e) => Array.from(e.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join('').trim();
  document.querySelectorAll('[data-arbi-wdcancel]').forEach((e) => e.removeAttribute('data-arbi-wdcancel'));
  const all = Array.from(document.querySelectorAll('button,a,span,div')).filter((e) => vis(e) && re.test(own(e) || (e.children.length === 0 ? (e.textContent || '').trim() : '')));
  // Внутренние: «Отменить» внутри «Отменить» — одна кнопка.
  const btns = all.filter((e) => !all.some((x) => x !== e && e.contains(x)));
  const inside = (el) => btns.filter((x) => el.contains(x)).length;
  const rows = [];
  for (const b of btns) {
    // Строка = самый крупный блок вокруг кнопки, где нет ДРУГИХ кнопок «Отменить»:
    // иначе кнопка строки USDT поднималась до общего списка и цепляла чужой PUMP.
    let r = b;
    for (let i = 0; i < 10 && r.parentElement && inside(r.parentElement) === 1; i++) r = r.parentElement;
    const t = (r.innerText || '').replace(/\s+/g, ' ').trim();
    if (r !== b && t.toUpperCase().includes(coin) && /\d/.test(t) && t.length < 700) rows.push({ b, t });
  }
  const nums = (t) => (t.replace(/(\d)[\s ](?=\d{3}\b)/g, '$1').match(/\d+(?:[.,]\d+)?/g) || []).map((s) => Number(s.replace(',', '.')));
  const amountHit = (t) => nums(t).some((n) => Math.abs(n - amount) <= Math.max(1e-8, amount * 1e-6));
  const head = addr.slice(0, 4).toLowerCase(); const tail = addr.slice(-4).toLowerCase();
  const addrOk = (t) => !addr || !(t.toLowerCase().includes(head) || t.toLowerCase().includes(tail)) || (t.toLowerCase().includes(head) && t.toLowerCase().includes(tail));
  const pick = rows.length === 1 ? rows : rows.filter((x) => amountHit(x.t) && addrOk(x.t));
  if (pick.length === 1) pick[0].b.setAttribute('data-arbi-wdcancel', '1');
  return { total: rows.length, picked: pick.length, texts: rows.map((x) => x.t.slice(0, 160)) };
};

/**
 * БЫСТРЫЙ ПУТЬ (~1 с): тот же вызов, что делает кнопка сайта, через API-клиент самой
 * страницы — подпись запроса считает сайт, мы заголовков не трогаем. Клиент есть на
 * любой странице BingX: Nuxt 2 (спот, дежурная вкладка) — window.$nuxt.$api, Nuxt 3
 * (активы) — #__nuxt.__vue_app__.$nuxt.$api. Найден по коду сайта 18.10:
 *   список  assets.queryWithdrawOnlinePage({pageNumber,pageSize}) → records[]
 *           (requestId, assetName, amount, fee, withdrawToAddress, withdrawCanCancelFlag)
 *   отмена  assets.cancelWithdraw({requestId}) → code 0 (POST …/withdraw/cancel-withdraw)
 * Выбор записи — те же правила, что у кнопки: неоднозначность = ничего не отменяем.
 */
const FAST = async ({ id, coin, amount, addr }) => {
  const app = (document.querySelector('#__nuxt') || {}).__vue_app__;
  const api = (window.$nuxt && window.$nuxt.$api) || (app && ((app.$nuxt && app.$nuxt.$api) || app.config.globalProperties.$api));
  const a = api && api.assets;
  if (!a || typeof a.cancelWithdraw !== 'function' || typeof a.queryWithdrawOnlinePage !== 'function') return { noApi: true };
  const t0 = Date.now();
  const list = async () => {
    const r = await a.queryWithdrawOnlinePage({ pageNumber: 1, pageSize: 20 });
    if (!r || r.code !== 0) throw new Error(`список выводов: code=${r && r.code} ${(r && (r.msg || r.message)) || ''}`.trim());
    return ((r.data && r.data.records) || []).filter((x) => x.withdrawCanCancelFlag === 1);
  };
  // Номер из терминала (API биржи) пробуем как requestId сайта ПАРАЛЛЕЛЬНО со списком:
  // совпал — отмена за один обмен с биржей; нет — список уже готов, задержки нет.
  // Только 15+ цифр: так выглядят номера BingX, чужой формат сразу мимо.
  const direct = /^\d{15,}$/.test(id) ? a.cancelWithdraw({ requestId: id }).catch(() => null) : Promise.resolve(null);
  const verify = (requestId) => { window.__arbiWdVerify = list().then((o) => !o.some((x) => String(x.requestId) === String(requestId))).catch(() => null); };
  try {
    const [d, open] = await Promise.all([direct, list().catch((e) => e)]);
    if (d && d.code === 0) { verify(id); return { requestId: id, code: 0, ms: Date.now() - t0, direct: true }; }
    if (open instanceof Error) throw open;
    const close = (n) => Math.abs(Number(n) - amount) <= Math.max(1e-8, amount * 1e-6);
    const sameAddr = (x) => !addr || !x.withdrawToAddress || String(x.withdrawToAddress).toLowerCase() === addr.toLowerCase();
    const mine = open.filter((x) => String(x.assetName || '').toUpperCase() === coin && sameAddr(x));
    const byId = mine.filter((x) => id && (String(x.requestId) === id || String(x.id) === id));
    const byAmt = mine.filter((x) => close(x.amount) || close(Number(x.amount) + Number(x.fee || 0)));
    const pick = byId.length === 1 ? byId : byAmt.length === 1 ? byAmt : mine.length === 1 ? mine : [];
    if (pick.length !== 1) return { picked: 0, open: open.length, mine: mine.length, ms: Date.now() - t0 };
    const requestId = pick[0].requestId;
    const c = await a.cancelWithdraw({ requestId });
    if (!c || c.code !== 0) return { requestId, code: c && c.code, msg: (c && (c.msg || c.message)) || '', ms: Date.now() - t0 };
    verify(requestId);
    return { requestId, code: 0, ms: Date.now() - t0, direct: d ? `code=${d.code}` : false };
  } catch (e) {
    return { error: String((e && e.message) || e).slice(0, 200), ms: Date.now() - t0 };
  }
};

function fastResult(r, coin, amount) {
  if (r.code === 0) return { ok: true, cancelled: true, via: 'site-api', ms: r.ms };
  if (r.picked === 0) {
    return { ok: false, error: r.mine
      ? `Не удалось однозначно найти этот вывод ${coin} ${amount} среди ${r.mine} отменяемых — ничего не отменено. Отмените на bingx.com → Активы → История выводов.`
      : `У BingX нет отменяемого вывода ${coin} ${amount} — возможно, он уже ушёл в обработку. Проверьте bingx.com → Активы → История выводов.` };
  }
  return { ok: false, error: `BingX не отменил вывод ${coin} ${amount}: ${r.error || `code=${r.code} ${r.msg || ''}`.trim()}` };
}

// Контроль ПОСЛЕ ответа терминалу: у записи больше нет кнопки отмены — только в журнал.
function logVerify(page, coin, log) {
  page.evaluate(() => window.__arbiWdVerify).then((v) => log(`[отмена вывода] ${coin}: контроль — ${v === true ? 'вывод больше не отменяемый ✓' : v === false ? '⚠ вывод всё ещё отменяемый' : 'не проверено'}`)).catch(() => {});
}

function argOf(w) {
  const coin = String(w.coin || '').toUpperCase();
  const amount = Number(w.amount);
  return { id: w.id == null ? '' : String(w.id), coin, amount, addr: String(w.address || '') };
}

/**
 * Отмена из УЖЕ открытой вкладки BingX — только вызов API-клиента страницы, без навигации,
 * поэтому её не ставим в очередь фоновой дорожки за уборкой/проверкой депозита (09.11:
 * отмена ждала чужую работу). null — открытой вкладки с клиентом нет, нужен полный путь.
 */
async function cancelInOpenTab(context, w, log = () => {}) {
  const arg = argOf(w);
  if (!arg.coin || !(arg.amount > 0)) return null;
  for (const p of context.pages()) {
    let url = ''; try { url = p.url(); } catch { /* закрыта */ }
    if (!/bingx\./i.test(url) || /login|sign-?in/i.test(url)) continue;
    const r = await p.evaluate(FAST, arg).catch(() => ({ noApi: true }));
    if (r.noApi) continue;
    log(`[отмена вывода] ${arg.coin} ${arg.amount}: прямой вызов из открытой вкладки → ${JSON.stringify(r)}`);
    if (r.code === 0) logVerify(p, arg.coin, log);
    return fastResult(r, arg.coin, arg.amount);
  }
  return null;
}

async function cancelWithdraw(context, w, log = () => {}) {
  const arg = argOf(w);
  const { coin, amount, addr } = arg;
  if (!coin || !(amount > 0)) return { ok: false, error: 'нет монеты или суммы вывода — отмену не начинаю' };
  // 1) уже открытая вкладка BingX (дежурная/торговая) — без загрузки страницы.
  const open = await cancelInOpenTab(context, w, log);
  if (open) return open;
  const page = markOwned(await newBackgroundPage(context));
  const apis = [];
  page.on('response', (r) => {
    try {
      const u = r.url();
      if (/\/api\//.test(u) && /withdraw/i.test(u)) apis.push(`${r.request().method()} ${scrubUrl(u)} → ${r.status()}`);
      if (apis.length > 40) apis.shift();
    } catch { /* диагностика */ }
  });
  try {
    const url = URL_TMPL.replace('{coin}', encodeURIComponent(coin));
    log(`[отмена вывода] ${coin} ${amount}: открываю ${scrubUrl(url)}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    if (/login|sign-?in/i.test(page.url())) {
      return { ok: false, loginRequired: true, error: loginRequiredError('BingX', 'Вывод не отменён.') };
    }
    // 2) API-клиент на только что открытой странице (появляется после загрузки скриптов).
    for (let t0 = Date.now(); Date.now() - t0 < 15000;) {
      const r = await page.evaluate(FAST, arg).catch(() => ({ noApi: true }));
      if (!r.noApi) {
        log(`[отмена вывода] ${coin} ${amount}: прямой вызов со страницы вывода → ${JSON.stringify(r)}`);
        return fastResult(r, coin, amount);
      }
      await page.waitForTimeout(500);
    }
    // 3) запасной путь — кнопка на странице.
    // Список выводов приходит запросом после загрузки — ждём кнопку «Отменить» до 12 с.
    const t0 = Date.now();
    let found = null;
    while (Date.now() - t0 < 12000) {
      found = await page.evaluate(SCAN, { coin, amount, addr, reSrc: CANCEL_RE.source });
      if (found.total > 0) break;
      await page.waitForTimeout(800);
    }
    if (!found || found.total === 0) {
      log(`[отмена вывода] ${coin}: кнопки «Отменить» нет; API страницы: ${apis.join(' | ') || '—'}`);
      return { ok: false, error: `На странице вывода BingX нет вывода ${coin} с кнопкой «Отменить» — возможно, он уже ушёл в обработку. Проверьте bingx.com → Активы → История выводов.` };
    }
    if (found.picked !== 1) {
      log(`[отмена вывода] ${coin} ${amount}: подходящих строк ${found.picked} из ${found.total} — не нажимаю. Строки: ${found.texts.join(' || ')}`);
      return { ok: false, error: `Не удалось однозначно найти этот вывод ${coin} ${amount} среди ${found.total} с кнопкой «Отменить» — ничего не нажато. Отмените на bingx.com → Активы → История выводов.` };
    }
    await page.click('[data-arbi-wdcancel="1"]', { timeout: 5000 });
    // Окно подтверждения — если биржа спросила.
    await page.waitForTimeout(600);
    const confirmed = await page.evaluate((reSrc) => {
      const re = new RegExp(reSrc, 'i');
      const vis = (e) => e && e.offsetParent !== null;
      const dlg = Array.from(document.querySelectorAll('[role="dialog"],[class*="modal" i],[class*="dialog" i]')).filter(vis).pop();
      if (!dlg) return false;
      const b = Array.from(dlg.querySelectorAll('button')).filter((x) => vis(x) && re.test((x.textContent || '').trim())).pop();
      if (b) { b.setAttribute('data-arbi-wdconfirm', '1'); return true; }
      return false;
    }, CONFIRM_RE.source);
    if (confirmed) await page.click('[data-arbi-wdconfirm="1"]', { timeout: 5000 }).catch(() => {});
    // Проверка: отменяемых выводов этой монеты стало на один меньше (простая перерисовка
    // списка этого не даёт — та же строка снова найдётся с кнопкой).
    let verified = false;
    for (let i = 0; i < 10 && !verified; i++) {
      await page.waitForTimeout(700);
      const after = await page.evaluate(SCAN, { coin, amount, addr, reSrc: CANCEL_RE.source }).catch(() => null);
      verified = !!after && after.total < found.total;
    }
    log(`[отмена вывода] ${coin} ${amount}: нажато «Отменить»${confirmed ? ' + подтверждение' : ''}; ${verified ? 'статус обновился' : 'статус не подтвердился за 7 с'}; API: ${apis.join(' | ') || '—'}`);
    return verified
      ? { ok: true, cancelled: true, confirmed }
      : { ok: false, ambiguous: true, error: `«Отменить» у вывода ${coin} ${amount} нажато, но статус на странице не обновился — проверьте историю выводов.` };
  } finally {
    await page.close().catch(() => {});
  }
}

module.exports = { cancelWithdraw, cancelInOpenTab, FAST };

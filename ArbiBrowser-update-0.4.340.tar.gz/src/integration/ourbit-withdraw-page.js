'use strict';

/**
 * ourbit-withdraw-page.js — ВЫВОД OURBIT ЧЕРЕЗ ФОРМУ САЙТА (оператор 16.11).
 *
 * Подтверждение вывода (submit_withdraw) сайт принимает только после невидимой капчи Geetest, которую запускает
 * сама страница при нажатии «Вывести» (запись 16.11: check_chain → captcha/robot/robot.assets.withdraw → gcaptcha4
 * load/verify → save_withdraw → submit_withdraw). Прямой запрос — 60008 «验证码错误» при тех же заголовках и подписи.
 * Поэтому вывод делает страница: своя вкладка вывода, сеть, адрес и сумма вводятся настоящими нажатиями, «Вывести»,
 * окно подтверждения — «Подтвердить». Капча — дело страницы; потребовала пазл — вкладка вперёд, ждём человека.
 *
 * Деньги защищены сверкой ЗАПРОСА самой страницы, а не разметки: до «Подтвердить» читаем тело save_withdraw, которое
 * отправила страница, — сумма, адрес, сеть, монета должны совпасть с намерением терминала; иначе окно закрывается,
 * ничего не подтверждено. Исход — ответ submit_withdraw страницы (withdrawId / код ошибки). Разметки не видно из
 * среды разработки: элементы ищутся по подписям (ru/en); не нашли — в журнал структура формы без значений.
 */

const ORIGIN = 'https://www.ourbit.com';
const TAB = 'OURBIT-WD';
const ADDR = 'input[placeholder*="адрес" i], input[placeholder*="address" i], textarea[placeholder*="адрес" i], textarea[placeholder*="address" i]';
const HUMAN_MS = Math.max(30_000, Number(process.env.ARBI_OURBIT_WD_HUMAN_MS) || 120_000);
const lower = (s) => String(s || '').trim().toLowerCase();

/** Тело save_withdraw страницы против намерения. null — совпало, иначе причина (для отказа). */
function saveMismatch(bodyStr, want) {
  let b = null;
  try { b = JSON.parse(bodyStr || ''); } catch { return 'тело подготовки вывода не прочитано'; }
  if (String(b.currency || '').toUpperCase() !== want.coin) return `монета ${b.currency} вместо ${want.coin}`;
  if (lower(b.address) !== lower(want.address)) return 'адрес на странице не тот, что в терминале';
  if (String(b.chain || '') !== want.chainName) return `сеть «${b.chain}» вместо «${want.chainName}»`;
  const a = Number(b.amount);
  const w = Number(want.amount);
  if (!(a > 0) || Math.abs(a - w) > Math.max(1e-9, w * 1e-9)) return `сумма ${b.amount} вместо ${want.amount}`;
  return null;
}

/** Структура формы вывода без значений — для правки поиска элементов по журналу. */
async function dumpForm(page, log, why) {
  const d = await page.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); const st = getComputedStyle(e); return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none'; };
    const t = (s, n = 40) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
    const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
    const inputs = [...document.querySelectorAll('input,textarea')].filter(vis).slice(0, 12).map((e) => `поле ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
    const sels = [...document.querySelectorAll('[class*="select" i]')].filter((e) => vis(e) && !e.querySelector('[class*="select" i]')).slice(0, 8).map((e) => `выбор ${cls(e)} «${t(e.textContent, 30)}»`);
    const btns = [...new Set([...document.querySelectorAll('button,[role="button"]')].filter(vis).map((b) => t(b.innerText, 24)).filter(Boolean))].slice(0, 20);
    const opts = [...document.querySelectorAll('.ant-select-item-option, .ant-modal-body')].filter(vis).slice(0, 3).map((o) => t(o.innerText, 300));
    return [...inputs, ...sels, `кнопки=[${btns.join(' | ')}]`, `пункты списка=[${opts.join(' | ')}]`].join(' ; ');
  }).catch((e) => `не снята: ${e.message}`);
  log(`[форма вывода] ${why}: ${d}`);
}

const urlOf = (coin) => `${ORIGIN}/ru-RU/assets/withdraw/${coin}`;
const NET_PLACEHOLDER = /выберите сеть|select.*network/i;

function findTab(context) {
  try { return context.pages().find((p) => p.__arbiDuty === TAB && !p.isClosed()) || null; } catch { return null; }
}

/** Свежая форма вывода монеты: открыта, адрес виден, сеть ещё не выбрана. */
async function freshForm(pg, coin) {
  if (!pg || !pg.url().startsWith(urlOf(coin))) return false;
  if (!(await pg.locator(ADDR).first().isVisible().catch(() => false))) return false;
  return pg.locator('.ant-select-selection-placeholder').filter({ hasText: NET_PLACEHOLDER }).first().isVisible().catch(() => false);
}

/**
 * Вкладка вывода (16.11, оператор: «вывод за 1–2 секунды»): загрузка формы — ~6 с (сети, адресная книга, капча),
 * поэтому она держится ОТКРЫТОЙ заранее (prewarm при открытой панели вывода в терминале) и после каждого вывода
 * перезагружается в фоне. Свежая форма той же монеты — без перезагрузки.
 */
async function wdPage(context, coin, log) {
  let pg = findTab(context);
  if (await freshForm(pg, coin)) { log('вывод: форма уже открыта — без загрузки'); return pg; }
  if (!pg) { pg = await context.newPage(); pg.__arbiDuty = TAB; }
  log(`вывод: открываю форму ${urlOf(coin)}`);
  await pg.goto(urlOf(coin), { waitUntil: 'domcontentloaded', timeout: 30_000 });
  // Ждём само поле адреса: форма рисуется после загрузки сетей и адресной книги (журнал 16.11: ~5 с после
  // открытия), а первое видимое поле страницы — поиск в шапке, он есть сразу.
  await pg.locator(ADDR).first().waitFor({ state: 'visible', timeout: 20_000 }).catch(() => {});
  return pg;
}

let warming = false;
/** Заранее открыть форму вывода (USDT), если вкладки нет. Ничего не вводит. */
async function prewarmForm(context, coin = 'USDT') {
  if (warming || findTab(context)) return;
  warming = true;
  try {
    const pg = await context.newPage();
    pg.__arbiDuty = TAB;
    await pg.goto(urlOf(coin), { waitUntil: 'domcontentloaded', timeout: 30_000 }).catch(() => {});
  } finally { warming = false; }
}

/** После вывода — свежая форма той же монеты в фоне, чтобы следующий вывод не ждал загрузки. */
function reloadLater(pg, coin) {
  const t = setTimeout(() => { if (!pg.isClosed()) pg.goto(urlOf(coin), { waitUntil: 'domcontentloaded', timeout: 30_000 }).catch(() => {}); }, 1500);
  if (t.unref) t.unref();
}

/** Вставка целиком (fill): одно событие ввода, без запроса сайта на каждый символ (журнал 16.11: 25 × match_chain). */
async function pasteInto(loc, text) {
  await loc.fill(String(text), { timeout: 3000 });
}

const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

/**
 * Сеть (журнал и снимок 16.11): щелчок по выбору «Выберите сеть вывода средств» открывает ОКНО со списком
 * (строка: «BSC» и под ней «BNB Smart Chain(BEP20)») и поиском. Пункт — по точному имени сети сайта; не видно —
 * имя в поиск окна. Ошибиться пунктом не страшно: деньги защищает сверка тела save_withdraw.
 */
async function pickNetwork(pg, chainName, log) {
  const sel = pg.locator('.ant-select').filter({ has: pg.locator('.ant-select-selection-placeholder', { hasText: NET_PLACEHOLDER }) }).first();
  if (!(await sel.locator('.ant-select-selector').click({ timeout: 3000 }).then(() => true).catch(() => false))) {
    await dumpForm(pg, log, 'не открылся выбор сети'); return false;
  }
  const modal = pg.locator('.ant-modal').filter({ hasText: NET_PLACEHOLDER }).last();
  let item = modal.getByText(chainName, { exact: true }).first();
  if (!(await item.waitFor({ state: 'visible', timeout: 2500 }).then(() => true).catch(() => false))) {
    await modal.locator('input').first().fill(chainName).catch(() => {});
    item = modal.getByText(chainName, { exact: true }).first();
    if (!(await item.waitFor({ state: 'visible', timeout: 1500 }).then(() => true).catch(() => false))) {
      await dumpForm(pg, log, `нет пункта сети «${chainName}»`); await pg.keyboard.press('Escape').catch(() => {}); return false;
    }
  }
  await item.click({ timeout: 3000 });
  await modal.waitFor({ state: 'hidden', timeout: 2000 }).catch(() => {});
  return true;
}

function waitPost(pg, re, ms) {
  return pg.waitForResponse((r) => re.test(r.url()) && r.request().method() === 'POST', { timeout: ms })
    .then(async (r) => ({ body: r.request().postData() || '', json: await r.json().catch(() => null) }))
    .catch(() => null);
}

/**
 * Вывод формой. want: { coin, chainName, address, amount }. Возврат — как у прямого пути:
 * { ok:true, withdrawId } | { ok:false, error, maybe? }.
 */
async function withdrawViaForm(context, want, log) {
  const t0 = Date.now();
  const pg = await wdPage(context, want.coin, log);
  try { return await fillAndSubmit(pg, want, log, t0); } finally { reloadLater(pg, want.coin); }
}

async function fillAndSubmit(pg, want, log, t0) {
  log(`вывод: форма готова за ${Date.now() - t0} мс`);

  // Порядок полей на странице (журнал 16.11): адрес, затем сеть, затем сумма — сумма появляется после выбора сети.
  const addr = pg.locator(ADDR).first();
  if (!(await addr.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля адреса'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле адреса — вывод не отправлен' }; }
  await pasteInto(addr, want.address);

  if (!(await pickNetwork(pg, want.chainName, log))) return { ok: false, error: `Ourbit: на форме вывода не нашлась сеть «${want.chainName}» — вывод не отправлен` };

  const amt = pg.locator('input[placeholder*="сумм" i], input[placeholder*="мин" i], input[placeholder*="количеств" i], input[placeholder*="amount" i], input[placeholder*="min" i]').first();
  await amt.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await amt.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля суммы'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле суммы — вывод не отправлен' }; }
  await pasteInto(amt, want.amount);

  const btn = pg.getByRole('button', { name: /^(вывести|вывод|withdraw)$/i }).last();
  await btn.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await btn.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Вывести»'); return { ok: false, error: 'Ourbit: на форме не нашлась кнопка «Вывести» — вывод не отправлен' }; }
  const checked = waitPost(pg, /\/withdraw\/check_chain\//, 5000);
  const saved = waitPost(pg, /\/withdraw\/save_withdraw\//, HUMAN_MS);
  await btn.click({ timeout: 4000 });
  log('вывод: «Вывести» нажата — проверка и капча страницы');
  // Страница не начала проверку за 5 с — форма не приняла данные (ошибка поля): не ждём 2 мин капчу, которой не будет.
  const ck = await checked;
  if (!ck) { await dumpForm(pg, log, 'страница не проверила вывод'); return { ok: false, error: 'Ourbit: форма не приняла данные вывода (страница не начала проверку) — вывод не отправлен' }; }
  if (ck.json && ck.json.code !== 0) return { ok: false, error: `Ourbit: проверка вывода — отказ сайта (code=${ck.json.code} «${ck.json.msg || ''}») — вывод не отправлен` };
  // Капча попросила человека — пазл виден: вкладку вперёд.
  const nudge = setTimeout(() => { pg.bringToFront().catch(() => {}); log(`вывод: капча ждёт человека — вкладка Ourbit на переднем плане (до ${Math.round(HUMAN_MS / 1000)} с)`); }, 6000);
  const sv = await saved;
  clearTimeout(nudge);
  if (!sv) { await dumpForm(pg, log, 'нет подготовки вывода'); return { ok: false, error: 'Ourbit: страница не подготовила вывод (капча не пройдена или форма не приняла данные) — вывод не отправлен' }; }
  if (!sv.json || sv.json.code !== 0) return { ok: false, error: `Ourbit: подготовка вывода — отказ сайта (code=${sv.json && sv.json.code} «${sv.json && sv.json.msg || ''}») — вывод не отправлен` };
  const bad = saveMismatch(sv.body, want);
  if (bad) {
    await pg.keyboard.press('Escape').catch(() => {});
    log(`вывод: ⛔ страница готовит не то — ${bad}; окно закрыто`);
    return { ok: false, error: `Ourbit: ${bad} — вывод НЕ подтверждён` };
  }

  const confirm = pg.locator('.ant-modal, [role="dialog"]').getByRole('button', { name: /^(подтвердить|confirm|ок|ok)$/i }).last();
  await confirm.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await confirm.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Подтвердить» в окне'); return { ok: false, error: 'Ourbit: окно подтверждения без кнопки «Подтвердить» — вывод не подтверждён' }; }
  const submitted = waitPost(pg, /\/withdraw\/submit_withdraw\//, 30_000);
  await confirm.click({ timeout: 4000 });
  const sb = await submitted;
  if (!sb || !sb.json) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true };
  if (sb.json.code !== 0) return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.json.code} «${sb.json.msg || ''}»)` };
  if (sb.json.data && sb.json.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit' };
  log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён формой сайта за ${Date.now() - t0} мс`);
  return { ok: true, withdrawId: String((sb.json.data && sb.json.data.withdrawId) || '') };
}

module.exports = { withdrawViaForm, prewarmForm, _saveMismatch: saveMismatch };

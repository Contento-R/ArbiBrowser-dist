'use strict';

/**
 * ourbit-sign.js — подпись запросов сайта Ourbit (x-ourbit-nonce / x-ourbit-sign), 16.11.
 *
 * Заявки сайт принимает без подписи, а подтверждение вывода (submit_withdraw) — нет: 60008 даже с device-id.
 * Ourbit — клон MEXC, у MEXC web-подпись известна: md5(nonce + тело + md5(ключ + nonce)[7:]), ключ — токен
 * входа из cookie. Формулу не угадываем: когда страница САМА шлёт подписанный POST, пересчитываем подпись
 * кандидатами (cookie и localStorage сайта × формулы) и запоминаем совпавшую. В журнал и файл — только
 * имя ключа и номер формулы, значения — никогда. Пока не совпало — подписи нет (вывод откажет понятно).
 */
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');

const ORIGIN = 'https://www.ourbit.com';
const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const FORMULAS = {
  f1: (k, n, b) => md5(n + b + md5(k + n).slice(7)), // MEXC web
  f2: (k, n, b) => md5(k + n + b),
  f3: (k, n, b) => md5(n + b + k),
  f4: (k, n, b) => md5(n + k + b),
  f5: (k, n, b) => sha256(n + b + md5(k + n).slice(7)),
  f6: (k, n, b) => md5(n + b + md5(k + n)),
};
const FILE = () => path.join(config.reportsDir, 'ourbit-sign.json');
let found = (() => { try { return JSON.parse(fs.readFileSync(FILE(), 'utf8')); } catch { return null; } })();
let missLogged = false;

async function candidates(page) {
  const out = [];
  try {
    for (const c of await page.context().cookies(ORIGIN)) if (c.value && c.value.length >= 8 && c.value.length <= 400) out.push({ src: 'cookie', name: c.name, value: c.value });
  } catch { /* контекст закрыт */ }
  const ls = await page.evaluate(() => {
    const r = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); const v = String(localStorage.getItem(k) || ''); if (v.length >= 8 && v.length <= 400) r.push([k, v]); } } catch { /* нет доступа */ }
    return r;
  }).catch(() => []);
  for (const [name, value] of ls) out.push({ src: 'localStorage', name, value });
  return out;
}

/** Страница отправила подписанный POST — найти, чем он подписан (один раз). */
async function probe(page, req, log) {
  if (found) return;
  const h = req.headers() || {};
  const sign = String(h['x-ourbit-sign'] || '').toLowerCase();
  const nonce = String(h['x-ourbit-nonce'] || '');
  if (!sign || !nonce) return;
  const body = req.postData() || '';
  const cands = await candidates(page);
  for (const c of cands) {
    for (const [f, fn] of Object.entries(FORMULAS)) {
      if (fn(c.value, nonce, body) === sign) {
        found = { src: c.src, name: c.name, f };
        try { fs.mkdirSync(path.dirname(FILE()), { recursive: true }); fs.writeFileSync(FILE(), JSON.stringify(found)); } catch { /* живёт до перезапуска */ }
        log(`[подпись сайта] совпало: ${c.src} «${c.name}», формула ${f} — вывод из терминала будет подписан как сайт`);
        return;
      }
    }
  }
  if (!missLogged) { missLogged = true; log(`[подпись сайта] не совпала ни с одной формулой (кандидатов ${cands.length}, длина подписи ${sign.length}, nonce ${nonce.length} симв.) — нужна доработка`); }
}

/** Заголовки подписи для тела `body` (строка, ровно как уйдёт); nonceAt — метка времени (мс), по умолчанию часы компьютера. Подпись не разобрана — {}. */
async function signFor(page, body, nonceAt) {
  if (!found) return {};
  let key = '';
  if (found.src === 'cookie') {
    try { key = ((await page.context().cookies(ORIGIN)).find((c) => c.name === found.name) || {}).value || ''; } catch { key = ''; }
  } else {
    key = await page.evaluate((n) => { try { return localStorage.getItem(n) || ''; } catch { return ''; } }, found.name).catch(() => '');
  }
  if (!key) return {};
  const nonce = String(nonceAt || Date.now()); // страница подписывает часами компьютера (журнал 16.11: nonce = часы −2 мс)
  return { 'x-ourbit-nonce': nonce, 'x-ourbit-sign': FORMULAS[found.f](key, nonce, body) };
}

const known = () => !!found;

module.exports = { probe, signFor, known, _FORMULAS: FORMULAS };

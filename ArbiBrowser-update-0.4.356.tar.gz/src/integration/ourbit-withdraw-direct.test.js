'use strict';
// Прямой вывод Ourbit: подтверждение формой, уровни шагов перед подтверждением (отказ 60008 → следующий шаг и повтор
// той же подготовки), свои запросы среди запросов страницы, отказ на всех уровнях → форма.
const test = require('node:test');
const assert = require('node:assert/strict');
const captcha = require('./ourbit-captcha');
const sign = require('./ourbit-sign');
const { _withdrawDirect: direct, _deviceOf: deviceOf, _authOf: authOf, _freshTrace: freshTrace, _nextTrace: nextTrace, _traceOf: traceOf, _notePostHdr: notePostHdr, _stepHdr: stepHdr, _markSent: markSent, _takeSent: takeSent } = require('./ourbit-order-page');

// Подпись в тестах — строка, которая подписана: по ней видно, что подписано ровно отправленное тело.
sign.signFor = async (_page, body) => ({ 'x-ourbit-sign': `sign(${body})` });

const TRACE = 'ab12cd34-1794862816767-xyzq';

function setup({ learned = {}, replies = {}, captchaReady = true } = {}) {
  let st = { ...learned };
  const calls = [];
  const context = { cookies: async () => [], pages: () => [] };
  const mk = (tab) => ({
    context: () => context,
    isClosed: () => false,
    evaluate: async (_fn, a) => {
      if (!a || !a.url) return '';
      const step = /check_chain/.test(a.url) ? 'check' : /captcha\/robot/.test(a.url) ? 'robot' : /save_withdraw/.test(a.url) ? 'save'
        : /submit_withdraw/.test(a.url) ? 'submit' : /check_risk/.test(a.url) ? 'risk' : /common\/ping/.test(a.url) ? 'ping' : 'other';
      calls.push({ step, tab, url: a.url, hdr: a.hdr, body: a.body, at: Date.now() });
      const q = replies[step];
      const r = Array.isArray(q) ? (q.length > 1 ? q.shift() : q[0]) : q;
      return r || { status: 200, code: 0, data: null, success: true };
    },
  });
  const page = mk('торги');
  const wd = mk('вывод');
  captcha.known = () => true;
  captcha.hasFresh = () => true;
  captcha.take = () => (captchaReady ? { token: 'geetest TOKEN', page: wd } : null);
  captcha.learned = () => ({ ...st });
  captcha.learnedSet = (p) => { st = { ...st, ...p }; };
  deviceOf.set(context, 'SUBMIT-DEVICE');
  authOf.set(context, 'AUTH');
  const c = {
    page, context, log: () => {},
    hdr: { 'luminex-uid': 'u1', 'luminex-trace-id': TRACE, pragma: 'akamai-x-cache-on', baggage: 'b', 'sentry-trace': 's', 'content-type': 'application/json' },
    uh: { 'ucenter-token': 'T', 'device-id': 'UC-DEVICE', 'timezone-login': 'UTC+1', language: 'ru-RU' },
    want: { coin: 'USDT', chainName: 'BNB Smart Chain(BEP20)', address: '0xabc', amount: '10' },
  };
  return { c, calls, state: () => st };
}
const QUICK = { status: 200, code: 0, data: { isQuickWithdraw: true } };
const SAVED = { status: 200, code: 0, data: { requestId: 'R1' } };
const DONE = { status: 200, code: 0, data: { withdrawId: 'W1', needVerify: false } };
const NO = { status: 200, code: 60008, data: null, msg: 'x' };
const steps = (calls) => calls.map((x) => x.step).join(',');
const at = (calls, step, n = 0) => calls.filter((x) => x.step === step)[n];

test('первый вывод: проверка и подготовка вместе, подтверждение — ФОРМОЙ, подписано ровно тело формы', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: DONE } });
  const r = await direct(c);
  assert.equal(r.ok, true);
  assert.equal(r.withdrawId, 'W1');
  assert.equal(r.usedCaptcha, false);
  assert.deepEqual(calls.slice(0, 2).map((x) => x.step).sort(), ['check', 'save']);
  assert.equal(steps(calls.slice(2)), 'submit');
  const sb = at(calls, 'submit');
  assert.equal(sb.body, 'isQuickWithdraw=true&requestId=R1');
  assert.equal(sb.body.length + 30, 63); // с requestId в 32 знака — ровно 63 знака, как у страницы (сверка 17.11)
  assert.equal(sb.hdr['content-type'], 'application/x-www-form-urlencoded');
  assert.equal(sb.hdr['x-ourbit-sign'], 'sign(isQuickWithdraw=true&requestId=R1)');
  assert.equal(sb.hdr['device-id'], 'SUBMIT-DEVICE');
  assert.equal(at(calls, 'save').hdr['content-type'], 'application/json'); // подготовка — JSON
  assert.match(at(calls, 'save').body, /^\{"amount":"10"/);
  assert.ok(calls.every((x) => x.url.startsWith('/'))); // адрес без домена — через перехватчики страницы
  assert.ok(calls.every((x) => !x.hdr.baggage && !x.hdr['sentry-trace'] && !x.hdr.pragma && !x.hdr['cache-control']));
  assert.equal(new Set(calls.map((x) => x.hdr['luminex-trace-id'])).size, calls.length);
  assert.equal(state().level, 0);
});

test('отказ 60008 без капчи — шаг капчи и повтор ТОЙ ЖЕ подготовки; уровень запоминается', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: [NO, DONE] } });
  const r = await direct(c);
  assert.equal(r.ok, true);
  assert.equal(r.usedCaptcha, true);
  assert.equal(calls.filter((x) => x.step === 'save').length, 1);
  assert.equal(steps(calls.slice(2)), 'submit,robot,submit');
  const rb = at(calls, 'robot');
  assert.equal(rb.tab, 'вывод');
  assert.equal(rb.hdr['captcha-token'], 'geetest TOKEN');
  assert.equal(rb.hdr['device-id'], 'UC-DEVICE');
  assert.equal(state().level, 1);
});

test('известный уровень «с капчей»: капча уходит одновременно с подготовкой', async () => {
  const { c, calls } = setup({ learned: { level: 1 }, replies: { check: QUICK, save: SAVED, submit: DONE } });
  assert.equal((await direct(c)).ok, true);
  assert.deepEqual(calls.slice(0, 3).map((x) => x.step).sort(), ['check', 'robot', 'save']);
  assert.equal(steps(calls.slice(3)), 'submit');
});

test('отказы дальше: check_risk и ping, затем пауза как у страницы', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: [NO, NO, NO, DONE] } });
  assert.equal((await direct(c)).ok, true);
  assert.equal(steps(calls.slice(2)), 'submit,robot,submit,risk,ping,submit,risk,ping,submit');
  assert.ok(at(calls, 'submit', 3).at - at(calls, 'save').at >= 1150);
  assert.equal(at(calls, 'risk').hdr.authorization, 'AUTH');
  assert.ok(!at(calls, 'ping').hdr['content-type']);
  assert.equal(state().level, 3);
});

test('отказ на всех уровнях — формой; после двух таких выводов прямой путь не пробуется', async () => {
  const { c, calls, state } = setup({ learned: { level: 3 }, replies: { check: QUICK, save: SAVED, submit: NO } });
  assert.equal((await direct(c)).form, true);
  assert.equal(calls.filter((x) => x.step === 'submit').length, 1);
  assert.equal(state().directFails, 1);
  await direct(c);
  const n = calls.length;
  assert.equal((await direct(c)).form, true);
  assert.equal(calls.length, n);
});

test('сайт просит коды — отказ без подтверждения', async () => {
  const { c, calls } = setup({ replies: { check: { status: 200, code: 0, data: { isQuickWithdraw: false } }, save: SAVED } });
  const r = await direct(c);
  assert.equal(r.ok, false);
  assert.match(r.error, /коды/);
  assert.ok(!calls.some((x) => x.step === 'submit'));
});

test('подтверждение без ответа — «мог пройти», ничего не повторяем', async () => {
  const { c, calls } = setup({ replies: { check: QUICK, save: SAVED, submit: { error: 'timeout' } } });
  const r = await direct(c);
  assert.equal(r.maybe, true);
  assert.ok(!r.form);
  assert.equal(calls.filter((x) => x.step === 'submit').length, 1);
});

test('нет свежей капчи — шаг капчи пропускается, дальше следующие уровни', async () => {
  const { c, calls, state } = setup({ captchaReady: false, replies: { check: QUICK, save: SAVED, submit: [NO, NO, DONE] } });
  assert.equal((await direct(c)).ok, true);
  assert.ok(!calls.some((x) => x.step === 'robot'));
  assert.equal(state().level, 2);
});

test('trace-id: тот же вид, другое значение, время — текущее', () => {
  const now = String(Date.now());
  const v = `ab12cd34-${now.slice(0, 3)}0000000000-xyzq`;
  const t = freshTrace(v);
  assert.notEqual(t, v);
  assert.match(t, /^[a-f0-9]{8}-\d{13}-[g-z]{4}$/);
  assert.ok(Math.abs(Number(t.split('-')[1]) - Date.now()) < 5000);
});

test('trace-id продолжает ряд страницы: общая часть та же, счётчик дальше; ряда нет — случайный того же вида', () => {
  const page = {};
  traceOf.set(page, ['ab12cd34-ffff-0017', 'ab12cd34-ffff-0018']);
  const a = nextTrace(page, 'x');
  const b = nextTrace(page, 'x');
  assert.match(a, /^ab12cd34-ffff-\d{4}$/);
  assert.notEqual(a, b);
  assert.ok(Number(a.slice(-4)) > 18);
  const other = {};
  traceOf.set(other, ['ab12cd34-ffff-aaaa1111', 'ab12cd34-ffff-bbbb2222']);
  assert.match(nextTrace(other, 'x'), /^ab12cd34-ffff-[a-f]{4}\d{4}$/);
  assert.match(nextTrace({}, 'cd-12'), /^[a-f]{2}-\d{2}$/);
});

test('заголовки страницы берутся только от её JSON-запросов (иначе «Invalid Content-Type» у нашей проверки)', () => {
  const { c } = setup();
  notePostHdr(c.context, { 'content-type': 'application/x-www-form-urlencoded', accept: 'x/y' });
  assert.equal(stepHdr(c)['content-type'], 'application/json');
  assert.equal(stepHdr(c).accept, undefined);
  notePostHdr(c.context, { 'content-type': 'application/json', accept: 'application/json, text/plain, */*', 'x-ourbit-sign': 's', 'device-id': 'd', cookie: 'c' });
  const h = stepHdr(c);
  assert.equal(h.accept, 'application/json, text/plain, */*');
  assert.ok(!h['x-ourbit-sign'] && !h['device-id'] && !h.cookie);
});

test('свой запрос узнаётся по пометке пути, один раз; запрос страницы на тот же путь — уже не наш', () => {
  const page = {};
  markSent(page, '/api/x', { a: '1' });
  assert.deepEqual(takeSent(page, '/api/x'), { a: '1' });
  assert.equal(takeSent(page, '/api/x'), null);
  assert.equal(takeSent(page, '/api/y'), null);
});

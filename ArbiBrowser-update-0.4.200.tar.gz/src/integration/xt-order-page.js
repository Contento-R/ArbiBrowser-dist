'use strict';

/**
 * xt-order-page.js — Стадия 3: РЕАЛЬНОЕ исполнение web-ордера XT в живой
 * странице браузера профиля.
 *
 * Скопировано по образцу mexc-order-page.js (см. там же общее обоснование:
 * почему в браузере, а не реплеем на сервере, и почему НЕ page.evaluate(fetch)
 * / НЕ синтетический JS-.click(), а доверенный Playwright-ввод через CDP
 * Input-домен — isTrusted=true, как у настоящего пользователя).
 *
 * ⚠️ НЕ ПРОВЕРЕНО против живого XT из среды разработки. Селекторы формы взяты
 * из наблюдений оператора (реальный DOM, см. комментарии у SELECTORS ниже) и
 * могут разойтись с текущей вёрсткой (хешированные CSS-модули). Все селекторы
 * ПЕРЕОПРЕДЕЛЯЕМЫ через env (ARBI_XT_SEL_*), чтобы починить без правки кода.
 *
 * ТРЕБУЕТ ЖИВОЙ ПРОВЕРКИ ОПЕРАТОРОМ (лучшее предположение, не гарантия):
 *   - ORDER_PLACE_RE — regex ответа постановки ордера (эндпоинт не подтверждён);
 *   - формат успеха/orderId в ответе (rc/code/mc — угадано по распространённым
 *     конвертам, НЕ проверено на бою);
 *   - TRADE_URL_TMPL — локаль URL пары (en по умолчанию, оператор может сменить
 *     на /ru/ через ARBI_XT_TRADE_URL);
 *   - SELECTORS.searchResult — селектор строки результата поиска пары.
 * Живой прогон обязателен ДО включения live-режима — см. session-note.
 */

const { formatDecimal, isPlainPositive, pairGate, fieldFresh } = require('./order-utils');
const { canOpenPairTab, markPairTab, markOwned, newBackgroundPage } = require('./pair-tabs');

const XT_ORIGIN = 'https://www.xt.com';
// URL торговой пары: env-шаблон с {pair}. Дефолт /ru/ ПОДТВЕРЖДЁН на бою 2026-07-08
// (адресная строка оператора: https://www.xt.com/ru/trade/tig_usdt). Переопределяемо.
const TRADE_URL_TMPL = process.env.ARBI_XT_TRADE_URL || 'https://www.xt.com/ru/trade/{pair}';
// regex ответа постановки ордера. ПОДТВЕРЖДЁН на бою 2026-07-08:
// POST https://www.xt.com/sapi/v4/order/order → {rc:0, mc:"SUCCESS", result:{orderId}}.
// IM-2: только ТОЧНЫЙ endpoint постановки (подтверждён на бою 2026-07-08:
// POST /sapi/v4/order/order). Прежние широкие альтернативы (/(v4|sapi)/order\b,
// /trade/order) матчили и поллинг открытых ордеров сайтом (/sapi/v4/order/list и
// т.п.) → захват ЧУЖОГО ответа как ответа нашего ордера (ложный успех с чужим
// orderId). Переопределяемо ARBI_XT_ORDER_RE, если XT сменит endpoint.
const ORDER_PLACE_RE = new RegExp(process.env.ARBI_XT_ORDER_RE || 'sapi/v4/order/order\\b', 'i');

// Селекторы формы ордера XT. XT использует CSS-модули с хешированными суффиксами —
// поэтому матчим по префиксу класса ([class*="..."]), а не по полному классу.
// Каждый переопределяется через env без пересборки.
/** Точность количества по паре (сколько знаков после точки принял XT). */
const XT_QTY_DEC = new Map();

const SELECTORS = {
  // Строка поиска пары ВНУТРИ дропдауна выбора пары (открывается кликом по заголовку
  // пары <h1>BASE/USDT>, подтверждено оператором 2026-07-09): <input class="search_input__hK_o2"
  // placeholder="Введите адрес криптовалюты или контракта">.
  search: process.env.ARBI_XT_SEL_SEARCH || 'input[class*="search_input__"],input[placeholder*="адрес криптовалюты"],input[placeholder*="контракт"]',
  // Открывашка дропдауна выбора пары — заголовок пары (h1). Доп. фолбэк-контейнеры поиска.
  searchOpen: process.env.ARBI_XT_SEL_SEARCH_ICON || '[class*="symbol_search__"],[class*="market_search__"],[class*="searchIconWrapper"]',
  // Числовые поля формы (3 шт: цена, кол-во, сумма) — общий класс на все три.
  // <input class="number_main__Ym0oL number_input__eI_8A" inputmode="decimal">
  // ПЕРВЫЙ input = цена, ВТОРОЙ = количество, третий (сумма) заполняется сам.
  numberInput: process.env.ARBI_XT_SEL_NUMBER || 'input[class*="number_input__"]',
  // Кнопка САБМИТА ордера — ТОЛЬКО с классом tradeLimit_btnSubmit__ (отличает
  // сабмит "Купить TIG" от вкладки-переключателя "Купить"). ПОДТВЕРЖДЕНО на бою
  // 2026-07-08: <button class="btnTxt tradeLimit_btnSubmit__GX8wE btnBuy">Купить TIG</button>.
  // Кнопка неактивной стороны в DOM ОТСУТСТВУЕТ, пока не выбрана вкладка стороны.
  submitBuy: process.env.ARBI_XT_SEL_BUY || 'button[class*="tradeLimit_btnSubmit__"].btnBuy',
  submitSell: process.env.ARBI_XT_SEL_SELL || 'button[class*="tradeLimit_btnSubmit__"].btnSell',
  // Общий сабмит (активной стороны) — фолбэк, если side-qualified не нашёлся.
  submit: process.env.ARBI_XT_SEL_SUBMIT || 'button[class*="tradeLimit_btnSubmit__"]',
  // Переключатель стороны — вкладки над формой. Текст РОВНО "Купить"/"Продать"
  // (сабмит — "Купить TIG", поэтому анкер ^...$ его не заденет). Sell-вкладка НЕ
  // имеет класса btnSell пока неактивна → выбираем по ТЕКСТУ. ПОДТВЕРЖДЕНО 2026-07-08.
  sideBuyRe: process.env.ARBI_XT_SIDE_BUY_RE || '^\\s*(Купить|Buy)\\s*$',
  sideSellRe: process.env.ARBI_XT_SIDE_SELL_RE || '^\\s*(Продать|Sell)\\s*$',
  // Вкладка Limit (best-effort по тексту).
  limitTab: process.env.ARBI_XT_SEL_LIMIT || 'text=/^(Limit|Лимит|Лимитный)$/i',
  // Кнопка подтверждения в модалке ордера (появляется не всегда).
  confirm: process.env.ARBI_XT_SEL_CONFIRM || 'button:has-text("Confirm"),button:has-text("Подтвердить"),button:has-text("确认")',
  // Строка результата в выпадающем поиске. ПОДТВЕРЖДЕНО на бою 2026-07-08:
  // <div class="list_content__…"><div class="list_pairName__…"><b>TIG</b><span>/USDT</span>…
  // Кликаем строку list_content (текст пары внутри — фильтр по hasText в changePairSpa).
  searchResult: process.env.ARBI_XT_SEL_SEARCH_RESULT || '[class*="list_content__"],[class*="list_pairName__"],[class*="searchResult"],[class*="result-item"]',
};
// Общие хелперы страницы (ввод/оверлеи/модалки/готовность сабмита) — один код на три
// биржи, различия — в профиле `page-driver.js`.
const { typeNumber, fastSetInputs, isSubmitReady, dismissBlockingModal, dismissOverlays, loginWall } = require('./page-driver').driverFor('xt', SELECTORS);
const { loginRequiredError } = require('./page-driver');

// Канон "BASE/QUOTE" → путь пары XT "base_quote" (нижний регистр, underscore).
function toXtPair(symbol) {
  return String(symbol).toLowerCase().replace('/', '_');
}

/**
 * Содержит ли URL нужную пару — ТЕРПИМО к percent-кодировке. Токены с non-ASCII
 * именем (напр. китайское 币安底裤_usdt) в адресной строке XT кодируются
 * (%E5%B8%81…), поэтому сырое u.includes('/trade/币安底裤_usdt') НЕ находит
 * совпадения НИКОГДА → ложный вывод «пара не открыта» → лишняя смена пары/
 * перезагрузка, и ложный timeout завершения SPA. Сравниваем и сырой, и
 * декодированный URL.
 */
function urlHasPair(u, pair) {
  const needle = '/trade/' + String(pair).toLowerCase();
  let dec = u;
  try { dec = decodeURIComponent(u); } catch { /* битый % — оставляем сырой */ }
  return String(u).toLowerCase().includes(needle) || String(dec).toLowerCase().includes(needle);
}

/**
 * Находит уже открытую страницу xt.com в контексте профиля, либо открывает
 * новую. Возвращает Playwright Page.
 */
async function getXtPage(context, pair, log) {
  const wantUrl = TRADE_URL_TMPL.replace('{pair}', pair);
  // Переиспользуем существующую вкладку xt.com (там живая залогиненная сессия).
  // Спящая вкладка (экономия памяти) физически на about:blank, но помнит свой URL.
  // ⚠️ Без этого поиск её НЕ ВИДЕЛ и открывал ДУБЛЬ рядом (жалоба оператора
  // 2026-08-30): спящих вкладок XT копилось всё больше. Образец — getMexcPage.
  let sleeping = null;
  let sleepingSame = null; // спящая вкладка ИМЕННО этой пары
  let firstLive = null; // первая живая вкладка XT не на нашей паре
  for (const p of context.pages()) {
    let u = '';
    try { u = p.url(); } catch { /* закрыта */ }
    if (!u.startsWith(XT_ORIGIN) && typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl.startsWith(XT_ORIGIN)) {
      if (urlHasPair(p.__arbiSleepUrl, pair)) sleepingSame = p;
      if (!sleeping) sleeping = p;
      continue;
    }
    if (u.startsWith(XT_ORIGIN)) {
      // Уже на нужной паре — тёплая вкладка (терпимо к кодировке URL). Плюс
      // DOM-подтверждение: заголовок пары h1 содержит base токена — надёжно даже
      // если XT кладёт в URL внутренний id вместо имени. Тёплая вкладка → НИКАКОЙ
      // смены пары/перезагрузки: ордер уходит напрямую (та самая жалоба по ST).
      // switched=false → пара НЕ менялась: React-обработчик кнопки ордера уже
      // «живой», первый клик отправит POST сразу.
      if (urlHasPair(u, pair)) return { page: markPairTab(p), cold: false, switched: false };
      const [base, quote = 'usdt'] = String(pair).split('_');
      const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // CR-1: граница токена И КВОТА — иначе (а) STIG-вкладка ложно тёплая для TIG,
      // (б) вкладка TIG/BTC ложно тёплая для TIG_USDT → ордер на ЧУЖОЙ книге без навигации.
      const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + esc(base) + '\\s*/\\s*' + esc(quote) + '(?![A-Za-z0-9])', 'i') })
        .first().isVisible().catch(() => false);
      if (h1Match) return { page: markPairTab(p), cold: false, switched: false };
      // Кандидат под смену пары / место в пуле — решаем ПОСЛЕ осмотра ВСЕХ вкладок.
      if (!firstLive) firstLive = p;
    }
  }
  // Тёплой вкладки пары нет. Раньше решение принималось на ПЕРВОЙ чужой вкладке
  // XT, не глядя дальше: вкладка нужной пары второй в списке → открывался ДУБЛЬ,
  // а уборка закрывала обе — каждый следующий ордер шёл «с холодной» (лог 05.09:
  // page=4072мс на TRUU при живой вкладке). Теперь дубль невозможен по построению.
  // СПЯЩАЯ ВКЛАДКА ЭТОЙ ЖЕ ПАРЫ — будим её, а не открываем соседку (лог оператора
  // 2026-09-08: спящая STONK + живая чужая пара → вторая вкладка STONK, уборка
  // закрыла обе). Проверяем ДО пула.
  if (sleepingSame) {
    log(`Бужу спящую вкладку своей пары: ${wantUrl}`);
    sleepingSame.__arbiSleepUrl = null;
    await sleepingSame.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    return { page: markPairTab(sleepingSame), cold: true, switched: true };
  }
  if (firstLive) {
    const p = firstLive;
    // ПУЛ ТЁПЛЫХ ВКЛАДОК: место есть → открываем паре СВОЮ вкладку вместо смены
    // пары в чужой. Вкладка прежней пары остаётся тёплой, обе дальше работают
    // без навигации. Пул полон → прежний путь (SPA-смена ниже).
    if (canOpenPairTab(context, XT_ORIGIN)) {
      log(`Открываю отдельную вкладку под пару (пул тёплых вкладок): ${pair}`);
      const fresh = markPairTab(markOwned(await newBackgroundPage(context)));
      await fresh.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      // Навигация не состоялась (прокси/сеть) — не оставляем пустую about:blank вкладку
      // и не заполняем форму на пустой странице: закрываем и честно отказываем.
      if (String(fresh.url()).startsWith('about:')) {
        await fresh.close().catch(() => {});
        throw new Error(`страница пары не открылась (${wantUrl}) — проверьте прокси/сеть профиля`);
      }
      return { page: fresh, cold: true, switched: true };
    }
    // Смена пары ПО УМОЛЧАНИЮ — SPA-поиск (без перезагрузки): форма остаётся
    // ТЁПЛОЙ. goto-режим доступен через ARBI_XT_NAV=goto.
    const navMode = (process.env.ARBI_XT_NAV || 'spa').toLowerCase();
    if (navMode === 'goto') {
      log(`Открываю страницу токена с нуля (goto): ${pair}`);
      await p.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      return { page: p, cold: true, switched: true };
    }
    const r = await changePairSpa(p, pair, log);
    return { page: p, cold: !r.spa, switched: true };
  }
  // Живых вкладок XT нет, но есть СПЯЩАЯ — будим её вместо открытия дубля.
  if (sleeping) {
    log(`Бужу спящую вкладку XT: ${wantUrl}`);
    sleeping.__arbiSleepUrl = null;
    await sleeping.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    return { page: sleeping, cold: true, switched: true };
  }
  log(`Открываю страницу XT: ${wantUrl}`);
  const page = markOwned(await newBackgroundPage(context));
  await page.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  return { page, cold: true, switched: true }; // первая загрузка вкладки → форма «сырая»
}

/**
 * Смена торговой пары БЕЗ перезагрузки страницы — через строку поиска сайта
 * (как это делает пользователь вручную). Best-effort: любой сбой → фолбэк на
 * page.goto (XT может быть SPA или нет — фолбэк обязателен).
 * @returns {Promise<{spa:boolean}>} spa=true если сменили без перезагрузки.
 */
/**
 * Открыть дропдаун выбора пары и сфокусировать его строку поиска; вернуть её локатор.
 *
 * Ключевое (подтверждено оператором 2026-07-09): поиск пары XT спрятан ВНУТРИ дропдауна,
 * который открывается кликом по ЗАГОЛОВКУ текущей пары <h1>BASE/USDT>. Поэтому:
 * 1) клик по заголовку-h1 (содержит "/") → дропдаун с поиском и списком пар;
 * 2) ждём поле поиска ВИДИМЫМ (не открылось — throw → быстрый фолбэк на перезагрузку);
 * 3) фокус ТРОЙНЫМ КЛИКОМ мышью (element-targeted). НЕ page-level Ctrl+A/JS focus —
 *    они выделяли всю страницу, а ввод уходил в никуда.
 */
async function focusSearchInput(page) {
  // ⚠️ ГЛАВНАЯ причина медленного 1-го ордера (перезагрузка вместо SPA): залипшая
  // risk/ST-модалка от ПРОШЛОГО токена (напр. 币安底裤 «Предупреждение о рисках» с
  // «Понятно», не нажатым пользователем) перехватывает pointer events → клик по h1
  // НЕ открывает дропдаун выбора пары → поле поиска не становится visible → timeout
  // → фолбэк на перезагрузку (6с). Закрываем модалку ПЕРЕД кликом (дёшево, ~мс).
  await dismissBlockingModal(page);
  // Открыть дропдаун ВЫБОРА ПАРЫ кликом ТОЛЬКО по заголовку пары <h1>BASE/USDT>.
  // ВАЖНО: НЕ кликаем иконку хедер-поиска (_searchIconWrapper_) — она открывает
  // ГЛОБАЛЬНЫЙ поиск (Деривативы/Спот/Функции/История поиска), а не список пар, и ввод
  // уходит не туда → result-item не находит пару → перезагрузка (ловили на скрине).
  const h1 = page.locator('h1', { hasText: '/' }).first();
  await h1.click({ timeout: 2000 }).catch(() => {});
  // Поле поиска ПАРЫ внутри дропдауна (placeholder "Введите адрес…", class search_input__).
  const input = page.locator(SELECTORS.search).first();
  try {
    await input.waitFor({ state: 'visible', timeout: 2500 });
  } catch (e) {
    // Поле не появилось — вероятно модалка возникла/перехватила клик уже ПОСЛЕ нашего
    // dismiss (или h1-клик не прошёл). Закрываем ещё раз и повторяем клик один раз
    // (force — на случай остаточного невидимого оверлея) — самовосстановление вместо
    // немедленной перезагрузки.
    await dismissBlockingModal(page);
    await h1.click({ timeout: 1500, force: true }).catch(() => {});
    await input.waitFor({ state: 'visible', timeout: 2500 });
  }
  await input.scrollIntoViewIfNeeded({ timeout: 1000 }).catch(() => {});
  // ФОКУС без указателя: input.focus() = DOM-focus, не требует поле в видимой области
  // (клик мышью падал "Element is outside of the viewport", когда дропдаун за окном).
  await input.focus();
  return input;
}

async function changePairSpa(page, pair, log) {
  const [base, quote] = String(pair).split('_');
  // Путь ДО перехода — чтобы finishSpa засчитал успех по САМОМУ ФАКТУ смены URL для
  // токенов, где displayName ≠ coinName (в адресе внутренний тикер, а не имя): ни pair,
  // ни base в h1 не совпадут, и раньше finishSpa падал в timeout 4с → перезагрузка.
  let prevPath = '';
  try { prevPath = await page.evaluate(() => location.pathname); } catch { /* игнор */ }
  const finishSpa = async () => {
    // Завершение SPA-перехода терпимо к кодировке URL И к тому, что XT может
    // держать в адресе внутренний id: успех, если decoded pathname содержит пару
    // ИЛИ заголовок h1 уже показывает base токена (напр. 币安底裤/USDT). Раньше
    // сырое includes('/trade/币安底裤_usdt') не совпадало → timeout 4с → перезагрузка.
    await page.waitForFunction((args) => {
      let dec = location.pathname;
      try { dec = decodeURIComponent(location.pathname); } catch { /* оставляем сырой */ }
      const path = (dec + ' ' + location.pathname).toLowerCase();
      if (path.includes('/trade/' + args.pair)) return true;
      const h1 = document.querySelector('h1');
      if (h1 && (h1.textContent || '').toLowerCase().includes(args.base)) return true;
      // displayName ≠ coinName: URL сменился на ДРУГУЮ торговую пару (не прежнюю).
      return !!(args.prev && location.pathname !== args.prev && /\/trade\//i.test(location.pathname));
    }, { pair, base: String(base).toLowerCase(), prev: prevPath }, { timeout: 4000 });
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 4000 }).catch(() => {});
  };

  let step = 'search-input';
  try {
    const input = await focusSearchInput(page);
    // Ввод ТОЛЬКО в поле (element-targeted, БЕЗ указателя/viewport): выделяем старый
    // текст в поле и заменяем вводом. Никакого page-level Ctrl+A → страница не выделяется.
    await input.selectText().catch(() => {});
    // delay 0 (было 20мс/символ): ввод залпом реальными keystroke-событиями (React
    // фильтр поиска триггерится) — экономит десятки мс без риска (это не числовое
    // поле ордера, к которому XT капризен). Переопределяемо ARBI_XT_SEARCH_DELAY.
    await input.pressSequentially(base, { delay: Number(process.env.ARBI_XT_SEARCH_DELAY || 0) });
    step = 'result-item';
    // Строка результата именно нужной пары (в выпадающем несколько токенов).
    // CR-1: экран + левая граница токена — «TIG/USDT» без границы матчил клон «STIG/USDT»
    // → клик уходил в чужую пару (pairGate поймал бы, но ордер срывался и время терялось).
    const escB = String(base).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const result = page.locator(SELECTORS.searchResult, { hasText: new RegExp('(?<![A-Za-z0-9])' + escB + `\\s*/?\\s*${(quote || '').toUpperCase()}`, 'i') }).first();
    await result.waitFor({ state: 'visible', timeout: 3500 });
    await result.click({ timeout: 2000 });
    step = 'url-change';
    await finishSpa();
    log(`Смена пары через поиск (SPA, без перезагрузки): ${pair}`);
    return { spa: true };
  } catch (e) {
    // Диагностика: какие поля ввода / элементы поиска реально есть на странице —
    // чтобы подобрать точный ARBI_XT_SEL_SEARCH без гадания (как чинили форму MEXC).
    if (step === 'search-input') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 12)
          .map((i) => ({ ph: i.placeholder || '', al: i.getAttribute('aria-label') || '', cls: String(i.className || '').slice(0, 45), t: i.type }));
        const searchish = Array.from(document.querySelectorAll('[class*="earch" i],[aria-label*="search" i],[aria-label*="поиск" i]')).filter(vis).slice(0, 6)
          .map((e) => ({ tag: e.tagName, al: e.getAttribute('aria-label') || '', cls: String(e.className || '').slice(0, 45) }));
        return { inputs, searchish };
      }).catch(() => ({}));
      console.log('[xt-exec] [diag поиск] ' + JSON.stringify(diag).slice(0, 950));
    }
    // Диагностика провала на строке-результате: какие строки реально в выпадающем
    // списке (класс+текст) — чтобы подобрать точный ARBI_XT_SEL_SEARCH_RESULT / понять,
    // почему нужная пара не подхватилась (частая причина медленного 1-го ордера).
    if (step === 'result-item') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const rows = Array.from(document.querySelectorAll('[class*="list_content__"],[class*="list_pairName__"],[class*="earch" i] [class*="item" i],[class*="result" i]'))
          .filter(vis).slice(0, 10)
          .map((e) => ({ cls: String(e.className || '').slice(0, 50), txt: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40) }));
        return { rows };
      }).catch(() => ({}));
      console.log('[xt-exec] [diag результат] ' + JSON.stringify(diag).slice(0, 950));
    }
    log(`SPA-навигация не удалась на шаге «${step}» (${String(e.message).slice(0, 50)}) — фолбэк на перезагрузку`);
    await page.goto(TRADE_URL_TMPL.replace('{pair}', pair), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    return { spa: false };
  }
}

/**
 * ПОДТВЕРЖДАЕТ (не закрывает!) модалку XT «Цена вашего ордера на X% выше/ниже
 * последней цены исполнения. Вы уверены?» — она появляется, когда лимитная цена
 * далеко от рынка (ставим в стакан / в 2× ниже — штатный сценарий оператора).
 * Без подтверждения order/place НЕ уходит. Отмечаем чекбокс «Никаких подсказок в
 * течение 1 часа» (модалка не будет мешать час) и жмём primary-кнопку подтверждения
 * (НЕ «Отмена»). Возвращает true, если подтвердили.
 */
async function confirmOrderPrompt(page) {
  return page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('.ant-modal-wrap,[class*="ant-modal-confirm"],[role="dialog"],[class*="odal"]')).filter(vis);
    for (const m of modals) {
      const txt = (m.innerText || '').replace(/\s+/g, ' ').trim();
      // Модалка подтверждения цены вне рынка (RU/EN). НЕ баланс/ошибка (те закрываем).
      const isPricePrompt = /уверен|are you sure|последней цены|last (traded )?price|% (выше|ниже|higher|lower)|отклонени|deviat/i.test(txt);
      if (!isPricePrompt) continue;
      if (/insufficient|not enough|недостаточн/i.test(txt)) continue;
      // Чекбокс «Никаких подсказок в течение 1 часа» — снимаем модалку на час.
      const cb = m.querySelector('input[type="checkbox"]');
      if (cb && !cb.checked) { try { cb.click(); } catch (_) {} }
      // Primary-кнопка подтверждения: «Подтвердить/Да/Продолжить/Уверен/OK/Confirm» —
      // НЕ «Отмена/Cancel/Нет».
      const btns = Array.from(m.querySelectorAll('button.ant-btn-primary,button'));
      const btn = btns.find((b) => vis(b)
        && /подтверд|confirm|продолж|continue|^да$|уверен|^ок$|^ok$|sure/i.test((b.innerText || '').trim())
        && !/отмен|cancel|^нет$|назад|back/i.test((b.innerText || '').trim()));
      if (btn && vis(btn)) { try { btn.click(); return true; } catch (_) {} }
    }
    return false;
  }).catch(() => false);
}

/**
 * ST-токен? У ST-токенов XT рядом с заголовком пары стоит метка «ST» (см. скрин
 * оператора: «WFCA/USDT ST»). Определяем это ПРЯМО ИЗ DOM — тогда знаем про
 * risk-модалку «Предупреждение о рисках» ЗАРАНЕЕ, даже для нового токена, которого
 * ещё нет в общей базе known_tokens (не дожидаясь, пока модалка перебьёт форму).
 */
async function detectStToken(page) {
  return page.evaluate(() => {
    const h1 = document.querySelector('h1');
    if (!h1) return false;
    // Поднимаемся к контейнеру шапки пары и ищем короткий leaf-бейдж ровно «ST».
    let root = h1;
    for (let i = 0; i < 4 && root.parentElement; i++) root = root.parentElement;
    const els = Array.from(root.querySelectorAll('*'));
    return els.some((el) => el.children.length === 0 && /^ST$/.test((el.textContent || '').trim()));
  }).catch(() => false);
}

/**
 * ПРОГРЕВ формы БЕЗ выставления ордера — БЕЗОПАСНО, ничего не покупаем/продаём.
 * Грузит страницу пары, закрывает промо-оверлеи, дожидается готовности лимит-формы
 * (≥2 number-инпутов + кнопки Buy/Sell = React догидрировался). БЕЗ единого клика
 * по кнопке ордера.
 */
async function warmupForm(context, pair, log) {
  const { page, cold } = await getXtPage(context, pair, log);
  await dismissOverlays(page);
  // ST-детект НА ПРОГРЕВЕ: терминал открывает web-токен → warmup. Если это ST-токен
  // (метка «ST» в DOM), закрываем «Предупреждение о рисках» здесь и возвращаем
  // riskModal=true → терминал запишет токен в ОБЩУЮ базу known_tokens ЕЩЁ ДО первого
  // ордера. Тогда у ЛЮБОГО пользователя (не только у того, кто первым столкнулся)
  // ордер по этому ST-токену идёт уже с превентивным закрытием — быстро.
  let sawSt = await detectStToken(page);
  if (sawSt) {
    for (let i = 0; i < 3; i++) {
      const r = await dismissBlockingModal(page);
      if (r && r.closed) break;
      await page.waitForTimeout(120);
    }
  }
  let inputs = await page.$$(SELECTORS.numberInput);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: 1000 }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 9000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.numberInput);
  }
  // Ждём общий сабмит (активной стороны). Кнопка неактивной стороны в DOM
  // отсутствует до выбора вкладки — её здесь НЕ ждём (иначе таймаут впустую).
  await page.waitForSelector(SELECTORS.submit, { state: 'visible', timeout: 9000 }).catch(() => {});
  // НЕ ждём enabled-состояния кнопки на ПУСТОЙ форме прогрева: если кнопка «Купить»
  // без значений disabled, цикл ожидания крутил бы ~5с (25×200мс) ВПУСТУЮ, и
  // реальный ордер, пришедший следом, эти 5с ждал бы в очереди (warmup и ордер
  // сериализованы в одном профиле). Форма уже готова (numberInput есть, кнопка
  // видима); enabled проверит executeIntent ПОСЛЕ заполнения. Короткая догидрация.
  await page.waitForTimeout(Number(process.env.ARBI_XT_WARMUP_SETTLE_MS || 250));
  await dismissOverlays(page);
  // Ещё раз проверим ST после гидрации (метка могла появиться позже) + добьём модалку.
  if (!sawSt) sawSt = await detectStToken(page);
  if (sawSt) { await dismissBlockingModal(page).catch(() => {}); }
  {
    const lw = await loginWall(page);
    if (lw.wall) { log(`Нет входа в аккаунт XT в этом профиле (на форме: «${lw.text}») — прогрев невозможен`); return { ok: false, cold, loginRequired: true, error: loginRequiredError('XT') }; }
  }
  log(`Форма прогрета (${pair})${cold ? ' [была холодная]' : ''}${sawSt ? ' [ST]' : ''} — ордер НЕ ставился`);
  return { ok: true, cold, riskModal: sawSt };
}

/**
 * Исполняет ОДНО намерение в живой странице XT.
 *
 * @param {import('playwright').BrowserContext} context  контекст профиля аккаунта
 * @param {object} intent  { id, accountId, symbol, side, type, price, quantity, dryRun }
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{ok:boolean, orderId?:string, error?:string}>}
 */
async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  const pair = toXtPair(intent.symbol);

  // v1: только limit (как и терминал-реплей). Market — отдельная вёрстка формы.
  if (intent.type !== 'limit' || intent.price == null) {
    return { ok: false, error: 'Стадия 3 v1: поддержан только limit-ордер с ценой' };
  }
  // IM-1: развернуть экспоненту (1.2e-7 → 0.00000012) и отсечь мусорные значения ДО
  // ввода. У XT это критично: "1.2e-7" в поле форма могла отправить как "1.2"
  // (лимитка в миллионы раз выше рынка).
  const priceStr = formatDecimal(intent.price);
  const qtyStr = formatDecimal(intent.quantity);
  if (!isPlainPositive(priceStr) || !isPlainPositive(qtyStr)) {
    return { ok: false, error: `Некорректные цена/количество: price=${intent.price} qty=${intent.quantity}. Ордер НЕ отправлен.` };
  }
  intent = { ...intent, price: priceStr, quantity: qtyStr };

  const t0 = Date.now();
  const { page, cold, switched } = await getXtPage(context, pair, log);
  const tPage = Date.now();
  // Сброс метки risk-модалки за эту попытку (dismissBlockingModal её выставит).
  try { page.__arbiSawRisk = false; } catch { /* игнор */ }
  // ПРЕВЕНТИВНОЕ закрытие risk-модалки ST-токена. Источники «токен = ST»:
  //   1) hints.riskModal из ОБЩЕЙ базы known_tokens (терминал, едино для всех юзеров);
  //   2) метка «ST» ПРЯМО В DOM заголовка пары — работает для НОВОГО токена, которого
  //      ещё нет в базе (не ждём, пока модалка перебьёт поиск/форму — жалоба оператора).
  // Если ST — активно закрываем «Понятно» (модалка всплывает не мгновенно → пара
  // попыток с паузой) и метим __arbiSawRisk, чтобы терминал записал токен в базу.
  const stHint = !!(intent.hints && intent.hints.riskModal);
  // Превентивно закрываем risk-модалку ST-токена ТОЛЬКО на СВЕЖЕЙ странице
  // (cold/switched): именно там модалка всплывает при открытии/смене пары. На ТЁПЛОЙ
  // переиспользуемой вкладке её уже закрыл warmup, а DOM-скан detectStToken + цикл
  // dismiss (до 3×120мс) на КАЖДОМ ордере — лишние ~0.2-0.4с, главный вклад в задержку
  // ПРОДАЖИ ST-токенов (напр. 币安底裤). Если модалка всплывёт позже — её добьёт
  // dismissBlockingModal/typeNumber перед вводом. ST-метку для базы уже записал warmup.
  if (cold || switched) {
    const stBadge = stHint ? true : await detectStToken(page);
    if (stBadge) {
      try { page.__arbiSawRisk = true; } catch { /* игнор */ }
      for (let i = 0; i < 3; i++) {
        const r = await dismissBlockingModal(page);
        if (r && r.closed) break;
        await page.waitForTimeout(120);
      }
    }
  }

  // Собираем URL всех POST-запросов страницы за попытку — чтобы в диагностике
  // увидеть, ушёл ли ордер вообще и на какой URL (вдруг мимо ORDER_PLACE_RE).
  const postUrls = [];
  // ПОСТОЯННЫЙ захват ОТВЕТА ордера. waitForResponse, вызванный ПОВТОРНО (после
  // таймаута первого ожидания), пропускает ответ, пришедший в щель между таймаутом и
  // новой подпиской → 8с впустую → ложная «order/place не ушёл», хотя POST ушёл и
  // заявка ВСТАЛА (ловили на 币安底裤: в diag POST=[...order/order], а результат —
  // ошибка). Этот листенер подписан ДО клика и не пропускает ничего.
  let capturedOrderResp = null;
  // CR-2: ответ ордера захватываем ТОЛЬКО на POST-запрос, реально ушедший В ЭТОЙ
  // попытке (firedReqs). Иначе на тёплой вкладке ловился ПОЗДНИЙ ответ ПРОШЛОГО
  // ордера → чужой orderId, ложный успех. Листенеры подписаны после t0.
  const firedReqs = new Set();
  const onResp = (r) => {
    try {
      if (r.request().method() !== 'POST') return;
      postUrls.push(r.url().replace(/\?.*$/, ''));
      if (!capturedOrderResp && firedReqs.has(r.request())) capturedOrderResp = r;
    } catch { /* игнор */ }
  };
  page.on('response', onResp);

  // Отслеживаем, УШЁЛ ли реальный POST order/place (не ответ, а сам запрос). Нужно
  // для БЕЗОПАСНОГО быстрого повтора: если первый клик не породил запрос ордера —
  // повтор безопасен; если запрос УЖЕ ушёл (а ответ медленный из-за прокси) —
  // повторять клик НЕЛЬЗЯ (задвоим ордер), надо просто дождаться ответа.
  let orderReqFired = false;
  const onReq = (req) => { try { if (req.method() === 'POST' && ORDER_PLACE_RE.test(req.url())) { orderReqFired = true; firedReqs.add(req); } } catch { /* игнор */ } };
  page.on('request', onReq);
  // IM-7: единая точка снятия листенеров. Все ранние return ниже (форма не распознана,
  // поля не совпали, сверка пары) обязаны звать cleanup(), иначе листенеры копятся на
  // долгоживущей странице (MaxListenersExceededWarning + рост шанса аномалий захвата).
  const cleanup = () => { page.off('response', onResp); page.off('request', onReq); };

  const TAB_TIMEOUT = Number(process.env.ARBI_XT_TAB_TIMEOUT_MS || 400);

  // Быстрая проверка: лимит-форма уже готова? Если ≥2 инпутов есть — вкладку Limit
  // НЕ трогаем. Клик по Limit нужен только если формы ещё нет.
  let inputs = await page.$$(SELECTORS.numberInput);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: TAB_TIMEOUT }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 8000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.numberInput);
  }
  const tTabs = Date.now();

  if (inputs.length < 2) {
    cleanup();
    return { ok: false, error: `Форма ордера XT не распознана (найдено инпутов: ${inputs.length}). Проверьте ARBI_XT_SEL_NUMBER.` };
  }
  await dismissOverlays(page);
  // Закрыть блокирующую модалку-ошибку от ПРОШЛОГО ордера (напр. нехватка баланса),
  // иначе она перехватит клики и завалит эту заявку.
  await dismissBlockingModal(page);
  // ВЫБОР СТОРОНЫ Buy/Sell ПЕРЕД вводом. Форма XT — переключатель (вкладки
  // "Купить"/"Продать"); кнопка-сабмит неактивной стороны в DOM отсутствует, а
  // переключение стороны может сбросить поля — поэтому сторону выбираем до заполнения.
  // Вкладку берём по ТЕКСТУ (Sell-вкладка не имеет класса btnSell пока неактивна).
  // Сабмит нужной стороны присутствует в DOM ТОЛЬКО когда форма уже на этой стороне
  // (кнопка неактивной стороны отсутствует). Используем это как надёжный признак: если
  // сабмит нужной стороны УЖЕ есть — форма на нужной стороне, НЕ переклацываем (экономим
  // клик + фиксированную перерисовку ~300мс). Иначе кликаем вкладку и ждём появления
  // сабмита нужной стороны (быстрый polling вместо фиксированных 300мс).
  const sideRe = intent.side === 'sell' ? SELECTORS.sideSellRe : SELECTORS.sideBuyRe;
  const wantSubmitSel = intent.side === 'sell' ? SELECTORS.submitSell : SELECTORS.submitBuy;
  if (await page.$(wantSubmitSel)) {
    log(`Сторона уже ${intent.side} — без переклика`);
  } else {
    try {
      const toggle = page.locator('button', { hasText: new RegExp(sideRe, 'i') }).first();
      await toggle.click({ timeout: 3000 });
      // Ждём появления сабмита ВЫБРАННОЙ стороны (форма перерисовалась) — обычно ~50мс,
      // вместо слепых 300мс. Признак безопасный: это та же кнопка, что жмём при сабмите.
      await page.waitForSelector(wantSubmitSel, { state: 'visible', timeout: 1500 }).catch(() => {});
      log(`Сторона выбрана: ${intent.side}`);
    } catch (e) {
      log(`Не удалось выбрать вкладку стороны ${intent.side} (${String(e.message).slice(0, 50)}) — продолжаю`);
    }
  }
  {
    const lw = await loginWall(page);
    if (lw.wall) { cleanup(); log(`Нет входа в аккаунт XT в этом профиле (на форме: «${lw.text}») — заявка НЕ отправлена`); return { ok: false, loginRequired: true, error: loginRequiredError('XT') }; }
  }
  log(`Заполняю форму: price=${intent.price} amount=${intent.quantity} (${intent.side})${cold ? ' [холодная]' : ''}`);
  // Сабмит нужной стороны; если side-qualified не появился — общий сабмит активной стороны.
  let submitSel = intent.side === 'sell' ? SELECTORS.submitSell : SELECTORS.submitBuy;
  let sideQualified = true;
  if (!(await page.$(submitSel))) { submitSel = SELECTORS.submit; sideQualified = false; }
  // Заполнение цены + количества с ПРОВЕРКОЙ ФАКТИЧЕСКИХ значений. XT не принимает
  // программный value для поля КОЛИЧЕСТВА (React/слайдер), а кнопка "Buy TIG" активна
  // даже при пустом кол-ве — поэтому опираться на isSubmitReady нельзя. Проверяем сами
  // значения и добиваем пустое поле реальным вводом с клавиатуры (свежий хэндл, т.к.
  // форма пересобирается после выбора стороны).
  const wantPrice = String(intent.price);
  // Точность количества, которую XT принял на этой паре в прошлый раз (усёк
  // 18.95734597 → 18.95): печатаем сразу усечённое — 5 знаков вместо 11, поле
  // количества XT принимает только посимвольный ввод по ~100 мс на знак (замер
  // 15.09: кол-во=1846 мс). Итоговая заявка та же — XT усекает всё равно.
  let wantQty = String(intent.quantity);
  const knownDec = XT_QTY_DEC.get(pair);
  if (knownDec != null && /^\d+\.\d+$/.test(wantQty)) {
    const [ip, fp] = wantQty.split('.');
    if (fp.length > knownDec) { wantQty = knownDec ? `${ip}.${fp.slice(0, knownDec)}` : ip; log(`Количество усечено до ${knownDec} зн. по прошлому ответу XT: ${wantQty}`); }
  }
  const wantP = parseFloat(wantPrice);
  const wantQ = parseFloat(wantQty);
  const readVals = () => page.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value));
  // Разбор фазы fill по шагам (#66: тюнить только по замеру). На бою она у XT
  // самая дорогая в ордере — 3537 мс из 4819 (оператор 15.09, TGC/USDT), при
  // page=3 и tabs=5. Из чего складывается, по одной цифре «fill=» не видно:
  // ожидание инициализации холодной формы, быстрая установка залпом, добивание
  // клавиатурой по полям и перечитывание. Считаем каждый шаг и печатаем одной
  // строкой — дальше режем то, что действительно дорого, а не по догадке.
  const fillMarks = { coldInit: 0, fast: 0, typed: 0, typedPrice: 0, typedQty: 0, reads: 0, attempts: 0 };
  const setField = async (idx, val) => {
    const cur = await page.$$(SELECTORS.numberInput);
    // Количество больше НЕ идёт посимвольно принудительно. Прежний `direct` выключал
    // вставку заодно с нативным сеттером, хотя React-поле XT не принимает именно
    // сеттер (fastSetInputs), а вставку — принимает (оператор проверил Ctrl+V руками).
    // typeNumber пробует вставку, строго проверяет результат и сам уходит на
    // посимвольный ввод, если поле её не приняло. Откат без выката: ARBI_XT_QTY_DIRECT=1.
    if (cur[idx]) await typeNumber(page, cur[idx], val, { direct: idx === 1 && process.env.ARBI_XT_QTY_DIRECT === '1' });
  };
  // Значение поля «похоже» на нужное: XT усекает по шагу токена, поэтому не точное
  // равенство, а близость (f ≈ want). Главное — отличить наше значение от значения
  // ПРОШЛОГО ордера (напр. 12.89 в поле, когда хотим 2.86 → далеко → перезаписать).
  const closeEnough = (v, want) => {
    const f = parseFloat(String(v).replace(/[,\s]/g, ''));
    return isFinite(f) && want > 0 && f <= want * 1.03 && f >= want * 0.85;
  };
  if (cold) {
    await page.waitForSelector(submitSel, { state: 'visible', timeout: 10000 }).catch(() => {});
    // ST-токены (напр. 币安底裤) на холодной странице показывают risk-модалку
    // «Предупреждение о рисках» → закрываем её (кнопка «Понятно»), иначе перехватит
    // клики по форме на 30с.
    await dismissBlockingModal(page);
    // ХОЛОДНАЯ форма: XT инициализирует форму АСИНХРОННО уже после появления кнопки —
    // проставляет рыночную цену и держит количество пустым. Если заполнить ДО этого,
    // React затрёт наши значения своими дефолтами (ловили: цена 0.10→0.1291, кол-во →
    // пусто → order/place не ушёл). Ждём, пока XT сам проставит цену (init завершён).
    // Цикл ВЫХОДИТ по появлению цены; потолок нужен лишь для неликвидных пар без last
    // price, где цена не приходит вовсе — там 25×150=3.75с горели ВСЕГДА. Порог/шаг в
    // env: на такой паре хватает меньшего ожидания (мы всё равно вводим свою цену сами).
    const initTries = Number(process.env.ARBI_XT_COLD_INIT_TRIES || 20);
    const initStep = Number(process.env.ARBI_XT_COLD_INIT_STEP_MS || 100);
    const tColdInit = Date.now();
    for (let i = 0; i < initTries; i++) {
      const v = await readVals().catch(() => []);
      if (v[0] && parseFloat(String(v[0]).replace(/[,\s]/g, '')) > 0) break;
      await page.waitForTimeout(initStep);
    }
    fillMarks.coldInit = Date.now() - tColdInit;
    await dismissBlockingModal(page); // модалка могла появиться за время init
  }
  // Заполняем оба поля так, чтобы КАЖДОЕ реально содержало нужное значение (строгая
  // проверка fieldFresh ниже). Поле количества на XT может сохранить значение прошлого
  // ордера (программный/быстрый ввод его не обновляет) → его надо перепечатать заново.
  const settleMs = Number(process.env.ARBI_XT_FILL_SETTLE_MS || 40); // было 120→60→40 (как BingX)
  // СТРОГАЯ проверка «поле УЖЕ содержит нужное значение» — в пределах одного шага
  // последнего отображаемого разряда XT (усечение/округление). В ОТЛИЧИЕ от closeEnough
  // (±%, широкая, для усадки по балансу) она НЕ принимает близкое-но-ЧУЖОЕ значение
  // прошлого ордера. Это критично: быстрый ввод (fastSetInputs) НЕ обновляет поле
  // КОЛИЧЕСТВА на XT → без строгой проверки закрепилась бы сумма прошлого ордера
  // (напр. 92.37 вместо 95.23, обе в пределах ±3% → ошибочная заявка). Здесь такое
  // поле признаётся «не своим» и добивается клавиатурой.
  // fieldFresh — единая строгая проверка из order-utils (M3: допуск от want, см. там).
  const bothFresh = (v) => fieldFresh(v[0], wantP) && fieldFresh(v[1], wantQ);
  let finalVals = [];
  // Быстрый путь (ARBI_XT_FAST_FILL, по умолчанию ВКЛ — как у BingX/MEXC): установка
  // обоих полей залпом нативным сеттером за один evaluate вместо посимвольного ввода
  // (~1.4с на бою → ~40мс). БЕЗОПАСНО: значения проверяются СТРОГО (fieldFresh); поле,
  // которое быстрый ввод не прижал (количество с React-слайдером), добивается
  // клавиатурой в цикле ниже, а ensureFilled перепроверяет перед кликом. Отключить:
  // ARBI_XT_FAST_FILL=0. Cold-форма — всегда посимвольно (React асинхронно затирает).
  if ((process.env.ARBI_XT_FAST_FILL || '1') === '1' && !cold) {
    const tFast = Date.now();
    await fastSetInputs(page, wantPrice, wantQty).catch(() => {});
    await page.waitForTimeout(settleMs);
    finalVals = await readVals().catch(() => []);
    fillMarks.fast = Date.now() - tFast;
  }
  // Посимвольный ввод: добиваем ЛЮБОЕ поле, которое ещё не содержит НУЖНОГО значения
  // (строгая проверка — чтобы не оставить сумму прошлого ордера). На холодной форме /
  // без быстрого пути finalVals=[] → печатаются оба.
  for (let attempt = 0; attempt < 3 && !bothFresh(finalVals); attempt++) {
    fillMarks.attempts = attempt + 1;
    // Раздельно по полям: замер 15.09 дал клавиатура=1354мс за ОДНУ попытку, и
    // по общей цифре не видно, кто из двух полей столько стоит. У XT поле
    // количества (React-слайдер) быструю вставку не принимает и всегда идёт
    // длинным путём — если цифры это подтвердят, на нём и будем резать.
    if (!fieldFresh(finalVals[0], wantP)) {
      const t = Date.now(); await setField(0, wantPrice); fillMarks.typedPrice += Date.now() - t;
    }
    if (!fieldFresh(finalVals[1], wantQ)) {
      const t = Date.now(); await setField(1, wantQty); fillMarks.typedQty += Date.now() - t;
    }
    fillMarks.typed = fillMarks.typedPrice + fillMarks.typedQty;
    await page.waitForTimeout(settleMs);
    const tRead = Date.now();
    finalVals = await readVals().catch(() => []);
    fillMarks.reads += Date.now() - tRead;
  }
  // CR-3: ЦЕНА — строгая проверка (fieldFresh, ±1 шаг разряда), НЕ closeEnough.
  // Широкий ±15% на цене пропускал бы sell на 15% ниже рынка (значение прошлого
  // ордера при сорванном добивании). Широкий допуск — ТОЛЬКО количеству (усадка по балансу).
  if (!fieldFresh(finalVals[0], wantP) || !closeEnough(finalVals[1], wantQ)) {
    console.log('[xt-exec] [diag заполнение] ' + JSON.stringify({ finalVals, wantPrice, wantQty }));
    cleanup();
    return { ok: false, error: `Поля не совпали с ордером: хотели цена=${wantPrice} кол-во=${wantQty}, в форме ${JSON.stringify(finalVals)}. Ордер НЕ отправлен.` };
  }
  log(`Поля заполнены: ${JSON.stringify(finalVals)} (хотели ${wantPrice}/${wantQty})`);
  // Учимся точности ТОЛЬКО когда XT реально усёк наше значение (иначе «20» → 0 знаков
  // было бы ложным уроком). Значение поля без разделителей тысяч.
  {
    // Хвостовая точка — это ТО ЖЕ усечение: XT, отсекая дробную часть целиком,
    // показывает «386204.», и прежняя проверка (`\.\d+` требует цифру ПОСЛЕ точки)
    // такое значение отвергала — урок не записывался НИКОГДА, и каждый следующий
    // ордер по паре снова печатал все 15 знаков вместо 6. Замер оператора 18.09
    // (TRUU/USDT, два ордера подряд): кол-во=1789 мс на 15 символов (~119 мс на
    // знак, поле количества XT принимает только посимвольный ввод), строки
    // «Количество усечено…» во втором ордере не было.
    const acc = String(finalVals[1] || '').replace(/[,\s]/g, '').replace(/\.$/, '');
    const accDec = (acc.split('.')[1] || '').length;
    const wantDec = (wantQty.split('.')[1] || '').length;
    // Учимся ТОЛЬКО когда целая часть совпала: тогда XT отрезал именно точность.
    // Разошлась целая часть — это усадка по балансу (closeEnough, ±15%), а не шаг
    // лота, и урок «столько-то знаков» был бы выдумкой (#54: догадка не гейт).
    const sameInt = acc.split('.')[0] === wantQty.split('.')[0];
    if (/^\d+(\.\d+)?$/.test(acc) && accDec < wantDec && sameInt) XT_QTY_DEC.set(pair, accDec);
  }
  const tFill = Date.now();
  log(`[timing fill] холодная_инициализация=${fillMarks.coldInit} быстрый_ввод=${fillMarks.fast} клавиатура=${fillMarks.typed}(цена=${fillMarks.typedPrice} кол-во=${fillMarks.typedQty}) перечитывание=${fillMarks.reads} попыток=${fillMarks.attempts} при fill=${tFill - tTabs}`);

  // CR-1 (learn-on-confirm): строгая сверка токена на странице с базой интента.
  // displayName≠coinName (GENSYN=«AI») легитимны — подтверждаются разово в терминале
  // (тогда приходит hints.coinAlias, блока нет). Без алиаса — блок со структурным
  // pairMismatch (терминал покажет «это верный токен?», сохранит алиас, повторит).
  const base = String(pair).split('_')[0];
  const pageBase = await page.evaluate(() => {
    for (const h of document.querySelectorAll('h1')) {
      const m = (h.textContent || '').trim().match(/([A-Za-z0-9一-鿿]+)\s*[/\-]\s*[A-Za-z]{2,}/);
      if (m) return m[1];
    }
    return null;
  }).catch(() => null);
  const gate = pairGate(pageBase, base, intent.hints && intent.hints.coinAlias);
  if (gate.block) {
    cleanup();
    if (gate.reason === 'unreadable') {
      return { ok: false, riskModal: !!page.__arbiSawRisk,
        error: `Не удалось прочитать пару на странице XT (ожидался ${base}) — ордер НЕ отправлен. Обновите страницу пары и повторите.` };
    }
    return { ok: false, pairMismatch: true, pageBase, wanted: base,
      error: `Биржа показывает пару ${pageBase}/…, а ордер для ${base}. Подтвердите, что это верный токен.`,
      riskModal: !!page.__arbiSawRisk };
  }
  if (gate.reason === 'alias') log(`M8: XT — ордер по ${base} пропущен по подтверждённому алиасу «${pageBase}» (доверенный реестр терминала для этой пары)`);

  // Один клик + ожидание ответа. Если ответа нет за attemptMs — возвращаем null
  // (заявка НЕ ушла — значит клик не отправил ордер, повтор безопасен).
  // У XT сторона выбирается кликом кнопки (Buy/Sell видны одновременно), поэтому
  // тут (в отличие от MEXC) НЕТ логики «активной вкладки» — просто жмём нужную кнопку.
  // Разбор фазы submit (#66): клик / поллинг ответа / модалки / ожидание ответа после.
  const xs = { attempts: 0, click: 0, poll: 0, modal: 0, wait: 0 };
  const clickAndWait = async (attemptMs) => {
    const respP = page.waitForResponse(
      (r) => firedReqs.has(r.request()),
      { timeout: attemptMs },
    );
    const respOrNull = respP.then((r) => r, () => null);
    // CR-2: POST ордера УЖЕ ушёл (мог уйти, пока дозаполняли/подтверждали) — повторный
    // клик ЗАДВОИТ ордер. Не кликаем: ждём захваченный ответ и возвращаем его.
    if (orderReqFired) {
      let cap = capturedOrderResp;
      for (let i = 0; !cap && i < Math.ceil(attemptMs / 100); i++) { await page.waitForTimeout(100); cap = capturedOrderResp; }
      return cap;
    }
    // Доверенный клик (CDP Input → isTrusted=true → анти-бот минтит подпись).
    // .catch: если модалка подтверждения (ant-modal-confirm) перехватывает клик,
    // НЕ роняем ордер жёсткой ошибкой (ловили на KTA: page.click Timeout 5000мс) —
    // идём в ветку __slow__ ниже, где жмём подтверждение и ждём ответ / повтор.
    xs.attempts++;
    const tClick = Date.now();
    await page.click(submitSel, { timeout: 3000, noWaitAfter: true }).catch(() => {});
    xs.click += Date.now() - tClick;
    // Ждём ЛИБО ответ, ЛИБО появление модалки — ПОЛЛИНГОМ (100мс), а не фиксированным
    // slowMs. Продажа лимиткой, пересекающей рынок, показывает модалку «может быть
    // исполнена сразу» быстро; фиксированное ожидание до ~1.2с перед её подтверждением
    // — это и была задержка продажи. Как только видим модалку — сразу подтверждаем
    // (ветка __slow__). Зеркало оптимизации BingX (0.4.18).
    const pollUntil = Math.min(Math.max(attemptMs - 150, 400), 1200);
    const startedAt = Date.now();
    let r = null;
    while (Date.now() - startedAt < pollUntil) {
      const raced = await Promise.race([respOrNull, new Promise((res) => setTimeout(() => res('__tick__'), 100))]);
      if (raced !== '__tick__') { r = raced; break; }
      const modalUp = await page.evaluate(() => {
        const vis = (e) => e && e.offsetParent !== null;
        return Array.from(document.querySelectorAll('[role="dialog"],[class*="odal" i],[class*="ialog" i]')).some(vis);
      }).catch(() => false);
      if (modalUp) { r = '__slow__'; break; }
    }
    xs.poll += Date.now() - startedAt;
    if (r === '__tick__' || r === null) r = '__slow__';
    const tModal = Date.now();
    if (r === '__slow__') {
      // Модалка «Недостаточно средств»? НЕ жмём confirm — внутри неё кнопка «Купить»
      // (= пополнение за фиат), и confirm-селектор по «Купить» попал бы по ней (лишний
      // клик/уход на пополнение). Сигналим наружу — там закроем и выйдем без повтора.
      const blk = await dismissBlockingModal(page);
      if (/insufficient|not enough|недостаточн/i.test(blk.text || '')) {
        return '__nofunds__';
      }
      // Модалка «Цена на X% выше/ниже последней — Вы уверены?» (лимитка вне рынка,
      // штатный сценарий: ставим в стакан). Её надо ПОДТВЕРДИТЬ, иначе ордер не уйдёт.
      // Отмечаем «Никаких подсказок час» + жмём «Подтвердить».
      const confirmedPrice = await confirmOrderPrompt(page);
      if (confirmedPrice) log('Подтвердил цену вне рынка (модалка «Вы уверены?»)');
      // Реальную модалку подтверждения ордера dismissBlockingModal НЕ трогает —
      // подтверждаем её кликом confirm (если не была модалка цены выше).
      if (!confirmedPrice) {
        // Только если кнопка УЖЕ на экране: безусловный клик ждал её все 1500 мс и
        // уходил в catch, когда модалки нет — а нет её почти всегда (зеркало правки
        // BingX 08.09; у XT на тёплой паре submit+resp=1802 при ответе биржи быстрее).
        const cbtn = page.locator(SELECTORS.confirm).first();
        if (await cbtn.isVisible().catch(() => false)) {
          await cbtn.click({ timeout: 1500, noWaitAfter: true })
            .then(() => log('Подтвердил модалку ордера'))
            .catch(() => { /* исчезла, пока жали */ });
        }
      }
      xs.modal += Date.now() - tModal;
      const tWait = Date.now();
      r = await respOrNull;
      xs.wait += Date.now() - tWait;
    }
    return r;
  };

  // СТРАХОВКА перед кликом: между заполнением и сабмитом холодная форма XT могла
  // сбросить поля (React ре-гидратация) → перезаполняем ЛЮБОЕ поле, где значение слетело.
  // Без этого ордер уходил с пустым количеством (ловили: поля=[цена,"",""]).
  const ensureFilled = async () => {
    await dismissBlockingModal(page); // убрать risk/ошибка-модалку, если перехватывает клики
    const v = await readVals().catch(() => []);
    if (!fieldFresh(v[0], wantP)) await setField(0, wantPrice);
    if (!fieldFresh(v[1], wantQ)) await setField(1, wantQty);
  };

  // Доверенный клик по кнопке сабмита + ОДИН повтор, если ордер не ушёл.
  // Первая попытка КОРОТКАЯ (2000мс, было 5000): на risk-token/Innovation-Zone парах
  // (WOJAK и т.п.) первый trusted-клик стабильно НЕ отправляет order/place, и заявку
  // ставит именно повтор — ждать 5с перед ним впустую (ловили submit+resp≈5.4с на бою).
  await ensureFilled();
  // M5 (XT): сверка стороны кнопки сабмита ПЕРЕД кликом. Клик по вкладке стороны выше
  // мог молча не сработать (таймаут → catch), и если при этом использовался общий
  // фолбэк-сабмит (sideQualified=false), кнопка АКТИВНОЙ стороны могла остаться
  // противоположной → sell ушёл бы как buy (класс дефекта M5 из MEXC, тут не было).
  // Читаем сторону РЕАЛЬНОЙ кнопки (класс btnBuy/btnSell + текст) и блокируем явно
  // противоположную. Нераспознанную не блокируем (как M5 MEXC — не ломать новый язык).
  if (!sideQualified) {
    const domSide = await page.$eval(submitSel, (el) => {
      const c = String(el.className || '');
      if (/btnSell/i.test(c)) return 'sell';
      if (/btnBuy/i.test(c)) return 'buy';
      const t = (el.textContent || '').toLowerCase();
      if (/sell|продать/.test(t)) return 'sell';
      if (/buy|купить/.test(t)) return 'buy';
      return '';
    }).catch(() => '');
    if (domSide && domSide !== intent.side) {
      cleanup();
      return { ok: false, error: `XT: сторона на форме (${domSide}) ≠ запрошенной (${intent.side}) — ордер НЕ отправлен (не удалось переключить вкладку стороны).` };
    }
  }
  log('Нажимаю кнопку ордера (trusted-клик)...');
  // На ТОЛЬКО ЧТО переключённой/холодной паре первый trusted-клик часто не рождает
  // POST (React ещё перепривязывает onClick после SPA) → первую попытку делаем
  // КОРОТКОЙ (ARBI_XT_RESP_TIMEOUT_FRESH_MS, ~800мс), чтобы быстрее перейти к повтору,
  // который заявку и ставит. На тёплой паре (switched=false) держим обычный таймаут —
  // там первый клик почти всегда срабатывает, короткий риск лишнего повтора не нужен.
  const firstMs = (switched || cold)
    ? Number(process.env.ARBI_XT_RESP_TIMEOUT_FRESH_MS || 800)
    : Number(process.env.ARBI_XT_RESP_TIMEOUT_MS || 2000);
  let resp = await clickAndWait(firstMs);
  // Модалка «Недостаточно средств» (баланса реально нет): повтор клика БЕСПОЛЕЗЕН
  // (та же модалка) и ВРЕДЕН (риск клика по «Купить»=пополнение — «лишний клик»,
  // на который жаловался оператор; + модалки копились). clickAndWait сигналит
  // '__nofunds__', ИЛИ проверяем сами при пустом ответе. Закрываем и выходим СРАЗУ
  // с понятной ошибкой, без повтора (быстрый fail вместо потери ~1.5-6с).
  // Модалка «Недостаточно средств» на ПЕРВОМ клике: clickAndWait её уже закрыл
  // крестиком (не жали «Купить» внутри — тот самый лишний клик; модалки не копятся).
  // ВАЖНО: после смены пары эта модалка ЧАСТО ЛОЖНАЯ (форма ещё не пересчитала
  // «Всего» → XT думает, что баланса нет), и тот же ордер проходит со ВТОРОЙ попытки.
  // Поэтому здесь НЕ фейлим — сбрасываем в null и идём в обычный повтор ниже; fail
  // только если недостаток ПОДТВЕРДИТСЯ на повторе.
  if (resp === '__nofunds__') {
    await dismissBlockingModal(page); // добить, если ещё висит
    resp = null;
  }
  if (!resp) {
    // Повторяем клик ТОЛЬКО если реальный запрос ордера НЕ ушёл — иначе (запрос ушёл,
    // ответ медленный из-за прокси) повтор задвоит ордер. Тогда просто ждём ответ.
    if (orderReqFired) {
      log('Запрос ордера УЖЕ ушёл — ответ медленный, жду без повтора (не дублируем)');
      // Сначала — захваченный листенером ответ (мог прийти в щель между таймаутом
      // первого ожидания и этой строкой; повторный waitForResponse его бы пропустил
      // навсегда → ложная «не ушёл»). Нет — ждём, поллинг переменной листенера.
      resp = capturedOrderResp;
      for (let i = 0; !resp && i < 80; i++) { // до 8с, шаг 100мс
        await page.waitForTimeout(100);
        resp = capturedOrderResp;
      }
    } else {
      log('Ответа нет и запрос ордера не ушёл — повтор клика (первый клик не отправил)');
      await ensureFilled(); // форма могла слететь снова — перезаполняем перед повтором
      resp = await clickAndWait(6000);
      // Недостаток ПОДТВЕРДИЛСЯ и на повторе (форма уже готова) → реальный fail.
      if (resp === '__nofunds__') {
        await dismissBlockingModal(page);
        page.off('response', onResp);
        page.off('request', onReq);
        log('XT: недостаточно баланса — подтверждено на повторе');
        return { ok: false, error: `XT отклонил: недостаточно баланса для ордера (кол-во ${wantQty} @ ${wantPrice}).`, riskModal: !!page.__arbiSawRisk };
      }
    }
  }
  if (resp === '__nofunds__') resp = null; // страховка: не превратить маркер в «успех»
  if (!resp && capturedOrderResp) resp = capturedOrderResp; // последний шанс — захваченный ответ

  page.off('response', onResp);
  page.off('request', onReq);
  // POST ордера УШЁЛ, но ответ так и не получен: заявка, ВЕРОЯТНО, стоит на бирже —
  // честно говорим это (и что повторов не делали), вместо ложного «не ушёл»,
  // провоцирующего ручной дубль.
  if (!resp && orderReqFired) {
    return {
      ok: false,
      ambiguous: true, // CR-6: неопределённость — терминал НЕ авторетраит (риск дубля)
      error: 'Запрос ордера отправлен на XT, но ответ не получен (медленный прокси). Заявка, вероятно, ВЫСТАВЛЕНА — проверьте «Открытые ордера» перед повтором. Повторная отправка не выполнялась (защита от дублирования).',
      riskModal: !!page.__arbiSawRisk,
    };
  }
  if (!resp) {
    // Детальная диагностика: почему ордер не ушёл — кнопка disabled? поля пустые?
    // логин-стена (сессия истекла)? какие POST реально ушли?
    const diag = await page.evaluate((SEL) => {
      const vis = (el) => el && el.offsetParent !== null;
      const q = (s) => Array.from(document.querySelectorAll(s));
      const sub = q(SEL.submit).find(vis) || q(SEL.submit)[0] || null;
      const st = sub ? getComputedStyle(sub) : null;
      const inputs = q(SEL.numberInput).filter(vis).map((i) => i.value);
      const body = (document.body.innerText || '').slice(0, 4000);
      const errs = q('[class*="error" i],[class*="invalid" i],[class*="tip" i],[class*="warn" i]')
        .filter(vis).map((e) => (e.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 6);
      const dialogs = q('[role="dialog"],[class*="odal"],[class*="ialog"],[class*="opup"]')
        .filter(vis).map((el) => (el.innerText || '').replace(/\s+/g, ' ').slice(0, 120)).slice(0, 3);
      return {
        submitText: sub ? (sub.innerText || '').replace(/\s+/g, ' ').trim() : '(нет кнопки сабмита)',
        submitDisabled: sub ? !!(sub.disabled || sub.getAttribute('aria-disabled') === 'true' || /disabl/i.test(sub.className) || (st && (st.pointerEvents === 'none' || parseFloat(st.opacity || '1') < 0.5))) : null,
        inputValues: inputs,
        loginWall: /войдите|войти в|log ?in|sign ?in|请登录|登录/i.test(body),
        errors: errs,
        dialogs,
        url: location.href,
      };
    }, SELECTORS).catch((e) => ({ err: e.message }));
    console.log('[xt-exec] [diag POST] ' + JSON.stringify(postUrls.slice(-10)));
    console.log('[xt-exec] [diag страница] ' + JSON.stringify(diag));
    // XT показал модалку-ошибку (нехватка баланса и т.п.) — закрываем её (иначе
    // заблокирует следующий ордер) и возвращаем понятную причину.
    const modalText = (diag.dialogs || []).join(' | ');
    const closed = await dismissBlockingModal(page);
    if (/insufficient|not enough|недостаточн/i.test(modalText + ' ' + (closed.text || ''))) {
      return { ok: false, error: `XT отклонил: недостаточно баланса для ордера (кол-во ${wantQty} @ ${wantPrice}).` };
    }
    return {
      ok: false,
      error: `order/place не ушёл. Кнопка "${diag.submitText}" disabled=${diag.submitDisabled}; поля=${JSON.stringify(diag.inputValues)}; loginWall=${diag.loginWall}; errors=${JSON.stringify(diag.errors)}; modal=${modalText.slice(0, 80)}; POST=${JSON.stringify(postUrls.slice(-6))}`,
    };
  }

  const tResp = Date.now();
  // Тайминг по фазам — чтобы видеть, где уходит время (цель ≤500мс на тёплой странице).
  log(`[timing submit] клик=${xs.click} поллинг=${xs.poll} модалки=${xs.modal} ответ-после=${xs.wait} попыток=${xs.attempts}`);
  log(`[timing] page=${tPage - t0} tabs=${tTabs - tPage} fill=${tFill - tTabs} submit+resp=${tResp - tFill} ИТОГО=${tResp - t0}мс`);

  const status = resp.status();
  let json = null;
  try { json = await resp.json(); } catch { /* не JSON */ }
  // Формат ответа XT ПОДТВЕРЖДЁН на бою 2026-07-08:
  // {rc:0, mc:"SUCCESS", ma:[], result:{orderId:"…", clientOrderId:null}}.
  const data = json && json.data;
  const result = json && json.result;
  const okCode = json && (json.rc === 0 || json.code === 0 || json.mc === 'SUCCESS');
  if (status >= 200 && status < 300 && okCode) {
    const orderId = (result && result.orderId) || (data && data.orderId)
      || (typeof data === 'string' ? data : undefined) || (result && result.id);
    // Биржа ответила УСПЕХОМ — ордер ВСТАЛ на бирже. orderId не распарсили (иная форма
    // конверта) → это НЕ «не выставлено»: ambiguous, чтобы терминал не авторетраил (дубль),
    // а показал «проверьте открытые ордера». Без флага плейн-fail провоцировал ретрай.
    if (!orderId) return { ok: false, ambiguous: true, error: `XT принял ордер (success), но orderId не распознан: ${JSON.stringify(json).slice(0, 160)}. Заявка ВЫСТАВЛЕНА — проверьте «Открытые ордера».`, riskModal: !!page.__arbiSawRisk };
    log(`Ордер выставлен: ${orderId}`);
    // riskModal — терминал обучит реестр known_tokens (в след. раз hint придёт заранее).
    return { ok: true, orderId: String(orderId), riskModal: !!page.__arbiSawRisk };
  }
  const msg = json ? String(json.msg || json.message || json.mc || json.code) : `HTTP ${status}`;
  return { ok: false, error: `XT отклонил ордер: ${String(msg).slice(0, 200)}`, riskModal: !!page.__arbiSawRisk };
}

/** Отмена ВСЕХ ордеров нативной кнопкой биржи «Cancel all» — для web-only токенов. */
async function cancelAllOrders(context, pair, log) {
  const { page } = await getXtPage(context, pair, log);
  await dismissOverlays(page);
  await dismissBlockingModal(page);
  const sel = process.env.ARBI_XT_SEL_CANCEL_ALL;
  // XT: <button class="btnTxt ...">Отменить все</button> → getByText (устойчиво к вёрстке).
  const btn = sel ? page.locator(sel).first()
    : page.getByText(/^\s*(cancel all|отменить\s+вс[её]|отмена всех)\s*$/i).first();
  try { await btn.waitFor({ state: 'visible', timeout: 8000 }); }
  catch { return { ok: false, error: 'Кнопка «Отменить все» не найдена (задайте ARBI_XT_SEL_CANCEL_ALL).' }; }
  // Клик по «Отменить все» ОБЯЗАН пройти: раньше .catch(()=>{}) глотал сбой, а функция
  // всё равно возвращала ok:true → терминал считал ордера отменёнными, хотя они висят.
  try { await btn.click({ timeout: 4000 }); }
  catch (e) { return { ok: false, error: `Клик по «Отменить все» не прошёл: ${String(e.message).slice(0, 80)} — ордера НЕ отменены.` }; }
  // Подтверждение (XT «OK»): якорный матч — НЕ трогаем «Отмена/Cancel». Жмём СРАЗУ по
  // появлению (force → без ожидания анимации/стабильности модалки) — отмена быстрее.
  const confirmBtn = page.locator('[role="dialog"] button,[class*="modal" i] button')
    .filter({ hasText: /^\s*(confirm|подтверд\w*|ok|да|yes)\s*$/i }).first();
  try {
    await confirmBtn.waitFor({ state: 'visible', timeout: Number(process.env.ARBI_XT_CANCEL_CONFIRM_MS || 2500) });
    await confirmBtn.click({ timeout: 1200, force: true, noWaitAfter: true });
  } catch { /* модалки подтверждения не было */ }
  log(`Отмена всех ордеров (${pair}): кнопка нажата`);
  return { ok: true, cancelledAll: true };
}

module.exports = { executeIntent, getXtPage, warmupForm, cancelAllOrders, toXtPair, SELECTORS };

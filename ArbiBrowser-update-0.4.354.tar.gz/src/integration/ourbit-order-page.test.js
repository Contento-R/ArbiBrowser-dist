'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { _coinGate: gate, _rowCoin: rowCoin, executeIntent } = require('./ourbit-order-page');

const now = Date.now();
const base = { symbol: 'VINE/USDT', side: 'buy', type: 'limit', price: '0.009', quantity: '100', createdAt: now };
const v = [{ chain: 'solana', contract: '6ajcp7…pump' }];

test('без подтверждения терминала заявка не уходит', () => {
  assert.match(gate({ ...base }), /не подтвердил/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE2', manual: false, verified: v, at: now } } }), /не подтвердил/);
});

test('автоматике нужна свежая сверка по контракту', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now } } }), null);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: null, at: now } } }), /не сверена/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now - 11 * 60_000 } } }), /устарела/);
});

test('ручная заявка с экрана — без контракта', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'vine', manual: true, verified: null, at: now } } }), null);
});

test('монета строки ордера: currency или symbol', () => {
  assert.equal(rowCoin({ currency: 'vine' }), 'VINE');
  assert.equal(rowCoin({ symbol: 'VINE_USDT' }), 'VINE');
  assert.equal(rowCoin({}), '');
});

test('без сверки до страницы дело не доходит', async () => {
  const r = await executeIntent(null, { ...base }, {});
  assert.equal(r.ok, false);
  assert.match(r.error, /заявка не отправлена/);
});

test('сети сайта → канон терминала', () => {
  const { _canonChain: c } = require('./ourbit-order-page');
  assert.equal(c('Solana(SOL)'), 'SOL');
  assert.equal(c('BNB Smart Chain(BEP20)'), 'BSC');
  assert.equal(c('Ethereum(ERC20)'), 'ETH');
  assert.equal(c('BSC'), 'BSC');
  assert.equal(c('solana'), 'SOL');
  assert.equal(c('BASE'), 'BASE');
});

const { _saveMismatch: saveMismatch } = require('./ourbit-withdraw-page');
const want = { coin: 'USDT', chainName: 'BNB Smart Chain(BEP20)', address: '0x' + 'a'.repeat(40), amount: '10' };
const body = (o) => JSON.stringify({ amount: '10', address: '0x' + 'A'.repeat(40), chain: 'BNB Smart Chain(BEP20)', currency: 'USDT', isQuickWithdraw: true, ...o });

test('вывод формой: запрос страницы совпал с намерением — подтверждаем', () => {
  assert.equal(saveMismatch(body({}), want), null);
  assert.equal(saveMismatch(body({ amount: '10.00' }), want), null);
});

test('вывод формой: страница готовит не то — не подтверждаем', () => {
  assert.match(saveMismatch(body({ address: '0x' + 'b'.repeat(40) }), want), /адрес/);
  assert.match(saveMismatch(body({ amount: '100' }), want), /сумма/);
  assert.match(saveMismatch(body({ chain: 'Tron(TRC20)' }), want), /сеть/);
  assert.match(saveMismatch(body({ currency: 'USDC' }), want), /монета/);
  assert.match(saveMismatch('не json', want), /не прочитано/);
});

test('подпись: формула MEXC (f1) — md5(nonce + тело + md5(ключ + nonce)[7:])', () => {
  const crypto = require('node:crypto');
  const md5 = (s) => crypto.createHash('md5').update(s).digest('hex');
  const { _FORMULAS: F } = require('./ourbit-sign');
  const k = 'WEBabc', n = '1700000000000', b = '{"a":1}';
  assert.equal(F.f1(k, n, b), md5(n + b + md5(k + n).slice(7)));
});

test('остатки: общий запрос — только монеты сводки; спрошенные терминалом — отдельно, свежие, не больше четырёх', () => {
  const { _balanceCoins: coins, _extraCoins: extra } = require('./ourbit-order-page');
  const overview = [{ currency: 'usdt', spot: '31.8' }, { currency: 'DUST', spot: '0' }, { currency: 'ABC', spot: '5' }];
  const base = coins(overview);
  assert.deepEqual(base.sort(), ['ABC', 'USDT']);
  const now = 1_000_000_000;
  const asked = new Map([['DRIFT', now - 1000], ['USDT', now], ['OLD', now - 21 * 60_000], ['A1', now - 5], ['A2', now - 4], ['A3', now - 3], ['A4', now - 2]]);
  assert.deepEqual(extra(asked, base, now), ['A4', 'A3', 'A2', 'A1']); // USDT уже в общем, OLD устарела, DRIFT — пятая
  assert.deepEqual(extra(new Map([['DRIFT', now]]), base, now), ['DRIFT']);
  assert.deepEqual(extra(undefined, base, now), []);
});

#!/usr/bin/env bash
# publish-update.sh — опубликовать обновление ArbiBrowser РУКАМИ, без GitHub Actions.
#
# Зачем (2026-09-17): у аккаунта Contento-R исчерпаны включённые минуты Actions
# («The job was not started because recent account payments have failed or your
# spending limit needs to be increased»), сборки не стартуют. Самообновление у
# пользователей читает только latest.json из публичного ArbiBrowser-dist, поэтому
# релиз можно выложить и без CI: тот же архив кода, тот же sha256, тот же манифест.
# Отличие от CI: архив лежит В САМОМ репо dist (ссылка на raw.githubusercontent.com),
# а не ассетом GitHub-релиза — создать релиз без токена нельзя.
#
# Запуск из корня ArbiBrowser (версия уже поднята в package.json, изменения закоммичены):
#   bash scripts/publish-update.sh [/путь/к/ArbiBrowser-dist]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST="${1:-$ROOT/../ArbiBrowser-dist}"
cd "$ROOT"
VER=$(node -p "require('./package.json').version")
NAME="ArbiBrowser-update-${VER}.tar.gz"
FILES="src bin scripts config.js package.json ArbiBrowser.bat ArbiBrowser.vbs"
[ -f package-lock.json ] && FILES="$FILES package-lock.json"
git -C "$DIST" fetch origin main -q && git -C "$DIST" checkout -q -B main origin/main
tar -czf "$DIST/$NAME" $FILES
SHA=$(sha256sum "$DIST/$NAME" | awk '{print $1}')
NOTES=$(node scripts/release-notes.js "$VER" | head -c 1500)
# ⚠️ ОСНОВНОЙ адрес архива — jsdelivr, raw остаётся зеркалом (оператор 2026-09-24).
# Причина: у пользователя с 0.4.168 raw.githubusercontent.com не открывается,
# программа уходила на запасной адрес (ассет GitHub-релиза), а релизы с 16.09 не
# выпускаются — последний так и остался 0.4.168, и панель честно писала «у вас
# последняя версия». Проверено: raw отдаёт v0.4.213, releases/latest — v0.4.168.
# jsdelivr раздаёт тот же файл из того же репозитория и открывается там, где raw
# закрыт, поэтому ставим его первым: так обновление доезжает и до СТАРЫХ сборок,
# которые про зеркала ещё не знают (они читают только поле url).
DIST="$DIST" node -e '
const [ver, name, sha, notes] = process.argv.slice(1);
const url = `https://cdn.jsdelivr.net/gh/Contento-R/ArbiBrowser-dist@main/${name}`;
const urlMirror = `https://raw.githubusercontent.com/Contento-R/ArbiBrowser-dist/main/${name}`;
require("fs").writeFileSync(process.env.DIST + "/latest.json", JSON.stringify({ version: "v" + ver, name, url, urlMirror, sha256: sha, notes }, null, 2) + "\n");
' "$VER" "$NAME" "$SHA" "$NOTES"
cd "$DIST" && git add latest.json "$NAME" && git commit -q -m "release: v${VER} (ручная публикация — CI аккаунта не стартует)" && git push origin main
# ⚠️ СБРОС КЕША jsdelivr — ОБЯЗАТЕЛЬНАЯ часть публикации (оператор 25.09: «обновление
# не прилетает»). jsdelivr кэширует файл по ВЕТКЕ (@main) примерно на 12 часов, а
# latest.json живёт по одному и тому же адресу — новый архив (новое имя файла)
# скачивался бы сразу, но программа о нём не узнавала: манифест ей отдавали старый.
# У пользователя raw.githubusercontent закрыт, и jsdelivr для него единственный
# рабочий адрес манифеста → «у вас последняя версия» на свежем релизе.
# ⚠️ ДВА purge, и второй — ГЛАВНЫЙ (проверено 25.09). purge одного ФАЙЛА сбрасывает
# только его копию, но jsdelivr отдельно держит резолв «ветка main → коммит», и после
# такого purge снова отдаёт файл ИЗ ПРЕЖНЕГО коммита: у оператора @main/latest.json
# показывал v0.4.216 через час после выпуска v0.4.218, хотя по @<sha> тот же адрес
# отдавал v0.4.218. Purge КАТАЛОГА обновляет резолв, и версия доезжает сразу.
curl -sS "https://purge.jsdelivr.net/gh/Contento-R/ArbiBrowser-dist@main/latest.json" >/dev/null || true
curl -sS "https://purge.jsdelivr.net/gh/Contento-R/ArbiBrowser-dist@main/" >/dev/null || true
sleep 3
# Проверка, что канал отдаёт ИМЕННО эту версию (иначе публикация не считается
# состоявшейся: «собранное ≠ доставленное»). Спрашиваем у GitHub API — это тот же
# адрес, который программа читает ПЕРВЫМ среди работающих, и он не кеширует.
# У jsdelivr версию тоже печатаем, но она справочная: его узлы расходятся между
# собой и могут показывать прежнюю версию ещё несколько часов.
API=$(curl -s -H 'Accept: application/vnd.github.raw' "https://api.github.com/repos/Contento-R/ArbiBrowser-dist/contents/latest.json?ref=main" | node -pe 'try{JSON.parse(require("fs").readFileSync(0,"utf8")).version}catch(e){""}' 2>/dev/null || echo '')
CDN=$(curl -s "https://cdn.jsdelivr.net/gh/Contento-R/ArbiBrowser-dist@main/latest.json" | node -pe 'try{JSON.parse(require("fs").readFileSync(0,"utf8")).version}catch(e){""}' 2>/dev/null || echo '')
echo "✅ опубликовано v${VER}: $NAME sha256=${SHA:0:12} · GitHub отдаёт ${API:-?} · jsdelivr ${CDN:-?} (догоняет)"
[ "$API" = "v${VER}" ] || echo "⚠️  GitHub ещё не отдаёт v${VER} — повторите проверку через минуту"

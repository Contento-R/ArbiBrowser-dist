'use strict';
// Готовность кнопки ордера: чем именно её заворачивает проверка.
// Замер 24.09 (заявка BASECAT, вкладки-части): кнопка НЕ disabled, клики
// принимает, мешает только opacity 0.3 — этот случай ждёт короткую отсрочку,
// а реально отключённая кнопка по-прежнему ждёт полный бюджет.
const test = require('node:test');
const assert = require('node:assert');
const { onlyOpacityBlocks } = require('./bingx-order-page');

const dim = {
  disabled: false, aria: null, class: 'bx-btn-primary bx-btn-round btn-order-blue',
  opacity: '0.3', pointerEvents: 'auto', text: 'Купить',
};

test('тусклая, но живая кнопка (снимок с вкладки-части) — мешает только прозрачность', () => {
  assert.equal(onlyOpacityBlocks(dim), true);
});

test('реально отключённая кнопка — полный бюджет, а не отсрочка', () => {
  assert.equal(onlyOpacityBlocks({ ...dim, disabled: true }), false);
  assert.equal(onlyOpacityBlocks({ ...dim, aria: 'true' }), false);
  assert.equal(onlyOpacityBlocks({ ...dim, class: 'btn-order-blue is-disabled' }), false);
  assert.equal(onlyOpacityBlocks({ ...dim, pointerEvents: 'none' }), false);
});

test('непрозрачная кнопка сюда не попадает (её пропустит обычная проверка), снимка нет — не гадаем', () => {
  assert.equal(onlyOpacityBlocks({ ...dim, opacity: '1' }), false);
  assert.equal(onlyOpacityBlocks(null), false);
});

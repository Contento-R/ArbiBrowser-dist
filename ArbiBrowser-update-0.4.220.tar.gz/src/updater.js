'use strict';

/**
 * updater.js — самообновление ArbiBrowser БЕЗ переустановки инсталлятора.
 *
 * Зачем. Раньше обновление .exe-сборки означало: скачать 262-мегабайтный
 * ArbiBrowser-Setup.exe, закрыть программу, пройти мастер установки. Живой код
 * приложения весит ~1.5 МБ — всё остальное в установщике это Node и Chromium,
 * которые от версии к версии не меняются. Поэтому здесь качается только КОД.
 *
 * Схема (перенесена из PandaVoice, оператор 2026-07-30):
 *   1. В публичном dist-репозитории лежит манифест latest.json по постоянному
 *      адресу. Читается как обычный файл через raw.githubusercontent.com — без
 *      токена и без GitHub API. Это принципиально: репозиторий с кодом
 *      приватный, и ходить в его Releases пользователь не может.
 *   2. Архив обновления качается во временный .part, проверяется по sha256 и
 *      только после этого переименовывается в готовый. Оборванная закачка не
 *      выглядит готовой, подменённый архив до установки не доходит.
 *   3. Распаковка поверх каталога приложения СВОИМ кодом (системный tar), а не
 *      проводником — иначе Windows метит файлы как «скачанные из интернета» и
 *      Smart App Control блокирует запуск.
 *
 * Отличие от PandaVoice, намеренное: там после установки процесс перезапускается
 * сам. Здесь этого делать НЕЛЬЗЯ молча — ArbiBrowser держит залогиненные
 * профили и исполняет биржевые ордера, перезапуск посреди сделки стоит денег.
 * Поэтому установка идёт только по явной команде и блокируется, пока открыт
 * хотя бы один профиль (см. `canInstall`).
 *
 * Пользовательские данные не рискуют: профили и настройки живут в DATA_HOME,
 * вне каталога приложения (config.js), а tar поверх каталога ничего не удаляет —
 * он только перезаписывает файлы, которые есть в архиве.
 */

const fs = require('node:fs');
const path = require('node:path');
const https = require('node:https');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');

const config = require('../config');
const pkg = require('../package.json');

const ROOT = path.join(__dirname, '..');

/** Публичный dist-репозиторий (owner/repo) — тот же, что у app-info.js. */
const UPDATE_REPO = process.env.ARBI_UPDATE_REPO || 'Contento-R/ArbiBrowser-dist';
const UPDATE_BRANCH = process.env.ARBI_UPDATE_BRANCH || 'main';
/** Манифест: обычный файл, без API и без токена. */
const MANIFEST_URL = process.env.ARBI_MANIFEST_URL
  || `https://raw.githubusercontent.com/${UPDATE_REPO}/${UPDATE_BRANCH}/latest.json`;
/** Адреса манифеста по порядку. raw.githubusercontent.com у части пользователей не
 *  открывается вовсе (оператор 2026-09-12: релиз есть, а панель отвечала
 *  «самообновление недоступно» и качала 260-мегабайтный установщик), тогда как
 *  github.com/…/releases/latest/download/… у них же качается — туда workflow кладёт
 *  тот же latest.json ассетом релиза. */
const MANIFEST_URLS = [
  MANIFEST_URL,
  // ⚠️ САМЫЙ СВЕЖИЙ АДРЕС — GitHub API (оператор 25.09: «обновление не прилетает»).
  // Проверено в лоб: в одну и ту же минуту разные узлы jsdelivr отдавали РАЗНЫЕ
  // версии манифеста (v0.4.216 и v0.4.217) — он кеширует файл по ветке, и обход
  // «?t=<время>» тут не работает: узел отдаёт свою копию независимо от параметра.
  // purge.jsdelivr.net при публикации помогает, но расходится по узлам не сразу.
  // contents API с Accept: application/vnd.github.raw отдаёт САМ файл с max-age 60с
  // и открывается там же, где github.com (releases уже читаем оттуда). Лимит без
  // токена — 60 запросов в час на IP: проверка идёт раз в час, с запасом.
  `https://api.github.com/repos/${UPDATE_REPO}/contents/latest.json?ref=${UPDATE_BRANCH}`,
  // ⚠️ ЗЕРКАЛО CDN (оператор 2026-09-24). У пользователя с версией 0.4.168 панель
  // честно писала «у вас последняя версия (0.4.168)»: raw.githubusercontent.com
  // на его машине не открывается, и программа читала ЗАПАСНОЙ адрес — ассет
  // GitHub-релиза. А релизы у нас с 16.09 не выпускаются (минуты Actions
  // кончились), последний релиз так и остался 0.4.168 — то есть запасной канал
  // отвечал правдой полуторанедельной давности. Проверено: raw отдаёт v0.4.213,
  // releases/latest — v0.4.168. jsdelivr раздаёт тот же файл из того же репо и
  // открывается там, где raw закрыт, поэтому он ВЫШЕ протухшего релиза.
  `https://cdn.jsdelivr.net/gh/${UPDATE_REPO}@${UPDATE_BRANCH}/latest.json`,
  `https://github.com/${UPDATE_REPO}/releases/latest/download/latest.json`,
].filter((u, i, a) => a.indexOf(u) === i);

/** Куда кладём скачанное — рядом с данными, не внутрь кода приложения. */
const UPDATES_DIR = path.join(config.dataDir, 'updates');

/** "v1.2.3"/"1.2.3" → [1,2,3]; нечисловые хвосты (rc/beta) отбрасываются. */
function parseVersion(v) {
  return String(v || '').replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
}

/** semver-сравнение: >0 если a новее b. */
function cmpVersion(a, b) {
  const pa = parseVersion(a); const pb = parseVersion(b);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** GET с поддержкой редиректов (release-ассеты отдаются через 302). */
function httpGet(url, onResponse, opts = {}) {
  const { timeout = 15000, maxRedirects = 5, headers = {} } = opts;
  return new Promise((resolve, reject) => {
    const go = (u, left) => {
      const req = https.get(u, {
        headers: { 'User-Agent': 'ArbiBrowser-updater', Accept: '*/*', ...headers },
        timeout,
      }, (res) => {
        const code = res.statusCode || 0;
        if (code >= 300 && code < 400 && res.headers.location) {
          res.resume();
          if (left <= 0) return reject(new Error('слишком много редиректов'));
          return go(new URL(res.headers.location, u).toString(), left - 1);
        }
        if (code < 200 || code >= 300) {
          res.resume();
          return reject(new Error(`HTTP ${code}`));
        }
        onResponse(res, resolve, reject);
      });
      req.on('timeout', () => { req.destroy(new Error('timeout')); });
      req.on('error', reject);
    };
    go(url, maxRedirects);
  });
}

/** Скачать и разобрать latest.json с одного адреса.
 *  ⚠️ С ОБХОДОМ КЭША (17.09): raw.githubusercontent.com отдаёт файл через CDN и
 *  держит прежнюю копию несколько минут — панель показывала «последняя версия»,
 *  хотя обновление уже опубликовано. Добавляем уникальный параметр и заголовки
 *  «не из кэша»: адрес тот же, ответ свежий. */
function fetchManifestFrom(url) {
  const fresh = `${url}${url.includes('?') ? '&' : '?'}t=${Date.now()}`;
  return httpGet(fresh, (res, resolve, reject) => {
    let data = '';
    res.setEncoding('utf8');
    res.on('data', (c) => { data += c; });
    res.on('end', () => {
      try {
        const j = JSON.parse(data);
        // contents API, если сырой формат не отдали: файл лежит в base64-поле.
        resolve(j && j.encoding === 'base64' && typeof j.content === 'string'
          ? JSON.parse(Buffer.from(j.content, 'base64').toString('utf8'))
          : j);
      } catch (e) { reject(new Error(`манифест не разобрать: ${e.message}`)); }
    });
  }, { timeout: 10000, headers: { 'cache-control': 'no-cache', pragma: 'no-cache', Accept: 'application/vnd.github.raw' } });
}

/** Манифест: адреса по порядку (см. MANIFEST_URLS); отказ — со ВСЕМИ причинами,
 *  чтобы «канал молчит» не был безымянным. */
async function fetchManifest() {
  const errors = [];
  for (const url of MANIFEST_URLS) {
    try { return await fetchManifestFrom(url); } catch (e) { errors.push(`${new URL(url).host}: ${String(e && e.message || e)}`); }
  }
  throw new Error(`манифест обновления недоступен (${errors.join('; ')})`);
}

/**
 * Есть ли версия новее установленной.
 * @returns {Promise<{current:string, latest:string|null, updateAvailable:boolean,
 *                    manifest:object|null, error:string|null}>}
 */
async function checkRemote() {
  const base = { current: pkg.version, latest: null, updateAvailable: false, manifest: null, error: null };
  try {
    const m = await fetchManifest();
    const latest = String(m && m.version || '').replace(/^v/i, '');
    if (!latest) return { ...base, error: 'в манифесте нет версии' };
    return { ...base, latest, updateAvailable: cmpVersion(latest, pkg.version) > 0, manifest: m };
  } catch (e) {
    return { ...base, error: String(e && e.message || e) };
  }
}

/** Готовый (уже скачанный и проверенный) архив для этой версии, если он есть. */
function downloadedPath(manifest) {
  if (!manifest || !manifest.name) return null;
  const p = path.join(UPDATES_DIR, manifest.name);
  return fs.existsSync(p) ? p : null;
}

/**
 * Скачать архив обновления: во временный .part → sha256 → переименование.
 * Повторный вызов при уже скачанном архиве ничего не качает.
 */
async function download(manifest) {
  if (!manifest || !manifest.url || !manifest.name) throw new Error('манифест без ссылки на архив');
  const ready = downloadedPath(manifest);
  if (ready) return { ok: true, path: ready, cached: true };

  fs.mkdirSync(UPDATES_DIR, { recursive: true });
  const target = path.join(UPDATES_DIR, manifest.name);
  const tmp = `${target}.part`;
  fs.rmSync(tmp, { force: true });

  // Архив тоже берём с зеркалом: адрес в манифесте — основной, `urlMirror` —
  // запасной (та же сборка, совпадение докажет sha256 ниже). Один недоступный
  // CDN не должен оставлять пользователя без обновления.
  // Третий адрес — GitHub API (тот же файл из того же репо). Нужен по той же
  // причине, что и для манифеста: у части пользователей raw закрыт, а узел
  // jsdelivr может ещё не знать о свежем файле. Целостность всё равно докажет
  // sha256 ниже, так что лишний источник ничем не рискует.
  const urls = [manifest.url, manifest.urlMirror,
    `https://api.github.com/repos/${UPDATE_REPO}/contents/${encodeURIComponent(manifest.name)}?ref=${UPDATE_BRANCH}`]
    .filter(Boolean)
    .filter((u, i, a) => a.indexOf(u) === i);
  // Хэш считается ЗАНОВО на каждую попытку: оборванная первая закачка иначе
  // подмешала бы свои байты во вторую, и честный архив не прошёл бы сверку.
  let hash = null;
  let lastErr = null;
  for (const u of urls) {
    try {
      hash = crypto.createHash('sha256');
      await httpGet(u, (res, resolve, reject) => {
        const out = fs.createWriteStream(tmp);
        res.on('data', (c) => hash.update(c));
        res.pipe(out);
        out.on('finish', () => out.close(() => resolve()));
        out.on('error', reject);
        res.on('error', reject);
      }, { timeout: 120000, headers: u.startsWith('https://api.github.com/') ? { Accept: 'application/vnd.github.raw' } : {} });
      lastErr = null;
      break;
    } catch (e) { lastErr = e; hash = null; fs.rmSync(tmp, { force: true }); }
  }
  if (!hash) throw new Error(`архив обновления не скачался: ${String(lastErr && lastErr.message || lastErr)}`);

  // Контрольная сумма — она же защита от подмены архива. Без неё сюда мог бы
  // доехать чужой код и распаковаться поверх приложения.
  const want = String(manifest.sha256 || '').toLowerCase();
  const got = hash.digest('hex');
  if (want && got !== want) {
    fs.rmSync(tmp, { force: true });
    throw new Error('контрольная сумма архива не совпала — файл повреждён или подменён');
  }
  fs.renameSync(tmp, target);
  return { ok: true, path: target, cached: false, sha256: got };
}

/**
 * Можно ли ставить прямо сейчас. Открытый профиль = живая сессия биржи (а то и
 * заявка в работе): распаковка кода под ней и последующий перезапуск оборвут
 * исполнение. Лучше честно отказать, чем потерять сделку.
 * @param {number} openProfiles сколько профилей сейчас запущено
 */
function canInstall(openProfiles) {
  if (openProfiles > 0) {
    return { ok: false, reason: `открыт${openProfiles === 1 ? ' профиль' : 'о профилей: ' + openProfiles} — закройте профили, обновление тронет исполнение ордеров` };
  }
  return { ok: true };
}

/** Распаковка системным tar: есть и в Linux, и в Windows 10+ (tar.exe). */
function extract(archive, dest) {
  return new Promise((resolve, reject) => {
    execFile('tar', ['-xzf', archive, '-C', dest], { timeout: 120000 }, (err, _out, stderr) => {
      if (err) return reject(new Error(`распаковка не удалась: ${(stderr || err.message).slice(0, 300)}`));
      resolve();
    });
  });
}

/** `npm install --omit=dev` — мгновенный, если зависимости не менялись. */
function npmInstall() {
  return new Promise((resolve) => {
    const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
    execFile(npm, ['install', '--omit=dev', '--no-audit', '--no-fund'], {
      cwd: ROOT, timeout: 300000, shell: process.platform === 'win32',
    }, (err, _out, stderr) => {
      // Не валим обновление: код уже распакован, а зависимости обычно те же.
      resolve(err ? { ok: false, error: (stderr || err.message).slice(0, 300) } : { ok: true });
    });
  });
}

/**
 * Установить скачанное обновление. НЕ перезапускает процесс сам — возвращает
 * `restartRequired`, а решение о перезапуске остаётся за вызывающим (см. шапку).
 */
async function install(manifest, { openProfiles = 0 } = {}) {
  const gate = canInstall(openProfiles);
  if (!gate.ok) return { ok: false, error: gate.reason };

  const archive = downloadedPath(manifest);
  if (!archive) return { ok: false, error: 'архив обновления не скачан' };

  const lockBefore = readLock();
  await extract(archive, ROOT);
  const depsChanged = lockBefore !== readLock();
  const dep = depsChanged ? await npmInstall() : { ok: true, skipped: true };

  // Архив больше не нужен: он занимает место и при следующем запуске выглядел
  // бы как «скачано обновление» уже установленной версии.
  fs.rmSync(archive, { force: true });

  // Зависимости изменились, а доустановить их не вышло (нет npm в portable-
  // сборке, нет сети). Код УЖЕ распакован и откатить его нечем, поэтому молчать
  // нельзя: при следующем запуске это вылезет как «Cannot find module». Честно
  // сообщаем и отправляем на переустановку установщиком — она кладёт всё сразу.
  if (depsChanged && !dep.ok) {
    return {
      ok: false,
      version: String(manifest.version || '').replace(/^v/i, ''),
      deps: dep,
      restartRequired: true,
      error: 'Код обновлён, но новые зависимости доустановить не удалось. Переустановите ArbiBrowser установщиком — он ставит всё сразу.',
    };
  }
  return {
    ok: true,
    version: String(manifest.version || '').replace(/^v/i, ''),
    deps: dep,
    restartRequired: true,
  };
}

/**
 * Отпечаток списка зависимостей — по нему видно, нужен ли npm install после
 * распаковки. Считаем по package.json, а НЕ по package-lock.json: лока в этом
 * репозитории нет, и отпечаток по нему всегда был бы пустым — то есть новые
 * зависимости молча не доустанавливались бы, и обновление падало бы при старте
 * на «Cannot find module». Лок, если появится, тоже учитываем.
 */
function readLock() {
  const parts = [];
  try {
    const p = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
    parts.push(JSON.stringify(p.dependencies || {}), JSON.stringify(p.optionalDependencies || {}));
  } catch { /* нет package.json — сравнивать нечего */ }
  try { parts.push(fs.readFileSync(path.join(ROOT, 'package-lock.json'), 'utf8')); } catch { /* лока нет */ }
  return parts.length ? crypto.createHash('sha256').update(parts.join('\n')).digest('hex') : '';
}

/**
 * Фоновая проверка: при старте и дальше каждые N часов — панель живёт сутками,
 * одной проверки на старте мало. Обновление только СКАЧИВАЕТСЯ; установка —
 * отдельным явным действием пользователя.
 * @param {(info:object)=>void} onReady вызывается, когда обновление скачано
 */
function startBackgroundCheck(onReady, { hours = 6 } = {}) {
  const every = Math.max(1, Number(process.env.ARBI_UPDATE_CHECK_HOURS || hours)) * 3600_000;
  const tick = async () => {
    try {
      const r = await checkRemote();
      if (!r.updateAvailable || !r.manifest) return;
      await download(r.manifest);
      if (typeof onReady === 'function') onReady(r);
    } catch { /* сеть/зеркало недоступны — молча ждём следующего круга */ }
  };
  void tick();
  const t = setInterval(tick, every);
  if (typeof t.unref === 'function') t.unref(); // не держим процесс живым ради таймера
  return () => clearInterval(t);
}

module.exports = {
  MANIFEST_URL, MANIFEST_URLS, UPDATES_DIR,
  cmpVersion, checkRemote, download, downloadedPath, canInstall, install,
  startBackgroundCheck,
  // экспортируем для теста
  _internals: { parseVersion, readLock },
};

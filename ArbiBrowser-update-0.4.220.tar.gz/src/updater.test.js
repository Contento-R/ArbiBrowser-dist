'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { cmpVersion, canInstall, downloadedPath } = require('./updater');

test('cmpVersion: сравнение версий манифеста с установленной', () => {
  assert.equal(cmpVersion('0.4.91', '0.4.90'), 1);
  assert.equal(cmpVersion('v0.4.91', '0.4.90'), 1, 'префикс v из тега не мешает');
  assert.equal(cmpVersion('0.4.90', '0.4.90'), 0);
  assert.equal(cmpVersion('0.4.89', '0.4.90'), -1, 'откат назад обновлением не считается');
  assert.equal(cmpVersion('0.5.0', '0.4.99'), 1, 'сравниваем по разрядам, не лексикографически');
  assert.equal(cmpVersion('0.4.90', '0.4.90-rc1'), 0, 'нечисловой хвост отбрасывается');
});

test('canInstall: под открытым профилем код не подменяем', () => {
  // Открытый профиль = живая сессия биржи и, возможно, заявка в работе.
  // Распаковка кода под ней с последующим перезапуском стоит денег.
  assert.equal(canInstall(0).ok, true);
  assert.equal(canInstall(1).ok, false);
  assert.equal(canInstall(3).ok, false);
  assert.match(canInstall(1).reason, /закройте профили/i);
});

test('downloadedPath: без манифеста/имени архива — ничего не «готово»', () => {
  assert.equal(downloadedPath(null), null);
  assert.equal(downloadedPath({}), null);
  // Несуществующее имя не должно выглядеть как скачанный архив.
  assert.equal(downloadedPath({ name: 'ArbiBrowser-update-0.0.0-нет-такого.tar.gz' }), null);
});

test('MANIFEST_URLS: raw → GitHub API → зеркало CDN → ассет релиза, без дублей', () => {
  const { MANIFEST_URLS, MANIFEST_URL } = require('./updater');
  assert.equal(MANIFEST_URLS[0], MANIFEST_URL);
  assert.ok(MANIFEST_URLS.length >= 4, 'нужны API, зеркало и запасной адрес');
  // Порядок здесь — ЧАСТЬ ПОВЕДЕНИЯ, не косметика:
  // • API выше CDN — jsdelivr кеширует манифест по ветке, и его узлы расходятся
  //   между собой (25.09: в одну минуту v0.4.216 и v0.4.217 с разных узлов);
  // • CDN выше ассета релиза — релизы с 16.09 не собираются и отвечают правдой
  //   полуторанедельной давности (0.4.168).
  assert.match(MANIFEST_URLS[1], /^https:\/\/api\.github\.com\/repos\/.+\/contents\/latest\.json\?ref=/);
  assert.match(MANIFEST_URLS[2], /^https:\/\/cdn\.jsdelivr\.net\/gh\/.+\/latest\.json$/);
  assert.match(MANIFEST_URLS[3], /^https:\/\/github\.com\/.+\/releases\/latest\/download\/latest\.json$/);
  assert.equal(new Set(MANIFEST_URLS).size, MANIFEST_URLS.length, 'без дублей');
});

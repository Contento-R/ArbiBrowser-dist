'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { scrub, scrubUrl } = require('./bingx-deposit-page');

test('scrub: секретные ключи и длинные строки вымарываются, обычные поля остаются', () => {
  const out = scrub({
    code: 0,
    data: { coin: 'STONK', accountType: 2, token: 'abc', sign: 'x', uid: 123, address: '3JjBtMTcAQ9yxp5WEVinowYaD2xnm57kv7NkDyQKtiZw', note: 'ok' },
    list: [{ name: 'Спот счет', sessionId: 'x' }],
  });
  assert.equal(out.code, 0);
  assert.equal(out.data.coin, 'STONK');
  assert.equal(out.data.accountType, 2);
  assert.equal(out.data.token, '[скрыто]');
  assert.equal(out.data.sign, '[скрыто]');
  assert.equal(out.data.uid, '[скрыто]');
  assert.match(out.data.address, /^\[скрыто/);
  assert.equal(out.data.note, 'ok');
  assert.equal(out.list[0].sessionId, '[скрыто]');
  assert.equal(out.list[0].name, 'Спот счет');
  // адрес вызова остаётся читаемым (17.09: проба прятала все URL как «длинные строки»)
  assert.equal(scrub({ url: 'https://api-app.we-api.com/api/v1/recharge/setting?coin=STONK&token=abc' }).url, 'https://api-app.we-api.com/api/v1/recharge/setting?coin=STONK&token=HIDDEN');
});

test('scrubUrl: секретные и длинные query-значения скрыты, путь виден', () => {
  const u = scrubUrl('https://api-app.we-api.com/api/v1/recharge/setting?coin=STONK&token=abcdef&sig=' + 'a'.repeat(40));
  assert.equal(u, 'https://api-app.we-api.com/api/v1/recharge/setting?coin=STONK&token=HIDDEN&sig=HIDDEN');
});

test('монета сверяется по границам слова: COINDEPO — это не DEP', () => {
  const { _coinMatches } = require('./bingx-deposit-page');
  assert.equal(_coinMatches('COINDEPO', 'DEP'), false);
  assert.equal(_coinMatches('DEP', 'DEP'), true);
  assert.equal(_coinMatches('DEP/USDT', 'DEP'), true);
  assert.equal(_coinMatches('BASECAT', 'CAT'), false);
});

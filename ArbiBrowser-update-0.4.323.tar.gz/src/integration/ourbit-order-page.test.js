'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { _coinGate: gate, _rowCoin: rowCoin, executeIntent } = require('./ourbit-order-page');

const now = Date.now();
const base = { symbol: 'VINE/USDT', side: 'buy', type: 'limit', price: '0.009', quantity: '100', createdAt: now };
const v = [{ chain: 'solana', contract: '6ajcp7…pump' }];

test('без подтверждения терминала заявка не уходит', () => {
  assert.match(gate({ ...base }), /не подтвердил/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE2', manual: false, verified: v, at: now } } }), /не подтвердил/);
});

test('автоматике нужна свежая сверка по контракту', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now } } }), null);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: null, at: now } } }), /не сверена/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now - 11 * 60_000 } } }), /устарела/);
});

test('ручная заявка с экрана — без контракта', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'vine', manual: true, verified: null, at: now } } }), null);
});

test('монета строки ордера: currency или symbol', () => {
  assert.equal(rowCoin({ currency: 'vine' }), 'VINE');
  assert.equal(rowCoin({ symbol: 'VINE_USDT' }), 'VINE');
  assert.equal(rowCoin({}), '');
});

test('без сверки до страницы дело не доходит', async () => {
  const r = await executeIntent(null, { ...base }, {});
  assert.equal(r.ok, false);
  assert.match(r.error, /заявка не отправлена/);
});

'use strict';

/**
 * withdraw-capture.js — ЛОВУШКА ДЛЯ ОТМЕНЫ ВЫВОДА BingX (оператор 2026-10-18).
 *
 * Чтобы отменять вывод за ~1 с, нужен тот же вызов API, что делает сайт по кнопке
 * «Отменить». Снять его руками в DevTools нельзя: вывод уходит в обработку раньше,
 * чем успеваешь кликнуть. Поэтому ловим сами, во всех вкладках BingX профиля:
 *   1) КОД САЙТА: в загружаемых скриптах BingX ищем строки адресов API со словом
 *      withdraw (и cancel/revoke рядом) + кусок кода вокруг — так виден адрес отмены
 *      и имена полей, даже без отменяемого вывода;
 *   2) ВЫЗОВЫ: любой запрос вкладки BingX к API вывода — метод, адрес, тело, ответ.
 * Заголовки и cookie НЕ читаются никогда; в телах вымарываются ключи вида token/sign/
 * uid/phone и длинные строки (адреса). Всё — в журнал «[захват вывода] …» и в файл
 * <данные>/reports/withdraw-capture.txt. BingX — по ARBI_WD_CAPTURE=1; Gate (вывод через
 * сайт, 19.10) — всегда, пока вызов не найден.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { scrub, scrubUrl } = require('./bingx-deposit-page');

// BingX: адрес отмены найден 18.10 (bingx-withdraw-page FAST) — только по ARBI_WD_CAPTURE=1.
// Gate: включено всегда, пока не найден вызов вывода через сайт (API закрывает вывод
// неликвидных монет, 19.10 EVO) — ловим его при первом ручном выводе на gate.com.
const ON = () => process.env.ARBI_WD_CAPTURE === '1';
const FILE = () => path.join(config.reportsDir, 'withdraw-capture.txt');
const API_HOST_RE = /bingx|we-api|acc-de|qq-os|bb-os|gate\.(com|io)/i;
const siteOf = (u) => (/gate\.(com|io)/i.test(u) ? 'gate' : /bingx\./i.test(u) ? 'bingx' : null);
const enabledFor = (u) => { const s = siteOf(u); return s === 'gate' || (s === 'bingx' && ON()); };
// Тела вывода могут нести одноразовые коды/пароль фонда — их ключи тоже вымарываем.
const CODE_KEY_RE = /code|otp|totp|pin|fund|pass|verif|captcha|sign|token/i;
const maskCodes = (v) => (Array.isArray(v) ? v.map(maskCodes) : v && typeof v === 'object'
  ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, CODE_KEY_RE.test(k) ? '[скрыто]' : maskCodes(x)])) : v);
const WD_RE = /withdraw/i;
// BingX зовёт отмену вывода «back» (back-apply/recent-back — первая находка 18.10)
const CANCEL_RE = /cancel|revoke|undo|back/i;
const PATH_RE = /["'`](\/?(?:api\/)?[A-Za-z0-9_\-/{}.]*withdraw[A-Za-z0-9_\-/{}.]*)["'`]/gi;
const scanned = new Set();  // URL скрипта → уже прочитан
const endpoints = new Map(); // путь → кусок кода вокруг
const attached = new WeakSet();

function out(line) {
  console.log(`[захват вывода] ${line}`);
  try {
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    fs.appendFileSync(FILE(), `${new Date().toISOString()} ${line}\n`);
  } catch { /* файл необязателен — журнал есть */ }
}

const body = (text, req = false) => {
  if (!text) return '';
  let v = null;
  try { v = JSON.parse(text); } catch {
    // Gate шлёт формы (a=1&b=2) — разбираем, чтобы видеть имена полей.
    if (/^[\w.%[\]-]+=/.test(text)) v = Object.fromEntries(new URLSearchParams(text));
  }
  return v == null ? `[не JSON, ${text.length} симв.]` : JSON.stringify(scrub(req ? maskCodes(v) : v)).slice(0, 3000);
};

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  const pageOn = () => { try { return enabledFor(String(page.url())); } catch { return false; } };
  page.on('request', (req) => {
    try {
      const u = req.url();
      if (!pageOn() || !API_HOST_RE.test(u) || !WD_RE.test(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (req.method() === 'GET' && !CANCEL_RE.test(u)) return; // GET-ы пишем ответом ниже
      out(`ВЫЗОВ ${req.method()} ${scrubUrl(u)} тело=${body(req.postData(), true)}`);
    } catch { /* диагностика */ }
  });
  page.on('response', async (resp) => {
    try {
      const req = resp.request();
      const u = resp.url();
      if (req.method() === 'OPTIONS') return;
      if (pageOn() && API_HOST_RE.test(u) && WD_RE.test(u) && /^(xhr|fetch)$/.test(req.resourceType())) {
        const t = await resp.text().catch(() => '');
        out(`ОТВЕТ ${req.method()} ${scrubUrl(u)} → ${resp.status()} ${body(t)}`);
        return;
      }
      if (req.resourceType() !== 'script' || !pageOn() || scanned.has(u)) return;
      scanned.add(u);
      const src = await resp.text().catch(() => '');
      if (!src || src.length > 12_000_000) return;
      let m; let found = 0;
      PATH_RE.lastIndex = 0;
      while ((m = PATH_RE.exec(src)) && found < 200) {
        found += 1;
        const p = m[1];
        if (!p.includes('/') || endpoints.has(p)) continue; // ключи переводов (recharge_withdraw_…) — не адреса
        const around = src.slice(Math.max(0, m.index - 160), m.index + p.length + 220).replace(/\s+/g, ' ');
        endpoints.set(p, around);
        out(`КОД ${p}${CANCEL_RE.test(p) ? '  ← ОТМЕНА?' : ''} | ${around}`);
      }
    } catch { /* диагностика */ }
  });
}

/** Подключить ловушку ко всем вкладкам профиля (текущим и будущим). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

module.exports = { attach, FILE };

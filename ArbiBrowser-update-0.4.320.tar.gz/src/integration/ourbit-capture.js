'use strict';

/**
 * ourbit-capture.js — ЗАПИСЬ ЗАПРОСОВ САЙТА OURBIT (оператор 2026-11-16).
 *
 * API Ourbit отвечает ключу 700007 «No permission to access the endpoint» даже на баланс — торговать
 * Ourbit будем через сайт, как MEXC. Чтобы собрать исполнение, нужен формат запросов самого сайта:
 * какие адреса он зовёт, с какими полями, что отвечает. Оператор руками ставит на ourbit.com одну
 * лимитку далеко от рынка, отменяет её и открывает активы — ловушка пишет всё, что для этого нужно:
 *   1) ВЫЗОВ / ОТВЕТ — запросы вкладки Ourbit к API заявок, отмены, открытых ордеров, баланса, активов,
 *      депозита (метод, адрес, тело, ответ); у вызова — ИМЕНА заголовков (без значений): так видно,
 *      какой подписью сайт заверяет заявку;
 *   2) ФОРМА — разметка торговой формы спота (поля, кнопки, вкладки «Лимит/Рынок») без значений,
 *      один раз на страницу — запасной путь «нажать как человек», если прямой вызов не выйдет.
 * Значения заголовков и cookie НЕ читаются никогда; в телах вымарываются ключи вида token/sign/uid/
 * phone/email/код и длинные строки (адреса, подписи) — общий scrub. Действий ловушка не делает: только
 * смотрит. Всё — в журнал «[захват Ourbit] …» и в файл <данные>/reports/ourbit-capture.txt.
 * Бюджет — 600 строк на процесс. Выключить — ARBI_OURBIT_CAPTURE=0.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { scrub, scrubUrl } = require('./bingx-deposit-page');

const ON = () => (process.env.ARBI_OURBIT_CAPTURE || '1') !== '0';
const FILE = () => path.join(config.reportsDir, 'ourbit-capture.txt');
const SITE_RE = /(^|\.)ourbit\.com$/i;
// Что интересно: заявки, отмена, открытые/история ордеров, баланс и активы, депозит/вывод.
const API_RE = /order|place|cancel|revoke|trade|deal|entrust|asset|balance|account|wallet|deposit|withdraw|transfer|capital/i;
const NOISE_RE = /\.(js|css|png|jpe?g|svg|webp|woff2?|ico)(\?|$)|kline|depth|ticker|market\/|banner|notice|announce|i18n|locale|log(ger)?\/|track|report|sensor|captcha/i;
// Тела заявок могут нести одноразовые коды/пароль фонда — их ключи вымарываем дополнительно.
const CODE_KEY_RE = /code|otp|totp|pin|fund|pass|pwd|verif|captcha|sign|token/i;
const maskCodes = (v) => (Array.isArray(v) ? v.map(maskCodes) : v && typeof v === 'object'
  ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, CODE_KEY_RE.test(k) ? '[скрыто]' : maskCodes(x)])) : v);

let budget = 600;
const attached = new WeakSet();
const forms = new Set(); // путь страницы → разметка формы уже снята

function out(line) {
  if (budget <= 0) return;
  budget -= 1;
  console.log(`[захват Ourbit] ${line}`);
  try {
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    fs.appendFileSync(FILE(), `${new Date().toISOString()} ${line}\n`);
  } catch { /* файл необязателен — журнал есть */ }
  if (budget === 0) console.log('[захват Ourbit] бюджет строк исчерпан — запись остановлена до перезапуска');
}

const isOurbit = (u) => { try { return SITE_RE.test(new URL(u).hostname); } catch { return false; } };

function body(text, req = false) {
  if (!text) return '';
  let v = null;
  try { v = JSON.parse(text); } catch {
    if (/^[\w.%[\]-]+=/.test(text)) v = Object.fromEntries(new URLSearchParams(text));
  }
  return v == null ? `[не JSON, ${text.length} симв.]` : JSON.stringify(scrub(req ? maskCodes(v) : v)).slice(0, 2500);
}

// Разметка торговой формы спота — поля, вкладки и кнопки БЕЗ значений, один раз на путь страницы.
const FORM_STRUCT = () => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const t = (s, n = 40) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
  const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter((c) => !/^\w{1,3}$/.test(c)).slice(0, 3).join('.');
  const out = [];
  for (const e of Array.from(document.querySelectorAll('input,textarea')).filter(vis).slice(0, 24)) out.push(`поле[${e.type || 'text'}] ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
  const tabs = [...new Set(Array.from(document.querySelectorAll('[role="tab"],[class*="tab" i]')).filter((e) => vis(e) && !e.children.length).map((e) => t(e.textContent, 20)).filter(Boolean))].slice(0, 30);
  out.push(`вкладки=[${tabs.join(' | ')}]`);
  const btns = [...new Set(Array.from(document.querySelectorAll('button,[role="button"]')).filter(vis).map((b) => `${t(b.innerText, 24)}{${cls(b)}}`).filter((x) => !x.startsWith('{')))].slice(0, 30);
  out.push(`кнопки=[${btns.join(' | ')}]`);
  return `${location.pathname} ${out.join(' ; ')}`;
};

async function dumpForm(page) {
  let u = ''; try { u = String(page.url()); } catch { return; }
  if (!isOurbit(u)) return;
  let key = ''; try { key = new URL(u).pathname; } catch { return; }
  if (!/exchange|spot|trade/i.test(key) || forms.has(key)) return;
  forms.add(key);
  try {
    await page.waitForTimeout(3000); // форма дорисовывается после загрузки
    const s = await page.evaluate(FORM_STRUCT);
    if (s) out(`ФОРМА ${s.slice(0, 3500)}`);
  } catch (e) { out(`ФОРМА: не снята (${String((e && e.message) || e).slice(0, 80)})`); }
}

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('load', () => { if (ON()) dumpForm(page).catch(() => {}); });
  page.on('request', (req) => {
    try {
      const u = req.url();
      if (!ON() || budget <= 0 || !isOurbit(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (!API_RE.test(u) || NOISE_RE.test(u)) return;
      if (req.method() === 'GET') return; // GET-ы пишем ответом ниже
      // Только ИМЕНА заголовков: значения (подписи, токены) не читаем и не пишем.
      const names = Object.keys(req.headers() || {}).filter((h) => !/^(accept|accept-language|accept-encoding|connection|content-length|origin|referer|sec-|user-agent|cookie)/i.test(h));
      out(`ВЫЗОВ ${req.method()} ${scrubUrl(u)} заголовки=[${names.join(',')}] тело=${body(req.postData(), true)}`);
    } catch { /* диагностика */ }
  });
  page.on('response', async (resp) => {
    try {
      const req = resp.request();
      const u = resp.url();
      if (!ON() || budget <= 0 || !isOurbit(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (!API_RE.test(u) || NOISE_RE.test(u)) return;
      const t = await resp.text().catch(() => '');
      out(`ОТВЕТ ${req.method()} ${scrubUrl(u)} → ${resp.status()} ${body(t)}`);
    } catch { /* диагностика */ }
  });
}

/** Подключить ловушку ко всем вкладкам профиля (текущим и будущим). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

module.exports = { attach, FILE, _isOurbit: isOurbit };

'use strict';

/**
 * proxy-bridge.js — локальный прокси-мост для SOCKS5 С АВТОРИЗАЦИЕЙ.
 *
 * Зачем: Chromium НЕ поддерживает аутентификацию SOCKS5 (ошибка
 * "Browser does not support socks5 proxy authentication"). А большинство
 * коммерческих антидетект-прокси — именно socks5 с логином/паролем.
 *
 * Решение (как в ADS Power/подобных): поднимаем локальный HTTP-прокси на
 * 127.0.0.1 БЕЗ авторизации, к которому подключается Chromium, а сами
 * форвардим трафик на upstream socks5 С логином/паролем. Для Chromium это
 * обычный незапароленный прокси — ограничение обходится штатно.
 *
 * SOCKS5-хендшейк реализован вручную (RFC 1928 + 1929), без внешних пакетов,
 * поэтому мост работает даже без установленного socks-proxy-agent.
 *
 * DNS: имя хоста назначения отправляется на socks5 как домен (ATYP=0x03), то
 * есть резолвится на стороне прокси — без утечки DNS (аналог socks5h).
 */

const net = require('node:net');
const http = require('node:http');
const crypto = require('node:crypto');

/**
 * Открывает TCP-туннель к destHost:destPort через upstream socks5 (с авторизацией).
 * @returns {Promise<net.Socket>} готовый к обмену сокет
 */
function socks5Connect(proxy, destHost, destPort) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(proxy.port, proxy.host);
    let stage = 'greeting';
    const useAuth = proxy.username != null && proxy.username !== '';

    const fail = (msg) => {
      socket.destroy();
      reject(new Error(msg));
    };

    socket.on('error', (e) => fail(`socks5 connect: ${e.message}`));

    socket.on('connect', () => {
      // Приветствие: версия 5, методы: [no-auth(0), user/pass(2)] или только нужный.
      const methods = useAuth ? [0x00, 0x02] : [0x00];
      socket.write(Buffer.from([0x05, methods.length, ...methods]));
    });

    socket.on('data', (data) => {
      try {
        if (stage === 'greeting') {
          if (data[0] !== 0x05) return fail('socks5: неверная версия в ответе');
          const method = data[1];
          if (method === 0x02) {
            // Аутентификация user/pass (RFC 1929).
            const u = Buffer.from(proxy.username || '', 'utf8');
            const p = Buffer.from(proxy.password || '', 'utf8');
            socket.write(Buffer.concat([Buffer.from([0x01, u.length]), u, Buffer.from([p.length]), p]));
            stage = 'auth';
          } else if (method === 0x00) {
            sendConnect();
          } else if (method === 0xff) {
            return fail('socks5: прокси отклонил методы аутентификации (нужен логин/пароль?)');
          } else {
            return fail(`socks5: неподдерживаемый метод ${method}`);
          }
        } else if (stage === 'auth') {
          if (data[1] !== 0x00) return fail('socks5: авторизация не пройдена (неверный логин/пароль)');
          sendConnect();
        } else if (stage === 'connect') {
          if (data[0] !== 0x05) return fail('socks5: неверный ответ на CONNECT');
          if (data[1] !== 0x00) return fail(`socks5: CONNECT отклонён, код ${data[1]}`);
          // Туннель установлен. Снимаем наш парсер и отдаём сокет.
          socket.removeAllListeners('data');
          socket.removeAllListeners('error');
          resolve(socket);
        }
      } catch (e) {
        fail(`socks5: ${e.message}`);
      }
    });

    function sendConnect() {
      stage = 'connect';
      const host = Buffer.from(destHost, 'utf8');
      const req = Buffer.concat([
        Buffer.from([0x05, 0x01, 0x00, 0x03, host.length]), // VER, CMD=connect, RSV, ATYP=domain, len
        host,
        Buffer.from([(destPort >> 8) & 0xff, destPort & 0xff]),
      ]);
      socket.write(req);
    }
  });
}

function basicAuth(proxy) {
  return 'Basic ' + Buffer.from(`${proxy.username || ''}:${proxy.password || ''}`).toString('base64');
}

/**
 * Открывает TCP-туннель к destHost:destPort через upstream HTTP(S)-прокси с
 * авторизацией (метод CONNECT + заголовок Proxy-Authorization).
 *
 * Зачем, если Chromium HTTP-прокси с паролем «умеет»: умеет он через обработчик
 * Playwright, и когда тот не отвечает (или вышестоящий прокси отклоняет креды
 * повторно), Chromium показывает СИСТЕМНОЕ окно «Прокси требует имя пользователя
 * и пароль». Оно висит поверх вкладки, глотает клики и клавиши, Playwright его не
 * видит и закрыть не может — торговля встаёт до ручной «Отмены» (инцидент
 * 2026-09-07: пять сорванных заявок подряд). Через мост браузер видит локальный
 * прокси, а отказ вышестоящего становится обычным 502 — страница не грузится,
 * но окно профиля остаётся управляемым.
 * @returns {Promise<net.Socket>} готовый к обмену сокет
 */
function httpConnect(proxy, destHost, destPort) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(proxy.port, proxy.host);
    let buf = Buffer.alloc(0);
    let done = false;
    const fail = (msg) => { if (done) return; done = true; socket.destroy(); reject(new Error(msg)); };
    socket.on('error', (e) => fail(`http proxy connect: ${e.message}`));
    socket.on('connect', () => {
      const head = [`CONNECT ${destHost}:${destPort} HTTP/1.1`, `Host: ${destHost}:${destPort}`];
      if (proxy.username) head.push(`Proxy-Authorization: ${basicAuth(proxy)}`);
      socket.write(head.join('\r\n') + '\r\n\r\n');
    });
    const onData = (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      const end = buf.indexOf('\r\n\r\n');
      if (end === -1) {
        if (buf.length > 16384) fail('http proxy: ответ на CONNECT без конца заголовков');
        return;
      }
      const status = buf.slice(0, end).toString('latin1').split('\r\n')[0];
      if (!/^HTTP\/1\.[01] 200/.test(status)) return fail(`http proxy: CONNECT → ${status}`);
      socket.removeListener('data', onData);
      const rest = buf.slice(end + 4);
      if (rest.length) socket.unshift(rest);
      done = true;
      resolve(socket);
    };
    socket.on('data', onData);
  });
}

/**
 * Поднимает локальный HTTP-мост, форвардящий на upstream socks5 ИЛИ http(s)
 * (в обоих случаях — с авторизацией).
 * @param {{type:string, host:string, port:number, username?:string, password?:string}} proxy
 * @returns {Promise<{server:string, close:()=>Promise<void>}>}
 */
function startBridge(proxy, opts = {}) {
  return new Promise((resolve, reject) => {
    // Кто получил 407 и куда шёл. Системное окно «прокси требует логин» —
    // это ОТВЕТ НАШЕГО МОСТА (в окне стоит его адрес 127.0.0.1:<порт>), но до
    // сих пор мост молчал, и причину нельзя было отличить от отказа провайдера
    // (оператор 21.09: окно вернулось после двух «починок»). Пишем первые
    // ARBI_BRIDGE_407_LOG записей — этого хватает, чтобы увидеть источник, и
    // журнал не заливается при шторме (#58).
    const logLine = typeof opts.log === 'function' ? opts.log : () => {};
    let denied = 0;
    const deniedMax = Number(process.env.ARBI_BRIDGE_407_LOG || 5);
    const note407 = (what, target) => {
      denied += 1;
      if (denied <= deniedMax) {
        logLine(`Мост отказал (407) запросу без пароля: ${what} ${String(target).slice(0, 60)}`
          + (denied === deniedMax ? ' — дальше такие отказы не логируются' : ''));
      }
    };
    const server = http.createServer();
    // Туннель к upstream: socks5 — рукопожатием RFC 1928/1929, http(s) — методом
    // CONNECT. Дальше оба одинаковы: обычный сокет, который мы сшиваем с клиентом.
    // Живые туннели: Node НЕ завершает server.close() для сокетов, ушедших в
    // CONNECT (счётчик соединений не спадает даже после closeAllConnections) —
    // значит закрытие профиля с открытым туннелем висло бы вечно. Рвём сами.
    const tunnels = new Set();
    // Тип вышестоящего: socks5 — рукопожатие RFC 1928/1929; http — CONNECT.
    // Тип https (TLS до самого прокси) мост НЕ обслуживает — лаунчер такие
    // профили через него и не пускает.
    const upstreamTunnel = (host, port) =>
      (proxy.type === 'socks5' ? socks5Connect : httpConnect)(proxy, host, port);

    // SEC-2: одноразовый логин/пароль на мост. Без него любой локальный процесс,
    // узнав порт (`ss -tlnp`), гонял бы трафик через ПЛАТНЫЙ прокси под выходным IP
    // биржевого аккаунта (триггер антифрода). Креды передаём ТОЛЬКО своему Chromium
    // (Playwright proxy config шлёт Proxy-Authorization). Chromium HTTP-proxy-auth
    // поддерживает (в отличие от SOCKS5 — ради чего мост и нужен).
    const bridgeUser = 'arbi';
    const bridgePass = crypto.randomBytes(18).toString('hex');
    const expectedAuth = 'Basic ' + Buffer.from(`${bridgeUser}:${bridgePass}`).toString('base64');
    // Аварийный выключатель: если 407-хендшейк Chromium неожиданно не сработает и
    // браузер не сможет ходить через мост — ARBI_BRIDGE_NO_AUTH=1 мгновенно вернёт
    // старое поведение (мост без auth), торговля не встанет до пересборки.
    const authOff = (process.env.ARBI_BRIDGE_NO_AUTH || '') === '1';
    const authorized = (req) => {
      if (authOff) return true;
      const got = req.headers['proxy-authorization'] || '';
      if (got.length !== expectedAuth.length) return false;
      try { return crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expectedAuth)); } catch { return false; }
    };

    // HTTPS-трафик идёт через CONNECT: браузер просит туннель к host:port.
    server.on('connect', (req, clientSocket, head) => {
      if (!authorized(req)) {
        note407('CONNECT', req.url);
        try { clientSocket.write('HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm="arbi"\r\n\r\n'); } catch (_) {}
        return clientSocket.destroy();
      }
      const [host, portStr] = req.url.split(':');
      const port = Number(portStr) || 443;
      upstreamTunnel(host, port)
        .then((upstream) => {
          clientSocket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
          if (head && head.length) upstream.write(head);
          upstream.pipe(clientSocket);
          clientSocket.pipe(upstream);
          // Рвём ОБЕ половины туннеля, когда умерла любая: только на 'error' было
          // мало — закрытая вкладка даёт 'close' без ошибки, и сокет к upstream
          // оставался жить (утечка сокетов и платного трафика; из-за неё же close()
          // моста висел, пока жив хоть один такой хвост).
          tunnels.add(clientSocket); tunnels.add(upstream);
          const cleanup = () => {
            tunnels.delete(clientSocket); tunnels.delete(upstream);
            upstream.destroy(); clientSocket.destroy();
          };
          for (const ev of ['error', 'close']) { upstream.on(ev, cleanup); clientSocket.on(ev, cleanup); }
        })
        .catch(() => { try { clientSocket.write('HTTP/1.1 502 Bad Gateway\r\n\r\n'); } catch (_) {} clientSocket.destroy(); });
    });

    // Обычный HTTP (не CONNECT) — тоже туннелируем на socks5 и проксируем запрос.
    server.on('request', (req, res) => {
      if (!authorized(req)) {
        note407(req.method || 'GET', req.url);
        res.writeHead(407, { 'Proxy-Authenticate': 'Basic realm="arbi"' });
        return res.end('proxy auth required');
      }
      let url;
      try { url = new URL(req.url); } catch { res.writeHead(400); return res.end('bad request'); }
      const port = Number(url.port) || 80;
      if (proxy.type !== 'socks5') {
        // Upstream — обычный HTTP-прокси: отдаём ему запрос как есть (absolute-URI),
        // подставив ЕГО авторизацию. Мостовой Proxy-Authorization наружу не уходит:
        // это отдельный, локальный секрет (SEC-2).
        const headers = { ...req.headers };
        delete headers['proxy-authorization'];
        if (proxy.username) headers['proxy-authorization'] = basicAuth(proxy);
        const up = http.request(
          { host: proxy.host, port: proxy.port, method: req.method, path: req.url, headers },
          (pr) => { res.writeHead(pr.statusCode || 502, pr.headers); pr.pipe(res); }
        );
        up.on('error', () => { try { res.writeHead(502); } catch (_) {} res.end(); });
        req.pipe(up);
        return;
      }
      socks5Connect(proxy, url.hostname, port)
        .then((upstream) => {
          const proxied = http.request(
            { hostname: url.hostname, port, path: url.pathname + url.search, method: req.method,
              headers: req.headers, createConnection: () => upstream },
            (pr) => { res.writeHead(pr.statusCode || 502, pr.headers); pr.pipe(res); }
          );
          proxied.on('error', () => { try { res.writeHead(502); } catch (_) {} res.end(); });
          req.pipe(proxied);
        })
        .catch(() => { try { res.writeHead(502); } catch (_) {} res.end(); });
    });

    server.on('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      resolve({
        server: `http://127.0.0.1:${port}`,
        username: bridgeUser,
        password: bridgePass,
        // closeAllConnections до close: иначе close() висит, пока жив хоть один
        // туннель (а они долгоживущие — WS биржи), и закрытие профиля не завершается.
        close: () => new Promise((r) => {
          for (const sock of tunnels) { try { sock.destroy(); } catch (_) {} }
          tunnels.clear();
          try { server.closeAllConnections(); } catch (_) {}
          server.close(() => r());
          // Страховка: даже после разрыва туннелей колбэк close() у Node может не
          // прийти. Закрытие профиля не должно висеть из-за уборки — 500 мс и дальше.
          setTimeout(() => r(), 500).unref();
        }),
      });
    });
  });
}

module.exports = { startBridge, socks5Connect, httpConnect };

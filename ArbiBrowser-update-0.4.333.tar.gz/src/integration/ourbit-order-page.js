'use strict';

/**
 * ourbit-order-page.js — исполнитель Ourbit через сайт (оператор 2026-11-16: «ourbit не даёт торговать спот
 * по api, делаем все токены через arbibr»).
 *
 * API Ourbit даёт ключам только чтение истории, поэтому заявки, отмены, открытые ордера и балансы — запросы
 * самого сайта из залогиненной вкладки профиля (fetch из страницы, cookie сессии). Проба 2 (0.4.322):
 * заявка без x-ourbit-sign/nonce принимается — подпись не нужна, формы нет, ≈0,3 с на заявку.
 * Остальные заголовки сайта (luminex-uid, language, …) берутся из любого его запроса к /api/ — значения
 * нигде не пишутся.
 *
 * ⛔ МОНЕТА ПО КОНТРАКТУ (оператор 16.11: «лучше не исполнить заявку и пропустить сделку, чем купить
 * однофамильца»). Заявка сайта называет монету тикером (`currency`). Тикер берётся ТОЛЬКО из intent.symbol,
 * и заявка уходит, только если терминал приложил сверку: hints.ourbit.ticker = этот тикер, и либо
 * verified (контракты, по которым Ourbit сам называет этот тикер; сверено ≤10 мин назад), либо manual
 * (ручная заявка человека с экрана — разрешено оператором). После постановки — проверка в открытых
 * ордерах, что встала та же монета; иначе отмена.
 */

const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { formatDecimal, isPlainPositive } = require('./order-utils');
const ourbitSign = require('./ourbit-sign');

const ORIGIN = 'https://www.ourbit.com';
const SKIP_HDR = /^(cookie|host|content-length|content-type|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|cache-control|sec-|:|x-ourbit-(sign|nonce)$)/i;
const VERIFY_MAX_MS = 10 * 60_000;
const OPEN_PATH = '/api/platform/spot/order/current/orders/v2?orderTypes=1,2,3,4,5,100&pageNum=1&pageSize=100&states=0,1,3';

const hdrOf = new WeakMap(); // context → заголовки последнего запроса сайта к /api/ (без подписи и cookie)
const attached = new WeakSet();

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('request', (req) => {
    try {
      if (!req.url().startsWith(`${ORIGIN}/api/`) || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      const h = {};
      for (const [k, v] of Object.entries(req.headers() || {})) if (!SKIP_HDR.test(k)) h[k] = v;
      if (h['device-id']) rememberDevice(page, h['device-id'], h['luminex-uid']);
      delete h['device-id'];
      if (h['luminex-uid']) hdrOf.set(page.context(), h);
      if (req.method() === 'POST' && (req.headers() || {})['x-ourbit-sign']) ourbitSign.probe(page, req, (m) => console.log('[ourbit-exec] ' + m)).catch(() => {});
    } catch { /* страница закрыта */ }
  });
}

/** Следить за запросами сайта Ourbit во всех вкладках профиля (для заголовков). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

const toPair = (symbol) => String(symbol || 'BTC/USDT').toUpperCase().replace('/', '_');
const usable = (pg, context) => { try { return !!pg && !pg.isClosed() && pg.context() === context && pg.url().startsWith(ORIGIN); } catch { return false; } };

const opening = new WeakMap();
/** Живая вкладка Ourbit профиля; нет — одна новая на страницу пары (навигация не параллелится). */
async function ensurePage(context, symbol, log) {
  let pages = [];
  try { pages = context.pages(); } catch { pages = []; }
  const pg = pages.find((p) => p.__arbiDuty === 'OURBIT' && usable(p, context)) || pages.find((p) => usable(p, context));
  if (pg) return pg;
  if (opening.has(context)) return opening.get(context);
  const p = (async () => {
    const page = await context.newPage();
    page.__arbiDuty = 'OURBIT';
    onPage(page);
    const url = `${ORIGIN}/exchange/${toPair(symbol)}`;
    log(`открываю вкладку ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    return page;
  })();
  opening.set(context, p);
  try { return await p; } finally { opening.delete(context); }
}

async function headers(context, waitMs = 8000) {
  const t0 = Date.now();
  while (!hdrOf.get(context) && Date.now() - t0 < waitMs) await new Promise((r) => setTimeout(r, 200));
  return { ...(hdrOf.get(context) || {}) };
}

async function call(page, method, path, hdr, body) {
  return page.evaluate(async ({ url, method, hdr, body }) => {
    try {
      // Предел 12 с: зависший запрос сайта держал намерение по 20 с (журнал 16.11).
      const res = await fetch(url, { method, headers: hdr, body: body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)), credentials: 'include', signal: AbortSignal.timeout(12_000) });
      const txt = await res.text();
      let j = null;
      try { j = JSON.parse(txt); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, data: j ? j.data : null, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: ORIGIN + path, method, hdr, body }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
}

/** POST с подписью сайта (если разобрана, ourbit-sign.js): тело сериализуется ОДИН раз — подписывается ровно оно. */
async function signedPost(page, path, hdr, body) {
  // Сначала — HTTP-клиентом самого сайта (он сам ставит x-ourbit-sign / nonce), иначе — своей подписью (ourbit-sign).
  const viaSite = await clientPost(page, path, body, hdr['device-id'] ? { 'device-id': hdr['device-id'] } : {});
  if (viaSite) return viaSite;
  const str = JSON.stringify(body);
  return call(page, 'POST', path, { ...hdr, ...(await ourbitSign.signFor(page, str)) }, str);
}

/**
 * HTTP-КЛИЕНТ САЙТА (16.11). Подпись x-ourbit-sign считает код страницы, формула не совпала ни с одной известной
 * (MEXC и варианты × 20 ключей cookie/localStorage). Страница — Next.js: через её webpack-чанк достаём кэш модулей
 * и ищем экземпляр axios с перехватчиком запросов, который подписывает (в коде перехватчика есть «sign»). Через него
 * запрос уходит так же, как от кнопки сайта. Не найден — null (дальше своя подпись / отказ). В журнал — только счётчики.
 */
const clientInfoLogged = new WeakSet();
async function clientPost(page, path, body, headers) {
  const r = await page.evaluate(async ({ url, body, headers }) => {
    const w = window;
    if (!w.__arbiOb) {
      const info = { chunk: false, mods: 0, axios: 0, signing: 0 };
      let client = null;
      try {
        const key = Object.keys(w).find((k) => /^webpackChunk/.test(k));
        const chunk = key && w[key];
        let req = null;
        if (chunk && typeof chunk.push === 'function') { info.chunk = true; chunk.push([[Symbol('arbi')], {}, (rq) => { req = rq; }]); }
        const mods = req && req.c ? Object.values(req.c) : [];
        info.mods = mods.length;
        const cands = [];
        for (const m of mods) {
          const ex = m && m.exports;
          if (!ex || (typeof ex !== 'object' && typeof ex !== 'function')) continue;
          let vals = [];
          try { vals = [ex, ex.default, ...Object.values(ex)]; } catch { vals = [ex]; }
          for (const v of vals) {
            try {
              if (v && v.interceptors && v.interceptors.request && typeof v.post === 'function' && !cands.some((c) => c.v === v)) {
                const src = (v.interceptors.request.handlers || []).map((h) => String(h && h.fulfilled)).join(' ');
                cands.push({ v, signs: /sign/i.test(src) });
              }
            } catch { /* геттер модуля */ }
          }
        }
        info.axios = cands.length;
        info.signing = cands.filter((c) => c.signs).length;
        const pick = cands.find((c) => c.signs);
        client = pick ? pick.v : null;
      } catch (e) { info.err = String(e && e.message || e).slice(0, 80); }
      w.__arbiOb = { client, info };
    }
    const ob = w.__arbiOb;
    if (!ob.client) return { info: ob.info };
    try {
      let j = await ob.client.post(url, body, { headers });
      if (j && j.data && typeof j.data === 'object' && 'code' in j.data && !('code' in j)) j = j.data;
      return { info: ob.info, res: { status: 200, code: j ? j.code : null, data: j ? j.data : null, msg: j ? String(j.msg || '').slice(0, 160) : 'пусто' } };
    } catch (e) {
      const d = e && e.response && e.response.data;
      if (d && typeof d === 'object') return { info: ob.info, res: { status: e.response.status || 200, code: d.code, data: d.data, msg: String(d.msg || '').slice(0, 160) } };
      if (e && typeof e === 'object' && 'code' in e && !e.response) return { info: ob.info, res: { status: 200, code: e.code, data: e.data, msg: String(e.msg || e.message || '').slice(0, 160) } };
      return { info: ob.info, res: { error: String(e && e.message || e).slice(0, 160) } };
    }
  }, { url: ORIGIN + path, body, headers }).catch((e) => ({ info: { err: String(e && e.message || e).slice(0, 80) } }));
  if (!clientInfoLogged.has(page)) {
    clientInfoLogged.add(page);
    const i = r.info || {};
    console.log(`[ourbit-exec] [клиент сайта] модулей ${i.mods || 0}, axios ${i.axios || 0}, с подписью ${i.signing || 0}${i.chunk ? '' : ', webpack-чанк не найден'}${i.err ? `, ошибка: ${i.err}` : ''} — ${r.res ? 'запросы вывода идут клиентом сайта' : 'клиент не найден'}`);
  }
  return r.res || null;
}

const ok = (r) => !!r && r.status === 200 && (r.code === 200 || r.code === 0);
const noLogin = (r) => !!r && (r.status === 401 || r.code === 401 || /log ?in|登录|未登录|session/i.test(String(r.msg || '')));
const fail = (what, r) => (noLogin(r)
  ? { ok: false, loginRequired: true, error: `Ourbit: нет входа в аккаунт в ArbiBrowser — ${what} не выполнено. Войдите в окне профиля.` }
  : { ok: false, error: `Ourbit: ${what} — отказ сайта (HTTP ${r && r.status != null ? r.status : '-'} code=${r && r.code != null ? r.code : '-'} «${(r && (r.msg || r.error)) || ''}»)` });

/** Проверка, которую обязан пройти каждый боевой ордер: монета подтверждена терминалом. null — можно. */
function coinGate(intent) {
  const base = String(intent.symbol || '').split('/')[0].toUpperCase();
  const g = intent.hints && intent.hints.ourbit;
  if (!g || String(g.ticker || '').toUpperCase() !== base) return 'терминал не подтвердил монету';
  if (g.manual === true) return null;
  if (!Array.isArray(g.verified) || !g.verified.length) return 'монета не сверена по контракту';
  const lag = Number(intent.createdAt) - Number(g.at);
  if (!(Number(g.at) > 0) || !(lag >= -60_000 && lag <= VERIFY_MAX_MS)) return 'сверка по контракту устарела';
  return null;
}

let loggedKeys = false;
const rowId = (x) => String((x && (x.id != null ? x.id : x.orderId)) || '');
const rowCoin = (x) => String((x && (x.currency || String(x.symbol || '').split(/[_/]/)[0])) || '').toUpperCase();

async function openRows(page, hdr) {
  const r = await call(page, 'GET', OPEN_PATH, hdr);
  if (!ok(r)) return { r };
  const rows = Array.isArray(r.data && r.data.resultList) ? r.data.resultList : [];
  return { rows };
}

async function cancel(page, hdr, orderId) {
  return call(page, 'DELETE', `/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(orderId)}`, hdr);
}

async function placeOrder(context, intent, log) {
  const why = coinGate(intent);
  if (why) return { ok: false, error: `Ourbit: ${why} — заявка не отправлена` };
  if (intent.type !== 'limit') return { ok: false, error: 'Ourbit: через сайт — только лимитные заявки (рыночная = агрессивная лимитка терминала)' };
  const [base, quote = 'USDT'] = String(intent.symbol).toUpperCase().split('/');
  const price = formatDecimal(intent.price);
  const quantity = formatDecimal(intent.quantity);
  if (!isPlainPositive(price) || !isPlainPositive(quantity)) return { ok: false, error: `Ourbit: цена/объём не числа (${intent.price} / ${intent.quantity})` };
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = { ...(await headers(context)), 'content-type': 'application/json' };
  const body = { currency: base, market: quote, tradeType: intent.side === 'sell' ? 'SELL' : 'BUY', price, quantity, orderType: 'LIMIT_ORDER' };
  const t0 = Date.now();
  const r = await call(page, 'POST', '/api/platform/spot/order/place', hdr, body);
  const ms = Date.now() - t0;
  if (r.error || (r.status >= 500)) return { ok: false, error: `Ourbit: ответа на заявку нет (${r.error || `HTTP ${r.status}`}) — заявка МОГЛА встать, проверьте открытые ордера` };
  const orderId = ok(r) && typeof r.data === 'string' && r.data ? r.data : null;
  if (!orderId) return fail(`заявка ${base}/${quote}`, r);
  log(`Ордер выставлен: ${orderId} — ${intent.side} ${quantity} ${base} @ ${price}, ответ ${ms} мс${intent.hints.ourbit.manual ? ' (ручная, без сверки контракта)' : ''}`);
  // Встала та же монета? Не нашли строку (уже исполнилась) — тело заявки и так несло подтверждённый тикер.
  const { rows } = await openRows(page, { ...hdr });
  const row = (rows || []).find((x) => rowId(x) === orderId);
  if (row && !loggedKeys) { loggedKeys = true; log(`поля открытого ордера сайта: ${Object.keys(row).join(',')}`); }
  const coin = row ? rowCoin(row) : '';
  if (coin && coin !== base) {
    const c = await cancel(page, hdr, orderId);
    return { ok: false, error: `Ourbit поставил заявку по ${coin} вместо ${base} — ${ok(c) ? 'заявка отменена' : `⚠ ОТМЕНИТЬ НЕ УДАЛОСЬ, снимите заявку ${orderId} руками`}` };
  }
  return { ok: true, orderId, direct: true };
}

// Сеть сайта (chainName «Solana(SOL)», walletType «SOL») → канон терминала (как canonChain в CEX exchange/ourbit.ts).
function canonChain(raw) {
  const s = String(raw || '').toLowerCase();
  if (s.includes('bep20') || s === 'bsc' || s === 'bnb' || s.includes('bnb smart')) return 'BSC';
  if (s.includes('erc20') || s === 'eth' || s === 'ethereum') return 'ETH';
  if (s.includes('trc20') || s === 'tron' || s === 'trx') return 'TRX';
  if (s === 'sol' || s.startsWith('solana')) return 'SOL';
  if (s === 'base' || s.startsWith('base(') || s.startsWith('base ')) return 'BASE';
  if (s.startsWith('arbitrum') || s === 'arb') return 'ARBITRUM';
  if (s.startsWith('polygon') || s === 'matic') return 'POLYGON';
  return String(raw || '').toUpperCase();
}

/**
 * Сеть монеты по справочнику сайта (`spot/currency/v3`, как страницы депозита и вывода). У сети своя «монета сайта»
 * (`currency`: USDT-BNB, USDT-ETH; USDT = TRC20), и адрес депозита выдаётся ПО НЕЙ (запись 16.11) — запрос с общим
 * «USDT» и сетью BSC давал адрес TRON. Ровно одна сеть под запрошенную, иначе отказ.
 */
async function chainOf(page, hdr, coin, chain) {
  const r = await call(page, 'GET', `/api/platform/asset/api/asset/spot/currency/v3?currency=${encodeURIComponent(coin)}`, hdr);
  if (!ok(r) || !r.data || !Array.isArray(r.data.chains)) return { r };
  const want = canonChain(chain);
  const hits = r.data.chains.filter((n) => canonChain(n.walletType) === want || canonChain(n.chainName) === want);
  if (hits.length !== 1) return { why: `у ${coin} на Ourbit ${hits.length ? 'несколько сетей' : 'нет сети'} ${chain} (есть: ${r.data.chains.map((n) => n.chainName).join(', ') || '—'})` };
  return { c: hits[0], available: r.data.available };
}

const fmtOf = (a) => (/^0x[0-9a-fA-F]{40}$/.test(a) ? 'EVM' : /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a) ? 'TRON' : /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a) ? 'base58' : 'другой');

const deviceOf = new WeakMap(); // context → заголовок device-id сайта (его шлёт только подтверждение вывода)

/*
 * device-id сайта (16.11): без него подтверждение быстрого вывода отвечает 60008 «неверный код» — сайт шлёт его только
 * в submit_withdraw. Запоминаем на диске по аккаунту Ourbit (luminex-uid) — переживает перезапуск ArbiBrowser, и один
 * раз ищем, где страница его хранит (в журнал — только ИМЯ ключа хранилища, не значение).
 */
const DEV_FILE = () => path.join(config.reportsDir, 'ourbit-device.json');
function devStore() { try { return JSON.parse(fs.readFileSync(DEV_FILE(), 'utf8')) || {}; } catch { return {}; } }
const devLogged = new Set();
function rememberDevice(page, dev, uid) {
  deviceOf.set(page.context(), dev);
  if (!uid) return;
  const st = devStore();
  if (st[uid] !== dev) {
    st[uid] = dev;
    try { fs.mkdirSync(path.dirname(DEV_FILE()), { recursive: true }); fs.writeFileSync(DEV_FILE(), JSON.stringify(st)); } catch { /* не записали — живёт до перезапуска */ }
  }
  if (devLogged.has(uid)) return;
  devLogged.add(uid);
  page.evaluate((v) => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (String(localStorage.getItem(k) || '').includes(v)) out.push(`localStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); if (String(sessionStorage.getItem(k) || '').includes(v)) out.push(`sessionStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (const c of document.cookie.split(';')) { const [k, ...r] = c.split('='); if (r.join('=').includes(v)) out.push(`cookie «${k.trim()}»`); } } catch { /* нет доступа */ }
    return out;
  }, dev).then((where) => console.log(`[ourbit-exec] device-id сайта запомнен (${dev.length} симв.); на странице — ${where.length ? where.join(', ') : 'не найден в хранилищах'}`))
    .catch(() => {});
}

/**
 * БЫСТРЫЙ ВЫВОД (запись 16.11): check_chain/v3 → save_withdraw/v4 → submit_withdraw/v3 — то же, что кнопки сайта
 * (окно подтверждения сайта = submit). Только если сайт сам говорит isQuickWithdraw (адрес в белом списке Ourbit,
 * сумма в лимите) — иначе он попросит коды почты/Google, и вывод не отправляется. Перед подтверждением — сверка:
 * адрес, на который сайт выводит (addressText), равен адресу терминала.
 */
async function withdraw(page, context, hdr0, s, log) {
  const coin = String(s.coin || '').toUpperCase();
  const address = String(s.address || '').trim();
  const amount = formatDecimal(s.amount);
  if (!address || !isPlainPositive(amount)) return { ok: false, error: 'Ourbit: вывод без адреса или суммы' };
  const n = await chainOf(page, hdr0, coin, s.chain);
  if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
  if (!n.c) return fail('справочник сетей', n.r);
  if (n.c.enableWithdraw === false) return { ok: false, error: `Ourbit: вывод ${coin} в сети ${n.c.chainName} закрыт` };
  const chainName = String(n.c.chainName);
  const hdr = { ...hdr0, 'content-type': 'application/json' };
  const cc = await signedPost(page, '/api/platform/asset/api/withdraw/check_chain/v3', hdr, { amount, address, chainName, currency: coin });
  if (!ok(cc) || !cc.data) return fail(`проверка вывода ${coin} ${chainName}`, cc);
  if (cc.data.isQuickWithdraw !== true) {
    return { ok: false, error: `Ourbit просит коды почты/Google для этого вывода (сумма больше лимита быстрого вывода или адрес не в белом списке Ourbit) — сделайте вывод на сайте` };
  }
  const sv = await signedPost(page, '/api/platform/asset/api/withdraw/save_withdraw/v4', hdr, {
    amount, address, chain: chainName, currency: coin, isQuickWithdraw: true,
    drawImageRequest: { backGroundColor: { colorR: 248, colorG: 248, colorB: 249 }, fontColor: { colorR: 27, colorG: 28, colorB: 29 }, fontSize: 28, width: 616, alignRight: true },
  });
  if (!ok(sv) || !sv.data || !sv.data.requestId) return fail(`подготовка вывода ${coin}`, sv);
  if (sv.data.addressText && String(sv.data.addressText).trim().toLowerCase() !== address.toLowerCase()) {
    return { ok: false, error: 'Ourbit: адрес вывода на сайте не совпал с адресом терминала — вывод НЕ подтверждён' };
  }
  // device-id = отпечаток браузера сайта: localStorage «ob_local_fingerprint_visitorId» (найден 16.11), запасные — сохранённый.
  const fromPage = await page.evaluate(() => { try { return localStorage.getItem('ob_local_fingerprint_visitorId') || ''; } catch { return ''; } }).catch(() => '');
  const dev = fromPage || deviceOf.get(context) || devStore()[hdr0['luminex-uid']];
  if (!dev) log('device-id сайта не найден — если подтверждение откажет (60008), сделайте один вывод на сайте Ourbit в этом профиле');
  const sb = await signedPost(page, '/api/platform/asset/api/withdraw/submit_withdraw/v3', dev ? { ...hdr, 'device-id': dev } : hdr, { isQuickWithdraw: 'true', requestId: String(sv.data.requestId) });
  if (sb.error || sb.status >= 500) return { ok: false, error: `Ourbit: ответа на подтверждение вывода нет (${sb.error || `HTTP ${sb.status}`}) — вывод МОГ пройти, проверьте историю выводов`, maybe: true };
  if (sb.code === 60008) {
    return { ok: false, error: ourbitSign.known()
      ? 'Ourbit не принял подтверждение быстрого вывода (60008) даже с подписью сайта — пришлите журнал ArbiBrowser. Вывод не отправлен.'
      : 'Ourbit требует подпись сайта на подтверждении вывода (60008): откройте на ourbit.com в этом профиле страницу вывода и выберите адрес — ArbiBrowser разберёт подпись (в журнале «[подпись сайта] совпало»), затем повторите. Вывод не отправлен.' };
  }
  if (!ok(sb) || !sb.data) return fail(`подтверждение вывода ${coin}`, sb);
  if (sb.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit', needVerify: true };
  log(`Вывод ${amount} ${coin} → ${chainName}: подтверждён быстрым выводом (адрес формата ${fmtOf(address)})`);
  return { ok: true, withdrawId: String(sb.data.withdrawId || '') };
}

async function siteCall(context, intent, log) {
  const t0 = Date.now();
  const r = await siteCallInner(context, intent, log);
  const ms = Date.now() - t0;
  if (ms > 3000) log(`запрос сайта ${intent.site && intent.site.op} шёл ${ms} мс${r && r.error ? ` (ошибка: ${String(r.error).slice(0, 80)})` : ''}`);
  return r;
}

async function siteCallInner(context, intent, log) {
  const s = intent.site || {};
  const t0 = Date.now();
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = await headers(context);
  if (Date.now() - t0 > 3000) log(`вкладка/заголовки сайта готовы за ${Date.now() - t0} мс`);
  if (s.op === 'cancel') {
    if (!s.orderId) return { ok: false, error: 'Ourbit: отмена без номера заявки' };
    const r = await cancel(page, hdr, s.orderId);
    return ok(r) ? { ok: true, canceled: s.orderId } : fail(`отмена ${s.orderId}`, r);
  }
  if (s.op === 'open') {
    const { rows, r } = await openRows(page, hdr);
    return rows ? { ok: true, rows } : fail('открытые ордера', r);
  }
  if (s.op === 'depositAddress') {
    const coin = String(s.coin || '').toUpperCase();
    const n = await chainOf(page, hdr, coin, s.chain);
    if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
    if (!n.c) return fail('справочник сетей', n.r);
    if (n.c.supportMemo === true) return { ok: false, error: `Ourbit: сеть ${n.c.chainName} с memo — адрес с сайта не выдаю, возьмите адрес и memo на сайте` };
    const vcoin = String(n.c.currency || coin);
    let address = String(n.c.address || '');
    if (!address) {
      const r = await call(page, 'POST', '/api/platform/deposit/address/create', { ...hdr, 'content-type': 'application/json' }, { currency: vcoin, chainName: n.c.chainName });
      if (!ok(r) || !r.data || !r.data.address) return fail(`адрес депозита ${vcoin} ${n.c.chainName}`, r);
      // Перепроверка: тот же адрес сайт показывает у ЭТОЙ сети монеты.
      const again = await chainOf(page, hdr, coin, s.chain);
      if (!again.c || String(again.c.address || '') !== String(r.data.address)) {
        return { ok: false, error: `Ourbit: выданный адрес ${vcoin} не совпал с адресом сети ${n.c.chainName} в списке сайта — адрес не показан` };
      }
      address = String(r.data.address);
    }
    log(`адрес депозита ${coin}: просили ${s.chain} → сеть сайта «${n.c.chainName}» (${vcoin}), адрес формата ${fmtOf(address)}`);
    return { ok: true, address, vcoin, chainName: n.c.chainName, enableDeposit: n.c.enableDeposit !== false };
  }
  if (s.op === 'withdraws') {
    const r = await call(page, 'GET', '/api/platform/withdraw/latest', hdr);
    if (!ok(r)) return fail('история выводов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      id: String(x.id || ''), coin: String(x.vcoinName || '').toUpperCase(), chain: canonChain(x.walletType), address: String(x.address || ''),
      amount: String(x.amount || '0'), fee: x.fee != null ? String(x.fee) : undefined, txHash: String(x.txid || ''),
      state: String(x.state || ''), time: Number(x.createTime) || 0, updated: Number(x.updateTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'wdConfig') {
    const r = await call(page, 'GET', '/api/platform/asset/api/withdraw/query/config/v3', hdr);
    if (!ok(r) || !r.data) return fail('настройки вывода', r);
    return { ok: true, quick: r.data.quickWithdrawEnabled === true, perWithdraw: Number(r.data.perWithdrawAmount) || 0, whiteList: r.data.whiteListEnabled === true };
  }
  if (s.op === 'withdraw') return withdraw(page, context, hdr, s, log);
  if (s.op === 'deposits') {
    const r = await call(page, 'GET', '/api/platform/asset/api/deposit/v2/latest', hdr);
    if (!ok(r)) return fail('история депозитов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      coin: String(x.vcoinName || x.currency || '').toUpperCase(), chain: canonChain(x.walletType || x.chainName),
      amount: String(x.amount || '0'), txHash: String(x.transactionHash || String(x.txid || '').split(':')[0] || ''),
      confirmations: Number(x.confirmations) || 0, required: Number(x.requireConfirmations) || 0,
      state: String(x.state || ''), time: Number(x.receiptTime || x.createTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'balances') {
    // Список монет спота — из сводки, точные «доступно / в заявках» — запросом по этим монетам.
    const o = await call(page, 'GET', '/api/platform/asset/api/asset/overview/convert/v2', hdr);
    if (!ok(o)) return fail('балансы', o);
    const coins = (Array.isArray(o.data) ? o.data : []).filter((x) => Number(x && x.spot) > 0).map((x) => String(x.currency || '').toUpperCase()).filter(Boolean);
    if (!coins.includes('USDT')) coins.push('USDT');
    const b = await call(page, 'GET', `/api/platform/spot/asset/currency/balances?currency=${coins.map(encodeURIComponent).join(',')}`, hdr);
    if (!ok(b)) return fail('балансы', b);
    const rows = (Array.isArray(b.data) ? b.data : []).map((x) => ({ currency: String(x.currency || '').toUpperCase(), available: String(x.available || '0'), frozen: String(x.frozen || '0') }));
    return { ok: true, rows };
  }
  return { ok: false, error: `Ourbit: неизвестный запрос сайта ${s.op}` };
}

async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  attach(context);
  if (intent.site) return siteCall(context, intent, log);
  if (intent.warmup) { await ensurePage(context, intent.symbol, log); return { ok: true, warmed: true }; }
  if (intent.loginCheck || intent.closeStale || intent.balance || intent.orders || intent.cancelAll) {
    return intent.loginCheck || intent.closeStale ? { ok: true, skipped: true } : { ok: false, error: 'Ourbit: этот вид намерения не поддержан (балансы/ордера — запросом сайта)' };
  }
  return placeOrder(context, intent, log);
}

module.exports = { attach, executeIntent, toPair, _coinGate: coinGate, _rowCoin: rowCoin, _canonChain: canonChain, _withdraw: withdraw };

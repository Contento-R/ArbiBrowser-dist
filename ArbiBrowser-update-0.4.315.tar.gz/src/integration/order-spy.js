'use strict';

/**
 * РАЗВЕДКА «заявка запросом» для BingX и XT (оператор 06.11: на MEXC заявка на любую монету уходит
 * запросом из одной служебной вкладки — проверить ту же схему на других биржах). Ничего не ставит и
 * не отменяет: на обычной заявке формой пишет в журнал устройство её запроса — адрес, вид тела, ИМЕНА
 * полей тела, параметров адреса и нестандартных заголовков (один раз на биржу+пару+сторону), а на
 * отмене ОДНОЙ заявки на сайте — каким запросом сайт её отменяет. Значения (подписи, токены, cookies,
 * цены) в журнал не пишутся никогда.
 */

const seen = new Set();
// Заголовки, которые ставит сам браузер, — не интересны; остальные (подписи, метки устройства) — именами.
const STD_HDR = /^(cookie|host|content-length|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|pragma|cache-control|content-type|sec-|:)/i;

function bodyKeys(raw) {
  if (!raw) return { kind: 'пустое', keys: [] };
  try {
    const j = JSON.parse(raw);
    if (j && typeof j === 'object' && !Array.isArray(j)) return { kind: 'JSON', keys: Object.keys(j) };
    return { kind: 'JSON-не объект', keys: [] };
  } catch { /* не JSON */ }
  try {
    const keys = [...new URLSearchParams(raw).keys()];
    if (keys.length) return { kind: 'форма', keys };
  } catch { /* не форма */ }
  return { kind: `не разобрано (${raw.length} байт)`, keys: [] };
}

/** Запрос постановки заявки (Playwright Request) → строка журнала, один раз на exchange+tag+путь. */
async function spyPlace(exchange, req, tag) {
  try {
    const u = new URL(req.url());
    const key = `${exchange}|${tag}|${u.pathname}`;
    if (seen.has(key)) return;
    seen.add(key);
    let h = {};
    try { h = await req.allHeaders(); } catch { h = req.headers(); }
    const { kind, keys } = bodyKeys(req.postData() || '');
    const ct = String(h['content-type'] || '?').split(';')[0];
    const hdrs = Object.keys(h).filter((k) => !STD_HDR.test(k));
    console.log(`[${exchange}-exec] [разведка заявки] ${tag}: ${req.method()} ${u.host}${u.pathname}; тело ${kind} (${ct}): ${keys.join(',') || '—'}; параметры адреса: ${[...u.searchParams.keys()].join(',') || '—'}; особые заголовки: ${hdrs.join(',') || '—'}`);
  } catch { /* разведка не мешает работе */ }
}

/** Отмена на сайте (ручная или наша) — каким запросом; один слушатель на профиль и биржу. */
function spyCancel(context, exchange, hostRe) {
  const flag = `__arbiCancelSpy_${exchange}`;
  if (!context || context[flag]) return;
  context[flag] = true;
  context.on('response', async (r) => {
    try {
      const q = r.request();
      if (q.method() !== 'POST' && q.method() !== 'DELETE') return;
      const u = new URL(q.url());
      if (!hostRe.test(u.hostname) || !/cancel/i.test(u.pathname)) return;
      const { kind, keys } = bodyKeys(q.postData() || '');
      let code = null;
      try { const j = await r.json(); code = j.code ?? j.rc ?? null; } catch { /* не JSON */ }
      console.log(`[${exchange}-exec] [разведка отмены] ${q.method()} ${u.host}${u.pathname}; тело ${kind}: ${keys.join(',') || '—'}; параметры адреса: ${[...u.searchParams.keys()].join(',') || '—'}; ответ HTTP ${r.status()} code=${code}`);
    } catch { /* разведка не мешает работе */ }
  });
}

// ── САМОПРОВЕРКА ПОДПИСИ ЗАЯВКИ BingX (оператор 12.11: «заявки частями из одной вкладки») ──
// Код страницы BingX (бандл _nuxt, функции Le/Re) подписывает каждый запрос так:
//   sign = SHA256(соль + timestamp + traceId + deviceId + platformId + appVersion + antiDeviceId + тело).toUpperCase(),
// соль — открытая строка из кода сайта, тело — fast-json-stable-stringify от тела, где числа и булевы — строками,
// null — "null". Если наш пересчёт совпадает с подписью настоящей заявки через форму, вкладка сможет отправлять
// части сама (без вкладок-частей). Здесь ТОЛЬКО сверка: ничего не отправляем, значения заголовков не пишем.
const crypto = require('crypto');
const BX_SALT = '95d65c73dc5c437' + '0ae9018fb7' + 'f2eab69';
function bxNorm(o) {
  for (const k of Object.keys(o)) {
    const v = o[k];
    if (v === null) o[k] = 'null';
    else if (typeof v === 'object') o[k] = bxNorm(v);
    else if (typeof v === 'number') o[k] = String(v).toUpperCase();
    else if (typeof v === 'boolean') o[k] = String(v);
  }
  return o;
}
function stableJson(v) {
  if (v === undefined) return undefined;
  if (typeof v === 'number') return isFinite(v) ? String(v) : 'null';
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map((x) => stableJson(x) || 'null').join(',') + ']';
  const parts = [];
  for (const k of Object.keys(v).sort()) { const sv = stableJson(v[k]); if (sv !== undefined) parts.push(JSON.stringify(k) + ':' + sv); }
  return '{' + parts.join(',') + '}';
}
function bingxSign(h, bodyStr, devKey = 'device_id') {
  let m = '{}';
  let v = null;
  try { v = bodyStr ? JSON.parse(bodyStr) : null; } catch { v = null; }
  if (v && typeof v === 'object' && JSON.stringify(v) !== '{}') m = stableJson(bxNorm(JSON.parse(JSON.stringify(v))));
  const src = BX_SALT + (h.timestamp || '') + (h.traceid || '') + (h[devKey] || '') + (h.platformid || '') + (h.app_version || '') + (h.antideviceid || '') + m;
  return crypto.createHash('sha256').update(src).digest('hex').toUpperCase();
}
let bxChecks = 0;
async function bingxSignCheck(req) {
  if (bxChecks >= 3) return;
  bxChecks += 1;
  try {
    let h = {};
    try { h = await req.allHeaders(); } catch { h = req.headers(); }
    const got = String(h.sign || '').toUpperCase();
    if (!got) { console.log('[bingx-exec] [подпись BingX] в запросе заявки нет заголовка sign — сверять нечего'); return; }
    const variant = ['device_id', 'visitorid'].find((k) => bingxSign(h, req.postData() || '', k) === got);
    console.log(variant
      ? `[bingx-exec] [подпись BingX] пересчёт СОВПАЛ (deviceId из «${variant}») — заявки частями можно слать из одной вкладки`
      : '[bingx-exec] [подпись BingX] пересчёт НЕ совпал — сайт считает подпись иначе, прямые заявки не включать');
  } catch (e) { console.log(`[bingx-exec] [подпись BingX] сверка не удалась: ${e && e.message ? e.message : e}`); }
}

module.exports = { spyPlace, spyCancel, bodyKeys, bingxSign, bingxSignCheck };

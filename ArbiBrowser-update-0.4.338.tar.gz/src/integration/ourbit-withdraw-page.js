'use strict';

/**
 * ourbit-withdraw-page.js — ВЫВОД OURBIT ЧЕРЕЗ ФОРМУ САЙТА (оператор 16.11).
 *
 * Подтверждение вывода (submit_withdraw) сайт принимает только после невидимой капчи Geetest, которую запускает
 * сама страница при нажатии «Вывести» (запись 16.11: check_chain → captcha/robot/robot.assets.withdraw → gcaptcha4
 * load/verify → save_withdraw → submit_withdraw). Прямой запрос — 60008 «验证码错误» при тех же заголовках и подписи.
 * Поэтому вывод делает страница: своя вкладка вывода, сеть, адрес и сумма вводятся настоящими нажатиями, «Вывести»,
 * окно подтверждения — «Подтвердить». Капча — дело страницы; потребовала пазл — вкладка вперёд, ждём человека.
 *
 * Деньги защищены сверкой ЗАПРОСА самой страницы, а не разметки: до «Подтвердить» читаем тело save_withdraw, которое
 * отправила страница, — сумма, адрес, сеть, монета должны совпасть с намерением терминала; иначе окно закрывается,
 * ничего не подтверждено. Исход — ответ submit_withdraw страницы (withdrawId / код ошибки). Разметки не видно из
 * среды разработки: элементы ищутся по подписям (ru/en); не нашли — в журнал структура формы без значений.
 */

const ORIGIN = 'https://www.ourbit.com';
const TAB = 'OURBIT-WD';
const HUMAN_MS = Math.max(30_000, Number(process.env.ARBI_OURBIT_WD_HUMAN_MS) || 120_000);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const lower = (s) => String(s || '').trim().toLowerCase();

/** Тело save_withdraw страницы против намерения. null — совпало, иначе причина (для отказа). */
function saveMismatch(bodyStr, want) {
  let b = null;
  try { b = JSON.parse(bodyStr || ''); } catch { return 'тело подготовки вывода не прочитано'; }
  if (String(b.currency || '').toUpperCase() !== want.coin) return `монета ${b.currency} вместо ${want.coin}`;
  if (lower(b.address) !== lower(want.address)) return 'адрес на странице не тот, что в терминале';
  if (String(b.chain || '') !== want.chainName) return `сеть «${b.chain}» вместо «${want.chainName}»`;
  const a = Number(b.amount);
  const w = Number(want.amount);
  if (!(a > 0) || Math.abs(a - w) > Math.max(1e-9, w * 1e-9)) return `сумма ${b.amount} вместо ${want.amount}`;
  return null;
}

/** Структура формы вывода без значений — для правки поиска элементов по журналу. */
async function dumpForm(page, log, why) {
  const d = await page.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); const st = getComputedStyle(e); return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none'; };
    const t = (s, n = 40) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
    const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
    const inputs = [...document.querySelectorAll('input,textarea')].filter(vis).slice(0, 12).map((e) => `поле ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
    const sels = [...document.querySelectorAll('[class*="select" i]')].filter((e) => vis(e) && !e.querySelector('[class*="select" i]')).slice(0, 8).map((e) => `выбор ${cls(e)} «${t(e.textContent, 30)}»`);
    const btns = [...new Set([...document.querySelectorAll('button,[role="button"]')].filter(vis).map((b) => t(b.innerText, 24)).filter(Boolean))].slice(0, 20);
    const opts = [...document.querySelectorAll('.ant-select-item-option')].filter(vis).slice(0, 15).map((o) => t(o.innerText, 40));
    return [...inputs, ...sels, `кнопки=[${btns.join(' | ')}]`, `пункты списка=[${opts.join(' | ')}]`].join(' ; ');
  }).catch((e) => `не снята: ${e.message}`);
  log(`[форма вывода] ${why}: ${d}`);
}

async function wdPage(context, coin, log) {
  let pg = null;
  try { pg = context.pages().find((p) => p.__arbiDuty === TAB && !p.isClosed()); } catch { pg = null; }
  if (!pg) { pg = await context.newPage(); pg.__arbiDuty = TAB; }
  const url = `${ORIGIN}/ru-RU/assets/withdraw/${coin}`;
  log(`вывод: открываю форму ${url}`);
  await pg.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 }); // всегда свежая форма — без остатков прошлого ввода
  await pg.locator('input').first().waitFor({ state: 'visible', timeout: 20_000 }).catch(() => {});
  await sleep(800);
  return pg;
}

async function typeInto(pg, loc, text) {
  await loc.click({ timeout: 4000 });
  await pg.keyboard.press('ControlOrMeta+a').catch(() => {});
  await pg.keyboard.press('Backspace').catch(() => {});
  await pg.keyboard.type(String(text), { delay: 25 });
}

const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

/**
 * Сеть: ant-select с подсказкой «Выберите сеть вывода средств» (журнал 16.11) → пункт списка с именем сети сайта.
 * Сеть уже выбрана (страница сама выбрала по адресу) — ничего не трогаем. Ошибиться пунктом не страшно: деньги
 * защищает сверка тела save_withdraw (там сеть сайта), но выбираем строго: пункт = имя сети, иначе единственный,
 * где оно встречается.
 */
async function pickNetwork(pg, chainName, log) {
  const chosen = pg.locator('.ant-select-selection-item').filter({ hasText: chainName });
  if (await chosen.first().isVisible().catch(() => false)) return true;
  const sel = pg.locator('.ant-select').filter({ has: pg.locator('.ant-select-selection-placeholder', { hasText: /сеть|network/i }) }).first();
  const opened = await sel.locator('.ant-select-selector').click({ timeout: 4000 }).then(() => true).catch(() => false);
  if (!opened) { await dumpForm(pg, log, 'не открылся выбор сети'); return false; }
  const opts = pg.locator('.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option');
  await opts.first().waitFor({ state: 'visible', timeout: 4000 }).catch(() => {});
  const texts = (await opts.allInnerTexts().catch(() => [])).map(norm);
  let i = texts.indexOf(chainName);
  if (i < 0) { const hits = texts.map((t, k) => (t.includes(chainName) ? k : -1)).filter((k) => k >= 0); if (hits.length === 1) i = hits[0]; }
  if (i < 0) { await dumpForm(pg, log, `нет пункта сети «${chainName}»`); await pg.keyboard.press('Escape').catch(() => {}); return false; }
  await opts.nth(i).click({ timeout: 4000 });
  await sleep(400);
  return true;
}

function waitPost(pg, re, ms) {
  return pg.waitForResponse((r) => re.test(r.url()) && r.request().method() === 'POST', { timeout: ms })
    .then(async (r) => ({ body: r.request().postData() || '', json: await r.json().catch(() => null) }))
    .catch(() => null);
}

/**
 * Вывод формой. want: { coin, chainName, address, amount }. Возврат — как у прямого пути:
 * { ok:true, withdrawId } | { ok:false, error, maybe? }.
 */
async function withdrawViaForm(context, want, log) {
  const pg = await wdPage(context, want.coin, log);

  // Порядок полей на странице (журнал 16.11): адрес, затем сеть, затем сумма — сумма появляется после выбора сети.
  const addr = pg.locator('input[placeholder*="адрес" i], input[placeholder*="address" i], textarea[placeholder*="адрес" i], textarea[placeholder*="address" i]').first();
  if (!(await addr.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля адреса'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле адреса — вывод не отправлен' }; }
  const checkAddr = waitPost(pg, /withdraw_check_address/, 5000);
  await typeInto(pg, addr, want.address);
  await pg.keyboard.press('Tab').catch(() => {});
  await checkAddr; // страница сверила адрес (как при ручном вводе); нет ответа — не страшно, сверка ниже по save_withdraw
  await sleep(300);

  if (!(await pickNetwork(pg, want.chainName, log))) return { ok: false, error: `Ourbit: на форме вывода не нашлась сеть «${want.chainName}» — вывод не отправлен` };

  const amt = pg.locator('input[placeholder*="сумм" i], input[placeholder*="мин" i], input[placeholder*="количеств" i], input[placeholder*="amount" i], input[placeholder*="min" i]').first();
  await amt.waitFor({ state: 'visible', timeout: 5000 }).catch(() => {});
  if (!(await amt.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля суммы'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле суммы — вывод не отправлен' }; }
  await typeInto(pg, amt, want.amount);
  await sleep(500);

  const btn = pg.getByRole('button', { name: /^(вывести|вывод|withdraw)$/i }).last();
  if (!(await btn.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Вывести»'); return { ok: false, error: 'Ourbit: на форме не нашлась кнопка «Вывести» — вывод не отправлен' }; }
  const saved = waitPost(pg, /\/withdraw\/save_withdraw\//, HUMAN_MS);
  await btn.click({ timeout: 4000 });
  log('вывод: «Вывести» нажата — проверка и капча страницы');
  // Капча попросила человека — пазл виден: вкладку вперёд.
  const nudge = setTimeout(() => { pg.bringToFront().catch(() => {}); log(`вывод: капча ждёт человека — вкладка Ourbit на переднем плане (до ${Math.round(HUMAN_MS / 1000)} с)`); }, 6000);
  const sv = await saved;
  clearTimeout(nudge);
  if (!sv) { await dumpForm(pg, log, 'нет подготовки вывода'); return { ok: false, error: 'Ourbit: страница не подготовила вывод (капча не пройдена или форма не приняла данные) — вывод не отправлен' }; }
  if (!sv.json || sv.json.code !== 0) return { ok: false, error: `Ourbit: подготовка вывода — отказ сайта (code=${sv.json && sv.json.code} «${sv.json && sv.json.msg || ''}») — вывод не отправлен` };
  const bad = saveMismatch(sv.body, want);
  if (bad) {
    await pg.keyboard.press('Escape').catch(() => {});
    log(`вывод: ⛔ страница готовит не то — ${bad}; окно закрыто`);
    return { ok: false, error: `Ourbit: ${bad} — вывод НЕ подтверждён` };
  }

  await sleep(600);
  const confirm = pg.locator('.ant-modal, [role="dialog"]').getByRole('button', { name: /^(подтвердить|confirm|ок|ok)$/i }).last();
  if (!(await confirm.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Подтвердить» в окне'); return { ok: false, error: 'Ourbit: окно подтверждения без кнопки «Подтвердить» — вывод не подтверждён' }; }
  const submitted = waitPost(pg, /\/withdraw\/submit_withdraw\//, 30_000);
  await confirm.click({ timeout: 4000 });
  const sb = await submitted;
  if (!sb || !sb.json) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true };
  if (sb.json.code !== 0) return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.json.code} «${sb.json.msg || ''}»)` };
  if (sb.json.data && sb.json.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit' };
  log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён формой сайта`);
  return { ok: true, withdrawId: String((sb.json.data && sb.json.data.withdrawId) || '') };
}

module.exports = { withdrawViaForm, _saveMismatch: saveMismatch };

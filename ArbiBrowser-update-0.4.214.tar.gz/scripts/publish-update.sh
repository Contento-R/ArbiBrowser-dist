#!/usr/bin/env bash
# publish-update.sh — опубликовать обновление ArbiBrowser РУКАМИ, без GitHub Actions.
#
# Зачем (2026-09-17): у аккаунта Contento-R исчерпаны включённые минуты Actions
# («The job was not started because recent account payments have failed or your
# spending limit needs to be increased»), сборки не стартуют. Самообновление у
# пользователей читает только latest.json из публичного ArbiBrowser-dist, поэтому
# релиз можно выложить и без CI: тот же архив кода, тот же sha256, тот же манифест.
# Отличие от CI: архив лежит В САМОМ репо dist (ссылка на raw.githubusercontent.com),
# а не ассетом GitHub-релиза — создать релиз без токена нельзя.
#
# Запуск из корня ArbiBrowser (версия уже поднята в package.json, изменения закоммичены):
#   bash scripts/publish-update.sh [/путь/к/ArbiBrowser-dist]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST="${1:-$ROOT/../ArbiBrowser-dist}"
cd "$ROOT"
VER=$(node -p "require('./package.json').version")
NAME="ArbiBrowser-update-${VER}.tar.gz"
FILES="src bin scripts config.js package.json ArbiBrowser.bat ArbiBrowser.vbs"
[ -f package-lock.json ] && FILES="$FILES package-lock.json"
git -C "$DIST" fetch origin main -q && git -C "$DIST" checkout -q -B main origin/main
tar -czf "$DIST/$NAME" $FILES
SHA=$(sha256sum "$DIST/$NAME" | awk '{print $1}')
NOTES=$(node scripts/release-notes.js "$VER" | head -c 1500)
# ⚠️ ОСНОВНОЙ адрес архива — jsdelivr, raw остаётся зеркалом (оператор 2026-09-24).
# Причина: у пользователя с 0.4.168 raw.githubusercontent.com не открывается,
# программа уходила на запасной адрес (ассет GitHub-релиза), а релизы с 16.09 не
# выпускаются — последний так и остался 0.4.168, и панель честно писала «у вас
# последняя версия». Проверено: raw отдаёт v0.4.213, releases/latest — v0.4.168.
# jsdelivr раздаёт тот же файл из того же репозитория и открывается там, где raw
# закрыт, поэтому ставим его первым: так обновление доезжает и до СТАРЫХ сборок,
# которые про зеркала ещё не знают (они читают только поле url).
DIST="$DIST" node -e '
const [ver, name, sha, notes] = process.argv.slice(1);
const url = `https://cdn.jsdelivr.net/gh/Contento-R/ArbiBrowser-dist@main/${name}`;
const urlMirror = `https://raw.githubusercontent.com/Contento-R/ArbiBrowser-dist/main/${name}`;
require("fs").writeFileSync(process.env.DIST + "/latest.json", JSON.stringify({ version: "v" + ver, name, url, urlMirror, sha256: sha, notes }, null, 2) + "\n");
' "$VER" "$NAME" "$SHA" "$NOTES"
cd "$DIST" && git add latest.json "$NAME" && git commit -q -m "release: v${VER} (ручная публикация — CI аккаунта не стартует)" && git push origin main
echo "✅ опубликовано v${VER}: $NAME sha256=${SHA:0:12}"

#!/usr/bin/env bash
# publish-release.sh — продублировать уже выложенное обновление (latest.json + архив из
# ArbiBrowser-dist) GitHub-РЕЛИЗОМ в dist-репозитории. Нужен GH_TOKEN с правом push в dist.
#
# Зачем (2026-09-30, оператор: «релизы обновляются только у меня, у всех остальных 0.4.168»):
# сборки ≤0.4.168 читают манифест с raw.githubusercontent.com, а когда тот закрыт (у части
# пользователей — всегда), идут на запасной адрес
#   github.com/Contento-R/ArbiBrowser-dist/releases/latest/download/latest.json.
# Релизы не выпускались с 16.09 (CI аккаунта не стартует), последний — v0.4.168, и такие
# пользователи две недели видели «у вас последняя версия», пока у оператора (raw открыт)
# всё обновлялось через jsdelivr. Архив кладём ассетом релиза, а в манифесте РЕЛИЗА url
# ставим на github.com — он у этих пользователей открыт по определению (иначе они бы и
# релиз не прочитали); jsdelivr — зеркалом. Манифест в ветке main не трогаем.
#
#   bash scripts/publish-release.sh [/путь/к/ArbiBrowser-dist]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST="${1:-$ROOT/../ArbiBrowser-dist}"
REPO="Contento-R/ArbiBrowser-dist"
[ -n "${GH_TOKEN:-}" ] || { echo "⚠️  GH_TOKEN не задан — GitHub-релиз не создан (старые сборки ≤0.4.168 обновления не увидят)"; exit 1; }
M="$DIST/latest.json"
j() { node -pe "JSON.parse(require('fs').readFileSync(process.argv[1],'utf8')).$2 ?? ''" "$1"; }
VER=$(j "$M" version | sed 's/^v//'); NAME=$(j "$M" name)
[ -f "$DIST/$NAME" ] || { echo "нет архива $DIST/$NAME"; exit 1; }
AUTH=(-H "Authorization: Bearer $GH_TOKEN" -H "Accept: application/vnd.github+json")
API="https://api.github.com/repos/$REPO"
RID=$(curl -s "${AUTH[@]}" "$API/releases/tags/v$VER" | node -pe 'try{JSON.parse(require("fs").readFileSync(0,"utf8")).id||""}catch{""}')
if [ -n "$RID" ]; then
  echo "релиз v${VER} уже есть (id $RID) — ассеты не перезаливаю"
else
  BODY=$(node -e 'const m=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));const v=process.argv[2];
    console.log(JSON.stringify({tag_name:"v"+v,target_commitish:"main",name:"ArbiBrowser v"+v,body:(m.notes||"")+"\n\nОбновление кода поверх установленной программы (установщик .exe не собирается — CI не стартует). Уже установленная программа предложит обновиться сама."}))' "$M" "$VER")
  RID=$(curl -fsS "${AUTH[@]}" -H 'Content-Type: application/json' -X POST "$API/releases" -d "$BODY" | node -pe 'JSON.parse(require("fs").readFileSync(0,"utf8")).id')
  UP="https://uploads.github.com/repos/$REPO/releases/$RID/assets"
  curl -fsS "${AUTH[@]}" -H 'Content-Type: application/gzip' --data-binary @"$DIST/$NAME" "$UP?name=$NAME" -o /dev/null
  TMP=$(mktemp)
  node -e 'const m=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));const [repo,ver]=process.argv.slice(2);
    m.urlMirror=m.url; m.url=`https://github.com/${repo}/releases/download/v${ver}/${m.name}`;
    require("fs").writeFileSync(process.argv[4], JSON.stringify(m,null,2)+"\n")' "$M" "$REPO" "$VER" "$TMP"
  curl -fsS "${AUTH[@]}" -H 'Content-Type: application/json' --data-binary @"$TMP" "$UP?name=latest.json" -o /dev/null
  rm -f "$TMP"
fi
# Проверка тем же адресом, что читают старые сборки (github.com отдаёт релиз без кэша).
GOT=$(curl -sL "https://github.com/$REPO/releases/latest/download/latest.json" | node -pe 'try{JSON.parse(require("fs").readFileSync(0,"utf8")).version}catch{""}')
echo "✅ релиз v${VER} в $REPO: releases/latest/download/latest.json отдаёт ${GOT:-?}"
[ "$GOT" = "v${VER}" ] || { echo "⚠️  релиз не стал latest — проверьте https://github.com/$REPO/releases"; exit 1; }

'use strict';

/**
 * pair-tabs.js — ПУЛ ТЁПЛЫХ ВКЛАДОК ПО ПАРАМ (оператор 2026-09-01).
 *
 * Раньше на каждую биржу держалась ОДНА вкладка: работа по второй паре означала
 * смену пары (SPA-поиск 1–2с, а на сбое — перезагрузка 3–6с) прямо внутри
 * выставления заявки. Оператор торгует несколькими парами одновременно, и эта
 * секунда-две платились почти на каждом переключении.
 *
 * Теперь на биржу можно держать до N вкладок (по умолчанию 3, env
 * ARBI_PAIR_TABS): у каждой активной пары своя тёплая вкладка, и заявка по любой
 * из них уходит без навигации. Прогрев (терминал шлёт его по своим открытым
 * вкладкам) наполняет пул ЗАРАНЕЕ, так что цену навигации платит фон, а не
 * выстрел. Пул полон → работает прежний путь: смена пары в существующей вкладке.
 *
 * ⚠️ Навигация к биржам НЕ распараллеливается (Akamai): открытие вкладки пула
 * идёт внутри той же блокировки контекста, что и всё остальное на денежном пути.
 * Здесь только УЧЁТ — «есть ли место в пуле» и пометка вкладки, чтобы её не
 * усыпил сборщик памяти.
 */

// Оператор 2026-09-02: «все открытые вкладки терминала с web-токенами должны
// греться всегда» — пул по умолчанию шире (3 не хватало: BASECAT+MEY+кошелёк
// = «полон», и прогрев BASECAT переключал вкладку MEY на другую пару).
const DEFAULT_MAX = 6;

/** Сколько вкладок пары этой биржи разрешено держать одновременно. */
function pairTabLimit() {
  const n = parseInt(process.env.ARBI_PAIR_TABS || '', 10);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_MAX;
}

/**
 * Живые (не спящие, не служебные) вкладки биржи в контексте.
 * @param {import('playwright').BrowserContext} context
 * @param {string} origin префикс URL биржи
 */
function exchangeTabs(context, origin) {
  const out = [];
  for (const p of context.pages()) {
    try {
      if (p.isClosed && p.isClosed()) continue;
      if (p.__arbiBalanceBg === true || p.__arbiOrdersBg === true) continue; // служебные
      const url = p.url();
      const sleepUrl = typeof p.__arbiSleepUrl === 'string' ? p.__arbiSleepUrl : '';
      if (url.startsWith(origin) || sleepUrl.startsWith(origin)) out.push(p);
    } catch { /* закрыта/навигация — пропускаем */ }
  }
  return out;
}

/**
 * Есть ли место под ЕЩЁ ОДНУ вкладку этой биржи? Если да — вызывающий открывает
 * новую вкладку с нужной парой вместо смены пары в существующей.
 */
function canOpenPairTab(context, origin) {
  if (!context) return false;
  // Место в пуле занимают только ТОРГОВЫЕ страницы пар: кошелёк/вывод/логин,
  // открытые оператором, раньше считались вкладками пула — пул «наполнялся»
  // ими, и прогрев новой пары уводил вкладку живой пары (лог 02.09: «Смена
  // пары через поиск: BASECAT_USDT» на вкладке MEY).
  return mainTradeTabs(context, origin).length < pairTabLimit();
}

/**
 * Торговые вкладки пар БЕЗ вкладок-частей. Пул задумывался как «сколько ПАР
 * держим тёплыми», а считал вкладки: у BingX одна пара с дроблением занимает
 * три места (главная + две части), и две пары забивали потолок 6 целиком —
 * третья пара оставалась без частей, её крупная заявка шла последовательно
 * (лог оператора 22.09: «пул тёплых вкладок полон (6) — открыл 0 из 2» по TGC
 * при живых STONK×3 и FONE×3). Части ограничиваются своим потолком на стороне
 * биржи, а не этим.
 */
function mainTradeTabs(context, origin) {
  return tradeTabs(context, origin).filter((p) => p.__arbiSplitTab !== true);
}

/** Торговые вкладки пар этой биржи (спящие — по запомненному URL). */
function tradeTabs(context, origin) {
  return exchangeTabs(context, origin).filter((p) => {
    try { return isTradePairUrl((typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl) || p.url()); } catch { return false; }
  });
}

/**
 * Пометить вкладку как вкладку ПУЛА: сборщик памяти (startIdleTabSleeper) такие
 * не усыпляет — иначе пул терял бы смысл ровно к моменту, когда пара понадобится.
 *
 * Метка ПРОТУХАЕТ (__arbiPairTabAt): терминал могли закрыть, и тогда никто уже
 * не подтверждает, что пара нужна. Просроченная метка перестаёт защищать вкладку
 * от усыпления — иначе брошенные вкладки жили бы вечно и ели память.
 */
/**
 * Метка «вкладку открыл САМ ArbiBrowser» (пул пар, спящие, восстановленные из
 * снимка, стартовая). Вкладка без метки = открыта оператором руками (Ctrl+T,
 * ссылка) — уборка её НЕ трогает (оператор 2026-09-08: «вкладки браузера =
 * вкладки терминала, но с исключением для открытых руками»). Ставится в момент
 * context.newPage() у нас; страницы, которые появились иначе, метки не получают.
 * Восстановленная из прошлой сессии ручная вкладка создаётся уже нами → своя.
 */
function markOwned(page) {
  try { if (page) page.__arbiOwned = true; } catch { /* игнор */ }
  return page;
}

/**
 * Рисует ли страница кадры (rAF за `ms`). Это ФАКТ вместо `visibilityState`:
 * скрытый/свёрнутый виджет Chromium ГЛОТАЕТ ввод — клавиши подтверждаются
 * мгновенно (лог 15.09: 93 символа за 35 мс), фокус остаётся на <body>, а
 * `document.visibilityState` при этом может отвечать 'visible'. rAF в таком
 * виджете не срабатывает — это и есть проверка.
 */
async function pageRenders(page, ms = Number(process.env.ARBI_RENDER_PROBE_MS || 250)) {
  return page.evaluate((t) => new Promise((r) => { requestAnimationFrame(() => r(true)); setTimeout(() => r(false), t); }), ms).catch(() => false);
}

/**
 * Вкладка ордера должна быть АКТИВНОЙ в своём окне. Лог оператора 2026-09-08
 * 08:26: MEXC — на КАЖДОМ ордере первый клик в поле выбирал таймаут 1200 мс
 * (срыв-клика=1), BingX — первый ордер: обычный запрос к странице 1833 мс,
 * клик 1145 мс; через секунды на той же вкладке — десятки мс. Так ведёт себя
 * СКРЫТАЯ вкладка: у неё не идут кадры (rAF), а Playwright перед кликом ждёт
 * «стабильность» элемента именно по кадрам; рендерер приглушён. Флаги против
 * фонового троттлинга кадры скрытой вкладке не возвращают — вкладку надо показать.
 * Сначала СЧИТАЕМ (visibilityState) — это и замер гипотезы, и след (#58); если
 * скрыта — bringToFront (один вызов). Окно профиля живёт на своём мониторе;
 * фоновую страницу баланса/истории это не касается (она сюда не попадает).
 * Рубильник: ARBI_ORDER_TAB_FRONT=0.
 */
async function ensureTabInFront(page, log = () => {}) {
  if ((process.env.ARBI_ORDER_TAB_FRONT || '1') === '0') return false;
  // ФАКТ, а не visibilityState (замер 30.09 в Chromium под Playwright): у неактивной
  // вкладки visibilityState = 'visible', а кадр rAF идёт 444 мс и page.click ждёт
  // 2079 мс (после bringToFront — 14 и 40 мс). На проде так выглядела каждая заявка
  // после перезапуска (клик=1453…1812 мс), и прежняя проверка её не ловила.
  const budget = Number(process.env.ARBI_FRONT_PROBE_MS || 120);
  let hidden = false;
  try {
    hidden = await page.evaluate(() => document.visibilityState !== 'visible');
    if (!hidden) hidden = !(await pageRenders(page, budget));
  } catch { return false; }
  if (!hidden) return false;
  try {
    await page.bringToFront();
    const ok = await pageRenders(page, budget);
    log(`Вкладка пары была в фоне (кадр дольше ${budget} мс) — выведена вперёд${ok ? '' : ', но кадры так и не пошли (окно перекрыто/свёрнуто?)'}`);
    return true;
  } catch { return false; }
}

/**
 * Новая вкладка В ФОНЕ — БЕЗ перехвата активной вкладки оператора.
 *
 * `context.newPage()` в обычном (не headless) Chromium делает новую вкладку
 * АКТИВНОЙ: оператор смотрит на свою страницу, а браузер молча уводит его на
 * только что открытую служебную (жалоба оператора 2026-09-11 «перехватывает
 * активную вкладку»; лог: 25 открытий вкладок пула + вкладки-части). Chromium
 * умеет открывать вкладку фоном (`Target.createTarget { background: true }`),
 * Playwright даёт до него доступ через CDP-сессию. Страницу забираем не по
 * событию (его может перехватить чужая вкладка), а сравнением списка страниц
 * до/после — так не остаётся «ничьей» вкладки при таймауте.
 *
 * Рубильник: ARBI_BG_TABS=0 → прежнее поведение (вкладка открывается активной).
 */
/**
 * Своя страница ArbiBrowser: пул пар, служебные фоновые, заглушки.
 *
 * ФОНОВОЕ ИСПОЛНЕНИЕ (оператор 15.09: «хочу быть на другой вкладке и что-то
 * делать, не влияя на исполнение ордеров»). В одном окне Chromium кадры идут
 * только у АКТИВНОЙ вкладки — скрытая не рендерится даже с флагами против
 * троттлинга, а Playwright перед кликом ждёт стабильности элемента именно по
 * кадрам (замер 08:26: клик 1145–1200 мс в скрытой вкладке против десятков мс
 * в видимой). Поэтому раньше исполнитель выводил вкладку пары вперёд
 * (ensureTabInFront) — и отбирал у оператора ту вкладку, на которой он работал.
 *
 * Решение — не вкладка, а ОКНО: каждая наша страница открывается в собственном
 * окне (`Target.createTarget … newWindow:true`), где она единственная и потому
 * всегда активная: кадры идут, клики мгновенные, ensureTabInFront видит
 * visibilityState='visible' и ничего не трогает. Окно создаётся в фоне
 * (`background:true`) и ставится ровно на место окна профиля — под окно
 * оператора, не поверх; флаг `--disable-backgrounding-occluded-windows` не
 * даёт перекрытому окну заснуть. Вкладки оператора живут в его окне, и мы туда
 * не заходим. Рубильник: ARBI_PAIR_WINDOWS=0 — прежние вкладки в общем окне.
 */
/** @param {{tab?:boolean}} [opts] tab — открыть ВКЛАДКОЙ в существующем окне, а не своим окном
 *  (оператор 15.09: вкладки-части BingX — вкладками, не отдельными страницами). */
async function newBackgroundPage(context, opts = {}) {
  if ((process.env.ARBI_BG_TABS || '1') !== '0') {
    const ref = context.pages().find((p) => { try { return !p.isClosed(); } catch { return false; } });
    if (ref) {
      try {
        const ownWindow = (process.env.ARBI_PAIR_WINDOWS || '1') !== '0' && !opts.tab;
        const before = new Set(context.pages());
        const cdp = await context.newCDPSession(ref);
        let refBounds = null;
        try {
          if (ownWindow) {
            // Место окна профиля — новое окно встанет туда же (тем же размером).
            try {
              const { windowId } = await cdp.send('Browser.getWindowForTarget');
              const { bounds } = await cdp.send('Browser.getWindowBounds', { windowId });
              if (bounds && bounds.windowState === 'normal') refBounds = bounds;
            } catch { /* без позиционирования */ }
          }
          await cdp.send('Target.createTarget', { url: 'about:blank', background: true, newWindow: ownWindow });
        } finally { await cdp.detach().catch(() => {}); }
        for (let i = 0; i < 50; i++) {
          const fresh = context.pages().find((p) => !before.has(p));
          if (fresh) {
            if (ownWindow) {
              fresh.__arbiOwnWindow = true;
              if (refBounds) {
                try {
                  const c2 = await context.newCDPSession(fresh);
                  try {
                    const { windowId } = await c2.send('Browser.getWindowForTarget');
                    await c2.send('Browser.setWindowBounds', {
                      windowId,
                      bounds: { left: refBounds.left, top: refBounds.top, width: refBounds.width, height: refBounds.height, windowState: 'normal' },
                    });
                  } finally { await c2.detach().catch(() => {}); }
                } catch { /* окно останется там, куда его поставил Chromium */ }
              }
            }
            return fresh;
          }
          await new Promise((r) => setTimeout(r, 100));
        }
      } catch { /* CDP недоступен — открываем обычной вкладкой ниже */ }
    }
  }
  return context.newPage();
}

function markPairTab(page) {
  try { if (page) { page.__arbiPairTab = true; page.__arbiPairTabAt = Date.now(); } } catch { /* игнор */ }
  return page;
}

/** Сколько метка пула защищает вкладку от усыпления без подтверждения. */
function pairTabTtlMs() {
  const n = parseInt(process.env.ARBI_PAIR_TAB_TTL_MIN || '', 10);
  return (Number.isFinite(n) && n > 0 ? n : 30) * 60_000;
}

/**
 * Свежая ли вкладка-ЧАСТЬ дробления крупной заявки (`__arbiSplitTab`).
 *
 * Смысл такой вкладки — быть ГОТОВОЙ формой ровно в момент заявки, как и у
 * вкладок пула пар. Усыплённая часть уводится навигацией прочь, форма исчезает,
 * и «доверенный клик» в ней уходит в пустоту: в журнале это «клик не отправил
 * запрос ордера», а заявка не уходит вовсе (разбор STONK/BingX 2026-09-16 —
 * сторож памяти вытеснял части, потому что исключения для них не было).
 * TTL тот же, что у пула: брошенные части не живут вечно.
 */
function isFreshSplitTab(page) {
  try {
    if (!page || page.__arbiSplitTab !== true) return false;
    const at = Number(page.__arbiSplitAt) || 0;
    return Date.now() - at < pairTabTtlMs();
  } catch { return false; }
}

/** Свежая ли метка пула (вкладку подтверждали недавно). */
function isFreshPairTab(page) {
  try {
    if (!page || page.__arbiPairTab !== true) return false;
    const at = Number(page.__arbiPairTabAt) || 0;
    return Date.now() - at < pairTabTtlMs();
  } catch { return false; }
}

/** Совпадает ли URL вкладки с парой «BASE_QUOTE» (разделитель у бирж свой). */
function urlIsPair(url, pair) {
  const [base, quote = 'USDT'] = String(pair || '').toUpperCase().split(/[_/-]/);
  if (!base) return false;
  const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Граница обязательна: без неё вкладка STIG_USDT сошла бы за TIG_USDT и была
  // бы закрыта как «лишняя», хотя пара нужна (клоны тикеров — норма для Alpha).
  const re = new RegExp(`(^|[^A-Z0-9])${esc(base)}[-_/]?${esc(quote)}([^A-Z0-9]|$)`, 'i');
  return re.test(String(url || '').toUpperCase());
}

/**
 * ТОРГОВАЯ ли это страница ПАРЫ (а не кошелёк, вывод, лендинг, логин).
 * Уборка закрывает только такие: страницу «Вывод средств», открытую оператором,
 * трогать нельзя, а определить её по метке пула невозможно.
 * Формы путей: BingX /spot/WOJAK-USDT, MEXC /exchange/TIG_USDT, XT /trade/tig_usdt.
 */
function isTradePairUrl(url) {
  const u = String(url || '');
  if (!/\/(spot|exchange|trade)\//i.test(u)) return false;
  // Последний сегмент пути должен выглядеть как пара с известной квотой.
  const seg = (u.split(/[?#]/)[0].replace(/\/+$/, '').split('/').pop() || '');
  // База от ОДНОГО символа: у оператора в работе есть тикеры «T» и «4».
  return /^[A-Z0-9]{1,15}[-_]?(USDT|USDC|USD|BTC|ETH|BNB)$/i.test(seg);
}

/**
 * Закрыть вкладки ТОРГОВЫХ ПАР, которых БОЛЬШЕ НЕТ в терминале (оператор
 * 2026-09-01: «закрыл токен в терминале — пусть закроется и в браузере»).
 *
 * ⚠️ Метка пула (__arbiPairTab) для отбора НЕ ГОДИТСЯ, хотя это была первая
 * реализация: метка ставится только когда через вкладку идёт работа, а по
 * ЗАКРЫТОЙ паре работы уже нет — значит вкладка её никогда не получит и уборка
 * пропускала бы её вечно (жалоба оператора 2026-09-02: «лишние вкладки остаются
 * висеть»). Тот же провал у вкладок, восстановленных из прошлой сессии профиля.
 * Поэтому отбираем по СМЫСЛУ страницы: торговая страница пары, которой нет в
 * списке терминала.
 *
 * НЕ закрываем:
 *   • НЕ торговые страницы (кошелёк, вывод, логин, лендинг) — они могли быть
 *     открыты оператором для дела и парой не опознаются;
 *   • служебные фоновые страницы (они не в exchangeTabs).
 *
 * Последнюю вкладку биржи РАНЬШЕ не трогали («с неё уходит следующий ордер»),
 * и это молча ломало правило: единственный токен биржи, закрытый в терминале,
 * оставался в браузере навсегда, без строки в логе (оператор 2026-09-05, третья
 * жалоба). Теперь закрываем и её: исполнители сами открывают новую страницу,
 * когда вкладок нет (context.newPage() в getXxxPage), сессия живёт в профиле.
 *
 * @param {object} context
 * @param {string} origin
 * @param {string[]} keepPairs пары, открытые в терминале (в любом формате)
 * @param {(m:string)=>void} [log]
 */
/**
 * Страница-заглушка для отпущенной СЛУЖЕБНОЙ вкладки (чтение истории/баланса).
 *
 * Не `about:blank`: пустая вкладка без имени выглядит как мусор, и оператор её
 * закрывает — а она одна на профиль и нужна следующему чтению (просьба
 * оператора 15.09: «пиши, что служебная, не закрывать, и в названии вкладки
 * тоже»). Поэтому data:-страница с говорящим <title> — он же имя вкладки в
 * панели Chromium — и крупной надписью в теле. Ничего не грузит из сети,
 * памяти не ест, к бирже не ходит.
 */
const PARKED_TITLE = 'ArbiBrowser · служебная вкладка — не закрывать';
const PARKED_PAGE = 'data:text/html;charset=utf-8,' + encodeURIComponent(
  '<!doctype html><html lang="ru"><head><meta charset="utf-8">'
  + `<title>${PARKED_TITLE}</title>`
  + '<style>html,body{height:100%;margin:0}body{display:flex;align-items:center;justify-content:center;'
  + 'background:#12161c;color:#c9d4e3;font:15px/1.6 system-ui,Segoe UI,Arial,sans-serif;text-align:center}'
  + 'b{display:block;font-size:19px;color:#f0b232;margin-bottom:10px}small{color:#7d8798}</style></head><body><div>'
  + '<b>Служебная вкладка ArbiBrowser — не закрывать</b>'
  + 'Через неё читаются история ордеров и балансы бирж.<br>Она одна на профиль и сейчас свободна.<br>'
  + '<small>Закроете — следующее чтение откроет новую и потратит лишнее время.</small>'
  + '</div></body></html>'
);

// ── Отклик вкладки (оператор 08.10, MEXC/BKN): прогрев 60 с, наведение мыши 13 с,
// чтение поля 1 с — страница была перегружена (вкладки одного сайта делят поток), а
// терминал писал «ArbiBrowser не запущен». Замер перед работой: одна пустая команда
// странице. Медленно — строка в журнале и подсказка к ошибке заявки (executor-core).
let lastSlow = null;
async function probeLag(page, log = () => {}) {
  const limit = Number(process.env.ARBI_SLOW_PAGE_MS || 1000);
  const t = Date.now();
  await Promise.race([page.evaluate(() => 1).catch(() => {}), new Promise((r) => setTimeout(r, 5000))]);
  const ms = Date.now() - t;
  if (!(limit > 0) || ms < limit) return ms;
  let host = '';
  try { host = new URL(page.url()).host; } catch { /* about:blank */ }
  let tabs = 0;
  try { tabs = page.context().pages().filter((p) => { try { return new URL(p.url()).host === host; } catch { return false; } }).length; } catch { /* закрыт */ }
  lastSlow = { ms, at: Date.now(), host, tabs };
  log(`Вкладка ${host} отвечает ${ms} мс (норма — десятки мс): браузер перегружен, вкладок этого сайта в профиле ${tabs} — закройте лишние`);
  return ms;
}
/** Подсказка к ошибке, если недавно (3 мин) видели перегруженную вкладку. */
function slowHint(maxAgeMs = 180000) {
  if (!lastSlow || Date.now() - lastSlow.at > maxAgeMs) return '';
  return ` Браузер перегружен: вкладка ${lastSlow.host} отвечала ${lastSlow.ms} мс, вкладок этого сайта в профиле ${lastSlow.tabs} — закройте лишние.`;
}

async function closeStalePairTabs(context, origin, keepPairs, log = () => {}) {
  const keep = Array.isArray(keepPairs) ? keepPairs.filter(Boolean) : [];
  const tabs = tradeTabs(context, origin);
  // «Последняя вкладка биржи» считается по ВСЕМ её вкладкам (кошелёк тоже
  // залогиненная сессия, с неё уйдёт следующий ордер), а закрываем — торговые.
  let closed = 0;
  const skipped = [];
  // Перепись того, что уборка ВИДЕЛА (оператор 15.09: «не закрывает лишние
  // отвязавшиеся вкладки», при том что в логе всегда «закрывать нечего»).
  // Пустой список торговых вкладок сам по себе ничего не объясняет: страницы
  // могли не пройти отбор по origin, не опознаться как страница пары, либо
  // это служебные фоновые страницы, которые уборка пропускает НАМЕРЕННО (они
  // висят на последней прочитанной паре и выглядят как брошенная вкладка).
  // Пишем перепись — дальше видно, какой именно фильтр их роняет (#58).
  if (!tabs.length) {
    let all = 0; let ofExchange = 0; let service = 0; const other = [];
    for (const p of context.pages()) {
      try {
        if (p.isClosed && p.isClosed()) continue;
        all += 1;
        const url = (typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl) || p.url();
        const mine = String(url).startsWith(origin);
        if (p.__arbiBalanceBg === true || p.__arbiOrdersBg === true) { if (mine) service += 1; continue; }
        if (!mine) continue;
        ofExchange += 1;
        if (other.length < 3) other.push(String(url).replace(/^https?:\/\//, '').slice(0, 48));
      } catch { /* закрыта/навигация */ }
    }
    log(`Уборка: торговых вкладок пары нет — закрывать нечего [перепись: всего ${all}, этой биржи ${ofExchange}, служебных фоновых ${service}${other.length ? ', не опознаны как пара: ' + other.join(' | ') : ''}]`);
  }
  // Сколько вкладок-ЧАСТЕЙ позволено живой паре. Части заводит только BingX
  // (`__arbiSplitTab`), поэтому у остальных бирж эта ветка не срабатывает
  // вовсе. Без неё лишние части копились: ветка «пара открыта в терминале»
  // сохраняла ВСЕ вкладки пары разом, сколько бы их ни осталось от прошлых
  // заявок и восстановлений сессии (лог оператора 22.09: 5493 МБ на профиль).
  const splitKeep = Math.max(0, Number(process.env.ARBI_BINGX_SPLIT_TABS || 3) - 1);
  const splitSeen = new Map(); // пара → сколько частей уже оставили
  // Дубли живой пары (оператор 08.10: две вкладки BKN_USDT в одном профиле делили
  // поток страницы с заявкой). Оставляем ОДНУ главную — ту, которой пользовались
  // последней; лишние НАШИ закрываем, ручные не трогаем.
  const mainSeen = new Set();
  const byUse = [...tabs].sort((a, b) => (Number(b.__arbiPairTabAt) || 0) - (Number(a.__arbiPairTabAt) || 0));
  for (const p of byUse) {
    try {
      const url = (typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl) || p.url();
      const short = String(url).replace(/^https?:\/\//, '').slice(0, 46);
      const livePair = keep.find((pair) => urlIsPair(url, pair));
      if (livePair) {
        if (p.__arbiSplitTab !== true) {
          if (!mainSeen.has(livePair) || p.__arbiOwned !== true) { mainSeen.add(livePair); skipped.push(`${short} — пара открыта в терминале`); continue; }
          await p.close();
          closed += 1;
          log(`Вкладка закрыта — вторая копия пары ${livePair} (одной достаточно): ${String(url).slice(0, 80)}`);
          continue;
        }
        const n = (splitSeen.get(livePair) || 0) + 1;
        splitSeen.set(livePair, n);
        if (n <= splitKeep) { skipped.push(`${short} — часть ${n}/${splitKeep} живой пары`); continue; }
        await p.close();
        closed += 1;
        log(`Вкладка-часть закрыта — лишняя сверх ${splitKeep} на пару ${livePair}: ${String(url).slice(0, 80)}`);
        continue;
      }
      // Вкладка без нашей метки — открыта оператором руками: не наша, не закрываем.
      if (p.__arbiOwned !== true) { skipped.push(`${short} — открыта руками (метки ArbiBrowser нет)`); continue; }
      // СВЕЖАЯ вкладка не закрывается, даже если её пары нет в списке терминала.
      //
      // Список «оставить» — это вкладки ТЕРМИНАЛА, и он ничего не знает про работу
      // по паре: снайпер, автопродажа и ручная заявка греют форму и ставят ордера
      // по монете, вкладка которой в терминале уже закрыта. Разбор лога оператора
      // 2026-09-20 (MEXC/WOJAK): в 8:53:57 уборка «оставить BATON, ANYONE» закрыла
      // вкладку WOJAK — и В ТУ ЖЕ СЕКУНДУ пришёл прогрев WOJAK, холодный, 6116 мс;
      // в 8:54:09 та же уборка закрыла её снова, в 8:54:15 чтение истории упало
      // («нет открытой вкладки»), в 8:54:16 — ещё один холодный прогрев 5808 мс, и
      // только в 8:54:22 ушла заявка. Две трети времени постановки — плата за
      // вкладку, закрытую секундами ранее.
      //
      // Окно отсчитывается от ПОСЛЕДНЕГО обращения к вкладке (markPairTab зовут и
      // при прогреве, и перед ордером), поэтому защищено именно то, чем пользуются.
      // Брошенная вкладка переживает уборку максимум на это окно и уходит следующей.
      const graceMs = Math.max(0, Number(process.env.ARBI_TAB_CLOSE_GRACE_SEC || 60) * 1000);
      const usedAt = Number(p.__arbiPairTabAt) || 0;
      if (graceMs && usedAt && Date.now() - usedAt < graceMs) {
        // Называем и СКОЛЬКО ОСТАЛОСЬ: «использовалась 8 с назад» не отвечает на
        // вопрос оператора «почему она всё ещё открыта, токена в терминале нет»
        // (жалоба 22.09). Если в следующих уборках это число не убывает — значит
        // вкладку кто-то продолжает трогать, и виден уже другой класс (#58).
        skipped.push(`${short} — пары нет в терминале, но её трогали ${Math.round((Date.now() - usedAt) / 1000)} с назад, закрою через ${Math.ceil((graceMs - (Date.now() - usedAt)) / 1000)} с`);
        continue;
      }
      // ⚠️ «На вкладку смотрят» из самой страницы НЕ определить: Playwright
      // эмулирует фокус и видимость для КАЖДОЙ страницы — document.hidden=false
      // и document.hasFocus()=true отвечают все вкладки разом (лог 02.09:
      // «пропущено — оператор смотрит на неё» ×3 при трёх вкладках). Две
      // попытки такой защиты (0.4.106, 0.4.109) оставляли вкладки висеть.
      // Правило оператора простое: вкладки браузера = вкладки терминала.
      // Торговая страница пары, которой нет в терминале, закрывается; нерыночные
      // страницы (кошелёк, вывод, логин) и последняя вкладка биржи — нет.
      await p.close();
      closed += 1;
      log(`Вкладка закрыта — пара больше не открыта в терминале: ${String(url).slice(0, 80)}`);
    } catch { /* закрылась сама / навигация — не мешаем */ }
  }
  // Нерыночные страницы биржи (вывод, депозит, кошелёк, логин), простоявшие на одном
  // адресе дольше ARBI_SERVICE_TAB_IDLE_MIN (30 мин) — закрываем (оператор 08.10:
  // страница вывода ONDO висела 5 ч и делила поток со страницей заявки). Отсчёт —
  // с первого раза, когда уборка увидела вкладку на этом адресе; смена адреса
  // (человек ею пользуется) отсчёт сбрасывает. Последнюю страницу профиля не трогаем.
  const idleMs = Math.max(0, Number(process.env.ARBI_SERVICE_TAB_IDLE_MIN ?? 30) * 60_000);
  if (idleMs) {
    for (const p of exchangeTabs(context, origin)) {
      try {
        if (p.isClosed && p.isClosed()) continue;
        const url = (typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl) || p.url();
        if (isTradePairUrl(url)) continue;
        if (p.__arbiSeenUrl !== url) { p.__arbiSeenUrl = url; p.__arbiSeenAt = Date.now(); continue; }
        const since = Math.max(Number(p.__arbiSeenAt) || 0, Number(p.__arbiPairTabAt) || 0);
        if (Date.now() - since < idleMs) continue;
        if (context.pages().length <= 1) continue;
        await p.close();
        closed += 1;
        log(`Вкладка закрыта — служебная страница биржи без дела ${Math.round((Date.now() - since) / 60000)} мин: ${String(url).slice(0, 80)}`);
      } catch { /* закрылась сама / навигация */ }
    }
  }

  // Служебная фоновая страница (чтение истории/баланса) остаётся жить намеренно
  // — она одна на профиль и переиспользуется. Но висеть ей на паре, которой в
  // терминале уже нет, незачем: для оператора это неотличимо от брошенной
  // вкладки (жалоба 15.09), а тяжёлая страница биржи ещё и ест память. Уводим
  // её на about:blank — следующее чтение всё равно навигирует само.
  let parked = 0;
  for (const p of context.pages()) {
    try {
      if (p.isClosed && p.isClosed()) continue;
      if (p.__arbiBalanceBg !== true && p.__arbiOrdersBg !== true) continue;
      if (typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl) continue; // уже спит
      const url = p.url();
      if (!String(url).startsWith(origin) || !isTradePairUrl(url)) continue;
      if (keep.some((pair) => urlIsPair(url, pair))) continue;
      await p.goto(PARKED_PAGE, { waitUntil: 'domcontentloaded', timeout: 5000 });
      parked += 1;
      log(`Фоновая страница отпущена — пара закрыта в терминале: ${String(url).slice(0, 80)}`);
    } catch { /* навигация/закрылась — не мешаем */ }
  }
  // Каждая пропущенная вкладка — С АДРЕСОМ И ПРИЧИНОЙ. Оператор 21.09: вкладки
  // висят, а в журнале была только россыпь причин без имён, и понять, ЧТО именно
  // не закрылось, было нельзя — «лечили» вслепую дважды (#58/#68).
  if (closed === 0 && !parked && skipped.length) log(`Уборка: закрывать нечего (пропущено: ${skipped.join(' | ')})`);
  return { closed, parked };
}

/**
 * Страница УСЫПЛЕНА сборщиком памяти (`sleepPage`): вместо биржи в ней лёгкая
 * заглушка «💤 вкладка спит», а вот URL при этом остаётся ПРЕЖНИМ — `setContent`
 * пишет документ на текущем адресе и адрес не меняет (проверено 25.09). Поэтому
 * проверки вида «страница уже на нужной паре — навигировать не надо» на спящей
 * странице проходят, и читалка разбирает заглушку: ни таблицы, ни вкладок, ноль
 * строк. Сон различим ТОЛЬКО по метке, что и делает эта функция.
 */
function isAsleep(page) {
  try { return typeof page.__arbiSleepUrl === 'string' && !!page.__arbiSleepUrl; } catch { return false; }
}

module.exports = {
  pageRenders, isAsleep,
  pairTabLimit, exchangeTabs, tradeTabs, mainTradeTabs, canOpenPairTab, markPairTab, markOwned, ensureTabInFront, newBackgroundPage,
  isFreshPairTab, isFreshSplitTab, pairTabTtlMs, urlIsPair, isTradePairUrl, closeStalePairTabs, PARKED_PAGE, PARKED_TITLE,
  probeLag, slowHint,
};

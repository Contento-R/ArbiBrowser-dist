'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { cmpVersion, canInstall, downloadedPath } = require('./updater');

test('cmpVersion: сравнение версий манифеста с установленной', () => {
  assert.equal(cmpVersion('0.4.91', '0.4.90'), 1);
  assert.equal(cmpVersion('v0.4.91', '0.4.90'), 1, 'префикс v из тега не мешает');
  assert.equal(cmpVersion('0.4.90', '0.4.90'), 0);
  assert.equal(cmpVersion('0.4.89', '0.4.90'), -1, 'откат назад обновлением не считается');
  assert.equal(cmpVersion('0.5.0', '0.4.99'), 1, 'сравниваем по разрядам, не лексикографически');
  assert.equal(cmpVersion('0.4.90', '0.4.90-rc1'), 0, 'нечисловой хвост отбрасывается');
});

test('canInstall: под открытым профилем код не подменяем', () => {
  // Открытый профиль = живая сессия биржи и, возможно, заявка в работе.
  // Распаковка кода под ней с последующим перезапуском стоит денег.
  assert.equal(canInstall(0).ok, true);
  assert.equal(canInstall(1).ok, false);
  assert.equal(canInstall(3).ok, false);
  assert.match(canInstall(1).reason, /закройте профили/i);
});

test('downloadedPath: без манифеста/имени архива — ничего не «готово»', () => {
  assert.equal(downloadedPath(null), null);
  assert.equal(downloadedPath({}), null);
  // Несуществующее имя не должно выглядеть как скачанный архив.
  assert.equal(downloadedPath({ name: 'ArbiBrowser-update-0.0.0-нет-такого.tar.gz' }), null);
});

test('archiveUrls: ассет релиза → зеркало манифеста → API → jsdelivr → raw, без дублей (08.10: 404 при живых каналах)', () => {
  const { archiveUrls } = require('./updater');
  const m = { name: 'ArbiBrowser-update-0.4.235.tar.gz', url: 'https://github.com/Contento-R/ArbiBrowser-dist/releases/download/v0.4.235/ArbiBrowser-update-0.4.235.tar.gz' };
  const u = archiveUrls(m);
  assert.equal(u[0], m.url);
  assert.match(u[1], /^https:\/\/api\.github\.com\/repos\/.+\/contents\/ArbiBrowser-update-0\.4\.235\.tar\.gz\?ref=/);
  assert.match(u[2], /^https:\/\/cdn\.jsdelivr\.net\/gh\/.+\/ArbiBrowser-update-0\.4\.235\.tar\.gz$/);
  assert.match(u[3], /^https:\/\/raw\.githubusercontent\.com\/.+\/ArbiBrowser-update-0\.4\.235\.tar\.gz$/);
  assert.equal(new Set(u).size, u.length);
  // Зеркало из манифеста (jsdelivr у ручной публикации) не дублируется.
  const withMirror = archiveUrls({ ...m, urlMirror: u[2] });
  assert.equal(withMirror.length, u.length); assert.equal(withMirror[1], u[2]);
});

test('MANIFEST_URLS: raw → GitHub API → зеркало CDN → ассет релиза, без дублей', () => {
  const { MANIFEST_URLS, MANIFEST_URL } = require('./updater');
  assert.equal(MANIFEST_URLS[0], MANIFEST_URL);
  assert.ok(MANIFEST_URLS.length >= 4, 'нужны API, зеркало и запасной адрес');
  // Порядок здесь — ЧАСТЬ ПОВЕДЕНИЯ, не косметика:
  // • API выше CDN — jsdelivr кеширует манифест по ветке, и его узлы расходятся
  //   между собой (25.09: в одну минуту v0.4.216 и v0.4.217 с разных узлов);
  // • CDN выше ассета релиза — релизы с 16.09 не собираются и отвечают правдой
  //   полуторанедельной давности (0.4.168).
  assert.match(MANIFEST_URLS[1], /^https:\/\/api\.github\.com\/repos\/.+\/contents\/latest\.json\?ref=/);
  assert.match(MANIFEST_URLS[2], /^https:\/\/cdn\.jsdelivr\.net\/gh\/.+\/latest\.json$/);
  assert.match(MANIFEST_URLS[3], /^https:\/\/github\.com\/.+\/releases\/latest\/download\/latest\.json$/);
  assert.equal(new Set(MANIFEST_URLS).size, MANIFEST_URLS.length, 'без дублей');
});

// 08.10: в 0.4.236 после УСПЕШНОЙ закачки падал ReferenceError (lastErr), архив
// выбрасывался по всем адресам — самообновление не работало вовсе, а тесты этого не
// видели: ни один не гонял download() целиком. Этот гоняет — с подменой https.get.
test('download: архив качается, сумма сверяется; первый адрес недоступен — берётся зеркало', async (t) => {
  const os = require('node:os');
  const fs = require('node:fs');
  const path = require('node:path');
  const crypto = require('node:crypto');
  const https = require('node:https');
  const { Readable } = require('node:stream');
  const body = Buffer.from('fake-archive-' + Date.now());
  const sha = crypto.createHash('sha256').update(body).digest('hex');
  const seen = [];
  t.mock.method(https, 'get', (url, opts, cb) => {
    seen.push(String(url));
    const res = Readable.from([body]);
    res.statusCode = String(url).includes('blocked.invalid') ? 404 : 200;
    res.headers = {};
    process.nextTick(() => cb(res));
    return { on() { return this; }, destroy() {} };
  });
  const { download } = require('./updater');
  const name = `ArbiBrowser-update-test-${process.pid}.tar.gz`;
  const r = await download({ name, url: 'https://blocked.invalid/a.tar.gz', urlMirror: 'https://mirror.example/a.tar.gz', sha256: sha });
  try {
    assert.equal(r.ok, true);
    assert.equal(r.sha256, sha);
    assert.equal(fs.readFileSync(r.path).toString(), body.toString());
    assert.equal(seen.length, 2, 'после отказа первого адреса — ровно один запрос к зеркалу');
  } finally { fs.rmSync(r.path, { force: true }); }
  // Подменённый архив не проходит сверку.
  await assert.rejects(download({ name: name + '.bad', url: 'https://mirror.example/b', sha256: '0'.repeat(64) }), /контрольная сумма/);
  void os; void path;
});

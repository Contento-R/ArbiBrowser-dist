'use strict';
// Прямой вывод Ourbit: порядок запросов как у страницы (из вкладки вывода, пауза перед подтверждением), свои trace-id,
// ускорение по одному шагу за вывод, отказ → форма.
const test = require('node:test');
const assert = require('node:assert/strict');
const captcha = require('./ourbit-captcha');
const sign = require('./ourbit-sign');
const { _withdrawDirect: direct, _deviceOf: deviceOf, _authOf: authOf, _freshTrace: freshTrace, _nextTrial: nextTrial, _nextTrace: nextTrace, _traceOf: traceOf, _fpDiff: fpDiff } = require('./ourbit-order-page');

// Подпись в тестах — пометка, что запрос подписан.
sign.signFor = async () => ({ 'x-ourbit-nonce': 'часы' });

const TRACE = 'ab12cd34-1794862816767-xyzq';

function setup({ learned = {}, replies = {}, auth = true } = {}) {
  let st = { ...learned };
  const calls = [];
  const context = { cookies: async () => [] };
  const mk = (tab) => ({
    context: () => context,
    isClosed: () => false,
    evaluate: async (_fn, a) => {
      if (!a || !a.url) return '';
      const step = /check_address/.test(a.url) ? 'addr' : /check_chain/.test(a.url) ? 'check' : /captcha\/robot/.test(a.url) ? 'robot' : /save_withdraw/.test(a.url) ? 'save'
        : /submit_withdraw/.test(a.url) ? 'submit' : /check_risk/.test(a.url) ? 'risk' : /common\/ping/.test(a.url) ? 'ping' : 'other';
      calls.push({ step, tab, url: a.url, hdr: a.hdr, at: Date.now() });
      const q = replies[step];
      const r = Array.isArray(q) ? (q.length > 1 ? q.shift() : q[0]) : q;
      return r || (step === 'ping' ? { status: 200, time: Date.now() - 150 } : { status: 200, code: 0, data: null, success: true });
    },
  });
  const page = mk('торги');
  const wd = mk('вывод');
  captcha.known = () => true;
  captcha.hasFresh = () => true;
  captcha.take = () => ({ token: 'geetest TOKEN', page: wd });
  captcha.learned = () => ({ ...st });
  captcha.learnedSet = (p) => { st = { ...st, ...p }; };
  deviceOf.set(context, 'SUBMIT-DEVICE');
  if (auth) authOf.set(context, 'AUTH');
  const c = {
    page, context, log: () => {},
    hdr: { 'luminex-uid': 'u1', 'luminex-trace-id': TRACE, pragma: 'no-cache', baggage: 'b', 'sentry-trace': 's', 'content-type': 'application/json' },
    uh: { 'ucenter-token': 'T', 'device-id': 'UC-DEVICE', 'timezone-login': 'UTC+1', language: 'ru-RU' },
    want: { coin: 'USDT', chainName: 'BNB Smart Chain(BEP20)', address: '0xabc', amount: '10' },
  };
  return { c, calls, state: () => st };
}
const QUICK = { status: 200, code: 0, data: { isQuickWithdraw: true } };
const SAVED = { status: 200, code: 0, data: { requestId: 'R1' } };
const DONE = { status: 200, code: 0, data: { withdrawId: 'W1', needVerify: false } };
const NO = { status: 200, code: 60008, data: null, msg: 'x' };
const steps = (calls) => calls.map((x) => x.step).join(',');
const at = (calls, step, n = 0) => calls.filter((x) => x.step === step)[n];
const FAST = { base: true, gapMs: 0, pingEach: false, addrFirst: false, saveAfter: false, robotAfter: false }; // всё ускорено — проб нет

test('первый вывод — как страница: из вкладки вывода, адрес → проверка → капча → подготовка → пауза с check_risk → ping → подтверждение', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: DONE } });
  const r = await direct(c);
  assert.deepEqual(r, { ok: true, withdrawId: 'W1' });
  assert.ok(calls.every((x) => x.tab === 'вывод'));
  assert.deepEqual(calls.slice(0, 2).map((x) => x.step).sort(), ['addr', 'risk']);
  assert.equal(steps(calls.slice(2)), 'check,robot,save,risk,ping,submit');
  assert.ok(calls.every((x) => x.url.startsWith('/'))); // адрес без домена — через перехватчики страницы
  assert.ok(!at(calls, 'ping').hdr['content-type'] && !at(calls, 'ping').hdr['x-ourbit-nonce']);
  assert.ok(at(calls, 'robot').at - at(calls, 'check').at >= 100);
  assert.ok(at(calls, 'submit').at - at(calls, 'save').at >= 1150);
  assert.equal(at(calls, 'robot').hdr['device-id'], 'UC-DEVICE');
  assert.equal(at(calls, 'robot').hdr['captcha-token'], 'geetest TOKEN');
  assert.equal(at(calls, 'submit').hdr['device-id'], 'SUBMIT-DEVICE');
  assert.equal(at(calls, 'risk').hdr.authorization, 'AUTH');
  assert.ok(calls.every((x) => !x.hdr.baggage && !x.hdr['sentry-trace'] && x.hdr['cache-control'] === 'no-cache'));
  assert.ok(calls.filter((x) => x.step !== 'risk').every((x) => !x.hdr.authorization));
  const traces = calls.map((x) => x.hdr['luminex-trace-id']);
  assert.equal(new Set([...traces, TRACE]).size, traces.length + 1); // у каждого запроса свой
  assert.equal(state().base, true);
});

test('trace-id: тот же вид, другое значение, время — текущее', () => {
  const now = String(Date.now());
  const v = `ab12cd34-${now.slice(0, 3)}0000000000-xyzq`;
  const t = freshTrace(v);
  assert.notEqual(t, v);
  assert.match(t, /^[a-f0-9]{8}-\d{13}-[g-z]{4}$/);
  assert.ok(Math.abs(Number(t.split('-')[1]) - Date.now()) < 5000);
});

test('сайт просит показать капчу (данные в ответе) — подготовки и подтверждения нет, вывод формой', async () => {
  const { c, calls } = setup({ learned: FAST, replies: { check: QUICK, robot: { status: 200, code: 0, success: true, data: { type: 'slide' } }, save: { status: 200, code: 1, data: null } } });
  const r = await direct(c);
  assert.equal(r.form, true);
  assert.ok(!calls.some((x) => x.step === 'submit'));
});

test('сайт просит коды — отказ без формы и без подтверждения', async () => {
  const { c, calls } = setup({ learned: FAST, replies: { check: { status: 200, code: 0, data: { isQuickWithdraw: false } } } });
  const r = await direct(c);
  assert.equal(r.ok, false);
  assert.match(r.error, /коды/);
  assert.ok(!calls.some((x) => x.step === 'submit'));
});

test('порядок «как страница» отказан 60008 — формой, одно подтверждение; после двух отказов прямой путь не пробуется', async () => {
  const { c, calls, state } = setup({ learned: { gapMs: 0 }, replies: { check: QUICK, save: SAVED, submit: NO } });
  assert.equal((await direct(c)).form, true);
  assert.equal(calls.filter((x) => x.step === 'submit').length, 1);
  assert.equal(state().baseFails, 1);
  await direct(c);
  assert.equal(state().baseFails, 2);
  const n = calls.length;
  assert.equal((await direct(c)).form, true);
  assert.equal(calls.length, n);
});

test('без заголовка check_risk порядок неполный — отказ не идёт в счёт', async () => {
  const { c, calls, state } = setup({ auth: false, learned: { gapMs: 0 }, replies: { check: QUICK, save: SAVED, submit: NO } });
  authOf.delete(c.context);
  assert.equal((await direct(c)).form, true);
  assert.ok(!calls.some((x) => x.step === 'risk'));
  assert.equal(state().baseFails, undefined);
});

test('после рабочего порядка — проба без паузы; прошла — запоминается', async () => {
  const { c, calls, state } = setup({ learned: { base: true }, replies: { check: QUICK, save: SAVED, submit: DONE } });
  assert.equal((await direct(c)).ok, true);
  assert.ok(at(calls, 'submit').at - at(calls, 'save').at < 300);
  assert.equal(state().gapMs, 0);
});

test('проба без паузы отказана — этот же вывод рабочим порядком на новой капче; граница запоминается', async () => {
  const { c, calls, state } = setup({ learned: { base: true }, replies: { check: QUICK, save: [SAVED, { status: 200, code: 0, data: { requestId: 'R2' } }], submit: [NO, DONE] } });
  assert.deepEqual(await direct(c), { ok: true, withdrawId: 'W1' });
  assert.equal(calls.filter((x) => x.step === 'save').length, 2);
  assert.ok(at(calls, 'submit', 1).at - at(calls, 'save', 1).at >= 1150);
  assert.equal(state().gapBad, 0);
  assert.equal(state().gapMs, undefined);
});

test('порядок проб: пауза 0 → деление пополам → шаги порядка → всё', () => {
  assert.equal(nextTrial({}).gapMs, 0);
  assert.equal(nextTrial({ gapBad: 0 }).gapMs, 600);
  assert.equal(nextTrial({ gapBad: 600 }).gapMs, 900);
  assert.equal(nextTrial({ gapBad: 0, gapMs: 600 }).gapMs, 300);
  assert.equal(nextTrial({ gapMs: 0 }).step, 'pingEach');
  assert.equal(nextTrial({ gapBad: 1050 }).step, 'pingEach');
  assert.equal(nextTrial({ gapMs: 0, pingEach: true, addrFirst: false, saveAfter: true }).step, 'robotAfter');
  assert.equal(nextTrial({ gapMs: 0, pingEach: true, addrFirst: false, saveAfter: true, robotAfter: false }), null);
});

test('ускоренный порядок: проверка, капча и подготовка вместе, подтверждение сразу, без своего ping', async () => {
  const { c, calls } = setup({ learned: FAST, replies: { check: QUICK, save: SAVED, submit: DONE } });
  assert.equal((await direct(c)).ok, true);
  assert.ok(!calls.some((x) => x.step === 'ping'));
  assert.equal(calls.filter((x) => x.step === 'save').length, 1);
  assert.ok(at(calls, 'save').at - calls[0].at < 100);
});

test('подтверждение без ответа — «мог пройти», формой не повторяем', async () => {
  const { c } = setup({ learned: FAST, replies: { check: QUICK, save: SAVED, submit: { error: 'timeout' } } });
  const r = await direct(c);
  assert.equal(r.maybe, true);
  assert.ok(!r.form);
});

test('trace-id продолжает ряд страницы: общая часть та же, счётчик дальше; ряда нет — случайный того же вида', () => {
  const page = {};
  traceOf.set(page, ['ab12cd34-ffff-0017', 'ab12cd34-ffff-0018']);
  const a = nextTrace(page, 'x');
  const b = nextTrace(page, 'x');
  assert.match(a, /^ab12cd34-ffff-\d{4}$/);
  assert.notEqual(a, b);
  assert.ok(Number(a.slice(-4)) > 18);
  const other = {};
  traceOf.set(other, ['ab12cd34-ffff-aaaa1111', 'ab12cd34-ffff-bbbb2222']);
  assert.match(nextTrace(other, 'x'), /^ab12cd34-ffff-[a-f]{4}\d{4}$/);
  assert.match(nextTrace({}, 'cd-12'), /^[a-f]{2}-\d{2}$/);
});

test('сверка подтверждений называет недостающее, лишнее и разное', () => {
  const d = fpDiff({ accept: '*/*', lang: 'ru', extra: '#aaaa/3' }, { accept: 'application/json', lang: 'ru', baggage: 'есть' });
  assert.match(d, /accept: у нас \*\/\*, у страницы application\/json/);
  assert.match(d, /нет у нас: baggage/);
  assert.match(d, /лишнее у нас: extra/);
  assert.ok(!/lang/.test(d));
  assert.match(fpDiff({ a: '1' }, { a: '1' }), /отличий нет/);
});

'use strict';

/**
 * mexc-withdraw-page.js — ВЫВОД С MEXC ЧЕРЕЗ САЙТ (оператор 22.10; план —
 * Infra/plans/mexc-web-withdraw-via-arbibrowser-2026-10-22.md).
 *
 * Новый аккаунт MEXC получил блок API-вывода (152100 → 700012), с сайта вывод работает,
 * у оператора включён «быстрый вывод» (адрес из адресной книги — без кодов). Терминал
 * шлёт сюда два вида намерений (только для аккаунта с галочкой «Выводить через сайт»):
 *   • withdrawPrep — подготовка заранее: вкладка вывода обновляет баланс, выбирает монету,
 *     сеть и адрес из адресной книги, вписывает сумму. Ни одна кнопка вывода не нажимается.
 *     Шлётся при выборе сети/кошелька в терминале и при росте баланса монеты (исполнился ордер).
 *   • withdraw — сам вывод: сверить форму со СВОИМ намерением, сумма → «Вывести» → окна
 *     подтверждения (со сверкой) → ответ сайта. Ровно одно нажатие «Вывести» на намерение.
 *
 * Сумма (оператор 22.10): max=false — вписывается РОВНО amount и читается обратно полностью
 * (помощник ввода ордеров засчитывает обрезанный биржей хвост — здесь так нельзя); max=true —
 * «вывести всё доступное»: жмём «Макс» страницы, число должно быть не больше amount + 2 %
 * и не меньше amount − комиссия страницы. Иначе — отказ, ничего не отправлено.
 * Адрес — только тот, что прислал терминал (белый список его группы): запись адресной книги
 * MEXC с тем же полным адресом, поле читается обратно целиком. Нет записи — отказ.
 *
 * Не трогает заявки и общий код ордеров: вкладка своя, в своём фоновом окне (кадры идут —
 * клики мгновенные), помечена как служебная (`__arbiDuty`): заявки, уборка и сон её
 * обходят. Все вкладки mexc.com живут в одном процессе браузера, поэтому перезагрузка
 * вкладки вывода идёт только в затишье заявок; замок вывода — свой, не дорожки заявок.
 * Ввод только доверенный (Playwright/CDP): у MEXC JS-клик не даёт подписи антибота.
 * Незнакомое окно — стоп; капча/код — окно вперёд, ждём человека, ничего не вводим.
 *
 * Разметку страницы вывода из среды разработки не видно (Akamai): поля ищутся по подписи
 * («Сеть», «Адрес», «Сумма»…), тексты переопределяются env ARBI_MEXC_WD_RX_*, при отказе в
 * журнал пишется структура формы без значений — по ней правится без релиза.
 */
const { newBackgroundPage, markOwned, pageRenders, isAsleep } = require('./pair-tabs');
const { isContextBusy, laneIdleMs } = require('./context-lock');
const { mexcBlocked, mexcBlockedMsLeft } = require('./mexc-order-page');
const { pickBaseAvail } = require('./order-utils');
const loginHold = require('./login-hold');

const ORIGIN = 'https://www.mexc.com';
const URL_TMPL = process.env.ARBI_MEXC_WITHDRAW_URL || `${ORIGIN}/ru-RU/assets/withdraw/{coin}`;
// Запрос, который создаёт вывод (захват ручного вывода оператора 22.10): «Отправить» на форме →
// save_withdraw (готовит заявку: сумма/адрес/сеть, ответ — requestId) → окно подтверждения →
// коды/ключ доступа → submit_withdraw (ответ — withdrawId, state WAIT). Деньги двигает только он.
const WD_REQ_RE = new RegExp(process.env.ARBI_MEXC_WITHDRAW_RE || '/withdraw/submit_withdraw/', 'i');
// Что страница сама отправляет MEXC: выбор адреса → withdraw_check_address {address, chainName,
// currency}; «Отправить» → save_withdraw {amount, address, chain, currency}. Сверка без разметки.
const SITE_RE = /\/(address_mark\/v2\/withdraw_check_address|withdraw\/save_withdraw)\b/;
// Служебные POST страницы вывода, которые вывод не создают (тот же захват). Любой другой POST с
// «withdraw» после «Отправить» — неизвестный: исход тогда «не знаю», а не «ничего не отправлено».
const WD_SAFE_RE = /withdraw_check_address|\/withdraw\/(check_chain|risk\/pre_check|save_withdraw)\b/;
const MAX_CONFIRMS = Math.max(1, Number(process.env.ARBI_MEXC_WD_MAX_CONFIRMS) || 2);
// Вывод, прождавший очередь ArbiBrowser дольше (терминал ждёт ответ 45 с), не исполняется.
const QUEUE_MAX_MS = 40_000;
const HUMAN_MS = Math.max(30_000, Number(process.env.ARBI_MEXC_WITHDRAW_HUMAN_MS) || 300_000);
const IDLE_MS = Math.max(0, Number(process.env.ARBI_MEXC_WD_IDLE_MS) || 3000);
const RELOAD_GAP_MS = Math.max(0, Number(process.env.ARBI_MEXC_WD_RELOAD_GAP_MS) || 10_000);
const REFRESH_MS = Math.max(5, Number(process.env.ARBI_MEXC_WD_REFRESH_MIN) || 30) * 60_000;
const MAX_ABOVE = 1.02;
const TAB = 'MEXC-WD';

const env = (k, d) => process.env[`ARBI_MEXC_WD_RX_${k}`] || d;
const RX = {
  coin: env('COIN', '^(монета|выберите монету|криптовалюта|выберите криптовалюту|coin|select coin|crypto)$'),
  network: env('NETWORK', '^(сеть|сеть вывода|выберите сеть|network|select network|chain|withdrawal network)$'),
  address: env('ADDRESS', '^(адрес|адрес вывода|адрес получателя|адрес кошелька|address|withdrawal address|wallet address)$'),
  amount: env('AMOUNT', '^(сумма|сумма вывода|количество|amount|withdrawal amount|withdraw amount)$'),
  max: env('MAX', '^(макс\\.?|максимум|max|все|всё|all)$'),
  // На форме MEXC кнопка — «Отправить», и в окне подтверждения тоже (захват 22.10).
  submit: env('SUBMIT', '^(вывести|вывод|отправить|withdraw|submit|подтвердить вывод)$'),
  confirm: env('CONFIRM', '^(подтвердить|подтверждаю|confirm|ок|ok|вывести|отправить|submit|withdraw|продолжить|continue)$'),
  cancel: env('CANCEL', '^(отмена|отменить|cancel)$'),
  book: env('BOOK', '(адресная книга|address book|сохран[её]нные адреса|выбрать адрес)'),
  fee: env('FEE', '^(комиссия|комиссия сети|комиссия за вывод|fee|network fee|withdrawal fee)'),
  // Окно, которому нужен человек: поле ввода кода, капча (iframe/canvas) или такие слова.
  human: env('HUMAN', '(введите код|код из|код подтверждения|код эл|verification code|google auth|аутентификатор|authenticator|captcha|капч|слайдер|slider|passkey|ключ\\S* доступа|отправить код|send code|get code)'),
  // Всплывашки, которые можно закрыть (если в окне нет слов про вывод).
  popup: env('POPUP', '(cookie|куки|новые функции|what.?s new|акци|promo|бонус|airdrop|реферал|подарок|gift|опрос|survey)'),
  wdWords: '(вывод|withdraw|адрес|address|сеть|network|сумм|amount)',
  success: env('SUCCESS', '(заявка на вывод (создана|отправлена|принята)|запрос на вывод( средств)? отправлен|вывод (средств )?(успешно )?(отправлен|создан|выполнен успешно)|withdrawal (request )?(submitted|created))'),
};

// ── Чистые помощники (покрыты тестами) ──────────────────────────────────────

/** Число со страницы → каноническая десятичная строка без лишних нулей; null — не число. */
function normAmount(s) {
  let v = String(s == null ? '' : s).replace(/[\s  ]/g, '');
  if (v.includes(',') && v.includes('.')) v = v.replace(/,/g, '');
  else v = v.replace(',', '.');
  if (!/^\d+(\.\d+)?$/.test(v)) return null;
  v = v.replace(/^0+(?=\d)/, '');
  if (v.includes('.')) v = v.replace(/0+$/, '').replace(/\.$/, '');
  return v;
}
/** Строгое равенство сумм как десятичных строк (без float). */
function sameAmount(a, b) {
  const x = normAmount(a); const y = normAmount(b);
  return x != null && x === y;
}
const isEvm = (a) => /^0x[0-9a-fA-F]{40}$/.test(String(a));
/** Адрес совпал целиком: EVM — без учёта регистра, прочие — побайтно. */
function addrEq(a, b) {
  const x = String(a || '').trim(); const y = String(b || '').trim();
  if (!x || !y) return false;
  return isEvm(x) && isEvm(y) ? x.toLowerCase() === y.toLowerCase() : x === y;
}
/** Короткая запись адреса для журнала. */
const short = (a) => { const s = String(a || ''); return s.length > 12 ? `${s.slice(0, 6)}…${s.slice(-4)}` : s; };
const normNet = (s) => String(s || '').toUpperCase().replace(/[\s_\-]+/g, '');
/** Код сети в скобках: «BNB Smart Chain(BEP20)» → «BEP20». */
const netCode = (s) => { const m = String(s || '').match(/\(([^)]+)\)/); return m ? normNet(m[1]) : normNet(s); };
const hasToken = (text, tok) => new RegExp(`(^|[^A-Z0-9])${tok.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Z0-9]|$)`).test(String(text || '').toUpperCase());
/** Показывает ли подпись нужную сеть: полное имя или код в скобках. */
function netMatches(text, want) {
  const t = normNet(text);
  if (t.includes(normNet(want))) return true;
  // «Имя(КОД)» с нашим кодом, но другим именем — другая сеть: Arbitrum Nova(ARB) ≠ Arbitrum One(ARB) (ревью 22.10).
  if (/\(/.test(normNet(want)) && t.includes(`(${netCode(want)})`)) return false;
  return hasToken(String(text || '').toUpperCase().replace(/\s+/g, ' '), netCode(want));
}
// Коды сетей для проверки «в поле выбрана ОДНА сеть»: если в значении есть чужой код —
// это список/плитки всех сетей, а не выбранное значение (ревью 22.10).
const NET_CODES = ['ERC20', 'BEP20', 'BEP2', 'TRC20', 'SOL', 'ARBITRUM', 'ARB', 'OPTIMISM', 'OP', 'BASE', 'MATIC', 'POLYGON', 'AVAXC', 'AVAX', 'TON', 'BTC', 'LTC', 'TRX', 'ZKSYNC', 'LINEA', 'SCROLL', 'APT', 'SUI', 'NEAR', 'ATOM', 'KCC', 'HECO'];
/** В тексте наша сеть и ни одной чужой. */
function netOnly(text, want) {
  const t = String(text || '');
  if (!t || !netMatches(t, want)) return false;
  const mine = netCode(want); const full = normNet(want);
  // Полное имя есть: чужая сеть — только другое «(КОД)» (список сетей); короткий код рядом («TRX Tron(TRC20)») не в счёт.
  if (normNet(t).includes(full)) return !(normNet(t).match(/\([A-Z0-9]+\)/g) || []).some((x) => x !== `(${mine})`);
  return !NET_CODES.some((c) => c !== mine && !full.includes(c) && hasToken(t, c));
}
/** Значение поля сети — ровно нужная сеть: совпала и чужих кодов нет, текст короткий. */
const netValueOk = (text, want) => String(text || '').length <= 80 && netOnly(text, want);
/** Выбор строки сети: полное имя — сильное совпадение, код — слабое; нужен ровно один. */
function pickNetwork(options, want) {
  const strong = options.map((t, i) => (normNet(t).includes(normNet(want)) ? i : -1)).filter((i) => i >= 0);
  if (strong.length === 1) return strong[0];
  if (strong.length > 1) return -1;
  const weak = options.map((t, i) => (hasToken(t, netCode(want)) ? i : -1)).filter((i) => i >= 0);
  return weak.length === 1 ? weak[0] : -1;
}
/** Выбор строки монеты: тикер отдельным словом; несколько — тот, где он первым. */
function pickCoin(options, coin) {
  const c = String(coin).toUpperCase();
  const hits = options.map((t, i) => (hasToken(t, c) ? i : -1)).filter((i) => i >= 0);
  if (hits.length === 1) return hits[0];
  const first = hits.filter((i) => String(options[i]).toUpperCase().trim().split(/[^A-Z0-9]+/)[0] === c);
  return first.length === 1 ? first[0] : -1;
}
/** Строка адресной книги: полный адрес → сильное; начало+конец → слабое; нужен ровно один. */
function pickAddress(options, addr) {
  const evm = isEvm(addr);
  const full = options.map((t, i) => {
    const toks = String(t).split(/[^0-9A-Za-z]+/);
    return toks.some((x) => addrEq(x, addr)) ? i : -1;
  }).filter((i) => i >= 0);
  if (full.length === 1) return { index: full[0], strong: true };
  if (full.length > 1) return { index: -1 };
  const head = addr.slice(0, 6); const tail = addr.slice(-4);
  const cmp = (s) => (evm ? String(s).toLowerCase() : String(s));
  const part = options.map((t, i) => (cmp(t).includes(cmp(head)) && cmp(t).includes(cmp(tail)) ? i : -1)).filter((i) => i >= 0);
  return part.length === 1 ? { index: part[0], strong: false } : { index: -1 };
}
/** В тексте есть адрес целиком (отдельным словом). */
const addrIn = (text, addr) => String(text || '').split(/[^0-9A-Za-z]+/).some((x) => addrEq(x, addr));
/** Адреса в тексте для журнала/ошибки — коротко (0x1234…abcd). */
const maskAddrs = (s) => String(s || '').replace(/\b(0x[0-9a-fA-F]{8,}|[1-9A-HJ-NP-Za-km-z]{26,})\b/g, (m) => short(m));
/**
 * Запись адресной книги (окно «Выберите адрес вывода», белый список MEXC — захват 22.10):
 * entries = [{ text: строка адреса, ctx: вся запись (метка, адрес, сеть) }]. Нужен наш адрес
 * в нашей сети: запись задаёт и сеть вывода. Тот же адрес в той же сети дважды («Недавно
 * используемые» повторяют книгу) — одна запись; разные сети/адреса — отказ.
 */
function pickBookEntry(entries, addr, net) {
  const cmp = (s) => (isEvm(addr) ? String(s).toLowerCase() : String(s)).trim();
  let hits = entries.map((e, i) => (addrIn(e.text, addr) ? i : -1)).filter((i) => i >= 0);
  if (!hits.length) hits = entries.map((e, i) => (cmp(e.text).includes(cmp(addr.slice(0, 6))) && cmp(e.text).includes(cmp(addr.slice(-4))) ? i : -1)).filter((i) => i >= 0);
  const ctx = (i) => entries[i].ctx || entries[i].text;
  // Полное имя сети в записи — повторы того же адреса в той же сети схлопываем; совпал лишь код — нужна ровно одна запись.
  const full = hits.filter((i) => netOnly(ctx(i), net) && normNet(ctx(i)).includes(normNet(net)));
  if (full.length) return new Set(full.map((i) => cmp(entries[i].text))).size === 1 ? full[0] : -1;
  const mine = hits.filter((i) => netOnly(ctx(i), net));
  if (mine.length) return mine.length === 1 ? mine[0] : -1;
  // Записи без сети (не белый список) — один адрес; сеть сверится полем после выбора.
  const silent = hits.filter((i) => !NET_CODES.some((c) => hasToken(ctx(i), c)));
  return silent.length === 1 && hits.length === 1 ? silent[0] : -1;
}
/** Тело запроса страницы (withdraw_check_address / save_withdraw) совпало с намерением; иначе — что не так. */
function siteProblem(b, w, amount) {
  if (!b || typeof b !== 'object') return 'нет данных';
  if (b.currency != null && String(b.currency).toUpperCase() !== String(w.coin).toUpperCase()) return `монета ${b.currency}`;
  if (!addrEq(b.address, w.address)) return `адрес ${short(b.address)}`;
  const net = b.chainName ?? b.chain;
  if (normNet(net) !== normNet(w.network)) return `сеть ${net}`; // имя сети в запросе — ровно наше, не по коду
  if (amount != null && !sameAmount(b.amount, amount)) return `сумма ${b.amount}`;
  return null;
}
/** Насколько «Макс» страницы может быть меньше суммы терминала: комиссия (+5 %), без неё — 0,1 %. */
const maxTol = (a, fee) => { const f = Number(fee) || 0; return f > 0 ? f * 1.05 + a * 1e-6 : a * 0.001; };
/** «Макс» страницы в допуске: не больше суммы терминала + 2 %, не меньше суммы − комиссия. */
function maxWithin(v, amount, fee) {
  const x = Number(normAmount(v)); const a = Number(normAmount(amount));
  if (!(x > 0) || !(a > 0)) return false;
  return x <= a * MAX_ABOVE + 1e-12 && x >= a - maxTol(a, fee);
}
/** Все прочтения числа со страницы: «1,234.5», «1 234,5», «1,234» (тысячи или дробь). */
function numVariants(tok) {
  const t = String(tok).replace(/[\s  ]/g, '');
  const out = [normAmount(t)];
  if (/^\d{1,3}(,\d{3})+$/.test(t)) out.push(normAmount(t.replace(/,/g, '')));
  if (/^\d{1,3}(\.\d{3})+,\d+$/.test(t)) out.push(normAmount(t.replace(/\./g, '').replace(',', '.')));
  return out.filter(Boolean);
}
/** Окно подтверждения показывает наш вывод: монета, сумма, сеть, начало и конец адреса. */
function confirmProblem(text, w, amount) {
  const t = String(text || '');
  if (!hasToken(t, String(w.coin).toUpperCase())) return `в окне нет монеты ${w.coin}`;
  const want = normAmount(amount);
  const toks = t.match(/(?<![A-Za-z0-9])\d[\d\s  .,]*\d|(?<![A-Za-z0-9])\d/g) || []; // «BEP20» — не сумма 20
  if (!toks.some((n) => numVariants(n).includes(want))) return `в окне нет суммы ${amount}`;
  if (!netMatches(t, w.network)) return `в окне нет сети ${w.network}`;
  const cmp = (s) => (isEvm(w.address) ? s.toLowerCase() : s);
  if (/[0-9A-Za-z]{20,}|0x[0-9a-fA-F]{4,}/.test(t) && !(cmp(t).includes(cmp(w.address.slice(0, 4))) && cmp(t).includes(cmp(w.address.slice(-4))))) {
    return `адрес в окне не совпадает с ${short(w.address)}`;
  }
  return null;
}

// ── Страница: поиск полей по подписи, окна, сканы (выполняются в странице) ─────

/** Поля формы по подписи → метки data-arbi-wd; значения для сверки. */
const FIND = ({ rx, keys }) => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const own = (e) => Array.from(e.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join(' ').replace(/\s+/g, ' ').trim();
  const txt = (e) => (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  document.querySelectorAll('[data-arbi-wd]').forEach((e) => { if (!/^opt|^btn/.test(e.getAttribute('data-arbi-wd'))) e.removeAttribute('data-arbi-wd'); });
  document.querySelectorAll('[data-arbi-wdi]').forEach((e) => e.removeAttribute('data-arbi-wdi'));
  // Сначала дешёвый отбор по своему тексту, getComputedStyle — только для кандидатов
  // (страница MEXC в общем процессе с заявкой: тысячи стилей на каждый вызов недопустимы).
  const labTxt = (e) => (e.children.length ? own(e) : String(e.textContent || '').replace(/\s+/g, ' ').trim()).replace(/[:：*]/g, '').trim();
  const any = new RegExp(keys.map((k) => `(?:${rx[k]})`).join('|'), 'i');
  const labels = Array.from(document.querySelectorAll('label,div,span,p,h3,h4,h5,dt,legend')).filter((e) => { const t = labTxt(e); return t && t.length <= 40 && any.test(t); });
  const out = {};
  for (const k of keys) {
    const re = new RegExp(rx[k], 'i');
    const lab = labels.find((e) => re.test(labTxt(e)) && vis(e));
    if (!lab) { out[k] = { found: false }; continue; }
    let box = lab; let ctl = null;
    for (let i = 0; i < 6 && !ctl; i++) {
      box = box.parentElement;
      if (!box) break;
      ctl = Array.from(box.querySelectorAll('input:not([type=hidden]):not([type=checkbox]):not([type=radio]),textarea,[role="combobox"],[class*="select" i]'))
        .filter((c) => vis(c) && !lab.contains(c) && (lab.compareDocumentPosition(c) & Node.DOCUMENT_POSITION_FOLLOWING))[0] || null;
    }
    if (!ctl) { out[k] = { found: false, label: true }; continue; }
    const input = /^(INPUT|TEXTAREA)$/.test(ctl.tagName) ? ctl : ctl.querySelector('input:not([type=hidden])');
    ctl.setAttribute('data-arbi-wd', k);
    if (input) input.setAttribute('data-arbi-wdi', k); // поле ввода (может быть самим ctl)
    // У выпадашки читаем ВЫБРАННОЕ значение, а не весь текст триггера (иначе список сетей «совпал бы» с любой).
    const selVal = !input && ctl.querySelector('[class*="selection-item" i],[class*="selected-value" i],[class*="select-value" i],[class*="selection" i]');
    // Пустой ввод, а выбранное показано рядом (не в value) — текст рамки поля.
    out[k] = { found: true, input: !!input, value: (input && input.value ? String(input.value) : txt(selVal || ctl) || (ctl === input && ctl.parentElement ? txt(ctl.parentElement) : '')).slice(0, 200) };
  }
  return out;
};

/** Видимые окна (модалки) поверх формы: текст, есть ли поле кода/капча, кнопки. Помечает кнопки. */
const DIALOGS = ({ rx }) => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 40 && r.height > 30 && s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05; };
  const txt = (e) => (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  document.querySelectorAll('[data-arbi-wd^="btn"]').forEach((e) => e.removeAttribute('data-arbi-wd'));
  const all = Array.from(document.querySelectorAll('[role="dialog"],[aria-modal="true"],[class*="modal" i]:not([class*="mask" i]),[class*="Dialog"]')).filter(vis);
  // Окно целиком — самый внешний элемент: у antd (MEXC ant-modal-v2, захват 22.10) заголовок, тело
  // и кнопки — разные …modal-…-элементы, по отдельности окно не сверить.
  const boxes = all.filter((d) => !all.some((x) => x !== d && x.contains(d)));
  return boxes.slice(0, 4).map((d, i) => {
    const t = txt(d).slice(0, 600);
    const inputs = Array.from(d.querySelectorAll('input')).filter((x) => vis(x) && !/checkbox|radio|hidden/i.test(x.type)).length;
    const captcha = !!d.querySelector('iframe,canvas,[class*="captcha" i],[id*="captcha" i],[class*="geetest" i],[class*="slider" i]');
    const btns = Array.from(d.querySelectorAll('button,[role="button"],a')).filter((b) => { const r = b.getBoundingClientRect(); return r.width > 2 && r.height > 2; }).map((b, j) => {
      const label = (txt(b) || b.getAttribute('aria-label') || '').slice(0, 30); // крестик antd — пустой текст, aria-label «Close»
      const key = `btn${i}-${j}`;
      b.setAttribute('data-arbi-wd', key);
      return { key, label, disabled: !!(b.disabled || b.getAttribute('aria-disabled') === 'true' || /disabled/i.test(b.className || '')) };
    });
    const box = Array.from(d.querySelectorAll('input[type=checkbox],[class*="checkbox" i]')).filter(vis).map((c, j) => { const key = `btn${i}-cb${j}`; c.setAttribute('data-arbi-wd', key); return { key, checked: !!(c.checked || /checked/i.test(c.className || '')) }; });
    return { text: t, inputs, captcha, human: new RegExp(rx.human, 'i').test(t), buttons: btns, checkboxes: box };
  });
};

/**
 * Варианты открытого списка (сеть, монета, адресная книга) — только то, что ПОЯВИЛОСЬ после клика.
 * { pre: true } до клика запоминает всё видимое: рамку поля с подсказкой (у MEXC «Выберите сеть
 * вывода средств» — div …__option внутри …__selectDropdownRoot, захват 22.10) и меню шапки сайта
 * (тоже popover/item). Раньше они читались как «список» — сеть «не находилась» (22.10).
 * После клика: rows — самые внутренние строки (option/item/li) с новым текстом (метка opt-N);
 * leaves — новые тексты, если у строк нет таких классов (метка data-arbi-wdl); entries — записи
 * с адресом (метка+адрес+сеть) для адресной книги; search — новое поле ввода (поиск списка).
 */
const OPTIONS = ({ pre } = {}) => {
  const K = Symbol.for('arbi.wd.pre');
  const vis = (e) => {
    if (e.checkVisibility && !e.checkVisibility({ opacityProperty: true, visibilityProperty: true, checkOpacity: true, checkVisibilityCSS: true })) return false;
    const r = e.getBoundingClientRect();
    return r.width > 2 && r.height > 2;
  };
  const own = (e) => { let s = ''; for (const n of e.childNodes) if (n.nodeType === 3) s += n.textContent; return s.replace(/\s+/g, ' ').trim(); };
  const txt = (e) => (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  const field = (e) => e.tagName === 'INPUT' || e.tagName === 'TEXTAREA';
  const scan = () => Array.from(document.body.querySelectorAll('*')).filter((e) => (field(e) ? e.type !== 'hidden' : own(e)) && !/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(e.tagName));
  if (pre) { window[K] = new WeakSet(scan().filter(vis)); return null; }
  const was = window[K] || new WeakSet();
  document.querySelectorAll('[data-arbi-wd^="opt"],[data-arbi-wd="search"]').forEach((e) => e.removeAttribute('data-arbi-wd'));
  document.querySelectorAll('[data-arbi-wdl]').forEach((e) => e.removeAttribute('data-arbi-wdl'));
  const fresh = scan().filter((e) => !was.has(e) && vis(e));
  const leaves = fresh.filter((e) => !field(e)).slice(0, 150);
  const search = fresh.find((e) => field(e) && !e.readOnly && !e.disabled && !/checkbox|radio/i.test(e.type));
  if (search) search.setAttribute('data-arbi-wd', 'search');
  // Строка — ближайший к тексту элемент option/item/li; обёртка списка (тоже …options/…items) отпадает как не самая внутренняя.
  const cand = [...new Set(leaves.map((l) => l.closest('[role="option"],[class*="option" i],[class*="item" i],li')).filter(Boolean))];
  const rows = cand.filter((r) => !cand.some((x) => x !== r && r.contains(x))).slice(0, 80);
  // Запись адресной книги: от строки адреса вверх, пока в предке нет второго адреса (и он не больше записи).
  const ADDR = /0x[0-9a-fA-F]{3,}|[1-9A-HJ-NP-Za-km-z]{3,}(…|\.\.\.)[1-9A-HJ-NP-Za-km-z]{3,}|[1-9A-HJ-NP-Za-km-z]{25,}/;
  const al = leaves.filter((l) => ADDR.test(own(l)));
  const entries = al.map((l) => {
    let e = l;
    while (e.parentElement && e.parentElement !== document.body && txt(e.parentElement).length < 400 && al.filter((x) => e.parentElement.contains(x)).length === 1) e = e.parentElement;
    return { text: own(l).slice(0, 160), ctx: txt(e).slice(0, 300), i: leaves.indexOf(l) };
  });
  rows.forEach((r, i) => r.setAttribute('data-arbi-wd', `opt${i}`));
  leaves.forEach((l, i) => l.setAttribute('data-arbi-wdl', String(i)));
  return { rows: rows.map((r) => txt(r).slice(0, 160)), leaves: leaves.map((l) => own(l).slice(0, 160)), entries, search: !!search };
};

/** Тексты у поля суммы: ошибки, комиссия; кнопка «Макс»; кнопка «Вывести» после поля суммы. */
const AROUND = ({ rx }) => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const own = (e) => Array.from(e.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join(' ').replace(/\s+/g, ' ').trim();
  const txt = (e) => (e.innerText || e.textContent || '').replace(/\s+/g, ' ').trim();
  const amt = document.querySelector('[data-arbi-wdi="amount"]') || document.querySelector('[data-arbi-wd="amount"]');
  const res = { errors: [], fee: null, max: false, submit: false, submitDisabled: null, covered: null };
  if (!amt) return res;
  let box = amt;
  for (let i = 0; i < 5 && box.parentElement; i++) box = box.parentElement;
  res.errors = Array.from(box.querySelectorAll('[class*="error" i],[class*="explain" i],[role="alert"],[class*="warn" i]')).filter(vis).map(txt).filter((t) => t && t.length < 160).slice(0, 3);
  const maxRe = new RegExp(rx.max, 'i');
  const mx = Array.from(box.querySelectorAll('button,span,a,div')).filter((e) => vis(e) && maxRe.test((e.children.length ? own(e) : txt(e)).trim()))[0];
  if (mx) { mx.setAttribute('data-arbi-wd', 'max'); res.max = true; }
  const feeRe = new RegExp(rx.fee, 'i');
  const feeLab = Array.from(document.querySelectorAll('div,span,label,p,dt')).filter((e) => vis(e) && feeRe.test((e.children.length ? own(e) : txt(e)).trim()))[0];
  if (feeLab) { const row = feeLab.parentElement || feeLab; const m = txt(row).match(/(\d[\d\s.,]*)/); res.fee = m ? m[1] : null; }
  const subRe = new RegExp(rx.submit, 'i');
  const sub = Array.from(document.querySelectorAll('button,[role="button"]'))
    .filter((b) => vis(b) && subRe.test(txt(b)) && (amt.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING))[0];
  if (sub) {
    sub.setAttribute('data-arbi-wd', 'submit');
    res.submit = true;
    res.submitDisabled = !!(sub.disabled || sub.getAttribute('aria-disabled') === 'true' || /disabled/i.test(sub.className || ''));
    const r = sub.getBoundingClientRect();
    const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    res.covered = !(top && (top === sub || sub.contains(top)));
  }
  return res;
};

/** Кнопка адресной книги рядом с полем адреса: маленький элемент со СВОИМ текстом → метка book. */
const BOOK = ({ rx }) => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && r.width < 400 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const own = (e) => Array.from(e.childNodes).filter((n) => n.nodeType === 3).map((n) => n.textContent).join(' ').replace(/\s+/g, ' ').trim();
  const addr = document.querySelector('[data-arbi-wd="address"]');
  if (!addr) return false;
  let box = addr;
  for (let i = 0; i < 5 && box.parentElement; i++) box = box.parentElement;
  const re = new RegExp(rx.book, 'i');
  const b = Array.from(box.querySelectorAll('button,span,a,div,i')).filter((e) => vis(e) && re.test(own(e)) && own(e).length < 40)[0];
  if (!b) return false;
  b.setAttribute('data-arbi-wd', 'book');
  return true;
};

/** Капча/проверка вне модального окна (GeeTest, слайдер, iframe проверок) — нужен человек. */
const HUMAN_OVERLAY = () => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 20 && r.height > 20 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const sel = '[class*="geetest" i],[class*="captcha" i],[id*="captcha" i],[class*="nc_wrapper" i],[class*="slider-verify" i],[class*="verify-slider" i],iframe[src*="captcha" i],iframe[src*="geetest" i],iframe[src*="recaptcha" i],iframe[src*="hcaptcha" i],iframe[src*="turnstile" i]';
  return Array.from(document.querySelectorAll(sel)).some(vis);
};

/** Где мы: форма вывода / стена входа / Access Denied / 404 / другая страница. */
const STATE = () => {
  const body = document.body ? String(document.body.innerText || '').slice(0, 4000) : '';
  if (/Access Denied|don't have permission|edgesuite\.net|Reference #\d/i.test(body) && body.length < 3000) return 'denied';
  if (/\/(login|register|signin|sign-in)/i.test(location.pathname)) return 'login';
  if (!/\/assets\/withdraw/i.test(location.pathname)) return 'elsewhere';
  if (/cannot be found|страница не найдена|не удалось найти/i.test(body) && body.length < 3000) return 'notfound';
  return 'ok';
};

/** Структура формы без значений — в журнал при отказе (по ней правятся подписи без релиза). */
const STRUCT = () => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); return r.width > 2 && r.height > 2 && getComputedStyle(e).visibility !== 'hidden'; };
  const t = (s) => String(s || '').replace(/\s+/g, ' ').trim().replace(/\b(0x[0-9a-fA-F]{6,}|[1-9A-HJ-NP-Za-km-z]{26,})\b/g, (m) => `${m.slice(0, 4)}…${m.slice(-4)}`).slice(0, 50);
  const inputs = Array.from(document.querySelectorAll('input,textarea')).filter(vis).slice(0, 15).map((e) => `input[${e.type || 'text'}] «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
  const btns = [...new Set(Array.from(document.querySelectorAll('button,[role="button"]')).filter(vis).map((b) => t(b.innerText)).filter(Boolean))].slice(0, 20);
  const labels = [...new Set(Array.from(document.querySelectorAll('label,dt,h4,h5,div,span')).filter((e) => vis(e) && !e.children.length).map((e) => t(e.textContent)).filter((x) => x && x.length < 30 && !/\d{3,}/.test(x)))].slice(0, 25);
  return `адрес=${location.pathname} поля=[${inputs.join(' | ')}] кнопки=[${btns.join(' | ')}] подписи=[${labels.join(' | ')}]`;
};

// ── Вкладка вывода ──────────────────────────────────────────────────────────

const chains = new WeakMap();   // context → цепочка задач вывода (свой замок, не дорожки заявок)
const pendingWd = new WeakMap(); // context → сколько выводов ждёт/идёт (подготовка им уступает)
const keepers = new WeakSet();
const wdEnd = new WeakMap(); // context → когда закончился прошлый вывод
let deniedUntil = 0;

function locked(ctx, fn) {
  const prev = chains.get(ctx) || Promise.resolve();
  const run = prev.then(fn, fn);
  chains.set(ctx, run.then(() => {}, () => {}));
  return run;
}

function findTab(context) {
  const pages = (() => { try { return context.pages(); } catch { return []; } })();
  for (const p of pages) { try { if (!p.isClosed() && p.__arbiDuty === TAB) return p; } catch { /* закрыта */ } }
  // Вкладка вывода, восстановленная после перезапуска (своя, не спящая) — берём её, а не открываем дубль.
  for (const p of pages) {
    try {
      if (!p.isClosed() && p.__arbiOwned === true && !p.__arbiDuty && !isAsleep(p) && /mexc\.com\/.*assets\/withdraw/i.test(p.url())) { p.__arbiDuty = TAB; return p; }
    } catch { /* закрыта */ }
  }
  return null;
}

const urlFor = (coin) => URL_TMPL.replace('{coin}', encodeURIComponent(String(coin).toUpperCase()));
const restoring = (context) => { try { return context.pages().some((p) => typeof p.__arbiPendingUrl === 'string'); } catch { return false; } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Ждать затишья заявок перед навигацией (Akamai: навигации к MEXC не параллелим; общий
 * процесс mexc.com: тяжёлая загрузка тормозит заявку). bg — подготовка: нужна свободная
 * дорожка ≥ IDLE_MS, иначе пропуск; вывод (действие человека) ждёт до 5 с и идёт.
 */
async function quietForNav(context, bg) {
  const until = Date.now() + (bg ? 15_000 : 10_000);
  while (Date.now() < until) {
    // Обе дорожки профиля (заявки и фоновые чтения со своими переходами) — навигации к MEXC не параллелим.
    if (!isContextBusy(context, 'order') && !isContextBusy(context, 'bg') && laneIdleMs(context, 'order') >= (bg ? IDLE_MS : 0) && !restoring(context)) return true;
    if (bg && (pendingWd.get(context) || 0) > 0) return false;
    await sleep(150);
  }
  return !bg;
}

/** Открыть/обновить вкладку вывода монеты. Возвращает { page } или { error }. */
async function loadTab(context, coin, log, { bg, force, reuse }) {
  if (mexcBlocked()) return { error: `MEXC временно недоступен (Access Denied) — пауза ещё ${Math.ceil(mexcBlockedMsLeft() / 1000)} с` };
  if (Date.now() < deniedUntil) return { error: `страница вывода MEXC отдала Access Denied — пауза ещё ${Math.ceil((deniedUntil - Date.now()) / 1000)} с. Смените IP прокси или подождите.` };
  let page = findTab(context);
  if (page) { page.__arbiPairTabAt = Date.now(); watchSite(page); } // уборка простоя не закроет её посреди работы
  const want = urlFor(coin);
  const onCoin = page && decodeURIComponent(String(page.url())).toUpperCase().includes(`/WITHDRAW/${String(coin).toUpperCase()}`);
  const fresh = page && page.__wdLoadedAt && Date.now() - page.__wdLoadedAt < RELOAD_GAP_MS;
  // Вывод берёт подготовленную вкладку как есть (остаток сверит отдельно); подготовка
  // обновляет страницу, если она не свежая — в этом её смысл.
  if (page && onCoin && !force && (reuse || fresh)) return { page, reloaded: false };
  if (!(await quietForNav(context, bg))) return { skipped: 'заявки или вывод — подготовка подождёт' };
  const t0 = Date.now();
  if (!page) {
    page = markOwned(await newBackgroundPage(context));
    page.__arbiDuty = TAB;
    log(`вкладка вывода открыта (своё окно)`);
  }
  page.__arbiPairTabAt = Date.now(); // уборка служебных страниц считает простой отсюда
  watchSite(page);
  resetSite(page);
  try {
    if (onCoin) await page.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 });
    else await page.goto(want, { waitUntil: 'domcontentloaded', timeout: 30_000 });
  } catch (e) { return { error: `страница вывода MEXC не открылась: ${String(e && e.message || e).slice(0, 120)}` }; }
  page.__wdLoadedAt = Date.now();
  page.__wdPrep = null;
  const st = await page.evaluate(STATE).catch(() => 'ok');
  if (st === 'denied') { deniedUntil = Date.now() + 300_000; return { error: 'MEXC: Access Denied на странице вывода — пауза 5 мин. Смените IP прокси или подождите.' }; }
  // Без флага loginRequired: он перевёл бы весь профиль в «идёт вход» и остановил заявки MEXC (ревью 22.10).
  if (st === 'login') return { error: 'страница вывода MEXC открыла вход — войдите в MEXC в окне ArbiBrowser (вывод не отправлен)' };
  if (st === 'notfound' || st === 'elsewhere') return { error: `страница вывода ${coin} не открылась (${st}): ${String(page.url()).slice(0, 90)}` };
  // Форма рисуется дважды (захват 22.10): сразу — заготовка (монеты нет, адрес — ввод «Введите адрес
  // вывода средств», список сетей пуст), через 1–3 с по ответам сайта — монета и белый список
  // адресов. Ждём монету в поле и два одинаковых снимка подряд, до 15 с.
  let prev = ''; let ready = false;
  for (let i = 0; i < 60 && !ready; i++) {
    if (bg && yieldNow(context)) return { skipped: 'пошла заявка или вывод' };
    const f = await page.evaluate(FIND, { rx: RX, keys: ['coin', 'network', 'address'] }).catch(() => ({}));
    const sig = JSON.stringify(f);
    ready = !!(f.coin && f.coin.found && hasToken(f.coin.value, String(coin).toUpperCase()) && f.network && f.network.found && f.address && f.address.found) && sig === prev;
    prev = sig;
    if (!ready) await sleep(250);
  }
  log(`шаг «страница» за ${Date.now() - t0} мс (${onCoin ? 'перезагрузка' : 'переход'})${ready ? '' : ' — форма не устоялась за 15 с, пробую как есть'}`);
  return { page, reloaded: true };
}

/** Закрыть известные всплывашки; незнакомое окно (не капча, не подтверждение) → текст отказа. */
async function clearPopups(page) {
  for (let i = 0; i < 3; i++) {
    const ds = await page.evaluate(DIALOGS, { rx: RX }).catch(() => []);
    if (!ds.length) return null;
    const d = ds[0];
    if (new RegExp(RX.popup, 'i').test(d.text) && !new RegExp(RX.wdWords, 'i').test(d.text)) {
      const close = d.buttons.find((b) => /^(×|✕|x|закрыть|close|понятно|got it|ок|ok|принять|accept)$/i.test(b.label.trim()) || !b.label.trim());
      if (close) { await page.click(`[data-arbi-wd="${close.key}"]`, { timeout: 2000 }).catch(() => {}); await sleep(250); continue; }
    }
    return `окно поверх формы: «${maskAddrs(d.text).slice(0, 140)}»`;
  }
  return null;
}

/** Выбор по строкам списка, а если строк нет/не совпало — по новым текстам. fn(тексты) → индекс. */
const pickIn = (fn) => (o) => {
  let i = fn(o.rows);
  if (i >= 0) return { sel: `[data-arbi-wd="opt${i}"]`, text: o.rows[i] };
  i = fn(o.leaves);
  return i >= 0 ? { sel: `[data-arbi-wdl="${i}"]`, text: o.leaves[i] } : null;
};
/** Запись адресной книги с нашим адресом в нашей сети — клик по строке адреса. */
const pickEntry = (w) => (o) => {
  const k = pickBookEntry(o.entries, w.address, w.network);
  return k >= 0 ? { sel: `[data-arbi-wdl="${o.entries[k].i}"]`, text: o.entries[k].ctx } : null;
};
const optsText = (r) => maskAddrs((r.opts || []).slice(0, 8).join(' / ')) || 'список пуст';

/**
 * Открыть список поля (клик по sel) и выбрать вариант: pick(снимок OPTIONS) → { sel, text } | null.
 * До клика запоминаем видимое, после — до 3 с ждём, пока новые варианты появятся и устоятся
 * (два снимка подряд); ничего нового — Escape и второй клик (список мог быть уже открыт).
 * Возвращает { ok, text } или { ok:false, empty (список не раскрылся), opts }.
 */
async function chooseIn(page, sel, pick, searchText, quit) {
  let o = null; let p = null;
  const step = quit ? 300 : 150; // подготовка в фоне — реже: страница MEXC в общем процессе с заявками
  for (let attempt = 0; attempt < 2 && !(o && o.leaves.length); attempt++) {
    if (attempt) { await page.keyboard.press('Escape').catch(() => {}); await sleep(250); }
    await page.evaluate(OPTIONS, { pre: true }).catch(() => {});
    await page.click(sel, { timeout: 3000 });
    let prev = ''; let typed = !searchText;
    for (const until = Date.now() + 3000; Date.now() < until;) {
      await sleep(step);
      if (quit && quit()) { await page.keyboard.press('Escape').catch(() => {}); return { ok: false, skipped: true, opts: [] }; }
      o = await page.evaluate(OPTIONS, {}).catch(() => o);
      if (!o) continue;
      if (!typed && o.search) {
        await page.click('[data-arbi-wd="search"]', { timeout: 2000 }).catch(() => {});
        await page.keyboard.insertText(searchText);
        typed = true; prev = '';
        continue;
      }
      const sig = JSON.stringify(o);
      p = o.leaves.length && sig === prev ? pick(o) : null;
      if (p) break;
      prev = sig;
    }
  }
  const opts = o ? (o.rows.length ? o.rows : o.leaves) : [];
  if (!p) { await page.keyboard.press('Escape').catch(() => {}); return { ok: false, empty: !(o && o.leaves.length), opts }; }
  // Перечитать прямо перед кликом: под меткой должен быть тот же вариант.
  const again = await page.evaluate(OPTIONS, {}).catch(() => null);
  const q = again && pick(again);
  if (!q || q.sel !== p.sel || q.text !== p.text) { await page.keyboard.press('Escape').catch(() => {}); return { ok: false, moved: true, opts }; }
  await page.click(p.sel, { timeout: 3000 });
  return { ok: true, text: p.text };
}

/** Прочитать значение поля после выбора (до 3 с, пока не уйдёт «Выберите»). */
async function readField(page, key, ok) {
  let v = '';
  for (let i = 0; i < 20; i++) {
    const f = await page.evaluate(FIND, { rx: RX, keys: [key] }).catch(() => ({}));
    v = (f[key] && f[key].value) || '';
    if (ok(v)) return { ok: true, value: v };
    await sleep(150);
  }
  return { ok: false, value: v };
}

// ── Сверка по запросам самой страницы (тела POST к MEXC) ──────────────────────

/** Слушать запросы вкладки один раз: последний withdraw_check_address / save_withdraw и остатки монет. */
function watchSite(page) {
  if (page.__wdSite) return;
  page.__wdSite = { check: null, save: null, avail: {} };
  page.on('request', (req) => {
    try {
      const m = req.method() === 'POST' && SITE_RE.exec(req.url());
      if (!m) return;
      const body = JSON.parse(req.postData() || 'null');
      if (body && typeof body === 'object') page.__wdSite[m[1].includes('save') ? 'save' : 'check'] = { at: Date.now(), body };
    } catch { /* не JSON — не сверка */ }
  });
  // Остаток монет, которым живёт страница (currency/query: available) — запасной путь к «Доступно».
  page.on('response', async (resp) => {
    try {
      if (!/\/asset\/withdraw\/currency\/query/.test(resp.url())) return;
      const j = JSON.parse(await resp.text());
      for (const a of (j && j.data && j.data.assets) || []) if (a && a.currency) page.__wdSite.avail[String(a.currency).toUpperCase()] = a.available;
    } catch { /* диагностика */ }
  });
}
const resetSite = (page) => { if (page.__wdSite) Object.assign(page.__wdSite, { check: null, save: null, avail: {} }); };
/** Остаток монеты на странице вывода: «Доступно 1 000 USDT» / «Доступный баланс: 1 000 USDT» (захват 22.10), иначе — из ответа сайта. */
async function availWd(page, coin) {
  const texts = await page.evaluate(() => {
    const out = [];
    for (const e of document.querySelectorAll('div,span,label,p')) {
      if (e.children.length > 3 || e.offsetParent === null || !/(Доступн(о|ый баланс)|Available)/i.test(e.textContent || '')) continue;
      for (const n of [e, e.parentElement]) {
        const t = n ? (n.textContent || '').replace(/\s+/g, ' ').trim() : '';
        if (t && t.length < 120 && /\d/.test(t)) out.push(t);
      }
    }
    return out;
  }).catch(() => []);
  const v = pickBaseAvail(texts, coin);
  if (v != null) return v;
  const a = page.__wdSite && page.__wdSite.avail[String(coin).toUpperCase()];
  return a != null && Number.isFinite(Number(a)) ? Number(a) : null;
}
/** Дождаться запроса страницы kind ('check'|'save') не старше since; null — не было. */
async function siteReq(page, kind, since, ms) {
  for (const until = Date.now() + ms; ; await sleep(100)) {
    const r = page.__wdSite && page.__wdSite[kind];
    if (r && r.at >= since) return r;
    if (Date.now() > until) return null;
  }
}

/**
 * Монета, адрес, сеть — выбрать (если ещё не выбраны) и сверить. Белый список MEXC (захват
 * 22.10): адрес — запись адресной книги, она же ставит сеть, поэтому сначала адрес; список сетей
 * до адреса пуст («Нет данных»). Сверка — по полям страницы или по её же запросу к MEXC
 * (withdraw_check_address: адрес целиком, сеть, монета) — в поле адреса может стоять метка книги.
 */
async function selectAll(page, w, log, quit) {
  const t0 = Date.now();
  const coin = String(w.coin).toUpperCase();
  const wc = { ...w, coin };
  const keys = ['coin', 'network', 'address'];
  let f = await page.evaluate(FIND, { rx: RX, keys });
  if (f.coin && f.coin.found && !hasToken(f.coin.value, coin)) {
    const r = await chooseIn(page, '[data-arbi-wd="coin"]', pickIn((xs) => pickCoin(xs, coin)), coin, quit);
    if (r.skipped) return { skipped: 'пошла заявка или вывод' };
    if (!r.ok) return { error: r.empty ? 'список монет MEXC не раскрылся по клику' : `монета ${coin} не найдена однозначно в списке MEXC (${optsText(r)})` };
    const c = await readField(page, 'coin', (v) => hasToken(v, coin));
    if (!c.ok) return { error: `монета не выбралась: на странице «${c.value.slice(0, 60)}»` };
    log(`монета ${coin} выбрана`);
    f = await page.evaluate(FIND, { rx: RX, keys });
  }
  if (!f.network || !f.network.found) return { error: 'на странице не найдено поле «Сеть»' };
  if (!f.address || !f.address.found) return { error: 'на странице не найдено поле «Адрес»' };
  const siteOk = () => { const s = page.__wdSite && page.__wdSite.check; return !!s && !siteProblem(s.body, wc); };
  if (!siteOk() && !addrIn(f.address.value, w.address)) {
    const ta = Date.now();
    let r = await chooseIn(page, f.address.input ? '[data-arbi-wdi="address"]' : '[data-arbi-wd="address"]', pickEntry(w), null, quit).catch((e) => ({ ok: false, empty: true, opts: [String(e && e.message || e).slice(0, 60)] }));
    if (r.skipped) return { skipped: 'пошла заявка или вывод' };
    if (!r.ok && r.empty) {
      // Список не раскрылся по клику в поле — пробуем кнопку адресной книги рядом.
      await page.evaluate(FIND, { rx: RX, keys: ['address'] }).catch(() => {});
      if (await page.evaluate(BOOK, { rx: RX }).catch(() => false)) r = await chooseIn(page, '[data-arbi-wd="book"]', pickEntry(w), null, quit).catch(() => r);
      if (r.skipped) return { skipped: 'пошла заявка или вывод' };
    }
    if (!r.ok) return { error: `адрес ${short(w.address)} в сети ${w.network} не найден в адресной книге MEXC — добавьте его туда (${r.empty ? 'адресная книга не открылась' : optsText(r)})` };
    log(`адрес выбран в адресной книге: «${maskAddrs(r.text).slice(0, 120)}»`);
    const s = await siteReq(page, 'check', ta, 2500);
    if (s) log(`сайт проверяет адрес: ${short(s.body.address)}, сеть ${s.body.chainName}, ${s.body.currency}${siteProblem(s.body, wc) ? ` — НЕ совпадает (${siteProblem(s.body, wc)})` : ' — совпадает'}`);
    f = await page.evaluate(FIND, { rx: RX, keys });
  }
  if (!netValueOk(f.network.value, w.network) && !siteOk()) {
    const r = await chooseIn(page, '[data-arbi-wd="network"]', pickIn((xs) => pickNetwork(xs, w.network)), null, quit);
    if (r.skipped) return { skipped: 'пошла заявка или вывод' };
    if (!r.ok) return { error: r.empty ? `список сетей MEXC не раскрылся по клику (нужна ${w.network})` : `сеть «${w.network}» не найдена однозначно на MEXC (${optsText(r)})` };
    const n = await readField(page, 'network', (v) => netValueOk(v, w.network));
    if (!n.ok) return { error: `сеть не выбралась: на странице «${n.value.slice(0, 60)}»` };
    log(`сеть выбрана: «${n.value.slice(0, 60)}»`);
    f = await page.evaluate(FIND, { rx: RX, keys });
  }
  // Итог разом (выбор адреса мог сменить сеть и наоборот). Запрос страницы, если был, обязан совпасть.
  const s = page.__wdSite && page.__wdSite.check;
  const bad = s && siteProblem(s.body, wc);
  if (bad) return { error: `страница MEXC выбрала не то (${bad}) — ничего не отправлено` };
  // Монета обязана подтвердиться положительно: иначе сеть/адрес/сумма легли бы на чужую монету.
  const coinOk = (f.coin && f.coin.found && hasToken(f.coin.value, coin)) || (s && String(s.body.currency || '').toUpperCase() === coin);
  if (!coinOk) return { error: f.coin && f.coin.found ? `монета на странице «${f.coin.value.slice(0, 40)}», а нужна ${coin}` : 'на странице не найдено поле «Монета» — монету не сверить' };
  if (!s && !netValueOk(f.network.value, w.network)) return { error: `сеть на странице «${String(f.network.value).slice(0, 40)}», а нужна ${w.network}` };
  if (!s && !addrIn(f.address.value, w.address)) return { error: `адрес на странице «${maskAddrs(f.address.value).slice(0, 60)}», а нужен ${short(w.address)}` };
  log(`шаг «монета/сеть/адрес» за ${Date.now() - t0} мс (${coin}, ${w.network}, ${short(w.address)}; сверено ${s ? 'по запросу страницы к MEXC' : 'по полям'})`);
  return { ok: true };
}

/** Вписать сумму: max — «Макс» страницы в допуске; иначе ровно amount. Возвращает { value } или { error }. */
async function putAmount(page, w, fee) {
  const f = await page.evaluate(FIND, { rx: RX, keys: ['amount'] });
  if (!f.amount || !f.amount.found) return { error: 'на странице не найдено поле «Сумма»' };
  const sel = f.amount.input ? '[data-arbi-wdi="amount"]' : '[data-arbi-wd="amount"]';
  const around = await page.evaluate(AROUND, { rx: RX });
  const pageFee = normAmount(around.fee) || normAmount(fee) || null;
  if (w.max && around.max) {
    await page.click('[data-arbi-wd="max"]', { timeout: 2000 });
    let v = ''; let last = null;
    for (let i = 0; i < 12; i++) {
      await sleep(120);
      v = await page.locator(sel).first().inputValue().catch(() => '');
      if (v && v === last) break;
      last = v;
    }
    if (!maxWithin(v, w.amount, pageFee)) return { error: `«Макс» на MEXC = ${v || 'пусто'} ${w.coin}, а в терминале ${w.amount} (комиссия ${pageFee ?? '?'}) — расхождение больше допустимого, вывод не отправлен`, value: v };
    return { value: normAmount(v), fee: pageFee, sel };
  }
  const box = page.locator(sel).first();
  for (const how of ['insert', 'type']) {
    await box.click({ clickCount: 3, timeout: 2000 }).catch(() => {});
    await page.keyboard.press('ControlOrMeta+a').catch(() => {});
    await page.keyboard.press('Backspace').catch(() => {});
    if (how === 'insert') await page.keyboard.insertText(String(w.amount));
    else await page.keyboard.type(String(w.amount), { delay: 15 });
    await sleep(80);
    const v = await box.inputValue().catch(() => '');
    if (sameAmount(v, w.amount)) return { value: normAmount(v), fee: pageFee, sel };
  }
  const v = await box.inputValue().catch(() => '');
  return { error: `MEXC не принял сумму ${w.amount} в точности (в поле «${v}») — вывод не отправлен. Возможно, лишние знаки после запятой.`, value: v };
}

/** Подготовка/вывод: дойти до заполненной и сверенной формы. */
async function fillForm(context, w, log, { bg, force }) {
  let r = await loadTab(context, w.coin, log, { bg, force: !!force, reuse: !bg });
  if (r.skipped || r.error) return r;
  let page = r.page;
  if (!(await pageRenders(page)) && !bg) await page.bringToFront().catch(() => {});
  let pop = await clearPopups(page);
  if (bg && yieldNow(context)) return { skipped: 'пошла заявка или вывод' };
  const quit = bg ? () => yieldNow(context) : null;
  let s = pop ? { error: pop } : await selectAll(page, w, log, quit);
  if (s.skipped) return { skipped: s.skipped };
  if (s.error && !r.reloaded) {
    // Форма из прошлой подготовки могла устареть или на ней висит окно прошлой попытки —
    // одна свежая загрузка (окна уходят сами, ничего не нажимаем) и повтор.
    r = await loadTab(context, w.coin, log, { bg, force: true });
    if (r.skipped || r.error) return r;
    page = r.page;
    pop = await clearPopups(page);
    s = pop ? { error: pop } : await selectAll(page, w, log, quit);
    if (s.skipped) return { skipped: s.skipped };
  }
  if (s.error) return { error: s.error, page };
  return { page, reloaded: r.reloaded };
}

async function dumpStruct(page, log, why) {
  const s = await page.evaluate(STRUCT).catch(() => '');
  if (s) log(`[структура формы] ${why}: ${s}`);
}

function keep(context, log) {
  if (keepers.has(context)) return;
  keepers.add(context);
  { const p0 = findTab(context); if (p0) p0.__arbiPairTabAt = Date.now(); }
  const t = setInterval(() => {
    const page = findTab(context);
    if (!page) { clearInterval(t); keepers.delete(context); return; }
    page.__arbiPairTabAt = Date.now(); // вкладка вывода живёт всегда (оператор 22.10) — уборка её не закроет
    // Раз в REFRESH_MS — свежая загрузка в затишье: страница, провисевшая часами, тормозит
    // заявки (ONDO 08.10: заявка 2 мин). Потом снова выбираем монету/сеть/адрес.
    const lp = page.__wdLastPrep;
    if (!lp || Date.now() - (page.__wdLoadedAt || 0) < REFRESH_MS || (page.__wdHumanUntil || 0) > Date.now()) return;
    if (isContextBusy(context, 'order') || laneIdleMs(context, 'order') < 20_000 || (pendingWd.get(context) || 0) > 0 || mexcBlocked() || loginHold.isHeld(context, 'MEXC')) return;
    locked(context, () => prepInner(context, lp, log, true, null)).catch(() => {});
  }, 60_000);
  if (t.unref) t.unref();
}

// Заявки важнее (Т6): тяжёлую часть подготовки не продолжаем, если пошла заявка или вывод.
const yieldNow = (context) => isContextBusy(context, 'order') || (pendingWd.get(context) || 0) > 0;
const prepSeq = new WeakMap(); // context → номер последней подготовки: устаревшие в очереди схлопываются

async function prepInner(context, w, log, refresh, seq) {
  if ((pendingWd.get(context) || 0) > 0) return { ok: true, skipped: 'идёт вывод' };
  { const p0 = findTab(context); if (p0 && (p0.__wdHumanUntil || 0) > Date.now()) { log(`подготовка ${w.coin} пропущена: форма у вас после сухого прогона`); return { ok: true, skipped: 'форма у человека' }; } }
  if (seq != null && seq !== prepSeq.get(context)) return { ok: true, skipped: 'есть подготовка новее' };
  const t0 = Date.now();
  if (refresh) { const p = findTab(context); if (p) p.__wdLoadedAt = 0; }
  const r = await fillForm(context, w, log, { bg: true });
  if (r.skipped) { log(`подготовка ${w.coin} пропущена: ${r.skipped}`); return { ok: true, skipped: r.skipped }; }
  if (r.error) {
    if (r.page) await dumpStruct(r.page, log, r.error);
    return { ok: false, error: r.error };
  }
  const page = r.page;
  page.__wdLastPrep = { coin: w.coin, network: w.network, address: w.address, amount: w.amount, max: !!w.max };
  keep(context, log);
  const available = await availWd(page, String(w.coin).toUpperCase()).catch(() => null);
  let pageMax = null; let fee = null;
  if (!yieldNow(context)) {
    // Сумму вписываем заранее (как черновик заявки): вывод всё равно сверит её со своим намерением.
    const a = w.max ? await putAmount(page, { ...w, amount: w.amount || String(available || '') }, w.fee) : (w.amount && available != null && Number(w.amount) <= available ? await putAmount(page, w, w.fee) : {});
    if (w.max && a.value) pageMax = normAmount(a.value);
    fee = a.fee || null;
  }
  page.__wdPrep = { coin: w.coin, network: w.network, address: w.address, at: Date.now() };
  log(`подготовка ${w.coin} ${w.network} → ${short(w.address)} готова за ${Date.now() - t0} мс; на странице доступно ${available ?? '?'}${pageMax ? `, «Макс» ${pageMax}` : ''}`);
  return { ok: true, prepared: true, available, pageMax, fee };
}

/** Подготовка формы заранее (намерение withdrawPrep). Денег не двигает. */
function prep(context, w, opts = {}) {
  const log = opts.log || (() => {});
  const seq = (prepSeq.get(context) || 0) + 1;
  prepSeq.set(context, seq);
  return locked(context, () => prepInner(context, w, log, false, seq));
}

/** Слушатель запросов вывода — ДО клика: событие запроса в CDP приходит с задержкой. */
function watchRequests(page) {
  const st = { fired: [], responses: [], other: [], t0: Date.now() };
  const onReq = (req) => {
    try {
      if (req.method() !== 'POST' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      const u = req.url();
      if (WD_REQ_RE.test(u)) st.fired.push(req);
      else if (/withdraw/i.test(u) && !WD_SAFE_RE.test(u)) st.other.push(new URL(u).pathname);
    } catch { /* диагностика */ }
  };
  const onResp = async (resp) => {
    try {
      const req = resp.request();
      if (!st.fired.includes(req)) return;
      let j = null; try { j = JSON.parse(await resp.text()); } catch { /* не JSON */ }
      const u = new URL(resp.url());
      st.responses.push({ path: u.pathname, status: resp.status(), json: j });
    } catch { /* диагностика */ }
  };
  page.on('request', onReq);
  page.on('response', onResp);
  st.stop = () => { page.off('request', onReq); page.off('response', onResp); };
  return st;
}

function verdict(resp) {
  const j = resp && resp.json;
  if (!resp || resp.status < 200 || resp.status >= 300 || !j || typeof j !== 'object') return { ok: null };
  const okCode = j.code === 0 || j.code === 200 || j.code === '0' || j.code === '200' || j.success === true;
  const d = j.data;
  const id = d && typeof d === 'object' ? (d.id ?? d.withdrawId ?? d.withdrawalId ?? null) : (typeof d === 'string' || typeof d === 'number' ? d : null);
  // needVerify — MEXC ждёт ещё одну проверку: вывода пока нет, итог — по следующему ответу/окну.
  if (okCode && d && typeof d === 'object' && d.needVerify === true) return { ok: null, pending: true };
  if (okCode) return { ok: true, id: id == null ? null : String(id) };
  return { ok: false, msg: String(j.msg || j.message || `code=${j.code}`).slice(0, 200) };
}

/**
 * Отказ после нажатия «Отправить». Запрос вывода (submit_withdraw) не уходил — ничего не
 * отправлено; уходил — «не знаю»: считается отправленным, не повторяется (#82).
 */
function notSentOrUnknown(req, why) {
  return req.fired.length === 0 && req.other.length === 0
    ? { ok: false, error: `${why} — ничего не отправлено.` }
    : { ok: false, ambiguous: true, error: `${why}. Запрос вывода уже ушёл — исход неизвестен, проверьте историю выводов MEXC; повтора не будет.` };
}

/**
 * Окна после «Отправить» (захват 22.10): подтверждение «Подтверждение информации о выводе» →
 * сверка окна и заявки, которую страница готовит (save_withdraw: сумма/адрес/сеть) → «Отправить»;
 * коды почты/аутентификатора или ключ доступа — окно вперёд, ждём человека; итог — ответ
 * submit_withdraw (withdrawId) или окно «Запрос на вывод средств отправлен».
 */
async function afterSubmit(page, req, w, sent, log, onHuman) {
  const confirmRe = new RegExp(RX.confirm, 'i');
  const closeRe = new RegExp(`${RX.cancel}|^(×|✕|закрыть|close)$`, 'i');
  const successRe = new RegExp(RX.success, 'i');
  const seen = new Set();
  const t0 = Date.now();
  let humanUntil = 0; let lastHuman = 0; let quietSince = t0; let confirms = 0; let success = false;
  let waitClose = false; // после «Подтвердить» следующее подтверждение — только когда прошлое окно исчезло
  let strange = ''; // незнакомое окно после нашего подтверждения: итог тогда «не знаю», а не «ничего не отправлено»
  for (;;) {
    await sleep(150);
    if (req.responses.some((r) => verdict(r).ok === true)) { success = true; break; }
    const overlay = await page.evaluate(HUMAN_OVERLAY).catch(() => false);
    const ds = await page.evaluate(DIALOGS, { rx: RX }).catch(() => []);
    // Окно кодов MEXC открывается ВТОРЫМ, поверх подтверждения — человек нужен, если хоть одно окно просит.
    const hd = ds.find((x) => x.inputs > 0 || x.captcha || x.human);
    const d = hd || ds[0];
    const human = overlay || !!hd;
    if (d && !hd && successRe.test(d.text) && !d.buttons.some((b) => /подтверд|confirm|вывести|отправить|withdraw/i.test(b.label))) { success = true; break; }
    if (human) {
      lastHuman = Date.now();
      if (!humanUntil) {
        humanUntil = Date.now() + HUMAN_MS;
        await page.bringToFront().catch(() => {});
        const what = maskAddrs(hd ? hd.text.slice(0, 120) : 'проверка (капча) на странице');
        log(`ждём вас: MEXC просит подтверждение — «${what}». Окно ArbiBrowser на переднем плане, жду до ${Math.round(HUMAN_MS / 60_000)} мин`);
        onHuman(`MEXC просит подтверждение вывода ${sent} ${w.coin}: «${what}» — введите в окне ArbiBrowser.`);
      }
      quietSince = Date.now();
    } else if (!d) {
      waitClose = false;
    } else {
      quietSince = Date.now();
      // Ключ окна без цифр: обратный отсчёт или пересчёт «к получению» не делают окно «новым».
      const key = d.text.replace(/\d+/g, '#').slice(0, 300);
      if (!seen.has(key)) {
        seen.add(key);
        const close = async () => { const c = d.buttons.find((b) => closeRe.test(b.label.trim())); if (c) await page.click(`[data-arbi-wd="${c.key}"]`, { timeout: 2000 }).catch(() => {}); };
        const why = confirmProblem(d.text, w, sent);
        const btns = d.buttons.filter((b) => !b.disabled && confirmRe.test(b.label.trim()));
        const first = confirms === 0 && !req.fired.length && !req.other.length;
        if (first && why) { await close(); return notSentOrUnknown(req, `Окно подтверждения MEXC показало не то (${why}) — окно закрыто`); }
        if (first && btns.length !== 1) { await close(); return notSentOrUnknown(req, `В окне подтверждения не одна кнопка подтверждения (${d.buttons.map((b) => b.label).join(' | ')}) — не нажимаю, окно закрыто`); }
        if (first || (!why && btns.length === 1 && !waitClose && confirms < MAX_CONFIRMS && !req.fired.length && !req.other.length)) {
          // Перед КАЖДЫМ подтверждением — заявка, которую приготовила страница (адрес в окне MEXC — картинка,
          // в тексте лишь метка книги): ровно наша. Нет такого запроса — не подтверждаем.
          const sv = await siteReq(page, 'save', req.t0, 3000);
          const bad = sv ? siteProblem(sv.body, w, sent) : 'страница не подготовила заявку (save_withdraw не замечен)';
          if (bad) { await close(); return notSentOrUnknown(req, `MEXC готовит не тот вывод: ${bad} — окно подтверждения закрыто`); }
          req.saved = sv.body;
          for (const cb of d.checkboxes) if (!cb.checked) await page.click(`[data-arbi-wd="${cb.key}"]`, { timeout: 2000 }).catch(() => {});
          log(`окно подтверждения сверено, заявка сайта: ${sv.body.amount} ${sv.body.currency} → ${short(sv.body.address)} (${sv.body.chain}) — «${btns[0].label}»`);
          confirms += 1;
          waitClose = true;
          await page.click(`[data-arbi-wd="${btns[0].key}"]`, { timeout: 3000 });
        } else {
          // После нашего подтверждения окна не закрываем и итог не решаем по ним: только наблюдаем.
          if (why) strange = maskAddrs(d.text.slice(0, 100));
          log(`окно после подтверждения — только наблюдаю: «${maskAddrs(d.text.slice(0, 100))}»`);
        }
      }
    }
    const settled = req.fired.length > 0 && req.responses.length >= req.fired.length;
    if (settled && !human && !d) break;
    if (Date.now() > (humanUntil || t0 + 20_000)) break;
    // Окон нет 8 с, запроса вывода нет (окно кодов закрыли/не появилось) — ждать нечего.
    if (!human && !d && !req.fired.length && Date.now() - quietSince > 8000) break;
    // Окно кодов закрыли, а наше подтверждение осталось висеть (так у MEXC, захват 22.10) — 10 с без человека и без запроса.
    if (humanUntil && !human && !req.fired.length && !req.other.length && Date.now() - lastHuman > 10_000) break;
  }
  for (let i = 0; i < 100 && req.responses.length < req.fired.length; i++) await sleep(150);
  const o = outcomeOf(req);
  if (success || o.ok) return { ok: true, withdrawId: o.withdrawId || null };
  if (o.rejected != null) return { ok: false, error: `MEXC отклонил вывод ${sent} ${w.coin}: ${o.rejected}` };
  if (o.none && !strange) {
    const errs = (await page.evaluate(AROUND, { rx: RX }).catch(() => ({ errors: [] }))).errors;
    return { ok: false, error: `После «Отправить» запрос вывода не ушёл${errs.length ? `: ${errs.join('; ')}` : (humanUntil ? ' — подтверждение (код/ключ доступа) не введено' : '')} — ничего не отправлено.` };
  }
  const why = strange ? `после подтверждения незнакомое окно «${strange}»` : req.other.length ? `страница отправила незнакомый запрос (${req.other.slice(0, 2).join(', ')})` : `запросов вывода ${req.fired.length}, ответов ${req.responses.length}`;
  return { ok: false, ambiguous: true, error: `Исход вывода ${sent} ${w.coin} неизвестен (${why}) — считаем отправленным, проверьте историю выводов MEXC. Повтора не будет.` };
}

/**
 * Итог по запросам вывода: успех — если успешен хоть один ответ (повтор страницей может прийти
 * отказом «уже обработано»); отказ — только если отказали все; none — запроса вывода не было.
 */
function outcomeOf(req) {
  const vs = req.responses.map(verdict);
  const ok = vs.find((v) => v.ok === true);
  if (ok) return { ok: true, withdrawId: ok.id };
  if (!req.fired.length && !req.other.length) return { none: true };
  if (!req.other.length && req.responses.length >= req.fired.length && vs.length && vs.every((v) => v.ok === false)) return { rejected: vs[vs.length - 1].msg };
  return { unknown: true };
}

/** Закрыть окна прошлой попытки ТОЛЬКО «Отменой»/крестиком — никогда «Подтвердить». */
async function dropDialogs(page) {
  const ds = await page.evaluate(DIALOGS, { rx: RX }).catch(() => []);
  for (const d of ds) {
    const b = d.buttons.find((x) => new RegExp(RX.cancel, 'i').test(x.label.trim()) || /^(×|✕|закрыть|close)$/i.test(x.label.trim()));
    if (b) await page.click(`[data-arbi-wd="${b.key}"]`, { timeout: 1500 }).catch(() => {});
  }
}

/**
 * Вывод (намерение withdraw). Отказ ДО нажатия «Вывести» — { ok:false } (ничего не отправлено);
 * после нажатия без ясного исхода — { ok:false, ambiguous:true } (считается отправленным).
 */
async function withdraw(context, w, opts = {}) {
  const log = opts.log || (() => {});
  const arrived = Number(opts.receivedAt) || Date.now(); // момент получения намерения (очередь исполнителя тоже считается)
  pendingWd.set(context, (pendingWd.get(context) || 0) + 1);
  try {
    return await locked(context, () => {
      // Ждали очереди дольше 40 с (прошлый вывод ждал человека): терминал уже не ждёт — не исполняем.
      const waited = Date.now() - arrived;
      if (waited > QUEUE_MAX_MS) return { ok: false, error: `Вывод MEXC ждал очереди ArbiBrowser ${Math.round(waited / 1000)} с (идёт прошлый вывод) — не исполняю, ничего не отправлено. Повторите.` };
      // Пришёл, пока шёл прошлый вывод (ждал кодов дольше, чем терминал ждёт ответа, — и повтор?): второй вывод тех же денег не делаем.
      if (arrived < (wdEnd.get(context) || 0)) return { ok: false, error: 'Вывод MEXC пришёл, пока шёл предыдущий вывод, — не исполняю, ничего не отправлено. Нужен ещё один — нажмите «Вывести» снова.' };
      return withdrawInner(context, w, log, opts.onHuman || (() => {})).finally(() => wdEnd.set(context, Date.now()));
    });
  } finally {
    pendingWd.set(context, Math.max(0, (pendingWd.get(context) || 1) - 1));
  }
}

async function withdrawInner(context, w, log, onHuman) {
  const t0 = Date.now();
  const coin = String(w.coin).toUpperCase();
  if (!coin || !w.network || !w.address || !(Number(normAmount(w.amount)) > 0)) return { ok: false, error: 'в намерении вывода нет монеты/сети/адреса/суммы — ничего не отправлено' };
  const r = await fillForm(context, { ...w, coin }, log, { bg: false });
  if (r.error || r.skipped) {
    if (r.page) await dumpStruct(r.page, log, r.error || r.skipped);
    return { ok: false, error: `Вывод MEXC не отправлен: ${r.error || r.skipped}` };
  }
  let page = r.page;
  keep(context, log);
  page.__wdLastPrep = { coin, network: w.network, address: w.address, amount: w.amount, max: !!w.max };
  // Хватает ли на странице: меньше — одна свежая загрузка (баланс мог не успеть), снова меньше — отказ.
  const need = Number(normAmount(w.amount));
  let available = await availWd(page, coin).catch(() => null);
  const short1 = (v) => v != null && v + 1e-12 < (w.max ? need - maxTol(need, w.fee) : need);
  if ((available == null || short1(available)) && !r.reloaded) {
    const again = await fillForm(context, { ...w, coin }, log, { bg: false, force: true });
    if (again.error) return { ok: false, error: `Вывод MEXC не отправлен: ${again.error}` };
    page = again.page;
    available = await availWd(page, coin).catch(() => null);
  }
  if (available == null) { await dumpStruct(page, log, 'не прочитан остаток'); return { ok: false, error: `Вывод MEXC не отправлен: на странице не прочитан остаток ${coin} («Доступно …») — монету и баланс не сверить` }; }
  if (short1(available)) return { ok: false, error: `Вывод MEXC не отправлен: на странице доступно ${available} ${coin}, а выводится ${w.amount}` };
  const ta = Date.now();
  const amt = await putAmount(page, { ...w, coin }, w.fee);
  if (amt.error) return { ok: false, error: amt.error };
  const sent = amt.value;
  const around = await page.evaluate(AROUND, { rx: RX });
  if (around.errors.length) return { ok: false, error: `MEXC не принимает вывод ${sent} ${coin}: ${around.errors.join('; ')} — ничего не отправлено` };
  log(`шаг «сумма» за ${Date.now() - ta} мс: ${sent} ${coin}${w.max ? ' (Макс страницы)' : ''}, доступно ${available ?? '?'}, комиссия ${amt.fee ?? '?'}`);
  if (!around.submit) { await dumpStruct(page, log, 'нет кнопки «Вывести»'); return { ok: false, error: 'на странице не найдена кнопка «Вывести» — ничего не отправлено' }; }
  if (around.submitDisabled) return { ok: false, error: `кнопка «Вывести» неактивна (форма не приняла данные) — ничего не отправлено` };
  if (around.covered) {
    const pop = await clearPopups(page);
    if (pop) return { ok: false, error: `Вывод MEXC не отправлен: ${pop}` };
  }
  // Перед кликом — поле суммы ещё раз, без фокуса: страница могла переформатировать число.
  await page.evaluate(() => { const a = document.activeElement; if (a && typeof a.blur === 'function') a.blur(); }).catch(() => {});
  await sleep(120);
  const final = await page.locator(amt.sel).first().inputValue().catch(() => '');
  if (!sameAmount(final, sent)) return { ok: false, error: `после ввода поле суммы стало «${final}» вместо ${sent} — ничего не отправлено` };
  const around2 = await page.evaluate(AROUND, { rx: RX });
  if (around2.errors.length) return { ok: false, error: `MEXC не принимает вывод ${sent} ${coin}: ${around2.errors.join('; ')} — ничего не отправлено` };
  if (!around2.submit || around2.submitDisabled) return { ok: false, error: 'кнопка «Вывести» неактивна после ввода суммы — ничего не отправлено' };
  if (await page.evaluate(HUMAN_OVERLAY).catch(() => false)) {
    await page.bringToFront().catch(() => {});
    return { ok: false, error: 'на странице MEXC проверка (капча) — пройдите её в окне ArbiBrowser и повторите вывод; ничего не отправлено' };
  }
  if (w.dryRun) {
    // Оператор 22.10: «заполняем быстро, автоматически, а дальше делаю всё я сам» — форма перед глазами.
    await page.bringToFront().catch(() => {});
    page.__wdHumanUntil = Date.now() + HUMAN_MS; // форма у человека: подготовка и обновление вкладки её не трогают
    log(`СУХОЙ ПРОГОН: форма заполнена и сверена (${sent} ${coin}, ${w.network}, ${short(w.address)}) за ${Date.now() - t0} мс — «Отправить» не нажата, окно MEXC на переднем плане`);
    return { ok: true, dryRun: true, sentAmount: sent, available, fee: amt.fee || null };
  }

  // ── Отправка: ровно одно нажатие «Отправить»; дальше — только сверенные подтверждения ──
  const req = watchRequests(page);
  try {
    await page.click('[data-arbi-wd="submit"]', { timeout: 3000 });
  } catch (e) {
    req.stop();
    return { ok: false, error: `кнопка «Отправить» не нажалась (${String(e && e.message || e).slice(0, 80)}) — ничего не отправлено` };
  }
  log(`нажата «Отправить» (${sent} ${coin} → ${short(w.address)}, ${w.network})`);
  let res;
  try {
    res = await afterSubmit(page, req, { ...w, coin }, sent, log, onHuman);
  } catch (e) {
    res = { ok: false, ambiguous: true, error: `После нажатия «Отправить» сбой (${String(e && e.message || e).slice(0, 120)}) — исход неизвестен, считаем отправленным; проверьте историю выводов MEXC. Повтора не будет.` };
  }
  if (!res.ok) {
    // Окна (код/капча) не оставляем — введённые потом, они отправили бы вывод тайком.
    await dropDialogs(page);
    page.__wdPrep = null;
    await quietForNav(context, false);
    await page.reload({ waitUntil: 'domcontentloaded', timeout: 30_000 }).catch(() => {});
    page.__wdLoadedAt = Date.now();
    resetSite(page);
    // Запрос вывода, ушедший, пока решали и закрывали окна (человек успел подтвердить), меняет итог (#82).
    if (!res.ambiguous) {
      const o = outcomeOf(req);
      if (o.ok) res = { ok: true, withdrawId: o.withdrawId };
      else if (!o.none && o.rejected == null) res = { ok: false, ambiguous: true, error: `${res.error.replace(/ — ничего не отправлено\.?$/, '')}. Но запрос вывода всё же ушёл — исход неизвестен, проверьте историю выводов MEXC; повтора не будет.` };
    }
  }
  req.stop();
  log(`отправка: запросов вывода ${req.fired.length}, ответов ${req.responses.length} (${req.responses.map((x) => `${x.path}→${x.status}`).join(', ') || '—'}), ${Date.now() - req.t0} мс`);
  if (res.ok) {
    page.__wdPrep = null;
    page.__wdLoadedAt = 0; // окно «Запрос отправлен» висит — следующая подготовка начнёт с чистой страницы
    resetSite(page);
    const sv = req.saved || {};
    log(`ВЫВОД ОТПРАВЛЕН: ${sv.amount || sent} ${coin} → ${short(sv.address || w.address)} (${sv.chain || w.network})${res.withdrawId ? ` № ${res.withdrawId}` : ''}; всего ${Date.now() - t0} мс`);
    return { ok: true, withdrawId: res.withdrawId || null, sentAmount: sent, fee: amt.fee || null, network: w.network, ms: Date.now() - t0 };
  }
  log(`${res.ambiguous ? 'исход вывода неизвестен' : 'вывод не состоялся'}: ${res.error}`);
  if (!res.ambiguous) await dumpStruct(page, log, res.error);
  return { ...res, sentAmount: sent };
}

module.exports = {
  prep, withdraw, findTab, TAB,
  // для тестов
  normAmount, numVariants, sameAmount, addrEq, addrIn, maskAddrs, netMatches, netValueOk, maxTol, pickNetwork, pickCoin, pickAddress, pickBookEntry, siteProblem, outcomeOf, maxWithin, confirmProblem, verdict, RX, WD_REQ_RE,
};

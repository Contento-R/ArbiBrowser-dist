'use strict';

/**
 * gmgn-page.js — ликвидность токена с gmgn.ai через живой Chromium (оператор 2026-09-17).
 *
 * Зачем. В сканере и PandaX «ликв» — это ликвидность ТОГО пула, через который
 * считается сделка; оператор хочет видеть рядом число GMGN (сумма по токену),
 * чтобы расхождение «мы взяли не тот пул» было видно глазами. Сервером это не
 * взять: в HTML страницы числа нет (грузится запросом уже в браузере), а API
 * gmgn с серверного IP отвечает страницей Cloudflare-челленджа. Поэтому читаем
 * в браузере профиля — там страница открывается как у человека.
 *
 * Дёшево по трафику: ПЕРВЫЙ токен открывается страницей, и по её же запросам
 * запоминается адрес ручки с числом; дальше остальные токены берутся этой
 * ручкой ИЗ КОНТЕКСТА БРАУЗЕРА (куки и отпечаток те же) — без рендера.
 *
 * Значение — справочное: оно живёт, только пока запущен браузер-поставщик.
 * В денежный расчёт не идёт (там наша он-чейн ликвидность пула).
 */

const { newBackgroundPage, markOwned } = require('./pair-tabs');

const GMGN_ORIGIN = process.env.ARBI_GMGN_ORIGIN || 'https://gmgn.ai';
/** Пауза между токенами: чужой сайт, темп заведомо ниже человеческого просмотра. */
const GAP_MS = Math.max(200, parseInt(process.env.ARBI_GMGN_GAP_MS || '800', 10) || 800);
/** Сеть у нас → слаг в адресе gmgn. */
const CHAIN_SLUG = {
  eth: 'eth', ethereum: 'eth', bsc: 'bsc', bnb: 'bsc', base: 'base',
  solana: 'sol', sol: 'sol', tron: 'tron', blast: 'blast', arbitrum: 'arb', polygon: 'polygon',
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** «$1.1M» / «554.4K» / «$1,234» → число. Мусор → null (догадок не выдумываем). */
function parseUsd(text) {
  const m = String(text || '').replace(/\s|,/g, '').match(/\$?(\d+(?:\.\d+)?)([KMB])?/i);
  if (!m) return null;
  const mult = { K: 1e3, M: 1e6, B: 1e9 }[(m[2] || '').toUpperCase()] || 1;
  const v = parseFloat(m[1]) * mult;
  return Number.isFinite(v) ? v : null;
}

/** Адрес ручки, из ответа которой страница взяла ликвидность (в памяти процесса). */
let apiTemplate = null;

/** Число «Ликвидность» из шапки страницы токена (по подписи, не по классам). */
async function readLiquidity(page) {
  return page.evaluate(() => {
    const RE = /Ликвидн|Liquidity/i;
    // Подпись и значение лежат в соседних узлах одного InfoItem; ищем по подписи.
    for (const el of document.querySelectorAll('[class*="info-item-title"], [class*="InfoItem"], div, span')) {
      const t = (el.textContent || '').trim();
      if (!RE.test(t) || t.length > 40) continue;
      let box = el;
      for (let i = 0; i < 4 && box; i++) {
        const val = box.querySelector('[class*="info-item-value"]');
        if (val && val.textContent && /\d/.test(val.textContent)) return val.textContent.trim();
        box = box.parentElement;
      }
    }
    return null;
  }).catch(() => null);
}

/** Ликвидность из тела ответа ручки gmgn (ключ ищем по имени, а не по позиции). */
function liquidityFromJson(obj, depth = 0) {
  if (!obj || depth > 6) return null;
  if (Array.isArray(obj)) {
    for (const x of obj.slice(0, 20)) { const v = liquidityFromJson(x, depth + 1); if (v != null) return v; }
    return null;
  }
  if (typeof obj !== 'object') return null;
  for (const [k, v] of Object.entries(obj)) {
    if (/^(liquidity|liquidity_usd|usd_liquidity)$/i.test(k)) {
      const n = typeof v === 'number' ? v : parseUsd(v);
      if (Number.isFinite(n)) return n;
    }
  }
  for (const v of Object.values(obj)) { const r = liquidityFromJson(v, depth + 1); if (r != null) return r; }
  return null;
}

async function getPage(context, log) {
  let page = context.pages().find((p) => { try { return p.__arbiGmgnBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context, { tab: true }));
    page.__arbiGmgnBg = true;
    log('Открыл фоновую вкладку gmgn (активная вкладка оператора не трогается)');
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

/**
 * @param {import('playwright').BrowserContext} context
 * @param {{tokens: {chain:string,address:string}[], log?: (m:string)=>void}} opts
 * @returns {Promise<{ok:true, rows: {chain,address,liquidityUsd,source,error}[]}>}
 */
async function readGmgnLiquidity(context, opts = {}) {
  const log = opts.log || (() => {});
  const tokens = (Array.isArray(opts.tokens) ? opts.tokens : []).slice(0, 25);
  const page = await getPage(context, log);
  const rows = [];
  // Адрес ручки с числом: ловим по ответам страницы, чтобы следующие токены брать
  // ею же, без рендера (куки и отпечаток браузера те же — это тот же клиент).
  const onResponse = async (resp) => {
    try {
      const url = resp.url();
      if (!/gmgn\.ai\//i.test(url) || !/\/api\/|\/defi\//i.test(url)) return;
      const ct = (resp.headers()['content-type'] || '');
      if (!/json/i.test(ct)) return;
      const j = await resp.json().catch(() => null);
      if (j && liquidityFromJson(j) != null) apiTemplate = url;
    } catch { /* диагностика */ }
  };
  page.on('response', onResponse);
  try {
    for (const t of tokens) {
      const chain = CHAIN_SLUG[String(t.chain || '').toLowerCase()] || String(t.chain || '').toLowerCase();
      const address = String(t.address || '').trim();
      const row = { chain: t.chain, address, liquidityUsd: null, source: null, error: null };
      if (!chain || !address) { row.error = 'нужны сеть и адрес контракта'; rows.push(row); continue; }
      try {
        // 1) Быстрый путь: ручка, которую страница уже показала (адрес подставляем).
        if (apiTemplate && apiTemplate.includes('/')) {
          const url = apiTemplate.replace(/0x[a-fA-F0-9]{40}|[1-9A-HJ-NP-Za-km-z]{32,44}/, address);
          if (url !== apiTemplate) {
            const r = await page.request.get(url, { timeout: 15000 }).catch(() => null);
            const j = r && r.ok() ? await r.json().catch(() => null) : null;
            const v = j ? liquidityFromJson(j) : null;
            if (v != null) { row.liquidityUsd = v; row.source = 'api'; rows.push(row); log(`${address.slice(0, 8)}… (${chain}): ликв ${v}`); await sleep(GAP_MS); continue; }
          }
        }
        // 2) Иначе открываем страницу токена и читаем число по подписи.
        await page.goto(`${GMGN_ORIGIN}/${chain}/token/${address}`, { waitUntil: 'domcontentloaded', timeout: 45000 });
        let txt = null;
        for (let i = 0; i < 20 && !txt; i++) { txt = await readLiquidity(page); if (!txt) await sleep(500); }
        row.liquidityUsd = parseUsd(txt);
        row.source = row.liquidityUsd == null ? null : 'page';
        if (row.liquidityUsd == null) row.error = 'число «Ликвидность» на странице не найдено';
        log(`${address.slice(0, 8)}… (${chain}): ${row.liquidityUsd != null ? `ликв ${row.liquidityUsd} (со страницы)` : row.error}`);
      } catch (e) {
        row.error = String((e && e.message) || e).split('\n')[0].slice(0, 160);
        log(`${address.slice(0, 8)}… (${chain}): ${row.error}`);
      }
      rows.push(row);
      await sleep(GAP_MS);
    }
  } finally {
    try { page.off('response', onResponse); } catch { /* игнор */ }
  }
  return { ok: true, rows, api: apiTemplate ? 'ручка найдена' : 'только страница' };
}

module.exports = { readGmgnLiquidity, _parseUsd: parseUsd, _liquidityFromJson: liquidityFromJson };

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const m = require('./mexc-withdraw-page');

test('sameAmount: строго, как десятичные строки; обрезанный хвост — НЕ равно', () => {
  assert.ok(m.sameAmount('7200.65', '7200.650'));
  assert.ok(m.sameAmount('0012.5', '12.50'));
  assert.ok(m.sameAmount('1 234,5', '1234.5'));
  assert.ok(m.sameAmount('1,234.5', '1234.5'));
  assert.ok(!m.sameAmount('386204.', '386204.76'), 'биржа обрезала хвост — для вывода это отказ');
  assert.ok(!m.sameAmount('', '1'));
  assert.ok(!m.sameAmount('abc', 'abc'));
});

test('addrEq: EVM без учёта регистра, Solana — побайтно', () => {
  const evm = '0xAbCdEf0123456789abcdef0123456789ABCDEF01';
  assert.ok(m.addrEq(evm, evm.toLowerCase()));
  assert.ok(!m.addrEq(evm, evm.slice(0, -1) + '2'));
  const sol = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
  assert.ok(m.addrEq(sol, sol));
  assert.ok(!m.addrEq(sol, sol.toLowerCase()));
});

test('pickNetwork: полное имя сильнее кода; неоднозначность — отказ', () => {
  const opts = ['BNB Smart Chain(BEP20) ≈1 мин', 'Ethereum(ERC20)', 'Tron(TRC20)'];
  assert.equal(m.pickNetwork(opts, 'BNB Smart Chain(BEP20)'), 0);
  assert.equal(m.pickNetwork(['BEP20', 'ERC20'], 'BNB Smart Chain(BEP20)'), 0, 'страница показывает только код');
  assert.equal(m.pickNetwork(['BEP20 (BSC)', 'BEP20 старая'], 'BNB Smart Chain(BEP20)'), -1);
  assert.equal(m.pickNetwork(opts, 'Solana(SOL)'), -1);
});

test('pickCoin: тикер отдельным словом, не подстрокой (DEP ≠ COINDEPO, AI ≠ AIX)', () => {
  assert.equal(m.pickCoin(['COINDEPO CoinDepo', 'DEP DEAPcoin'], 'DEP'), 1);
  assert.equal(m.pickCoin(['AIX', 'AI Sleepless AI'], 'AI'), 1);
  assert.equal(m.pickCoin(['USDT Tether', 'USDC USD Coin'], 'USDT'), 0);
  assert.equal(m.pickCoin(['PEPE', 'PEPE PEPE 2.0'], 'PEPE'), -1);
});

test('pickAddress: полный адрес — сильное; начало+конец — только если один', () => {
  const a = '0x1234567890abcdef1234567890abcdef12345678';
  assert.deepEqual(m.pickAddress(['Мой DEX 0x1234567890ABCDEF1234567890ABCDEF12345678', 'Другой 0xffff'], a), { index: 0, strong: true });
  assert.deepEqual(m.pickAddress(['DEX 0x1234…5678', 'Gate 0x9999…0000'], a), { index: 0, strong: false });
  assert.equal(m.pickAddress(['A 0x1234…5678', 'B 0x1234…5678'], a).index, -1);
  assert.equal(m.pickAddress(['Gate 0x9999…0000'], a).index, -1);
});

test('maxWithin: «Макс» страницы — не больше суммы терминала +2 %, не меньше суммы − комиссия', () => {
  assert.ok(m.maxWithin('100', '100', '1'));
  assert.ok(m.maxWithin('99', '100', '1'), 'комиссия сверху (класс WOJAK)');
  assert.ok(m.maxWithin('101.5', '100', '1'), 'докупка в последнюю секунду');
  assert.ok(!m.maxWithin('103', '100', '1'));
  assert.ok(!m.maxWithin('90', '100', '1'));
  assert.ok(!m.maxWithin('', '100', '1'));
});

test('confirmProblem: монета, сумма, сеть, адрес из окна MEXC', () => {
  const w = { coin: 'USDT', network: 'BNB Smart Chain(BEP20)', address: '0x1234567890abcdef1234567890abcdef12345678' };
  const good = 'Подтверждение вывода Монета USDT Сеть BNB Smart Chain(BEP20) Адрес 0x1234...5678 Сумма 1,234.5 USDT Комиссия 0.01';
  assert.equal(m.confirmProblem(good, w, '1234.5'), null);
  assert.match(m.confirmProblem(good, w, '1234.6'), /суммы/);
  assert.match(m.confirmProblem(good.replace('USDT', 'USDC').replace('USDT', 'USDC'), w, '1234.5'), /монеты/);
  assert.match(m.confirmProblem(good.replace('BNB Smart Chain(BEP20)', 'Ethereum(ERC20)'), w, '1234.5'), /сети/);
  assert.match(m.confirmProblem(good.replace('0x1234...5678', '0x9999...0000'), w, '1234.5'), /адрес/);
});

test('verdict: ответ сайта на вывод', () => {
  assert.deepEqual(m.verdict({ status: 200, json: { code: 0, data: { id: 'abc' } } }), { ok: true, id: 'abc' });
  assert.deepEqual(m.verdict({ status: 200, json: { code: 200, data: 12345 } }), { ok: true, id: '12345' });
  assert.equal(m.verdict({ status: 200, json: { code: 30005, msg: 'insufficient' } }).ok, false);
  assert.equal(m.verdict({ status: 502, json: null }).ok, null, 'нет ясного ответа — «не знаю», не «не отправлено»');
  assert.equal(m.verdict(undefined).ok, null);
});

test('maxWithin: допуск снизу = комиссия, а не 0,1 % суммы (ревью 22.10)', () => {
  assert.ok(!m.maxWithin('999', '1000', '0.1'), 'комиссия 0.1 — 999 при 1000 вне допуска');
  assert.ok(m.maxWithin('999.9', '1000', '0.1'));
  assert.ok(m.maxWithin('999.2', '1000', ''), 'комиссия неизвестна — 0,1 %');
});

test('netValueOk: в поле ровно одна сеть; список/плитки всех сетей — не выбор', () => {
  const want = 'BNB Smart Chain(BEP20)';
  assert.ok(m.netValueOk('BNB Smart Chain(BEP20)', want));
  assert.ok(m.netValueOk('BEP20', want));
  assert.ok(!m.netValueOk('BNB Smart Chain(BEP20) Ethereum(ERC20) Tron(TRC20)', want), 'плитки всех сетей');
  assert.ok(!m.netValueOk('Ethereum(ERC20)', want));
  assert.ok(!m.netValueOk('Выберите сеть', want));
  assert.ok(m.netValueOk('Arbitrum One(ARB)', 'Arbitrum One(ARB)'));
});

// ── Настоящая страница вывода MEXC (захват ручного вывода оператора 22.10; адреса — выдуманные) ──
const A = '0x538f1c2b3d4e5f60718293a4b5c6d7e8f90102b7';
const B = '0x9999aaaabbbbccccddddeeeeffff000011112222';
const BSC = 'BNB Smart Chain(BEP20)';

test('pickBookEntry: адресная книга белого списка — адрес в НАШЕЙ сети; «Недавно используемые» — повтор, не неоднозначность', () => {
  const book = [
    { text: A, ctx: `Недавно используемые P Общие В белом списке ${A} BSC BNB Smart Chain(BEP20)` },
    { text: 'DZsiQ4r8aS1vLxT9yBn', ctx: 'P Общие В белом списке DZsiQ4r8aS1vLxT9yBn SOL Solana(SOL)' },
    { text: A, ctx: `P Общие В белом списке ${A} ETH Ethereum(ERC20)` },
    { text: A, ctx: `P Общие В белом списке ${A} BSC BNB Smart Chain(BEP20)` },
  ];
  assert.equal(m.pickBookEntry(book, A, BSC), 0, 'тот же адрес в той же сети дважды — берём первую');
  assert.equal(m.pickBookEntry(book, A, 'Ethereum(ERC20)'), 2, 'тот же адрес — запись ETH, а не BSC');
  assert.equal(m.pickBookEntry(book, A, 'Arbitrum One(ARB)'), -1, 'адрес не сохранён для этой сети');
  assert.equal(m.pickBookEntry(book, B, BSC), -1, 'адреса нет в книге');
  const shortBook = [
    { text: '0x538F…02B7', ctx: 'Недавно используемые P 0x538F…02B7 BSC BNB Smart Chain(BEP20)' },
    { text: '0x538F…02B7', ctx: 'P 0x538F…02B7 BSC BNB Smart Chain(BEP20)' },
  ];
  assert.equal(m.pickBookEntry(shortBook, A, BSC), 0, 'сокращённый адрес: начало+конец, повтор — одна запись');
  assert.equal(m.pickBookEntry([{ text: '0x538F…02B7', ctx: 'P 0x538F…02B7 BSC BNB Smart Chain(BEP20)' }, { text: '0x538F…02B7', ctx: 'X 0x538F…02B7 ETH Ethereum(ERC20)' }], A, 'Ethereum(ERC20)'), 1);
  assert.equal(m.pickBookEntry([{ text: `Мой DEX ${A}`, ctx: `Мой DEX ${A}` }], A, BSC), 0, 'запись без сети — один адрес, сеть сверится полем');
  assert.equal(m.pickBookEntry([{ text: A, ctx: A }, { text: A, ctx: `${A} копия` }], A, BSC), -1, 'два адреса без сети — не угадываем');
});

test('siteProblem: тело запроса страницы к MEXC (withdraw_check_address / save_withdraw) — ровно наше', () => {
  const w = { coin: 'USDT', network: BSC, address: A };
  assert.equal(m.siteProblem({ currency: 'USDT', address: A.toUpperCase().replace('0X', '0x'), chainName: BSC, vcoinId: 'x' }, w), null);
  assert.match(m.siteProblem({ currency: 'USDT', address: A, chainName: 'Ethereum(ERC20)' }, w), /сеть/);
  assert.match(m.siteProblem({ currency: 'USDT', address: B, chainName: BSC }, w), /адрес/);
  assert.match(m.siteProblem({ currency: 'USDC', address: A, chainName: BSC }, w), /монета/);
  const save = { amount: '5', address: A, chain: BSC, currency: 'USDT', isQuickWithdraw: false };
  assert.equal(m.siteProblem(save, w, '5'), null);
  assert.equal(m.siteProblem(save, w, '5.0'), null);
  assert.match(m.siteProblem({ ...save, amount: '50' }, w, '5'), /сумма/);
  assert.equal(m.siteProblem(null, w), 'нет данных');
});

test('MEXC 22.10: запрос вывода — submit_withdraw, ответ — withdrawId; подписи формы и окон', () => {
  assert.ok(m.WD_REQ_RE.test('https://www.mexc.com/api/platform/asset/api/withdraw/submit_withdraw/v3?mh=x'));
  assert.ok(!m.WD_REQ_RE.test('https://www.mexc.com/api/platform/asset/api/withdraw/save_withdraw/v4'), 'save_withdraw только готовит заявку');
  assert.ok(!m.WD_REQ_RE.test('https://www.mexc.com/api/platform/asset/api/withdraw/check_chain/v3'));
  assert.deepEqual(m.verdict({ status: 200, json: { data: { withdrawId: 'f00d', needVerify: false, code: null, state: 'WAIT' }, code: 0, msg: 'success' } }), { ok: true, id: 'f00d' });
  assert.equal(m.verdict({ status: 200, json: { data: { withdrawId: 'f00d', needVerify: true }, code: 0 } }).ok, null, 'needVerify — вывода ещё нет');
  const re = (k) => new RegExp(m.RX[k], 'i');
  assert.ok(re('coin').test('Выберите криптовалюту'));
  assert.ok(re('submit').test('Отправить') && re('confirm').test('Отправить'));
  assert.ok(re('success').test('1 Запрос на вывод средств отправлен 2 Обработка 3 Вывод завершен Криптовалюта USDT'));
  assert.ok(!re('success').test('Подтверждение информации о выводе Получено 4,99 USDT Сумма 5 Отправить'));
  assert.ok(re('human').test('Код эл. почты Код аутентификатора Создать и использовать ключ доступа'));
  assert.ok(!re('human').test('Подтверждение информации о выводе Получено ‎4,99 USDT(Комиссия: ‎0,01 USDT) Сумма 5 Адрес P Сеть BSC(BNB Smart Chain(BEP20)) Обязательно проверьте точность адреса вывода средств и сети перевода, чтобы предотвратить потерю ваших активов Отправить'));
});

test('confirmProblem: окно подтверждения MEXC — адрес картинкой (в тексте метка «P»), сумма/сеть/монета текстом', () => {
  const w = { coin: 'USDT', network: BSC, address: A };
  const t = 'Подтверждение информации о выводе Получено ‎4,99 USDT(Комиссия: ‎0,01 USDT) Сумма 5 Адрес P Сеть BSC(BNB Smart Chain(BEP20)) Обязательно проверьте точность адреса вывода средств и сети перевода, чтобы предотвратить потерю ваших активов Отправить';
  assert.equal(m.confirmProblem(t, w, '5'), null);
  assert.match(m.confirmProblem(t, w, '6'), /суммы/);
  assert.equal(m.confirmProblem(t.replace('Сумма 5', 'Сумма 1 000'), w, '1000'), null);
});

test('addrIn / maskAddrs', () => {
  assert.ok(m.addrIn(`P ${A.toUpperCase().replace('0X', '0x')}`, A));
  assert.ok(!m.addrIn('P 0x538F…02B7', A));
  assert.equal(m.maskAddrs(`адрес ${A} ок`), 'адрес 0x538f…02b7 ок');
});

test('сети с одним кодом: Arbitrum Nova(ARB) ≠ Arbitrum One(ARB); короткий код рядом с именем — не чужая сеть (ревью 22.10)', () => {
  const one = 'Arbitrum One(ARB)';
  assert.ok(!m.netMatches('ARB Arbitrum Nova(ARB)', one));
  assert.ok(!m.netValueOk('Arbitrum Nova(ARB)', one));
  assert.ok(m.netValueOk('TRX Tron(TRC20)', 'Tron(TRC20)'), 'TRX — короткий код Tron, не чужая сеть');
  assert.ok(m.netValueOk('BEP20', BSC), 'только код — как раньше');
  assert.ok(!m.netValueOk('BNB Smart Chain(BEP20) Ethereum(ERC20)', BSC), 'список сетей');
  assert.equal(m.pickBookEntry([{ text: A, ctx: `P ${A} ARB Arbitrum Nova(ARB)` }, { text: A, ctx: `P ${A} ARB Arbitrum One(ARB)` }], A, one), 1);
  assert.equal(m.pickBookEntry([{ text: A, ctx: `P ${A} TRX Tron(TRC20)` }], A, 'Tron(TRC20)'), 0);
  assert.match(m.siteProblem({ currency: 'USDT', address: A, chainName: 'Arbitrum Nova(ARB)' }, { coin: 'USDT', network: one, address: A }), /сеть/);
});

test('confirmProblem: «20» внутри «BEP20» — не сумма', () => {
  const w = { coin: 'USDT', network: BSC, address: A };
  assert.match(m.confirmProblem('Сумма 200 USDT Сеть BSC(BNB Smart Chain(BEP20))', w, '20'), /суммы/);
  assert.equal(m.confirmProblem('Сумма 20 USDT Сеть BSC(BNB Smart Chain(BEP20))', w, '20'), null);
});

test('outcomeOf: успех — если успешен хоть один ответ; отказ — только если отказали все; незнакомый запрос — «не знаю»', () => {
  const ok = { status: 200, json: { code: 0, data: { withdrawId: 'w1', needVerify: false } } };
  const no = { status: 200, json: { code: 30001, msg: 'already processed' } };
  assert.deepEqual(m.outcomeOf({ fired: [1, 2], responses: [ok, no], other: [] }), { ok: true, withdrawId: 'w1' });
  assert.equal(m.outcomeOf({ fired: [1], responses: [no], other: [] }).rejected, 'already processed');
  assert.equal(m.outcomeOf({ fired: [1], responses: [], other: [] }).unknown, true, 'запрос ушёл без ответа');
  assert.equal(m.outcomeOf({ fired: [], responses: [], other: ['/x/withdraw/quick'] }).unknown, true);
  assert.equal(m.outcomeOf({ fired: [], responses: [], other: [] }).none, true);
});

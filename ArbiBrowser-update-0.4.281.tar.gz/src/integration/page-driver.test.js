'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { driverFor, PROFILES } = require('./page-driver');

const SEL = { numberInput: 'input.n', input: 'input.n', submit: 'button.s', submitBuy: 'button.b', submitSell: 'button.sl' };

// Дубль страницы/поля Playwright: пишем в журнал, что было вызвано и с чем.
function fakePage({ evaluate, $eval } = {}) {
  const calls = [];
  return {
    calls,
    keyboard: {
      press: async (k) => calls.push(['press', k]),
      insertText: async (s) => calls.push(['insert', s]),
      type: async (s) => calls.push(['type', s]),
    },
    evaluate: evaluate || (async () => ({ closed: 0, text: '' })),
    $eval: $eval || (async () => { throw new Error('нет'); }),
  };
}
// `evaluate` отдаёт ЗНАЧЕНИЕ поля (так его читает typeNumber, чтобы отличить принятую
// вставку от чужого значения в поле). stuck=true — поле приняло последнюю вставку;
// stuck=false — осталось пустым; строка/функция — что именно «показывает» поле.
// noFocus=true — элемент не умеет focus/selectText (как было до 0.4.204): быстрый
// путь MEXC тогда обязан откатиться на настоящий клик мышью.
function fakeHandle(calls, { failFirst = false, stuck = true, shows = null, noFocus = false } = {}) {
  let n = 0;
  const lastInsert = () => { const c = [...calls].reverse().find((x) => x[0] === 'insert'); return c ? c[1] : ''; };
  return {
    focus: async () => { if (noFocus) throw new Error('нет focus'); calls.push(['focus']); },
    selectText: async () => { if (noFocus) throw new Error('нет selectText'); calls.push(['select']); },
    click: async (o) => { calls.push(['click', o]); if (failFirst && n++ === 0) throw new Error('перекрыто'); },
    evaluate: async () => {
      if (typeof shows === 'function') return shows(lastInsert());
      if (shows != null) return shows;
      return stuck ? lastInsert() : '';
    },
  };
}

test('профили: три биржи, регэкспы собираются, неизвестная биржа — ошибка', () => {
  assert.deepEqual(Object.keys(PROFILES).sort(), ['bingx', 'mexc', 'xt']);
  for (const p of Object.values(PROFILES)) {
    new RegExp(p.modal.block, 'i'); new RegExp(p.modal.ok, 'i');
    if (p.modal.risk) new RegExp(p.modal.risk, 'i');
    if (p.overlays.hide) new RegExp(p.overlays.hide, 'i');
  }
  assert.throws(() => driverFor('okx', SEL), /неизвестная/);
  assert.throws(() => driverFor('bingx', { submit: 'x' }), /SELECTORS\.numberInput/);
});

test('typeNumber BingX/XT: вставка одним событием, поле приняло → без посимвольного ввода', async () => {
  const page = fakePage();
  const h = fakeHandle(page.calls);
  await driverFor('bingx', SEL).typeNumber(page, h, '0.0123');
  const kinds = page.calls.map((c) => c[0]);
  assert.deepEqual(kinds, ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].timeout, 4000);
  assert.equal(page.calls[0][1].force, false);
});

test('typeNumber: биржа усекла хвост по шагу лота → вставка засчитана, посимвольного ввода нет', async () => {
  const page = fakePage();
  // XT показывает усечённое количество с хвостовой точкой — это ПРИНЯТАЯ вставка.
  const h = fakeHandle(page.calls, { shows: '386204.' });
  await driverFor('xt', SEL).typeNumber(page, h, '386204.76576681');
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert']);
});

test('typeNumber: в поле осталось ЧУЖОЕ значение прошлого ордера → вставка НЕ засчитана', async () => {
  const page = fakePage();
  const h = fakeHandle(page.calls, { shows: '92.37' });
  await driverFor('xt', SEL).typeNumber(page, h, '95.23');
  // Обе вставки (точка, затем запятая) отвергнуты → добиваем посимвольно.
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert', 'click', 'press', 'insert', 'click', 'press', 'type']);
});

test('typeNumber: поле ждёт запятую — точка не принята, вставка с запятой засчитана', async () => {
  const page = fakePage();
  // Поле принимает значение, только если разделитель — запятая.
  const h = fakeHandle(page.calls, { shows: (ins) => (ins.includes(',') ? ins : '') });
  await driverFor('xt', SEL).typeNumber(page, h, '12.5');
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert', 'click', 'press', 'insert']);
  assert.equal(page.calls.filter((c) => c[0] === 'insert').pop()[1], '12,5');
});

test('typeNumber XT direct: поле количества — сразу посимвольно, без вставки', async () => {
  const page = fakePage();
  await driverFor('xt', SEL).typeNumber(page, fakeHandle(page.calls), '12345', { direct: true });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
});

// 0.4.203: MEXC перешёл на вставку (оператор проверил Ctrl+V руками). Посимвольный
// набор остался фолбэком — и внутри typeNumber, и на сессию (MEXC_INSERT_OK).
test('typeNumber MEXC: force-клик 1200мс на откате, значение идёт ВСТАВКОЙ', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { noFocus: true }), '777', { st });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].force, true);
  assert.equal(page.calls[0][1].timeout, 1200);
  assert.equal(st.inserted, 1, 'поле засчитано как вставленное');
  assert.equal(st.typeN, 0, 'посимвольного набора не было');
  assert.equal(st.keysN, 0);
  assert.equal(st.fallback, 0);
});

// 0.4.204: самая дорогая статья заполнения после перехода на вставку — проезд
// курсора к полю (замер 21.09: наведение 77-474 мс). Фокусируемся без мыши.
test('typeNumber MEXC: фокус без мыши — курсор к полю не едет', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls), '777', { st });
  assert.deepEqual(page.calls.map((c) => c[0]), ['focus', 'select', 'press', 'insert']);
  assert.equal(page.calls.filter((c) => c[0] === 'click').length, 0, 'мышью не кликаем');
  assert.equal(st.fastFocus, 1);
  assert.equal(st.inserted, 1);
});

test('typeNumber MEXC: фокус без мыши не удался → обычный клик мышью', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { noFocus: true }), '777', { st });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].force, true, 'откат — прежний force-клик');
  assert.equal(st.fastFocus, undefined);
});

test('typeNumber MEXC: поле не приняло вставку → добиваем посимвольно', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  // Поле остаётся пустым, что бы мы ни вставляли (анти-бот/React не принял).
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { stuck: false }), '77.5', { st });
  assert.equal(page.calls.filter((c) => c[0] === 'type').length, 1, 'фолбэк на клавиатуру сработал');
  assert.equal(st.keysN, 4);
  assert.equal(st.typeN, 1);
});

test('typeNumber MEXC direct: вставка выключена на сессию → сразу посимвольно', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls), '777', { st, direct: true });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
  assert.equal(st.typeN, 1);
  assert.equal(st.keysN, 3);
});

test('typeNumber: сорванный клик → закрыть модалку → повтор с force; st.fallback растёт', async () => {
  let modalCalls = 0;
  const page = fakePage({ evaluate: async () => { modalCalls++; return { closed: 0, text: '' }; } });
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  // noFocus: проверяем именно ветку клика мышью (на MEXC она теперь откат).
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { failFirst: true, noFocus: true }), '5', { st });
  const clicks = page.calls.filter((c) => c[0] === 'click');
  assert.equal(clicks.length, 2);
  assert.equal(clicks[1][1].force, true);
  assert.equal(modalCalls, 1);
  assert.equal(st.fallback, 1);
});

test('dismissBlockingModal: risk-модалка ставит __arbiSawRisk (BingX/XT), MEXC — нет', async () => {
  const risky = async () => ({ closed: 1, text: 'Предупреждение о риске: инновационная зона' });
  for (const [ex, want] of [['bingx', true], ['xt', true], ['mexc', undefined]]) {
    const page = fakePage({ evaluate: risky });
    const r = await driverFor(ex, SEL).dismissBlockingModal(page);
    assert.equal(r.closed, 1);
    assert.equal(page.__arbiSawRisk, want, ex);
  }
  // Баланс — не риск.
  const page = fakePage({ evaluate: async () => ({ closed: 1, text: 'Insufficient balance' }) });
  await driverFor('bingx', SEL).dismissBlockingModal(page);
  assert.equal(page.__arbiSawRisk, undefined);
});

test('dismissOverlays: опрос без крестика → Escape (только BingX); возвращает число', async () => {
  const page = fakePage({ evaluate: async () => ({ closed: 2, surveyLeft: true }) });
  assert.equal(await driverFor('bingx', SEL).dismissOverlays(page), 2);
  assert.deepEqual(page.calls, [['press', 'Escape']]);
  const bad = fakePage({ evaluate: async () => { throw new Error('страница закрыта'); } });
  assert.equal(await driverFor('mexc', SEL).dismissOverlays(bad), 0);
});

test('isSubmitReady: side-режим пробует сторону → общий → true; MEXC — одна evaluate', async () => {
  const asked = [];
  const page = fakePage({ $eval: async (s) => { asked.push(s); throw new Error('нет'); } });
  assert.equal(await driverFor('xt', SEL).isSubmitReady(page, 'sell'), true);
  assert.deepEqual(asked, ['button.sl', 'button.s']);
  const ok = fakePage({ $eval: async (s) => s === 'button.b' });
  assert.equal(await driverFor('bingx', SEL).isSubmitReady(ok, 'buy'), true);
  let sel = null;
  const mexc = fakePage({ evaluate: async (fn, s) => { sel = s; return false; } });
  assert.equal(await driverFor('mexc', SEL).isSubmitReady(mexc, 'sell'), false);
  assert.equal(sel, 'button.s');
});

test('loginWall: «Log In» на месте кнопки ордера или в шапке → wall; Buy → нет', async () => {
  const d = driverFor('mexc', SEL);
  const mk = (ret) => ({ evaluate: async (fn, sel) => ret });
  assert.equal((await d.loginWall(mk({ wall: true, text: 'Log In / Sign Up' }))).wall, true);
  assert.equal((await d.loginWall(mk({ wall: false, text: 'Buy WOJAK' }))).wall, false);
  assert.equal((await d.loginWall({ evaluate: async () => { throw new Error('closed'); } })).wall, false);
  // Вход сделан в другой вкладке: первая проверка — стена, после перезагрузки — форма (07.10 BingX/USEPAID).
  const stale = { reloads: 0, n: 0, evaluate: async () => (stale.n++ === 0 ? { wall: true, text: 'шапка: Войти' } : { wall: false, text: 'Купить USEPAID' }),
    reload: async () => { stale.reloads++; }, waitForSelector: async () => null };
  const logs = [];
  assert.equal((await d.loginWallFresh(stale, (m) => logs.push(m))).wall, false);
  assert.equal(stale.reloads, 1); assert.match(logs[0], /перезагружаю/);
  // Залогинен сразу — перезагрузки нет; стена и после перезагрузки — стена.
  const okp = { reloads: 0, evaluate: async () => ({ wall: false, text: 'Buy' }), reload: async () => { okp.reloads++; } };
  assert.equal((await d.loginWallFresh(okp)).wall, false); assert.equal(okp.reloads, 0);
  const out = { evaluate: async () => ({ wall: true, text: 'шапка: Войти' }), reload: async () => {}, waitForSelector: async () => null };
  assert.equal((await d.loginWallFresh(out)).wall, true);
  const { loginRequiredError } = require('./page-driver');
  assert.match(loginRequiredError('MEXC'), /нет входа в аккаунт MEXC/);
  // Хвост меняется по месту: заявка / прогрев / чтение истории (у прогрева и чтения
  // заявки не было — «Заявка НЕ отправлена» там вводило бы в заблуждение).
  assert.match(loginRequiredError('MEXC'), /Заявка НЕ отправлена\.$/);
  assert.match(loginRequiredError('BingX', 'История ордеров не прочитана.'), /BingX.*История ордеров не прочитана\.$/);
});

test('checkLogin: живая вкладка без стены — вход есть; стена везде — решает свежая вкладка', async () => {
  const { checkLogin } = require('./page-driver');
  const page = (url, extra = {}) => ({ url: () => url, isClosed: () => false, ...extra });
  let fresh = null;
  const freshPage = () => (fresh = page('https://bingx.com/ru/spot/BTC-USDT', {
    goto: async () => {}, waitForLoadState: async () => {}, waitForTimeout: async () => {}, close: async () => { fresh.closed = true; },
  }));
  // Стена по странице: `walls` — множество вкладок со стеной (fresh — по флагу freshWall).
  const opts = (walls, freshWall) => ({
    origin: 'https://bingx.com',
    tradeUrl: 'https://bingx.com/ru/spot/BTC-USDT',
    exchange: 'BingX',
    loginWall: async (p) => { seen.push(p); const w = p === fresh ? freshWall : walls.has(p); return w ? { wall: true, text: 'шапка: Log In' } : { wall: false, text: 'Buy BTC' }; },
  });
  let seen = [];

  // Спящая вкладка держит ТОТ ЖЕ адрес — её брать нельзя (в ней заглушка).
  const sleeping = page('https://bingx.com/ru/spot/STONKUSDT', { __arbiSleepUrl: 'https://bingx.com/ru/spot/STONKUSDT' });
  const stale = page('https://bingx.com/ru/spot/STONKUSDT');
  const live = page('https://bingx.com/ru/spot/TUSDT');
  const ctx = (pages) => ({ pages: () => pages, newPage: async () => freshPage() });

  // Старая вкладка (загружена до входа) показывает «Log In», соседняя — нет: вход есть, без новой вкладки.
  const ok1 = await checkLogin(ctx([sleeping, stale, live]), opts(new Set([stale]), true));
  assert.equal(ok1.loggedIn, true);
  assert.ok(!seen.includes(sleeping), 'спящую вкладку не проверяем');
  assert.equal(fresh, null, 'новую вкладку не открываем');

  // Стена на всех живых, свежая вкладка без стены — вход есть, вкладка закрыта за собой.
  seen = [];
  const ok2 = await checkLogin(ctx([sleeping, stale]), opts(new Set([stale]), false));
  assert.equal(ok2.loggedIn, true);
  assert.equal(fresh.closed, true);

  // Стена и на свежей — нет входа.
  seen = []; fresh = null;
  const bad = await checkLogin(ctx([sleeping, stale]), opts(new Set([stale]), true));
  assert.equal(bad.loginRequired, true);
  assert.equal(bad.exchange, 'BingX');
  assert.match(bad.error, /нет входа в аккаунт BingX/);
  assert.equal(fresh.closed, true);
});

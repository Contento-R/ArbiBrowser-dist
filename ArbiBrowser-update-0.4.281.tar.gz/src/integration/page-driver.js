'use strict';

// Профиль, где перезагрузка только что подтвердила «нет входа» → время подтверждения.
const wallConfirmedAt = new WeakMap();
const WALL_RECHECK_MS = 30_000;
// Когда в профиле последний раз увидели вход (login-hold снял режим «идёт вход»).
const loginSeenAt = new WeakMap();
/** Вход выполнен: сбросить «нет входа подтверждено» и запомнить момент. */
function noteLogin(context) {
  if (!context) return;
  wallConfirmedAt.delete(context);
  loginSeenAt.set(context, Date.now());
}
const FRESH_PAGE_MS = 120_000;

/**
 * Единый драйвер страницы биржи (Этап 1 ревизии, 2026-09-15).
 *
 * До этого пять хелперов (typeNumber / fastSetInputs / isSubmitReady /
 * dismissBlockingModal / dismissOverlays) жили ТРЕМЯ копиями в bingx-/mexc-/xt-order-page.js
 * и годами расходились: фикс, найденный на одной бирже, до двух других не доезжал
 * (у MEXC-копии не было ни risk-метки, ни primary-кнопки; у XT — крестика-иконки BingX).
 * Здесь один код, а различия бирж сведены в ДАННЫЕ профиля ниже. Поведение каждой
 * биржи сохранено байт-в-байт по смыслу: профиль = то, что делала её копия.
 *
 * Регэкспы хранятся строками (`source`), потому что в page.evaluate RegExp не передать —
 * внутри страницы они собираются `new RegExp(src, 'i')`.
 */

const { markOwned, newBackgroundPage, isAsleep } = require('./pair-tabs');

const CLOSE_SEL = '[aria-label*="close" i],[class*="close" i],[class*="lose" i] button,button[class*="lose"]';

const PROFILES = {
  bingx: {
    inputKey: 'numberInput',
    submitMode: 'side',
    clickMs: () => 4000,
    forceClick: () => false,
    insertText: () => (process.env.ARBI_INSERT_TEXT || '1') === '1',
    modal: {
      sel: '.ant-modal-wrap,[class*="ant-modal-confirm"],[role="dialog"],[class*="modal" i],[class*="dialog" i],[class*="popup" i]',
      // BingX ST-токены (напр. AI/GENSYN) показывают «Предупреждение о риске» с кнопкой
      // «Принято» (+ баннер «инновационная зона») → перехват формы.
      block: 'insufficient|not enough|недостаточн|balance|баланс|transfer|error|ошибк|fail|failed|limit reached|too small|minimum|риск|risk|предупрежд|warning|инновацион|innovation|делистинг|delisting',
      ok: '^(ok|close|cancel|отмена|закрыть|got it|понятно|принято|принимаю|accept|i accept|i agree|understood|确定|取消|知道了|i understand|agree|согласен)$',
      primarySel: 'button.ant-btn-primary,button[class*="primary" i]',
      primaryExclude: 'buy|sell|купить|продать|детали|подробн|more',
      risk: 'риск|risk|предупрежд|warning|инновацион|innovation',
    },
    overlays: {
      // Прямые крестики окна «предупреждение о риске проекта» и app-попапа (из userscript
      // оператора) — перехватывают клики по форме.
      preClose: ['.price-project-warn .ppw-close', '.b-dialog-content .ic-close'],
      // «Satisfaction Survey» и прочие промо: крестик — иконка через CSS-переменную
      // (--svg: …ic-close.svg) на <i class="bx-svg-inner">, текста нет.
      bxSvg: true,
      closeSel: `${CLOSE_SEL},[class*="icon-close" i],[class*="ic-close" i],svg[class*="close" i]`,
      glyph: true,   // текстовый крестик ×/✕/✖ среди мелких элементов модалки
      survey: true,  // опрос без крестика → Escape из Node
      hide: null,
    },
  },
  mexc: {
    inputKey: 'input',
    submitMode: 'visible',
    // Без таймаута click по НЕВИДИМОМУ/перекрытому полю висел 30с (WOJAK). Force по
    // умолчанию ВКЛ с 0.4.129 — проверка актуальности Playwright ни разу ничего не
    // защитила, а стоила 1,2 с на ордер; промах ловит строгая сверка полей перед сабмитом.
    // …и автоматически, если в этом заполнении клик уже сорвался (st.fallback).
    clickMs: () => Number(process.env.ARBI_MEXC_INPUT_CLICK_MS || 1200),
    forceClick: (st) => (process.env.ARBI_MEXC_INPUT_FORCE_CLICK || '1') !== '0' || !!(st && st.fallback),
    // Вставка (CDP Input.insertText = то же, что Ctrl+V руками) ВКЛЮЧЕНА с 0.4.203:
    // оператор проверил вручную, что MEXC принимает вставку в поля формы, а прежний
    // запрет был перестраховкой — его писали по аналогии с fastSetInputs (нативный
    // value-сеттер, isTrusted=false), который анти-бот действительно игнорирует.
    // Посимвольный набор остаётся фолбэком: внутри typeNumber — при неудачной вставке,
    // и на всю сессию — если заявка после вставки не ушла (см. MEXC_INSERT_OK).
    insertText: () => (process.env.ARBI_MEXC_INSERT_TEXT || '1') !== '0',
    // Фокус БЕЗ МЫШИ. Замер 21.09: «клик-в-поле=124(наведение=77…)» и
    // «клик-в-поле=498(наведение=474…)» — после перехода на вставку это самая
    // дорогая статья заполнения, а тратится она на проезд курсора к полю.
    // focus()+selectText() дают то же самое (фокус + выделенное старое значение
    // под замену) мгновенно. Вставка остаётся доверенным событием ввода — её
    // анти-бот и проверяет. Если поле так значение не примет, typeNumber сам
    // вернётся к настоящему клику мышью и посимвольному набору.
    fastFocus: () => (process.env.ARBI_MEXC_FAST_FOCUS || '1') !== '0',
    modal: {
      sel: '[class*="ant-modal"],[class*="odal-v2"],[role="dialog"],[class*="onfirm"]',
      block: 'insufficient|not enough|недостаточн|balance|баланс|error|ошибк|fail|failed|too small|minimum|risk|риск|warning|внимани',
      ok: '^(ok|close|cancel|отмена|закрыть|got it|понятно|确定|取消|知道了)$',
      primarySel: null,
      primaryExclude: null,
      risk: null,
    },
    overlays: {
      preClose: [],
      bxSvg: false,
      // У «Market Movers» крестик не ловился прежними селекторами — ищем ШИРОКО.
      closeSel: `${CLOSE_SEL},svg[class*="lose" i],i[class*="lose" i],[class*="icon-close" i],[class*="guanbi" i]`,
      glyph: false,
      survey: false,
      hide: 'market movers', // промо-панель без крестика — прячем сам оверлей
    },
  },
  xt: {
    inputKey: 'numberInput',
    submitMode: 'side',
    clickMs: () => 4000,
    forceClick: () => false,
    insertText: () => (process.env.ARBI_INSERT_TEXT || '1') === '1',
    modal: {
      sel: '.ant-modal-wrap,[class*="ant-modal-confirm"],[role="dialog"],[class*="odal"]',
      block: 'insufficient|not enough|недостаточн|balance|баланс|transfer|error|ошибк|fail|failed|limit reached|too small|minimum|риск|risk|предупрежд|warning',
      ok: '^(ok|close|cancel|отмена|закрыть|got it|понятно|确定|取消|知道了|i understand|agree|согласен)$',
      primarySel: 'button.ant-btn-primary',
      primaryExclude: 'buy|sell|купить|продать',
      risk: 'риск|risk|предупрежд|warning',
    },
    overlays: { preClose: [], bxSvg: false, closeSel: CLOSE_SEL, glyph: false, survey: false, hide: null },
  },
};

/**
 * @param {'bingx'|'mexc'|'xt'} name
 * @param {object} selectors  SELECTORS интеграции (нужны numberInput|input, submit, submitBuy/Sell)
 */
function driverFor(name, selectors) {
  const p = PROFILES[name];
  if (!p) throw new Error(`page-driver: неизвестная биржа ${name}`);
  if (!selectors || !selectors[p.inputKey] || !selectors.submit) throw new Error(`page-driver(${name}): нужны SELECTORS.${p.inputKey} и SELECTORS.submit`);

  /**
   * БЫСТРЫЙ ввод обоих полей ОДНИМ evaluate (один CDP round-trip вместо двух):
   * нативный сеттер value + событие input → React обновляет состояние (handle.fill()
   * React-контролируемый инпут игнорирует).
   */
  async function fastSetInputs(page, price, qty) {
    return page.evaluate((a) => {
      const setV = (el, v) => {
        const d = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
        d.set.call(el, v);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      };
      const inputs = document.querySelectorAll(a.sel);
      if (inputs.length < 2) return false;
      setV(inputs[0], a.price);
      setV(inputs[1], a.qty);
      return inputs[0].value === a.price && inputs[1].value === a.qty;
    }, { sel: selectors[p.inputKey], price: String(price), qty: String(qty) });
  }

  /**
   * Посимвольный ввод одного поля. click({clickCount:3}) — тройной клик МЫШЬЮ по полю:
   * реально фокусирует React-поле (программный focus() на XT не всегда активировал поле)
   * и выделяет текст В ПОЛЕ (не по странице, как Ctrl+A при неудачном фокусе).
   * Значение потом строго сверяется (fieldFresh) перед сабмитом.
   * Короткий таймаут клика: модалка перехватила клик → падаем быстро, закрываем её,
   * повторяем с force — а не висим 30с (ловили на ST-токенах).
   * Вставка ВСЕЙ строки одним доверенным событием (CDP Input.insertText) с проверкой,
   * что значение попало в поле; иначе — надёжный посимвольный ввод. Профиль решает,
   * включена ли вставка (MEXC — нет, анти-бот).
   * @param {{direct?:boolean, st?:object}} [opts]  direct — сразу посимвольно (поле
   *   количества XT вставку не принимает никогда, попытка стоила ~2с); st — счётчики
   *   тайминга `[timing fill]` (point/clear/click/keys/keysN/typeN/fallback).
   */
  async function typeNumber(page, handle, value, opts = {}) {
    const st = opts.st;
    const t0 = Date.now();
    // Быстрый путь: фокус и выделение без проезда курсора (см. fastFocus в
    // профиле). Не вышло — идём обычным кликом мыши, как раньше.
    let focused = false;
    if (!opts.direct && p.fastFocus && p.fastFocus()) {
      try {
        await handle.focus({ timeout: 1000 });
        await handle.selectText({ timeout: 1000 });
        focused = true;
        if (st) st.fastFocus = (st.fastFocus || 0) + 1;
      } catch { focused = false; }
    }
    if (!focused) {
      try {
        await handle.click({ clickCount: 3, timeout: p.clickMs(), force: p.forceClick(st) });
      } catch {
        if (st) st.fallback++;
        await dismissBlockingModal(page);
        await handle.click({ clickCount: 3, timeout: 4000, force: true }).catch(() => {});
      }
    }
    const tClear = Date.now();
    await page.keyboard.press('Backspace');
    if (st) { st.point += tClear - t0; st.clear += Date.now() - tClear; st.click += Date.now() - t0; }
    const s = String(value);
    if (!opts.direct && p.insertText()) {
      // Вставка (CDP Input.insertText) — это то же, что Ctrl+V руками: настоящее
      // событие ввода, которое React-поля принимают. НЕ путать с fastSetInputs
      // (нативный value-сеттер в evaluate) — вот его React действительно игнорирует.
      //
      // Проверка «вставка сработала» — СТРОГАЯ. Прежняя («поле не пустое») засчитывала
      // успех, даже если в поле осталось значение ПРОШЛОГО ордера: непустое же.
      // Здесь значение поля обязано быть началом того, что мы вставляли: биржа вправе
      // усечь хвост по шагу лота («386204.76…» → «386204.»), но не подменить число.
      //
      // Второй заход — с ЗАПЯТОЙ вместо точки: часть бирж ждёт десятичный разделитель
      // по локали поля и ввод с точкой молча не принимает (оператор 18.09). Стоит он
      // одну вставку; не принялось и так — уходим на посимвольный ввод, как раньше.
      const accepted = (raw, variant) => {
        let n = String(raw || '').replace(/\s/g, '');
        // В варианте с запятой она — ДЕСЯТИЧНЫЙ разделитель; в обычном — разделитель
        // тысяч, и тогда её просто убираем («1,082,704.» → «1082704.»).
        n = variant.includes(',') ? n.replace(',', '.') : n.replace(/,/g, '');
        n = n.replace(/\.$/, '');
        return n.length > 0 && s.startsWith(n);
      };
      const variants = s.includes('.') ? [s, s.replace('.', ',')] : [s];
      for (const variant of variants) {
        try {
          await page.keyboard.insertText(variant);
          const raw = await handle.evaluate((el) => String(el.value || '')).catch(() => '');
          if (accepted(raw, variant)) {
            if (st) st.inserted = (st.inserted || 0) + 1;
            return;
          }
        } catch { /* фолбэк ниже */ }
        await handle.click({ clickCount: 3, timeout: 2000 }).catch(() => {});
        await page.keyboard.press('Backspace').catch(() => {});
      }
    }
    const t1 = Date.now();
    await page.keyboard.type(s, { delay: 0 });
    if (st) { st.keys += Date.now() - t1; st.keysN += s.length; st.typeN++; }
  }

  /**
   * Закрывает промо/куки/инфо-оверлеи (опрос, «Market Movers», риск-инфо), которые
   * перекрывают форму и СРЫВАЮТ клик по ордеру. Трогает ТОЛЬКО промо: модалку
   * подтверждения ордера (Confirm/Buy/Sell/order) НЕ закрывает. Best-effort,
   * синтетический клик по крестику (промо анти-ботом не защищено).
   * @returns {Promise<number>} сколько закрыли
   */
  async function dismissOverlays(page) {
    const res = await page.evaluate((o) => {
      const vis = (el) => el && el.offsetParent !== null;
      let closed = 0;
      let surveyLeft = false;
      for (const sel of o.preClose) {
        const el = document.querySelector(sel);
        if (el && vis(el)) { try { el.click(); closed++; } catch (_) {} }
      }
      if (o.bxSvg) {
        for (const el of document.querySelectorAll('i.bx-svg-inner,[class*="bx-svg-inner"]')) {
          const sv = (el.getAttribute('style') || '') + (getComputedStyle(el).getPropertyValue('--svg') || '');
          if (vis(el) && /ic-close/i.test(sv)) { try { (el.closest('[class*="close"]') || el).click(); closed++; } catch (_) {} }
        }
      }
      const hideRe = o.hide ? new RegExp(o.hide, 'i') : null;
      const dialogs = Array.from(document.querySelectorAll(
        '[role="dialog"],[class*="odal"],[class*="ialog"],[class*="opup"]')).filter(vis);
      for (const d of dialogs) {
        const txt = (d.innerText || '');
        // НЕ закрываем модалку ордера — только промо/инфо/опрос.
        if (/confirm|подтвер|\bbuy\b|\bsell\b|купить|продать|order|ордер/i.test(txt)) continue;
        const isSurvey = o.survey && /survey|recommend|satisfaction|feedback|опрос|оцените|отзыв/i.test(txt);
        let btn = d.querySelector(o.closeSel);
        if (!btn && o.glyph) {
          btn = Array.from(d.querySelectorAll('button,span,i,a,div')).filter(vis)
            .find((e) => /^[\s]*[×✕✖xX]?[\s]*$/.test((e.textContent || '').trim()) && (e.textContent || '').trim().length <= 2 && /[×✕✖xX]/.test((e.textContent || '') + (e.className || '')));
        }
        if (btn && vis(btn)) { try { btn.click(); closed++; continue; } catch (_) {} }
        if (hideRe && hideRe.test(txt)) { try { d.style.display = 'none'; closed++; continue; } catch (_) {} }
        if (isSurvey) surveyLeft = true; // не смогли закрыть кликом → Escape в Node
      }
      return { closed, surveyLeft };
    }, p.overlays).catch(() => ({ closed: 0, surveyLeft: false }));
    // Опрос/промо без крестика — закрываем Escape (модалки BingX закрываются по Esc).
    // Это НЕ трогает форму ордера.
    if (res && res.surveyLeft) { try { await page.keyboard.press('Escape'); } catch (_) { /* ignore */ } }
    return (res && res.closed) || 0;
  }

  /**
   * Закрывает БЛОКИРУЮЩУЮ модалку-ошибку/риск (нехватка баланса, «Предупреждение о
   * рисках» ST-токена, ant-modal-confirm), которая перехватывает клики по кнопке ордера
   * и валит все следующие заявки. Закрываем ТОЛЬКО ошибочные/инфо — не подтверждение
   * ордера. Если закрыли именно risk/ST-модалку — ставим page.__arbiSawRisk (executeIntent
   * вернёт это терминалу для обучения known_tokens).
   * @returns {Promise<{closed:number, text:string}>}
   */
  async function dismissBlockingModal(page) {
    const r = await page.evaluate((m0) => {
      const vis = (el) => el && el.offsetParent !== null;
      const blockRe = new RegExp(m0.block, 'i');
      const okRe = new RegExp(m0.ok, 'i');
      const exclRe = m0.primaryExclude ? new RegExp(m0.primaryExclude, 'i') : null;
      let closed = 0; let text = '';
      const modals = Array.from(document.querySelectorAll(m0.sel)).filter(vis);
      for (const m of modals) {
        const txt = (m.innerText || '').replace(/\s+/g, ' ').trim();
        if (!blockRe.test(txt)) continue;
        if (/подтвердите ордер|confirm order|place order/i.test(txt)) continue;
        text = txt.slice(0, 120);
        // Крестик → кнопка-подтверждение по точному тексту («Понятно/OK/Принято…») →
        // primary-кнопка, кроме Buy/Sell/«Детали»/«See more».
        const btn = m.querySelector('.ant-modal-close,[aria-label*="close" i],button[class*="close" i]')
          || Array.from(m.querySelectorAll('button')).find((b) => okRe.test((b.innerText || '').trim()))
          || (m0.primarySel ? Array.from(m.querySelectorAll(m0.primarySel)).find((b) => vis(b) && !exclRe.test((b.innerText || '').trim())) : null);
        if (btn && vis(btn)) { try { btn.click(); closed++; } catch (_) {} }
      }
      return { closed, text };
    }, p.modal).catch(() => ({ closed: 0, text: '' }));
    if (p.modal.risk && r && r.closed && new RegExp(p.modal.risk, 'i').test(r.text || '')) {
      try { page.__arbiSawRisk = true; } catch { /* игнор */ }
    }
    return r;
  }

  /**
   * Готова ли кнопка сабмита (форма приняла значения)? best-effort, «не знаем» → true.
   * side-режим (BingX/XT): кнопка нужной стороны → общий сабмит → true.
   * visible-режим (MEXC): в DOM обе кнопки, видима только активная — берём её.
   */
  async function isSubmitReady(page, side) {
    if (p.submitMode === 'visible') {
      return page.evaluate((sel) => {
        const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
        const el = Array.from(document.querySelectorAll(sel)).filter(vis)[0];
        if (!el) return true;
        const s = getComputedStyle(el);
        return !(el.disabled || el.getAttribute('aria-disabled') === 'true'
          || /disabl/i.test(el.className) || s.pointerEvents === 'none'
          || parseFloat(s.opacity || '1') < 0.5);
      }, selectors.submit).catch(() => true);
    }
    const sel = side === 'sell' ? selectors.submitSell : selectors.submitBuy;
    const test = (s) => page.$eval(s, (el) => {
      const st = getComputedStyle(el);
      return !(el.disabled || el.getAttribute('aria-disabled') === 'true'
        || /disabl/i.test(el.className) || st.pointerEvents === 'none'
        || parseFloat(st.opacity || '1') < 0.5);
    });
    return test(sel).catch(() => test(selectors.submit).catch(() => true));
  }

  /**
   * Нет входа в аккаунт биржи в этом профиле (оператор 15.09: «когда пользователь
   * незалогинен — так и писать в терминал»). Признак — на месте кнопки ордера
   * «Log In / Sign Up / Войти», либо кнопки ордера нет вовсе, а в шапке видна
   * кнопка входа. Проверяется на прогреве и перед заявкой; текст ошибки — единый.
   * @returns {Promise<{wall:boolean, text:string}>}
   */
  async function loginWall(page) {
    return page.evaluate((sel) => {
      const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
      const re = /(^|[\s/|])(log ?in|sign ?in|sign ?up|войти|вход|регистрац|connexion|s'inscrire|登录|注册)([\s/|]|$)/i;
      const subs = Array.from(document.querySelectorAll(sel)).filter(vis).map((e) => (e.textContent || '').replace(/\s+/g, ' ').trim());
      const text = subs.join(' | ');
      if (subs.length) return { wall: re.test(text), text };
      // Кнопки ордера нет — ищем кнопку входа в шапке (точный короткий текст).
      const hdr = Array.from(document.querySelectorAll('header a,header button,[class*="header" i] a,[class*="header" i] button'))
        .filter(vis).map((e) => (e.textContent || '').replace(/\s+/g, ' ').trim()).filter((t) => t.length <= 16);
      const login = hdr.find((t) => /^(log ?in|sign ?in|войти|вход|connexion|登录)$/i.test(t));
      return { wall: !!login, text: login ? `шапка: ${login}` : '' };
    }, selectors.submit).catch(() => ({ wall: false, text: '' }));
  }

  /**
   * То же, но с одной перезагрузкой вкладки (оператор 07.10, BingX/USEPAID): вход
   * сделан в ДРУГОЙ вкладке того же профиля, а торговая вкладка загружена раньше —
   * её шапка так и показывает «Войти», хотя cookie входа уже есть, и пять заявок
   * подряд падали «нет входа». Видим стену → перезагружаем страницу → проверяем
   * снова; стена осталась — вход в профиле действительно не сделан.
   */
  async function loginWallFresh(page, log) {
    const first = await loginWall(page);
    if (!first.wall) return first;
    // Разлогин уже подтверждён перезагрузкой в этом профиле только что (оператор 18.10,
    // STONK/BingX): каждая следующая заявка снова перезагружала страницу и тратила
    // 15–35 с, третья упиралась в таймаут терминала. Теперь — ответ «нет входа» сразу.
    let ctx = null;
    try { ctx = page.context(); } catch { /* страница закрыта */ }
    const sinceMs = ctx ? Date.now() - (wallConfirmedAt.get(ctx) || 0) : Infinity;
    if (sinceMs < WALL_RECHECK_MS) {
      if (typeof log === 'function') log(`На вкладке «${first.text}» — нет входа (подтверждено ${Math.round(sinceMs / 1000)} с назад, без перезагрузки)`);
      return first;
    }
    // СВЕЖАЯ страница (оператор 18.10): загружена меньше 2 мин назад и ПОСЛЕ последнего
    // замеченного входа — она уже видит текущие cookie, перезагрузка ничего не даст.
    // Перезагрузка нужна лишь вкладке, загруженной ДО входа в другой вкладке (кейс 07.10).
    const loadedAt = await page.evaluate(() => performance.timeOrigin).catch(() => 0);
    if (loadedAt && Date.now() - loadedAt < FRESH_PAGE_MS && loadedAt > ((ctx && loginSeenAt.get(ctx)) || 0)) {
      if (ctx) wallConfirmedAt.set(ctx, Date.now());
      if (typeof log === 'function') log(`На вкладке «${first.text}» — нет входа (страница загружена ${Math.round((Date.now() - loadedAt) / 1000)} с назад, перезагрузка не нужна)`);
      return first;
    }
    if (typeof log === 'function') log(`На вкладке «${first.text}» — перезагружаю страницу: вход мог быть сделан в другой вкладке профиля`);
    try {
      await page.reload({ waitUntil: 'domcontentloaded', timeout: 15000 });
      await page.waitForSelector(selectors.submit, { state: 'visible', timeout: 6000 }).catch(() => {});
    } catch { return first; }
    const again = await loginWall(page);
    if (ctx) { if (again.wall) wallConfirmedAt.set(ctx, Date.now()); else wallConfirmedAt.delete(ctx); }
    return again;
  }

  return { typeNumber, fastSetInputs, isSubmitReady, dismissBlockingModal, dismissOverlays, loginWall, loginWallFresh, profile: p };
}

/**
 * ПРОВЕРКА ВХОДА В АККАУНТ БИРЖИ — без единого торгового действия (оператор 25.09:
 * «при открытии веб-токена после простоя проверять, что залогинены на ВСЕХ биржах
 * с веб-токенами»). Прогрев отвечает только за ту биржу, чей токен открыли; здесь
 * спрашиваем остальные, чтобы разлогин не всплыл в момент заявки.
 *
 * Берём ЛЮБУЮ живую (не спящую) вкладку этой биржи — она уже загружена, проверка
 * стоит один evaluate. Вкладки нет — открываем фоновую на торговой странице,
 * смотрим и ЗАКРЫВАЕМ за собой: лишних вкладок после проверки не остаётся.
 *
 * Молчим, когда не уверены: «стены входа не видно» — это ok, а не утверждение
 * «точно залогинен». Ложная тревога здесь дороже пропуска — оператор перестанет
 * верить плашке.
 *
 * @param {import('playwright').BrowserContext} context
 * @param {{origin:string, tradeUrl:string, loginWall:Function, exchange:string, log?:Function}} o
 */
async function checkLogin(context, o) {
  const log = o.log || (() => {});
  // Все живые вкладки биржи: cookie у профиля общие — хватит ОДНОЙ без «Log In». Первая
  // попавшаяся могла быть загружена ДО входа в другой вкладке и всё ещё показывать «Log In»
  // в шапке (кейс 07.10; оператор 25.10: «вход выполнен, а пишет залогиниться»).
  const live = context.pages().filter((p) => {
    try { return !p.isClosed() && !isAsleep(p) && String(p.url()).startsWith(o.origin); } catch { return false; }
  });
  let lw = { wall: false, text: '' };
  for (const p of live) {
    lw = await o.loginWall(p);
    if (!lw.wall) { log(`Вход в аккаунт ${o.exchange} на месте`); return { ok: true, loggedIn: true, exchange: o.exchange }; }
  }
  // Живых вкладок нет или на всех «Log In» — решает свежая фоновая вкладка: она видит
  // текущие cookie. Закрываем за собой — лишних вкладок после проверки не остаётся.
  const opened = markOwned(await newBackgroundPage(context));
  await opened.goto(o.tradeUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  if (!String(opened.url()).startsWith(o.origin)) {
    await opened.close().catch(() => {});
    return { ok: false, exchange: o.exchange, error: `страница ${o.exchange} не открылась — вход не проверен` };
  }
  // Свежей странице нужно дорисовать шапку/форму, иначе «стены входа не видно»
  // означало бы всего лишь «ещё не отрисовано».
  await opened.waitForLoadState('load', { timeout: 8000 }).catch(() => {});
  await opened.waitForTimeout(500);
  lw = await o.loginWall(opened);
  await opened.close().catch(() => {});
  if (lw.wall) {
    log(`Нет входа в аккаунт ${o.exchange} в этом профиле (на свежей странице: «${lw.text}»${live.length ? `; живых вкладок с «Log In»: ${live.length}` : ''})`);
    return { ok: true, loggedIn: false, loginRequired: true, exchange: o.exchange,
      error: loginRequiredError(o.exchange, 'Войдите в профиле ArbiBrowser до выставления заявок.') };
  }
  log(`Вход в аккаунт ${o.exchange} на месте (проверено во временной вкладке${live.length ? `; ${live.length} старых вкладок показывали «Log In» — их обновит следующая заявка` : ''})`);
  return { ok: true, loggedIn: true, exchange: o.exchange };
}

// Окно, которое прятать НЕЛЬЗЯ: подтверждение/риск ордера (их жмёт confirm*-ветка) и проверка
// безопасности биржи (капча: текст «verify/проверка» или содержимое — iframe/canvas без текста).
const KEEP_COVER_RE = 'подтвер|confirm|ордер|order|risk|риск|verif|captcha|security|проверк|安全|验证';

/**
 * Убрать то, что лежит ПОВЕРХ кнопки ордера. Клик force идёт по координатам, и браузер
 * отдаёт его самому верхнему элементу в этой точке. Лог и скрин 14.10 (STONK/BingX, узкое
 * окно): уведомление «Листинг в Зоне инновации…» легло на «Купить», клик ушёл в него —
 * «order/place не ушёл» при активной кнопке и пустом списке модалок. Тот же глухой клик
 * на MEXC (BKN 29.10) — функция общая (перенесена из bingx-order-page.js, 0.4.277).
 * Поднимаемся от элемента в центре кнопки до самого внешнего предка, который кнопку не
 * содержит, и прячем его. Подтверждения/риск/капчу не трогаем (KEEP_COVER_RE).
 * @returns {Promise<string|null>} текст спрятанного элемента или null.
 */
async function uncoverSubmit(page, sel, log) {
  const hid = await page.evaluate(({ s, keep }) => {
    const sub = Array.from(document.querySelectorAll(s)).find((e) => e.offsetParent !== null && e.getBoundingClientRect().width > 2);
    if (!sub) return null;
    const r = sub.getBoundingClientRect();
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    if (!hit || hit === sub || sub.contains(hit) || hit.contains(sub)) return null;
    let cover = hit;
    while (cover.parentElement && !cover.parentElement.contains(sub)) cover = cover.parentElement;
    const txt = (cover.innerText || '').replace(/\s+/g, ' ').trim();
    if (new RegExp(keep, 'i').test(txt) || (!txt && cover.querySelector('iframe,canvas'))) return null;
    cover.style.setProperty('display', 'none', 'important');
    return txt.slice(0, 80) || cover.tagName.toLowerCase();
  }, { s: sel, keep: KEEP_COVER_RE }).catch(() => null);
  if (hid && log) log(`Кнопку ордера накрывало «${hid}» — убрал перед кликом`);
  return hid;
}

/**
 * След глухого клика (#58): кто в точке клика кнопки и что за «окна» на странице — класс,
 * размер, есть ли iframe/canvas (капча рисуется ими, текста у неё нет: BKN/MEXC 29.10 —
 * три окна с пустым текстом и без кнопок). `captcha` — окно проверки безопасности видно.
 */
async function clickPointFacts(page, sel) {
  return page.evaluate(({ s, keep }) => {
    // Не offsetParent: у окна с position:fixed (обёртки модалок, капча) он всегда null.
    const vis = (el) => el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== 'hidden';
    const desc = (n) => {
      if (!n || !n.tagName) return '?';
      const cls = typeof n.className === 'string' && n.className.trim() ? '.' + n.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
      return `${n.tagName.toLowerCase()}${n.id ? '#' + n.id : ''}${cls}`;
    };
    let hit = null;
    const sub = Array.from(document.querySelectorAll(s)).find((e) => vis(e) && e.getBoundingClientRect().width > 2);
    if (sub) {
      const r = sub.getBoundingClientRect();
      const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      const chain = [];
      for (let n = el, i = 0; n && i < 4; n = n.parentElement, i += 1) chain.push(desc(n));
      const reaches = !!el && (el === sub || sub.contains(el) || el.contains(sub));
      // Нажатие перехватил кадр/холст без текста (так рисуется капча) — это проверка безопасности.
      let cover = el;
      while (!reaches && cover && cover.parentElement && !cover.parentElement.contains(sub)) cover = cover.parentElement;
      const coverIsFrame = !reaches && !!cover && !(cover.innerText || '').trim() && (/^(IFRAME|CANVAS)$/.test(cover.tagName) || !!cover.querySelector('iframe,canvas'));
      hit = { el: el ? chain.join(' < ') : '(пусто)', reachesSubmit: reaches, coverIsFrame };
    }
    const verifyRe = /verif|captcha|security|проверк|安全|验证|slide|слайд|puzzle|пазл/i;
    let captcha = !!(hit && hit.coverIsFrame);
    const dialogs = Array.from(document.querySelectorAll('[role="dialog"],[class*="odal"],[class*="ialog"],[class*="opup"],[class*="aptcha"],[id*="aptcha"]'))
      .filter(vis).map((el) => {
        const r = el.getBoundingClientRect();
        const text = (el.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 100);
        const frames = Array.from(el.querySelectorAll('iframe')).map((f) => { try { return new URL(f.src).host; } catch { return 'iframe'; } });
        const canvas = !!el.querySelector('canvas');
        if (r.width > 40 && r.height > 40 && verifyRe.test(text)) captcha = true;
        return { cls: desc(el), size: `${Math.round(r.width)}x${Math.round(r.height)}`, text, frames, canvas,
          buttons: Array.from(el.querySelectorAll('button')).map((b) => (b.innerText || '').trim()).filter(Boolean).slice(0, 4) };
      }).slice(0, 5);
    return { hit, dialogs, captcha, keep };
  }, { s: sel, keep: KEEP_COVER_RE }).catch((e) => ({ err: String(e && e.message).slice(0, 80) }));
}

/**
 * Единый текст для терминала: нет входа в аккаунт биржи в профиле ArbiBrowser.
 * @param {string} exchange  биржа
 * @param {string} [tail]    чем кончилось из-за разлогина (по умолчанию — про заявку;
 *                           у прогрева и чтения истории свой хвост)
 */
const loginRequiredError = (exchange, tail = 'Заявка НЕ отправлена.') => `В ArbiBrowser нет входа в аккаунт ${exchange}: откройте окно профиля ArbiBrowser, войдите на бирже ${exchange} и повторите. ${tail}`;

module.exports = { driverFor, PROFILES, loginRequiredError, checkLogin, noteLogin, uncoverSubmit, clickPointFacts };

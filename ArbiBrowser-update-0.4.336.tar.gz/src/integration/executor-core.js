'use strict';
const { slowHint } = require('./pair-tabs');

/**
 * executor-core.js — общий транспорт web-исполнителей (MEXC / XT / далее BingX
 * и любые будущие биржи с web-only токенами).
 *
 * Каждый исполнитель опрашивает у цекс-терминала очередь «намерений ордера» для
 * текущего юзера (per-user X-Arbi-Token), исполняет их В браузере и постит
 * результат. Так обходится Akamai: реальный Chromium с правильным
 * TLS/сенсором/куками.
 *
 * Две цели под многопользовательский режим + низкую latency + низкую нагрузку:
 *   1) KEEP-ALIVE — одно переиспользуемое TCP/TLS-соединение вместо нового
 *      рукопожатия на каждый опрос (старый код открывал сокет ~10×/сек на юзера).
 *   2) LONG-POLL — GET /pending?wait=<мс> держится на сервере до появления
 *      намерения (доставка ~0мс) вместо опроса с интервалом (интервал добавлял
 *      задержку к КАЖДОМУ ордеру и бил сервер вхолостую, когда никто не торгует).
 *
 * Обратная совместимость: если сервер игнорирует ?wait (старый билд), запрос
 * вернётся сразу, и мы падаем на скромный sleep между опросами (как раньше).
 *
 * Никакой биржевой специфики здесь нет — конкретная биржа задаётся конфигом
 * (пути /pending и /result, env-имена). Новая биржа = 10-строчный файл-обёртка.
 */

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');

// ── Отчёт о версии/обновлении ArbiBrowser терминалу ──────────────────────────
// Терминал (куда смотрит пользователь) показывает «обнови ArbiBrowser», когда есть
// апдейт. Источник правды — сам ArbiBrowser (он проверяет релизы GitHub-dist через
// app-info). Кладём версию и наличие апдейта в ЗАГОЛОВКИ каждого /pending (кэш,
// обновляем раз в час — GitHub не долбим).
const APP_VERSION = (() => { try { return require('../../package.json').version; } catch { return ''; } })();
let updateCache = { current: APP_VERSION, latest: '', updateAvailable: false };
let updateTimer = null;
async function refreshUpdateCache() {
  try {
    const appInfo = require('../app-info');
    const r = await appInfo.checkAppUpdate();
    updateCache = { current: r.current || APP_VERSION, latest: r.latest || '', updateAvailable: !!r.updateAvailable };
  } catch { /* сеть/GitHub недоступны — оставляем прошлый кэш */ }
}
function ensureUpdateChecks() {
  if (updateTimer) return;
  refreshUpdateCache();
  updateTimer = setInterval(refreshUpdateCache, 60 * 60 * 1000);
  if (updateTimer.unref) updateTimer.unref();
}

// ── CR-5: журнал идемпотентности исполнения ──────────────────────────────────
// Проблема: executeIntent выставил ордер, затем POST результата упал по сети ИЛИ
// процесс убит между кликом и постом → результат терялся, ретрая нет → терминал,
// не получив результат, мог переотдать intent → ордер выставлялся ВТОРОЙ раз.
// Решение: перед РЕАЛЬНЫМ исполнением помечаем intent.id «в работе» на диске; по
// завершении пишем результат. Повторный intent с тем же id НЕ исполняем — отдаём
// сохранённый результат. at-most-once исполнение. (Полная идемпотентность сквозь
// цепочку требует СТАБИЛЬНОГО intent.id со стороны терминала — см. findings CR-5.)
const JOURNAL_PATH = path.join(config.dataDir, 'intent-journal.json');
const JOURNAL_TTL_MS = 24 * 60 * 60 * 1000; // сутки — дальше id уже неактуален
let journalCache = null;

function loadJournal() {
  if (journalCache) return journalCache;
  try {
    const raw = fs.readFileSync(JOURNAL_PATH, 'utf8');
    journalCache = JSON.parse(raw) || {};
  } catch { journalCache = {}; }
  // Прибираем протухшее, чтобы файл не рос бесконечно.
  const now = Date.now();
  let changed = false;
  for (const id of Object.keys(journalCache)) {
    // + ответы чтений сайта Ourbit (списки rows) — писались до 0.4.332 и раздували файл; не нужны.
    const j = journalCache[id];
    if (now - (j.ts || 0) > JOURNAL_TTL_MS || (j.result && Array.isArray(j.result.rows))) { delete journalCache[id]; changed = true; }
  }
  if (changed) persistJournal();
  return journalCache;
}

function persistJournal() {
  try {
    fs.mkdirSync(path.dirname(JOURNAL_PATH), { recursive: true });
    // M2: атомарная запись (tmp + rename). Раньше writeFileSync писал поверх — краш
    // ПОСРЕДИ записи бил JSON → на старте loadJournal ловил ошибку и ОБНУЛЯЛ весь
    // журнал → все id снова переисполнимы (дубли). rename атомарен на той же ФС:
    // основной файл либо старый целый, либо новый целый, никогда не «половина».
    const tmp = JOURNAL_PATH + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(journalCache || {}), 'utf8');
    fs.renameSync(tmp, JOURNAL_PATH);
  } catch (e) { /* журнал best-effort: диск недоступен — не роняем ордер */ }
}

function journalGet(id) { return loadJournal()[id]; }
function journalSet(id, entry) { loadJournal()[id] = { ...entry, ts: Date.now() }; persistJournal(); }

// Пул keep-alive: горстка сокетов переиспользуется для всех опросов и POST
// результатов одного исполнителя. maxSockets мал специально — исполнителю нужна
// одна «висящая» long-poll + изредка POST; не создаём лишних соединений к серверу.
// 16.11: было 4 — с исполнителем Ourbit четыре long-poll (MEXC, XT, BingX, Ourbit) занимали ВСЕ сокеты,
// и POST результата ждал освобождения до 8–13 с (тормозил и заявки MEXC/BingX). 12 — с запасом.
const keepAliveOpts = { keepAlive: true, keepAliveMsecs: 15000, maxSockets: 12, maxFreeSockets: 4 };
const AGENTS = { http: new http.Agent(keepAliveOpts), https: new https.Agent(keepAliveOpts) };

function requestJson(method, path, body, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const url = config.terminal.url.replace(/\/+$/, '') + path;
    const isHttps = url.startsWith('https:');
    const lib = isHttps ? https : http;
    const data = body ? JSON.stringify(body) : null;
    const headers = {
      'X-Arbi-Token': config.terminal.token, Accept: 'application/json', Connection: 'keep-alive',
      // Версия ArbiBrowser + наличие апдейта → терминал покажет «обнови ArbiBrowser».
      'X-Arbi-Version': updateCache.current || '',
      'X-Arbi-Update-Available': updateCache.updateAvailable ? '1' : '0',
      'X-Arbi-Latest': updateCache.latest || '',
    };
    if (data) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(data); }
    const req = lib.request(url, { method, headers, timeout: timeoutMs, agent: isHttps ? AGENTS.https : AGENTS.http }, (res) => {
      let d = '';
      res.on('data', (c) => (d += c));
      res.on('end', () => {
        let parsed = null;
        try { parsed = d ? JSON.parse(d) : null; } catch { /* не JSON */ }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          return reject(new Error((parsed && parsed.error) || `HTTP ${res.statusCode}`));
        }
        resolve(parsed);
      });
    });
    req.on('timeout', () => req.destroy(new Error('таймаут терминала')));
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ── Паник-пауза (кнопка «Стоп запросы» в панели) ─────────────────────────────
// Глобальный тумблер для ВСЕХ бирж: пока включён, циклы НЕ опрашивают терминал —
// значит ноль запросов к биржам (ни ордеров, ни warmup, ни чтения истории) и ноль
// спама в лог. Интенты копятся в очереди терминала и протухают по MAX_INTENT_AGE;
// при снятии паузы опрос возобновляется. Один флаг на процесс — общий для mexc/xt/bingx.
let paused = false;
function setPaused(v) { paused = !!v; }
function isPaused() { return paused; }

/**
 * Создаёт исполнитель для одной биржи.
 * @param {{pendingPath:string, resultPath:string, waitEnv:string, pollEnv:string, defaultWaitMs?:number, defaultPollMs?:number}} cfg
 */
function makeExecutor(cfg) {
  const { pendingPath, resultPath, waitEnv, pollEnv } = cfg;

  /** Обрабатывает ОДНО намерение: исполняет (или dry-run/warmup) и постит результат. */
  async function handleIntent(intent, opts) {
    const log = opts.log || (() => {});
    // Служебные (read/warmup) интенты не несут стороны и количества — печатать их
    // как «buy 0 SYM limit» значит топить лог мнимыми ордерами и путать оператора
    // (жалоба 30.08: «сотни строк про ордера, которых никто не ставил»).
    const kind = intent.warmup ? 'прогрев формы'
      : intent.loginCheck ? 'проверка входа в аккаунт'
      : intent.openLogin ? 'открыть вкладку входа'
      : intent.withdrawCancel ? 'отмена вывода на сайте'
      : intent.withdraw ? 'вывод через сайт'
      : intent.withdrawPrep ? 'подготовка вывода'
      : intent.balance ? 'чтение баланса'
        : intent.orders ? 'чтение истории ордеров'
          : intent.cancelAll ? 'отмена всех ордеров'
            : intent.closeStale ? 'уборка вкладок'
              : intent.depositProbe ? 'счёт получения депозита'
                : null;
    // Уборка не про одну пару: печатаем keep-список, а не intent.symbol — иначе
    // в логе MEXC появлялась «MEY/USDT», хотя MEY торговался на BingX (02.09).
    const wd = intent.withdraw || intent.withdrawPrep;
    const what = intent.withdrawCancel
      ? `${intent.withdrawCancel.coin} ${intent.withdrawCancel.amount}`
      : wd
      ? `${wd.coin} ${wd.amount || ''}${wd.max ? ' (MAX)' : ''} → ${wd.network}${wd.dryRun ? ' [сухой прогон]' : ''}`
      : intent.loginCheck
      ? 'залогинены ли мы на этой бирже'
      : intent.closeStale
      ? `оставить ${(Array.isArray(intent.keepSymbols) && intent.keepSymbols.join(', ')) || '(ни одной пары)'}`
      : intent.depositProbe
        ? `${(Array.isArray(intent.depositProbe.coins) && intent.depositProbe.coins.join(', ')) || '?'}${intent.depositProbe.set ? ' → ' + intent.depositProbe.set : ' (только проверка)'}`
        : intent.symbol;
    log(intent.site
      ? `Намерение ${intent.id} [запрос сайта: ${intent.site.op}${intent.site.coin ? ' ' + intent.site.coin : ''}${intent.site.chain ? ' ' + intent.site.chain : ''}]`
      : kind
      ? `Намерение ${intent.id} [${kind}]: ${what}`
      : `Намерение ${intent.id}: ${intent.side} ${intent.quantity} ${intent.symbol} ${intent.type}${intent.price ? ' @ ' + intent.price : ''}${intent.dryRun ? ' [DRY-RUN]' : ''}${Number(intent.createdAt) > 0 ? ` (возраст ${Math.max(0, Date.now() - Number(intent.createdAt))} мс по часам сервера)` : ''}`);

    // CR-5: РЕАЛЬНЫЙ ордер по этому intent.id уже исполнялся? Тогда НЕ исполняем
    // повторно (риск дубля) — переотправляем сохранённый результат. dry-run/warmup
    // ордер не ставят → журналировать нечего.
    // Чтение сайта (Ourbit: балансы, ордера, история…) повторять безопасно — в журнал не пишем: ~1 запрос в
    // секунду раздувал файл на сутки, а он целиком переписывается на каждой записи (16.11). Отмена и вывод — пишем.
    const readSite = !!(intent.site && !['cancel', 'withdraw'].includes(intent.site.op));
    const journaled = (!readSite && !intent.dryRun && !intent.warmup && !intent.loginCheck && !intent.openLogin && !intent.balance && !intent.orders && !intent.closeStale && !intent.depositProbe && !intent.withdrawPrep) ? journalGet(intent.id) : null;
    if (journaled && journaled.result) {
      log(`Намерение ${intent.id} УЖЕ исполнялось — переотправляю сохранённый результат (без повтора ордера)`);
      await postResultWithRetry(journaled.result, log);
      return { intent, result: journaled.result };
    }
    if (journaled && journaled.inflight) {
      // M2: маркер «в работе» есть, а результата нет → процесс умер МЕЖДУ кликом и
      // записью результата. НЕ переисполняем (риск дубля перевешивает): ордер мог уже
      // уйти на биржу. Отдаём unknown — оператор проверит вручную. at-most-once.
      const result = { intentId: intent.id, ok: false, status: 'unknown', symbol: intent.symbol,
        error: 'Исполнение было прервано — результат неизвестен. Проверьте ордер на бирже вручную (возможно, он выставлен).' };
      log(`Намерение ${intent.id}: прерванное исполнение (inflight) — НЕ повторяю, отдаю unknown`);
      await postResultWithRetry(result, log);
      return { intent, result };
    }

    let result;
    try {
      if (intent.dryRun) {
        result = { intentId: intent.id, ok: true, dryRun: true, message: 'DRY-RUN: ордер не выставлен' };
      } else if (typeof opts.executeIntent === 'function') {
        // M2: пишем маркер «в работе» на диск ДО клика. Если процесс умрёт между
        // кликом и записью результата — на рестарте тот же id вернёт unknown (выше),
        // а не переисполнится вслепую.
        if (!readSite && !intent.balance && !intent.orders && !intent.closeStale && !intent.depositProbe && !intent.loginCheck && !intent.openLogin && !intent.withdrawPrep) journalSet(intent.id, { inflight: true }); // read-интенты, уборка и подготовка вывода — фон, не ордер
        // WATCHDOG: зависший Playwright-вызов (напр. page.evaluate без таймаута на
        // «замёрзшей» вкладке) НИКОГДА не резолвится → contextLock не отпускается →
        // ВЕСЬ цикл этой биржи (и соседних на общем контексте) встаёт навсегда. Гонка
        // с таймером освобождает цикл. Порог ЩЕДРЫЙ (по умолчанию 120с, вдвое больше
        // таймаута продюсера 30с) — легитимный «холодный» ордер укладывается с запасом,
        // фейерит ТОЛЬКО настоящий вис. Зависший промис продолжит в фоне (JS не убить),
        // но к 120с страница заведомо мертва; журнал уже помечен inflight → повторная
        // доставка того же id вернёт unknown, а не переисполнит.
        // Обход «Счёта получения» — не ордер: он идёт по монетам минутами, и общий
        // порог 120 с рубил пачку на середине (17.09: 50 монет = 4+ минуты, результат
        // терялся целиком). Бюджет считается от объёма работы: монета ≈ 30 с, обход
        // всех сетей монеты — вчетверо больше.
        const probe = intent.depositProbe;
        const probeMs = probe
          ? 120000 + (Array.isArray(probe.coins) ? probe.coins.length : 1) * (probe.networks === 'all' ? 120000 : 30000)
          : 0;
        // Вывод через сайт может ждать человека (капча/код) — бюджет от этого ожидания.
        const wdMs = intent.withdraw ? Math.max(30000, Number(process.env.ARBI_MEXC_WITHDRAW_HUMAN_MS) || 300000) + 60000 : 0;
        const watchdogMs = Math.max(Number(process.env.ARBI_EXEC_WATCHDOG_MS || 120000), probeMs, wdMs);
        const r = await Promise.race([
          opts.executeIntent(intent),
          new Promise((resolve) => setTimeout(
            () => resolve({ ok: false, ambiguous: true, error: `Исполнение зависло дольше ${Math.round(watchdogMs / 1000)}с — прервано. Проверьте открытые ордера на бирже перед повтором.` }),
            watchdogMs,
          )),
        ]);
        // symbol пробрасываем всегда — терминал по нему обучает реестр known_tokens
        // (напр. запоминает ST-токен по riskModal из результата order-page).
        result = { intentId: intent.id, symbol: intent.symbol, ...r };
      } else {
        result = { intentId: intent.id, ok: false, error: 'Реальное исполнение не подключено' };
      }
    } catch (e) {
      result = { intentId: intent.id, ok: false, error: e.message };
    }

    // Перегруженная вкладка — причина в тексте ошибки, а не догадка терминала.
    if (result && result.ok === false && typeof result.error === 'string') result.error += slowHint();

    // Записываем результат В ЖУРНАЛ ДО POST: если POST упадёт/процесс умрёт, при
    // повторной доставке того же id мы не переисполним ордер, а отдадим этот результат.
    if (!readSite && !intent.dryRun && !intent.warmup && !intent.loginCheck && !intent.openLogin && !intent.balance && !intent.orders && !intent.closeStale && !intent.depositProbe && !intent.withdrawPrep) journalSet(intent.id, { result });
    await postResultWithRetry(result, log);
    log(`Результат ${intent.id}: ${result.ok ? 'ok' : 'ошибка: ' + (result.error || 'без описания')}${result.dryRun ? ' (dry-run)' : ''}`);
    return { intent, result };
  }

  /**
   * CR-5: доставить результат терминалу с ретраями (at-least-once). Один сетевой
   * сбой раньше терял результат навсегда → терминал переотдавал intent → дубль.
   * 4 попытки с бэкоффом; журнал уже сохранён, так что даже полный провал доставки
   * не приведёт к переисполнению (при повторной доставке id вернём сохранённое).
   */
  async function postResultWithRetry(result, log) {
    const backoffs = [0, 500, 1500, 4000];
    for (let i = 0; i < backoffs.length; i++) {
      if (backoffs[i]) await sleep(backoffs[i]);
      try { await requestJson('POST', resultPath, result); return true; }
      catch (e) { (log || (() => {}))(`POST результата не удался (попытка ${i + 1}/${backoffs.length}): ${e.message}`); }
    }
    return false;
  }

  /**
   * Один заход к /pending (с long-poll, если waitMs>0). Возвращает
   * {processed, longPolled}: processed — сколько намерений обработано;
   * longPolled — сервер реально держал соединение (значит опрос делать не надо).
   */
  /** Только чтения: не ставят, не отменяют, не навигируют торговую вкладку.
   *  Авто-проверка счёта депозита — своя фоновая вкладка, тоже сюда (26.09). */
  // Уборка вкладок и ЛЮБАЯ проверка счёта депозита — тоже фон (11.10): уборка идёт в дорожке
  // 'bg' и ждала там проверку депозита BingX (15–50 с, тот же профиль), а цикл MEXC ждал
  // уборку и не забирал заявки — WOJAK пролежал в очереди 5082 мс при выстреле 569 мс.
  const readIntent = (i) => !!i && !!(i.orders || i.balance || i.loginCheck || i.openLogin || i.depositProbe || i.closeStale || i.withdrawCancel);
  let readChain = Promise.resolve();
  // ПРОГРЕВ ТОЖЕ НЕ ДЕРЖИТ ЦИКЛ (11.10): пока цикл ждал прогрев (главная + части BingX, до 8 с),
  // он не опрашивал /pending — заявка лежала на сервере («возраст 3069 мс»), в нашей очереди
  // её не было, и уступать ей (laneQueued) было некому. Теперь прогревы идут своей цепочкой,
  // цикл сразу возвращается к опросу, заявка встаёт в замок дорожки 'order' за прогревом —
  // и прогрев частей видит её и уступает.
  let warmChain = Promise.resolve();
  // ВЫВОД ЧЕРЕЗ САЙТ — своя цепочка (22.10): вывод может минутами ждать человека (капча),
  // и цикл заявок биржи не должен стоять за ним. Внутри — по одному, как и прежде.
  let wdChain = Promise.resolve();

  async function pollOnce(opts = {}, waitMs = 0) {
    // batch=10: если у юзера в очереди несколько намерений — заберём пачкой за
    // один round-trip (мультиплекс), исполним по очереди, без лишних запросов.
    const path = waitMs > 0 ? `${pendingPath}?wait=${waitMs}&batch=10` : pendingPath;
    const t0 = Date.now();
    const resp = (await requestJson('GET', path, null, waitMs > 0 ? waitMs + 10000 : 15000)) || {};
    const heldMs = Date.now() - t0;
    // Новый сервер вернёт intents[]; старый — intent (или ничего). Поддерживаем оба.
    const intents = Array.isArray(resp.intents) ? resp.intents : (resp.intent ? [resp.intent] : []);
    // Боевой ордер — ВПЕРЁД всего служебного в одном батче. FIFO отдавал бы прогрев
    // (чужая пара, секунды навигации) или чтение истории раньше реального ордера, и
    // деньги ждали бы фон. Стабильная разбивка: реальная работа сохраняет свой порядок,
    // служебное уходит в хвост (и всё равно исполнится — просто после ордера).
    // Чтение истории/баланса сюда добавлено 25.09: у оператора части одной продажи
    // STONK разъехались на 20 с — между ними стояли чтения истории по 8 с каждое.
    const service = (i) => !!i && !!(i.warmup || i.dryRun || i.orders || i.balance || i.closeStale || i.depositProbe || i.loginCheck || i.openLogin || i.withdrawPrep);
    const ordered = [
      ...intents.filter((i) => !service(i)),
      ...intents.filter(service),
    ];
    for (const intent of ordered) {
      // ЧТЕНИЯ НЕ ДЕРЖАТ ЦИКЛ БИРЖИ (ревизия 26.09). История/баланс/проверка входа
      // идут на своих фоновых страницах и в дорожке 'bg' замка, но цикл биржи ждал
      // их целиком: заявка, пришедшая в эту секунду, стояла за чтением (1–8 с).
      // Теперь чтения идут своей цепочкой (по одному, как и прежде), а цикл сразу
      // возвращается к опросу. Правило «фон не стартует, пока торговая занята»
      // соблюдается как было: обработчик чтения проверяет isContextBusy перед стартом.
      if (readIntent(intent)) {
        readChain = readChain
          .then(() => handleIntent(intent, opts))
          .catch((e) => (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`));
        continue;
      }
      if (intent.withdraw) {
        intent.__receivedAt = Date.now(); // возраст вывода — от получения (ожидание в цепочке тоже считается)
        wdChain = wdChain
          .then(() => handleIntent(intent, opts))
          .catch((e) => (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`));
        continue;
      }
      // Подготовки вывода — сразу, без цепочки: модуль сам выстраивает их за своим замком,
      // схлопывает устаревшие (номер — при получении) и уступает выводу.
      if (intent.withdrawPrep) {
        handleIntent(intent, opts).catch((e) => (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`));
        continue;
      }
      // Заявка с разрешением «прямым запросом» (intent.hints.direct, MEXC) — не ждём её в цикле:
      // прямые заявки идут параллельно, а обычный путь (форма) всё равно встаёт за замок вкладки.
      if ((intent.hints && intent.hints.direct && !intent.dryRun && !intent.warmup && intent.type === 'limit') || intent.site) {
        handleIntent(intent, opts).catch((e) => (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`));
        continue;
      }
      if (intent.warmup) {
        warmChain = warmChain
          .then(() => handleIntent(intent, opts))
          .catch((e) => (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`));
        continue;
      }
      try { await handleIntent(intent, opts); }
      catch (e) { (opts.log || (() => {}))(`Обработка намерения не удалась: ${e.message}`); }
    }
    // Считаем long-poll состоявшимся, только если сервер держал соединение
    // близко к запрошенному wait (значит поддерживает ?wait). Иначе — старый
    // сервер вернул сразу пусто → нужен sleep-фолбэк.
    const longPolled = waitMs > 0 && heldMs >= Math.max(waitMs - 500, 500);
    return { processed: intents.length, longPolled };
  }

  /**
   * Запускает цикл. Возвращает функцию остановки.
   * @param {{intervalMs?:number, log?:(m:string)=>void, executeIntent?:Function}} [opts]
   */
  function startLoop(opts = {}) {
    // 25с long-poll по умолчанию: сервер отдаёт намерение мгновенно, а вхолостую
    // держится одно соединение (переустанавливается раз в ~25с). Переопределяемо.
    const waitMs = Number(process.env[waitEnv] || cfg.defaultWaitMs || 25000);
    // Фолбэк-интервал, только если сервер БЕЗ long-poll (старый билд).
    const idleSleepMs = opts.intervalMs || Number(process.env[pollEnv] || cfg.defaultPollMs || 100);
    ensureUpdateChecks(); // фоновая проверка обновления ArbiBrowser (кэш → заголовки /pending)
    let stopped = false;
    (async function loop() {
      while (!stopped) {
        // Паник-пауза оператора: НЕ опрашиваем терминал — ноль запросов к биржам и
        // в лог. Проверяем часто, чтобы возобновление было мгновенным.
        if (paused) { await sleep(300); continue; }
        let processed = 0;
        let longPolled = false;
        try {
          ({ processed, longPolled } = await pollOnce(opts, waitMs));
        } catch (e) {
          (opts.log || (() => {}))(`Опрос не удался: ${e.message}`);
          await sleep(1000); // сеть/сервер недоступен — не долбим в тайтлуп
          continue;
        }
        if (stopped) break;
        // Обработали что-то ИЛИ сервер честно держал long-poll → сразу следующий
        // заход (без простоя). Sleep нужен только если старый сервер вернул
        // пусто мгновенно — тогда не бьём его чаще, чем раз в idleSleepMs.
        if (processed === 0 && !longPolled) await sleep(idleSleepMs);
      }
    })();
    return () => { stopped = true; };
  }

  return { pollOnce, startLoop };
}

module.exports = { requestJson, makeExecutor, setPaused, isPaused, _journal: { loadJournal, persistJournal, journalGet, journalSet, JOURNAL_PATH, JOURNAL_TTL_MS } };

'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { mexcCoinId } = require('./mexc-order-page');

const H = (c) => c.repeat(32);
const USDT = H('e');
// Подставная страница: список рынков и слушатель ответов профиля (ответ страницы пары).
function fakePage(lists) {
  const handlers = [];
  const ctx = { on: (ev, fn) => { if (ev === 'response') handlers.push(fn); } };
  let calls = 0;
  return {
    calls: () => calls,
    context: () => ctx,
    evaluate: async () => { calls++; return lists[Math.min(calls - 1, lists.length - 1)]; },
    pageSaysTrade: async (d) => { for (const fn of handlers) await fn({ url: () => 'https://www.mexc.com/api/platform/spot/market-v2/web/symbol/trade?x=1', json: async () => ({ data: d }) }); },
  };
}

test('mexcCoinId: тикер ровно один в списке рынков; не к USDT — null', async () => {
  const p = fakePage([[{ vn: 'AAA', cd: H('a'), mcd: USDT, ps: 6 }, { vn: 'BBB', cd: H('b'), mcd: USDT, ps: 4 }]]);
  const e = await mexcCoinId(p, 'AAA_USDT');
  assert.strictEqual(e.cd, H('a'));
  assert.strictEqual(e.mcd, USDT);
  assert.strictEqual(await mexcCoinId(p, 'AAA_USDC'), null);
});

test('mexcCoinId: новый листинг — нет в списке → ответ страницы пары; пара не к USDT — не берём', async () => {
  // Кэш списка общий на процесс (прошлый тест его заполнил) — монеты CCC/DDD в нём нет: перезапрос
  // списка ограничен 30 с, поэтому источник — ответ страницы пары.
  const p = fakePage([[{ vn: 'AAA', cd: H('a'), mcd: USDT }]]);
  assert.strictEqual(await mexcCoinId(p, 'CCC_USDT'), null); // страница ещё ничего не сказала
  await p.pageSaysTrade({ vn: 'CCC', mn: 'USDT', cd: H('c'), mcd: USDT, ps: 8 });
  const e = await mexcCoinId(p, 'CCC_USDT');
  assert.strictEqual(e.cd, H('c'));
  assert.strictEqual(e.src, 'страница пары');
  await p.pageSaysTrade({ vn: 'DDD', mn: 'USDC', cd: H('d'), mcd: USDT }); // не к USDT — не берём
  assert.strictEqual(await mexcCoinId(p, 'DDD_USDT'), null);
});

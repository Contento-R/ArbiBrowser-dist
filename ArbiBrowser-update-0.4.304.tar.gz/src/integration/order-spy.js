'use strict';

/**
 * РАЗВЕДКА «заявка запросом» для BingX и XT (оператор 06.11: на MEXC заявка на любую монету уходит
 * запросом из одной служебной вкладки — проверить ту же схему на других биржах). Ничего не ставит и
 * не отменяет: на обычной заявке формой пишет в журнал устройство её запроса — адрес, вид тела, ИМЕНА
 * полей тела, параметров адреса и нестандартных заголовков (один раз на биржу+пару+сторону), а на
 * отмене ОДНОЙ заявки на сайте — каким запросом сайт её отменяет. Значения (подписи, токены, cookies,
 * цены) в журнал не пишутся никогда.
 */

const seen = new Set();
// Заголовки, которые ставит сам браузер, — не интересны; остальные (подписи, метки устройства) — именами.
const STD_HDR = /^(cookie|host|content-length|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|pragma|cache-control|content-type|sec-|:)/i;

function bodyKeys(raw) {
  if (!raw) return { kind: 'пустое', keys: [] };
  try {
    const j = JSON.parse(raw);
    if (j && typeof j === 'object' && !Array.isArray(j)) return { kind: 'JSON', keys: Object.keys(j) };
    return { kind: 'JSON-не объект', keys: [] };
  } catch { /* не JSON */ }
  try {
    const keys = [...new URLSearchParams(raw).keys()];
    if (keys.length) return { kind: 'форма', keys };
  } catch { /* не форма */ }
  return { kind: `не разобрано (${raw.length} байт)`, keys: [] };
}

/** Запрос постановки заявки (Playwright Request) → строка журнала, один раз на exchange+tag+путь. */
async function spyPlace(exchange, req, tag) {
  try {
    const u = new URL(req.url());
    const key = `${exchange}|${tag}|${u.pathname}`;
    if (seen.has(key)) return;
    seen.add(key);
    let h = {};
    try { h = await req.allHeaders(); } catch { h = req.headers(); }
    const { kind, keys } = bodyKeys(req.postData() || '');
    const ct = String(h['content-type'] || '?').split(';')[0];
    const hdrs = Object.keys(h).filter((k) => !STD_HDR.test(k));
    console.log(`[${exchange}-exec] [разведка заявки] ${tag}: ${req.method()} ${u.host}${u.pathname}; тело ${kind} (${ct}): ${keys.join(',') || '—'}; параметры адреса: ${[...u.searchParams.keys()].join(',') || '—'}; особые заголовки: ${hdrs.join(',') || '—'}`);
  } catch { /* разведка не мешает работе */ }
}

/** Отмена на сайте (ручная или наша) — каким запросом; один слушатель на профиль и биржу. */
function spyCancel(context, exchange, hostRe) {
  const flag = `__arbiCancelSpy_${exchange}`;
  if (!context || context[flag]) return;
  context[flag] = true;
  context.on('response', async (r) => {
    try {
      const q = r.request();
      if (q.method() !== 'POST' && q.method() !== 'DELETE') return;
      const u = new URL(q.url());
      if (!hostRe.test(u.hostname) || !/cancel/i.test(u.pathname)) return;
      const { kind, keys } = bodyKeys(q.postData() || '');
      let code = null;
      try { const j = await r.json(); code = j.code ?? j.rc ?? null; } catch { /* не JSON */ }
      console.log(`[${exchange}-exec] [разведка отмены] ${q.method()} ${u.host}${u.pathname}; тело ${kind}: ${keys.join(',') || '—'}; параметры адреса: ${[...u.searchParams.keys()].join(',') || '—'}; ответ HTTP ${r.status()} code=${code}`);
    } catch { /* разведка не мешает работе */ }
  });
}

module.exports = { spyPlace, spyCancel, bodyKeys };

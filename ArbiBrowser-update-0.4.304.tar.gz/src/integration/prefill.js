'use strict';
/**
 * prefill.js — ЧЕРНОВИК ЗАЯВКИ в форме биржи (оператор 22.10, пилот MEXC/XT/BingX).
 *
 * Терминал шлёт сторону/цену/количество из панели заявки при каждом изменении (прогрев
 * с полем `prefill`). Здесь их вписываем в форму тёплой вкладки пары заранее — реальной
 * заявке остаётся клик. Кнопку ордера черновик НЕ ЖМЁТ НИКОГДА: кликает только настоящее
 * намерение ордера, и его executeIntent сверяет поля с СОБОЙ (priceFresh/closeEnough),
 * а не с черновиком; не совпало — перебивает, как без черновика.
 *
 * Правила оператора:
 *   • продажа: монеты на счёте меньше нужного (депозит ещё в пути, биржа не даёт вписать
 *     больше остатка) — вписываем сторону и цену, количество впишет заявка;
 *   • покупка: сумма больше доступных USDT — вписываем количество на доступное
 *     (запоминаем остаток на странице — заявка по нему урежется так же, clampBuyToQuote).
 * Ждёт настоящая заявка — черновик уступает (не держит денежную дорожку).
 */
const { laneQueued } = require('./context-lock');
const { priceFresh, fieldFresh, pickBaseAvail } = require('./order-utils');

const AVAIL_RE = /(Дост\.|Доступно|Available|Avbl|可用)/i;
/** Остаток актива на форме («Доступно 1,234 USDT»), null — не прочитан. Та же разметка, что baseAvailOnPage BingX. */
async function availOnPage(page, asset) {
  const texts = await page.evaluate((rs) => {
    const rx = new RegExp(rs, 'i');
    const out = [];
    for (const e of document.querySelectorAll('div,span,label,p')) {
      if (e.children.length > 3 || e.offsetParent === null || !rx.test(e.textContent || '')) continue;
      for (const n of [e, e.parentElement]) {
        const t = n ? (n.textContent || '').replace(/\s+/g, ' ').trim() : '';
        if (t && t.length < 120 && /\d/.test(t)) out.push(t);
      }
    }
    return out;
  }, AVAIL_RE.source).catch(() => []);
  return pickBaseAvail(texts, asset);
}

const decOf = (s) => { const m = String(s).match(/\.(\d+)$/); return m ? m[1].length : 0; };
/** Вниз до dec знаков, без экспоненты. */
const floorStr = (v, dec) => { const k = 10 ** Math.min(dec, 12); return (Math.floor(v * k) / k).toFixed(Math.min(dec, 12)).replace(/\.?0+$/, ''); };
/** Сколько купить на доступные USDT (0,1 % запаса на округление/комиссию); null — урезать не нужно. */
function buyCap(price, qty, avail, dec) {
  if (!(avail > 0) || !(price > 0) || !(qty > 0) || price * qty <= avail * 1.001) return null;
  return floorStr((avail * 0.999) / price, dec);
}

/**
 * Вписать черновик. x — адаптер биржи:
 *   setSide(page, side) → bool · readVals(page) → [цена, кол-во] · write(page, price|null, qty|null)
 */
// Сторона не встала (нет монеты → вместо «Продать» кнопка «Депозит», страница не отвечает) — черновик
// этой пары и стороны не пробуем SIDE_FAIL_PAUSE_MS: оператор 05.11, OBI — каждые 20 с по 17–20 с попыток
// держали браузер, заявка PROM ждала 11–23 с. Пара|сторона: та же монета на покупку не страдает.
const SIDE_FAIL_PAUSE_MS = Math.max(0, Number(process.env.ARBI_PREFILL_SIDE_PAUSE_MS) || 120_000);
const sideFailUntil = new Map();
async function runPrefill(context, page, pair, pf, x, log) {
  const t0 = Date.now();
  const busy = () => laneQueued(context, 'order') > 1;
  if (busy()) return { ok: true, skipped: 'ждёт заявка' };
  const sideKey = `${pair}|${pf.side}`;
  const pausedUntil = sideFailUntil.get(sideKey) || 0;
  if (pausedUntil > Date.now()) return { ok: true, skipped: `сторона (пауза ещё ${Math.ceil((pausedUntil - Date.now()) / 1000)} с)` };
  if (!(await x.setSide(page, pf.side))) {
    sideFailUntil.set(sideKey, Date.now() + SIDE_FAIL_PAUSE_MS);
    log(`Черновик: сторона ${pf.side} не встала (${Date.now() - t0} мс) — поля не трогаю, черновики ${pair} ${pf.side} не пробую ${Math.round(SIDE_FAIL_PAUSE_MS / 1000)} с`);
    return { ok: true, skipped: 'сторона' };
  }
  sideFailUntil.delete(sideKey);
  if (busy()) return { ok: true, skipped: 'ждёт заявка' };
  const p = Number(pf.price);
  let qStr = Number(pf.quantity) > 0 ? String(pf.quantity) : '';
  let note = '';
  if (pf.side === 'buy') {
    const usdt = await availOnPage(page, 'USDT');
    page.__arbiQuoteAvail = usdt != null ? { v: usdt, at: Date.now() } : null;
    const cap = qStr ? buyCap(p, Number(qStr), usdt, decOf(qStr) || 6) : null;
    if (cap) { note = `на ${(p * Number(qStr)).toFixed(2)} USDT, доступно ${usdt} — вписал на доступное`; qStr = cap; }
  } else if (qStr) {
    const have = await availOnPage(page, String(pair).split('_')[0]);
    if (have == null || have + 1e-12 < Number(qStr)) { note = `монеты на счёте ${have ?? '?'} < ${qStr} — количество впишет заявка`; qStr = ''; }
  }
  if (busy()) return { ok: true, skipped: 'ждёт заявка' };
  const v = await x.readVals(page).catch(() => []);
  const needP = !priceFresh(v[0], p);
  // Количество не вписываем (продажа больше остатка) — стираем прежнее: чужое число в поле
  // переводит форму в ошибку «больше доступного», а заявка всё равно впишет своё.
  const clearQ = !qStr && Number(String(v[1] || '').replace(/[,\s]/g, '')) > 0;
  const needQ = clearQ || (!!qStr && !fieldFresh(v[1], Number(qStr)));
  if (needP || needQ) await x.write(page, needP ? String(pf.price) : null, needQ ? qStr : null, v);
  page.__arbiPrefill = { side: pf.side, price: String(pf.price), qty: qStr, at: Date.now() };
  log(`Черновик ${pf.side} @ ${pf.price}${qStr ? ` × ${qStr}` : ''}: ${needP || needQ ? 'вписан' : 'уже в форме'}${note ? ` (${note})` : ''}, ${Date.now() - t0} мс`);
  return { ok: true, prefilled: true };
}

/**
 * Заявка на покупку больше доступных USDT (оператор 22.10) — ставим на доступное.
 * Читаем остаток только когда черновик минуту назад уже видел нехватку: остальные
 * заявки этой проверкой не платят. Без черновика поведение прежнее.
 */
async function clampBuyToQuote(page, intent, log) {
  if (intent.side !== 'buy') return intent;
  const c = page.__arbiQuoteAvail;
  const p = Number(intent.price); const q = Number(intent.quantity);
  if (!c || Date.now() - c.at > 60_000 || !(p * q > c.v * 1.001)) return intent;
  const usdt = await availOnPage(page, 'USDT');
  const cap = buyCap(p, q, usdt, decOf(intent.quantity) || 6);
  if (!cap) return intent;
  log(`Покупка на ${(p * q).toFixed(2)} USDT больше доступного (${usdt} USDT) — ставлю на доступное: ${cap} вместо ${intent.quantity}`);
  return { ...intent, quantity: cap };
}

module.exports = { runPrefill, clampBuyToQuote, availOnPage, buyCap };

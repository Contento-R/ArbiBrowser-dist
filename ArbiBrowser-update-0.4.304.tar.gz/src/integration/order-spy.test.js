'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { bodyKeys } = require('./order-spy');

test('bodyKeys: JSON — имена полей верхнего уровня', () => {
  assert.deepStrictEqual(bodyKeys('{"symbol":"A_USDT","price":"1","sign":"x"}'), { kind: 'JSON', keys: ['symbol', 'price', 'sign'] });
});

test('bodyKeys: форма — имена параметров', () => {
  assert.deepStrictEqual(bodyKeys('symbol=a_usdt&side=BUY&price=1'), { kind: 'форма', keys: ['symbol', 'side', 'price'] });
});

test('bodyKeys: пусто и не объект', () => {
  assert.deepStrictEqual(bodyKeys(''), { kind: 'пустое', keys: [] });
  assert.deepStrictEqual(bodyKeys('[1,2]'), { kind: 'JSON-не объект', keys: [] });
});

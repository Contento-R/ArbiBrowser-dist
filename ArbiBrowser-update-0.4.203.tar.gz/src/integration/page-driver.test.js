'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { driverFor, PROFILES } = require('./page-driver');

const SEL = { numberInput: 'input.n', input: 'input.n', submit: 'button.s', submitBuy: 'button.b', submitSell: 'button.sl' };

// Дубль страницы/поля Playwright: пишем в журнал, что было вызвано и с чем.
function fakePage({ evaluate, $eval } = {}) {
  const calls = [];
  return {
    calls,
    keyboard: {
      press: async (k) => calls.push(['press', k]),
      insertText: async (s) => calls.push(['insert', s]),
      type: async (s) => calls.push(['type', s]),
    },
    evaluate: evaluate || (async () => ({ closed: 0, text: '' })),
    $eval: $eval || (async () => { throw new Error('нет'); }),
  };
}
// `evaluate` отдаёт ЗНАЧЕНИЕ поля (так его читает typeNumber, чтобы отличить принятую
// вставку от чужого значения в поле). stuck=true — поле приняло последнюю вставку;
// stuck=false — осталось пустым; строка/функция — что именно «показывает» поле.
function fakeHandle(calls, { failFirst = false, stuck = true, shows = null } = {}) {
  let n = 0;
  const lastInsert = () => { const c = [...calls].reverse().find((x) => x[0] === 'insert'); return c ? c[1] : ''; };
  return {
    click: async (o) => { calls.push(['click', o]); if (failFirst && n++ === 0) throw new Error('перекрыто'); },
    evaluate: async () => {
      if (typeof shows === 'function') return shows(lastInsert());
      if (shows != null) return shows;
      return stuck ? lastInsert() : '';
    },
  };
}

test('профили: три биржи, регэкспы собираются, неизвестная биржа — ошибка', () => {
  assert.deepEqual(Object.keys(PROFILES).sort(), ['bingx', 'mexc', 'xt']);
  for (const p of Object.values(PROFILES)) {
    new RegExp(p.modal.block, 'i'); new RegExp(p.modal.ok, 'i');
    if (p.modal.risk) new RegExp(p.modal.risk, 'i');
    if (p.overlays.hide) new RegExp(p.overlays.hide, 'i');
  }
  assert.throws(() => driverFor('okx', SEL), /неизвестная/);
  assert.throws(() => driverFor('bingx', { submit: 'x' }), /SELECTORS\.numberInput/);
});

test('typeNumber BingX/XT: вставка одним событием, поле приняло → без посимвольного ввода', async () => {
  const page = fakePage();
  const h = fakeHandle(page.calls);
  await driverFor('bingx', SEL).typeNumber(page, h, '0.0123');
  const kinds = page.calls.map((c) => c[0]);
  assert.deepEqual(kinds, ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].timeout, 4000);
  assert.equal(page.calls[0][1].force, false);
});

test('typeNumber: биржа усекла хвост по шагу лота → вставка засчитана, посимвольного ввода нет', async () => {
  const page = fakePage();
  // XT показывает усечённое количество с хвостовой точкой — это ПРИНЯТАЯ вставка.
  const h = fakeHandle(page.calls, { shows: '386204.' });
  await driverFor('xt', SEL).typeNumber(page, h, '386204.76576681');
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert']);
});

test('typeNumber: в поле осталось ЧУЖОЕ значение прошлого ордера → вставка НЕ засчитана', async () => {
  const page = fakePage();
  const h = fakeHandle(page.calls, { shows: '92.37' });
  await driverFor('xt', SEL).typeNumber(page, h, '95.23');
  // Обе вставки (точка, затем запятая) отвергнуты → добиваем посимвольно.
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert', 'click', 'press', 'insert', 'click', 'press', 'type']);
});

test('typeNumber: поле ждёт запятую — точка не принята, вставка с запятой засчитана', async () => {
  const page = fakePage();
  // Поле принимает значение, только если разделитель — запятая.
  const h = fakeHandle(page.calls, { shows: (ins) => (ins.includes(',') ? ins : '') });
  await driverFor('xt', SEL).typeNumber(page, h, '12.5');
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert', 'click', 'press', 'insert']);
  assert.equal(page.calls.filter((c) => c[0] === 'insert').pop()[1], '12,5');
});

test('typeNumber XT direct: поле количества — сразу посимвольно, без вставки', async () => {
  const page = fakePage();
  await driverFor('xt', SEL).typeNumber(page, fakeHandle(page.calls), '12345', { direct: true });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
});

// 0.4.203: MEXC перешёл на вставку (оператор проверил Ctrl+V руками). Посимвольный
// набор остался фолбэком — и внутри typeNumber, и на сессию (MEXC_INSERT_OK).
test('typeNumber MEXC: force-клик 1200мс, значение идёт ВСТАВКОЙ; счётчики st', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls), '777', { st });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].force, true);
  assert.equal(page.calls[0][1].timeout, 1200);
  assert.equal(st.inserted, 1, 'поле засчитано как вставленное');
  assert.equal(st.typeN, 0, 'посимвольного набора не было');
  assert.equal(st.keysN, 0);
  assert.equal(st.fallback, 0);
});

test('typeNumber MEXC: поле не приняло вставку → добиваем посимвольно', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  // Поле остаётся пустым, что бы мы ни вставляли (анти-бот/React не принял).
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { stuck: false }), '77.5', { st });
  assert.equal(page.calls.filter((c) => c[0] === 'type').length, 1, 'фолбэк на клавиатуру сработал');
  assert.equal(st.keysN, 4);
  assert.equal(st.typeN, 1);
});

test('typeNumber MEXC direct: вставка выключена на сессию → сразу посимвольно', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls), '777', { st, direct: true });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
  assert.equal(st.typeN, 1);
  assert.equal(st.keysN, 3);
});

test('typeNumber: сорванный клик → закрыть модалку → повтор с force; st.fallback растёт', async () => {
  let modalCalls = 0;
  const page = fakePage({ evaluate: async () => { modalCalls++; return { closed: 0, text: '' }; } });
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { failFirst: true }), '5', { st });
  const clicks = page.calls.filter((c) => c[0] === 'click');
  assert.equal(clicks.length, 2);
  assert.equal(clicks[1][1].force, true);
  assert.equal(modalCalls, 1);
  assert.equal(st.fallback, 1);
});

test('dismissBlockingModal: risk-модалка ставит __arbiSawRisk (BingX/XT), MEXC — нет', async () => {
  const risky = async () => ({ closed: 1, text: 'Предупреждение о риске: инновационная зона' });
  for (const [ex, want] of [['bingx', true], ['xt', true], ['mexc', undefined]]) {
    const page = fakePage({ evaluate: risky });
    const r = await driverFor(ex, SEL).dismissBlockingModal(page);
    assert.equal(r.closed, 1);
    assert.equal(page.__arbiSawRisk, want, ex);
  }
  // Баланс — не риск.
  const page = fakePage({ evaluate: async () => ({ closed: 1, text: 'Insufficient balance' }) });
  await driverFor('bingx', SEL).dismissBlockingModal(page);
  assert.equal(page.__arbiSawRisk, undefined);
});

test('dismissOverlays: опрос без крестика → Escape (только BingX); возвращает число', async () => {
  const page = fakePage({ evaluate: async () => ({ closed: 2, surveyLeft: true }) });
  assert.equal(await driverFor('bingx', SEL).dismissOverlays(page), 2);
  assert.deepEqual(page.calls, [['press', 'Escape']]);
  const bad = fakePage({ evaluate: async () => { throw new Error('страница закрыта'); } });
  assert.equal(await driverFor('mexc', SEL).dismissOverlays(bad), 0);
});

test('isSubmitReady: side-режим пробует сторону → общий → true; MEXC — одна evaluate', async () => {
  const asked = [];
  const page = fakePage({ $eval: async (s) => { asked.push(s); throw new Error('нет'); } });
  assert.equal(await driverFor('xt', SEL).isSubmitReady(page, 'sell'), true);
  assert.deepEqual(asked, ['button.sl', 'button.s']);
  const ok = fakePage({ $eval: async (s) => s === 'button.b' });
  assert.equal(await driverFor('bingx', SEL).isSubmitReady(ok, 'buy'), true);
  let sel = null;
  const mexc = fakePage({ evaluate: async (fn, s) => { sel = s; return false; } });
  assert.equal(await driverFor('mexc', SEL).isSubmitReady(mexc, 'sell'), false);
  assert.equal(sel, 'button.s');
});

test('loginWall: «Log In» на месте кнопки ордера или в шапке → wall; Buy → нет', async () => {
  const d = driverFor('mexc', SEL);
  const mk = (ret) => ({ evaluate: async (fn, sel) => ret });
  assert.equal((await d.loginWall(mk({ wall: true, text: 'Log In / Sign Up' }))).wall, true);
  assert.equal((await d.loginWall(mk({ wall: false, text: 'Buy WOJAK' }))).wall, false);
  assert.equal((await d.loginWall({ evaluate: async () => { throw new Error('closed'); } })).wall, false);
  const { loginRequiredError } = require('./page-driver');
  assert.match(loginRequiredError('MEXC'), /нет входа в аккаунт MEXC/);
});

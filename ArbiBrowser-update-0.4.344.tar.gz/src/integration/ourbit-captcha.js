'use strict';

/**
 * ourbit-captcha.js — КАПЧА ВЫВОДА OURBIT ДЛЯ ПРЯМОГО ЗАПРОСА (оператор 16.11: «вывод за 1–2 секунды»).
 *
 * Запись 16.11: страница вывода при загрузке незаметно проходит Geetest v4 (gcaptcha4 load → verify, ответ —
 * seccode: captcha_id, lot_number, pass_token, gen_time, captcha_output) и держит результат. По «Отправить» шлёт его
 * в заголовке captcha-token на GET /ucgateway/captcha_api/captcha/robot/robot.assets.withdraw — после этого сайт
 * принимает подготовку и подтверждение вывода (без шага — 60008).
 *
 * Здесь: (1) ловим seccode из ответов verify во вкладках Ourbit (в памяти, не на диске); (2) при первом выводе формой
 * сравниваем заголовок captcha-token страницы с пойманными seccode и выводим ФОРМАТ — шаблон с местами полей
 * («{lot_number}» и т.п.) и разделителями; шаблон без значений сохраняется на диск; (3) прямой вывод берёт свежий
 * неиспользованный seccode страницы и собирает заголовок по шаблону. Заголовки ucenter-token / timezone-login /
 * device-id — из запросов самой страницы к /ucgateway (только в памяти, в журнал не пишутся).
 */

const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');

const FIELDS = ['captcha_output', 'pass_token', 'lot_number', 'captcha_id', 'gen_time'];
const MAX_AGE_MS = Math.max(30_000, Number(process.env.ARBI_OURBIT_CAPTCHA_MAX_AGE_MS) || 150_000);
const FILE = () => path.join(config.reportsDir, 'ourbit-captcha.json');
const ROBOT_RE = /\/ucgateway\/captcha_api\/captcha\/robot\//;

const codes = new WeakMap(); // context → [{ seccode, at, page, used }]
const ucHdr = new WeakMap(); // context → { 'ucenter-token', 'timezone-login', 'device-id', language }
let template = null;
try { template = JSON.parse(fs.readFileSync(FILE(), 'utf8')).template || null; } catch { template = null; }

const log = (m) => console.log(`[ourbit-exec] [капча сайта] ${m}`);

/**
 * Вид «geetest <base64(JSON)>» (журнал 16.11: «geetest «882»==», 892 симв.): JSON внутри — поля seccode под своими
 * именами. Шаблон — префикс + список [ключ JSON → поле seccode, число?] в порядке ключей; принимается, только если
 * сборка из этого seccode дала заголовок СИМВОЛ В СИМВОЛ.
 */
function learnB64(token, seccode) {
  const m = String(token).match(/^(\S+ )?([A-Za-z0-9+/]+={0,2})$/);
  if (!m) return null;
  let obj = null;
  try { obj = JSON.parse(Buffer.from(m[2], 'base64').toString('utf8')); } catch { return null; }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;
  const keys = [];
  for (const [k, v] of Object.entries(obj)) {
    const f = FIELDS.find((x) => seccode[x] != null && String(seccode[x]) === String(v));
    if (!f) return null; // поле не из seccode — собрать не сможем
    keys.push({ k, f, num: typeof v === 'number' });
  }
  const template = { kind: 'b64json', prefix: m[1] || '', keys };
  return buildWith(template, seccode) === String(token) ? { template, hits: keys.length, clean: keys.length >= 2 } : null;
}

function buildWith(t, seccode) {
  if (t && t.kind === 'b64json') {
    const o = {};
    for (const { k, f, num } of t.keys) o[k] = num ? Number(seccode[f]) : String(seccode[f] ?? '');
    return t.prefix + Buffer.from(JSON.stringify(o), 'utf8').toString('base64');
  }
  return String(t).replace(/\{([a-z_]+)(\|u)?\}/g, (_, f, u) => (u ? encodeURIComponent(String(seccode[f] ?? '')) : String(seccode[f] ?? '')));
}

/** Шаблон заголовка по пойманному seccode: значения полей → {поле} (или {поле|u} в URL-кодировке). */
function learn(token, seccode) {
  const b = learnB64(token, seccode);
  if (b) return b;
  let t = String(token);
  let hits = 0;
  for (const f of FIELDS) {
    const v = seccode[f] == null ? '' : String(seccode[f]);
    if (!v) continue;
    const u = encodeURIComponent(v);
    if (t.includes(v)) { t = t.split(v).join(`{${f}}`); hits += 1; } else if (u !== v && t.includes(u)) { t = t.split(u).join(`{${f}|u}`); hits += 1; }
  }
  const rest = t.replace(/\{[a-z_]+(\|u)?\}/g, '');
  return { template: t, hits, clean: hits >= 2 && !/[A-Za-z0-9]{9,}/.test(rest) };
}

function build(seccode) {
  return template ? buildWith(template, seccode) : null;
}

const masked = (s) => String(s).replace(/[A-Za-z0-9]{9,}/g, (m) => `«${m.length}»`).slice(0, 300);

function onResponse(page, resp) {
  const u = resp.url();
  if (!/gcaptcha4\.geetest\.com\/verify/.test(u)) return;
  resp.text().then((t) => {
    const m = String(t).match(/\(([\s\S]*)\)\s*;?\s*$/);
    let j = null; try { j = JSON.parse(m ? m[1] : t); } catch { return; }
    const d = j && j.data;
    if (!d || d.result !== 'success' || !d.seccode || !d.seccode.pass_token) return;
    const ctx = page.context();
    const list = (codes.get(ctx) || []).filter((x) => Date.now() - x.at < 10 * 60_000).slice(-5);
    list.push({ seccode: d.seccode, at: Date.now(), page, used: false });
    codes.set(ctx, list);
  }).catch(() => {});
}

function onRequest(page, req) {
  const u = req.url();
  if (!/^https:\/\/www\.ourbit\.com\/ucgateway\//.test(u)) return;
  req.allHeaders().then((h) => {
    const ctx = page.context();
    const keep = {};
    for (const k of ['ucenter-token', 'timezone-login', 'device-id', 'language']) if (h[k]) keep[k] = h[k];
    if (keep['ucenter-token']) ucHdr.set(ctx, keep);
    const tok = h['captcha-token'];
    if (!ROBOT_RE.test(u) || !tok) return;
    // Страница отдала seccode — он израсходован (и наш прямой путь его не возьмёт).
    const list = codes.get(ctx) || [];
    for (const x of list.slice().reverse()) {
      const l = learn(tok, x.seccode);
      if (l.hits) { x.used = true; x.page.__seccodeUsed = true; }
      if (!l.clean) continue;
      if (JSON.stringify(template) !== JSON.stringify(l.template)) {
        template = l.template;
        try { fs.mkdirSync(path.dirname(FILE()), { recursive: true }); fs.writeFileSync(FILE(), JSON.stringify({ template, at: new Date().toISOString() })); } catch { /* живёт до перезапуска */ }
        const shown = typeof template === 'string' ? template.slice(0, 200) : `${template.prefix}base64(JSON: ${template.keys.map((x) => `${x.k}←${x.f}`).join(', ')})`;
        log(`формат заголовка капчи разобран: «${shown}» — следующий вывод пойдёт прямым запросом`);
      }
      return;
    }
    if (!template) {
      let inner = '';
      try {
        const m = String(tok).match(/^(\S+ )?([A-Za-z0-9+/]+={0,2})$/);
        const o = m && JSON.parse(Buffer.from(m[2], 'base64').toString('utf8'));
        if (o && typeof o === 'object') inner = `, внутри JSON: ${Object.entries(o).map(([k, v]) => `${k}=${typeof v}(${String(v).length})`).join(', ')}`;
      } catch { /* не base64(JSON) */ }
      log(`формат заголовка капчи не разобран (длина ${String(tok).length}, вид «${masked(tok)}»${inner}, пойманных ответов капчи ${list.length}) — выводы пока формой`);
    }
  }).catch(() => {});
}

/** Свежий неиспользованный seccode страницы → значение captcha-token (seccode помечается израсходованным). */
function take(context) {
  if (!template) return null;
  const list = codes.get(context) || [];
  const x = list.slice().reverse().find((c) => !c.used && Date.now() - c.at < MAX_AGE_MS && !c.page.isClosed());
  if (!x) return null;
  x.used = true; x.page.__seccodeUsed = true;
  return build(x.seccode);
}

const hasFresh = (context) => (codes.get(context) || []).some((c) => !c.used && Date.now() - c.at < MAX_AGE_MS && !c.page.isClosed());
const headersOf = (context) => ({ ...(ucHdr.get(context) || {}) });
const known = () => !!template;

module.exports = { onResponse, onRequest, take, hasFresh, headersOf, known, ROBOT_PATH: '/ucgateway/captcha_api/captcha/robot/robot.assets.withdraw', _learn: learn };

'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { _coinGate: gate, _rowCoin: rowCoin, executeIntent } = require('./ourbit-order-page');

const now = Date.now();
const base = { symbol: 'VINE/USDT', side: 'buy', type: 'limit', price: '0.009', quantity: '100', createdAt: now };
const v = [{ chain: 'solana', contract: '6ajcp7…pump' }];

test('без подтверждения терминала заявка не уходит', () => {
  assert.match(gate({ ...base }), /не подтвердил/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE2', manual: false, verified: v, at: now } } }), /не подтвердил/);
});

test('автоматике нужна свежая сверка по контракту', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now } } }), null);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: null, at: now } } }), /не сверена/);
  assert.match(gate({ ...base, hints: { ourbit: { ticker: 'VINE', manual: false, verified: v, at: now - 11 * 60_000 } } }), /устарела/);
});

test('ручная заявка с экрана — без контракта', () => {
  assert.equal(gate({ ...base, hints: { ourbit: { ticker: 'vine', manual: true, verified: null, at: now } } }), null);
});

test('монета строки ордера: currency или symbol', () => {
  assert.equal(rowCoin({ currency: 'vine' }), 'VINE');
  assert.equal(rowCoin({ symbol: 'VINE_USDT' }), 'VINE');
  assert.equal(rowCoin({}), '');
});

test('без сверки до страницы дело не доходит', async () => {
  const r = await executeIntent(null, { ...base }, {});
  assert.equal(r.ok, false);
  assert.match(r.error, /заявка не отправлена/);
});

test('сети сайта → канон терминала', () => {
  const { _canonChain: c } = require('./ourbit-order-page');
  assert.equal(c('Solana(SOL)'), 'SOL');
  assert.equal(c('BNB Smart Chain(BEP20)'), 'BSC');
  assert.equal(c('Ethereum(ERC20)'), 'ETH');
  assert.equal(c('BSC'), 'BSC');
  assert.equal(c('solana'), 'SOL');
  assert.equal(c('BASE'), 'BASE');
});

// Подставная страница: ответы сайта по пути запроса.
function fakePage(over = {}) {
  const calls = [];
  const resp = {
    'spot/currency/v3': { status: 200, code: 0, data: { chains: [{ chainName: 'BNB Smart Chain(BEP20)', walletType: 'BSC', currency: 'USDT-BNB', enableWithdraw: true }] } },
    'check_chain/v3': { status: 200, code: 0, data: { isQuickWithdraw: true } },
    'save_withdraw/v4': { status: 200, code: 0, data: { requestId: 'r1', addressText: '0x' + 'a'.repeat(40) } },
    'submit_withdraw/v3': { status: 200, code: 0, data: { withdrawId: 'w1', needVerify: false } },
    ...over,
  };
  return { calls, page: { evaluate: async (_fn, a) => { calls.push(a.url); const k = Object.keys(resp).find((x) => a.url.includes(x)); return resp[k]; } } };
}
const wd = { coin: 'USDT', chain: 'BSC', address: '0x' + 'a'.repeat(40), amount: '10' };
const { _withdraw: withdraw } = require('./ourbit-order-page');

test('вывод: быстрый вывод подтверждён', async () => {
  const f = fakePage();
  const r = await withdraw(f.page, {}, {}, wd, () => {});
  assert.equal(r.ok, true);
  assert.equal(r.withdrawId, 'w1');
});

test('вывод: сайт просит коды — не подтверждаем', async () => {
  const f = fakePage({ 'check_chain/v3': { status: 200, code: 0, data: { isQuickWithdraw: false } } });
  const r = await withdraw(f.page, {}, {}, wd, () => {});
  assert.equal(r.ok, false);
  assert.ok(!f.calls.some((u) => u.includes('submit_withdraw')));
});

test('вывод: адрес сайта не совпал — не подтверждаем', async () => {
  const f = fakePage({ 'save_withdraw/v4': { status: 200, code: 0, data: { requestId: 'r1', addressText: '0x' + 'b'.repeat(40) } } });
  const r = await withdraw(f.page, {}, {}, wd, () => {});
  assert.equal(r.ok, false);
  assert.ok(!f.calls.some((u) => u.includes('submit_withdraw')));
});

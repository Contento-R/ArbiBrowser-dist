'use strict';

/**
 * bingx-deposit-page.js — «Счёт получения» депозита BingX: проверка и перевод
 * на «Спот счёт» в живой странице профиля (оператор 2026-09-17).
 *
 * Зачем. Депозит BingX по умолчанию падает на Счёт фонда, и терминал тратит
 * секунды и запросы (опрос истории депозитов, чтение Фонда, перевод, ожидание
 * Спота) на то, чтобы монета стала продаваемой. На странице депозита у монеты
 * есть «Счёт получения» (Счёт фонда ⇄ Спот счёт): если у торгуемых монет
 * поставить «Спот счёт», шаг Фонд→Спот исчезает целиком.
 *
 * Что делает интент `depositProbe` ({coins:[…], set:'SPOT'|null}):
 *   • для каждой монеты открывает страницу депозита в ФОНОВОЙ вкладке профиля,
 *     читает показанную монету, сеть и текущий «Счёт получения»;
 *   • при set:'SPOT' и значении «Счёт фонда» — нажимает ⇄ → «Спот счёт» → OK
 *     и перечитывает значение;
 *   • записывает сетевые вызовы страницы к API биржи за это время (метод, URL,
 *     тело запроса, тело ответа) — чтобы найти прямой вызов смены счёта и
 *     дальше не кликать, а звать его.
 *
 * БЕЗОПАСНОСТЬ ВЫВОДА. Заголовки запросов НЕ записываются вовсе (там cookie и
 * токены сессии). В телах запроса/ответа и в query-параметрах вымарываются
 * ключи, похожие на секреты/идентификаторы (token, sign, cookie, auth, uid,
 * phone, email, device…), и ЛЮБЫЕ длинные (≥32 симв.) буквенно-цифровые
 * строки. Наружу уходит только это — в терминал, тем же путём, что и
 * результат любого интента.
 */

const { newBackgroundPage, markOwned } = require('./pair-tabs');

const BINGX_ORIGIN = process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com';
// Страница депозита с монетой в query. Если у BingX другой параметр — env.
const DEPOSIT_URL_TMPL = process.env.ARBI_BINGX_DEPOSIT_URL || `${BINGX_ORIGIN}/ru/assets/recharge?coin={coin}`;
// Хосты API страницы (подтверждённый: api-app.we-api.com — см. bingx-order-page.js).
// По ПУТИ, а не по хосту: BingX раскидывает вызовы по доменам (we-api.com,
// qq-os.com, acc-de.com), и сохранение счёта ушло на qq-os.com мимо фильтра (17.09).
const API_RE = new RegExp(process.env.ARBI_BINGX_DEPOSIT_API_RE || '/api/(wallet-deposit-withdraw|asset-manager|coin|fiat)/|we-api\\.com|bingx\\.com/api', 'i');
// Вызовы, относящиеся к депозиту/счёту — их отдаём подробно; остальные считаем.
const RELEVANT_RE = /recharge|deposit|account|asset|setting|config|wallet|transfer|coin/i;
const SECRET_KEY_RE = /token|secret|sign|cookie|auth|session|passw|apikey|api[_-]?key|private|uid|user[_-]?id|phone|email|device|fingerprint|trace|nonce|captcha/i;
const MAX_REQ_PER_COIN = 25;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Вымарать секреты/идентификаторы из любого JSON-значения. */
function scrub(v, depth = 0) {
  if (depth > 6) return '[глубже не смотрим]';
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => scrub(x, depth + 1));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, val] of Object.entries(v).slice(0, 60)) o[k] = SECRET_KEY_RE.test(k) ? '[скрыто]' : scrub(val, depth + 1);
    return o;
  }
  if (typeof v === 'string') {
    // URL — это адрес вызова, ради него проба и нужна; query уже вымаран scrubUrl.
    if (/^https?:\/\//i.test(v)) return scrubUrl(v);
    if (v.length >= 32 && /^[A-Za-z0-9+/=_\-.:]+$/.test(v)) return `[скрыто, ${v.length} симв.]`;
    return v.length > 200 ? v.slice(0, 200) + '…' : v;
  }
  return v;
}
function scrubUrl(u) {
  try {
    const url = new URL(u);
    for (const k of [...url.searchParams.keys()]) {
      const val = url.searchParams.get(k) || '';
      if (SECRET_KEY_RE.test(k) || val.length >= 32) url.searchParams.set(k, 'HIDDEN');
    }
    return url.origin + url.pathname + url.search;
  } catch { return String(u).slice(0, 200); }
}
function scrubBody(text) {
  if (!text) return null;
  // Сначала разбор, потом обрезка: раньше тело резалось до 6000 символов ДО
  // JSON.parse, и валидный ответ попадал в отчёт как «[не JSON]» (17.09).
  try {
    const j = scrub(JSON.parse(text));
    const out = JSON.stringify(j);
    return out.length > 12000 ? `${out.slice(0, 12000)}…[обрезано, всего ${out.length}]` : j;
  } catch { return `[не JSON, ${text.length} симв.]`; }
}

/** Запись вызовов страницы к API биржи. Заголовки не читаем никогда. */
function attachRecorder(page) {
  const rows = [];
  // ВСЕ исходящие запросы (метод, адрес, тип) и кадры веб-сокета: сохранение
  // «Счёта получения» не нашлось среди xhr/fetch, хотя выбор переживает
  // перезагрузку (17.09) — значит оно уходит другим путём. Тел не читаем,
  // только адрес и превью кадра, оба вымараны.
  const all = [];
  const ws = [];
  const onRequest = (req) => {
    try {
      all.push({ t: Date.now(), method: req.method(), url: scrubUrl(req.url()), rt: req.resourceType(), hasBody: !!req.postData() });
      if (all.length > 600) all.shift();
    } catch { /* диагностика */ }
  };
  const onWs = (sock) => {
    try {
      sock.on('framesent', (d) => {
        try {
          const raw = typeof d.payload === 'string' ? d.payload : String(d.payload);
          ws.push({ t: Date.now(), dir: 'sent', preview: String(scrubBody(raw) ?? raw.slice(0, 300)).slice(0, 600) });
          if (ws.length > 120) ws.shift();
        } catch { /* диагностика */ }
      });
    } catch { /* диагностика */ }
  };
  page.on('request', onRequest);
  page.on('websocket', onWs);
  const onResponse = async (resp) => {
    try {
      const req = resp.request();
      const url = req.url();
      if (!API_RE.test(url)) return;
      const rt = req.resourceType();
      if (rt !== 'xhr' && rt !== 'fetch') return;
      let body = null;
      try { body = await resp.text(); } catch { /* тело недоступно — не критично */ }
      // Справочник монет биржи: в нём может быть счёт зачисления по каждой монете —
      // тогда обходить придётся только те, что на Фонде (оператор: «1000 монет — долго»).
      if (/support-coins/i.test(url) && body && !lastSupportCoins) lastSupportCoins = scrubBody(body);
      rows.push({
        t: Date.now(), method: req.method(), url: scrubUrl(url), status: resp.status(),
        request: scrubBody(req.postData()), response: body ? scrubBody(body) : null,
      });
      if (rows.length > 400) rows.shift();
    } catch { /* запись — диагностика, страницу не трогает */ }
  };
  page.on('response', onResponse);
  return {
    rows, all, ws,
    detach: () => {
      try { page.off('response', onResponse); page.off('request', onRequest); page.off('websocket', onWs); } catch { /* игнор */ }
    },
  };
}
let lastSupportCoins = null;

async function getDepositPage(context, log) {
  let page = context.pages().find((p) => { try { return p.__arbiDepositBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context, { tab: true }));
    page.__arbiDepositBg = true;
    log('Открыл фоновую вкладку депозита (активная вкладка оператора не трогается)');
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

/** Текст n-го шага формы (0 — монета, 1 — сеть): вторая непустая строка = выбранное значение. */
async function readStepValue(page, n) {
  const txt = await page.locator('.bx-step-content').nth(n).innerText({ timeout: 5000 }).catch(() => '');
  const lines = txt.split('\n').map((s) => s.trim()).filter(Boolean);
  return (lines[1] || lines[0] || '').slice(0, 60);
}

async function readReceiveAccount(page, waitMs = 0) {
  // Блок «Информация про депозит» рисуется ПОСЛЕ ответа биржи (адрес депозита,
  // справочник сети) — читать сразу после выбора сети рано (17.09, DEP/COINDEPO:
  // сеть выбрана, а счёт «?»). Ждём появления строки, но не дольше waitMs.
  const deadline = Date.now() + Math.max(0, waitMs);
  for (;;) {
    const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
    if (await item.count()) {
      const txt = await item.locator('.right-text').first().innerText({ timeout: 5000 }).catch(() => '');
      const v = txt.replace(/\s+/g, ' ').trim();
      if (v) return v;
    }
    if (Date.now() >= deadline) return null;
    await sleep(500);
  }
}

/** Выбрать монету через выпадающий список, если query-параметр не сработал. */
async function selectCoin(page, coin, log) {
  // Тот же тип выпадашки, что у сети (подтверждено отчётом 17.09): триггер —
  // .bx-select-popover в шаге, список — .dp-item в всплывающем .tip-base.
  // Нужен для монет, у которых ?coin= в адресе не выбирает монету (внутреннее имя
  // на бирже отличается от тикера пары — класс GENSYN/«AI»).
  const step = page.locator('.bx-step-content').nth(0);
  await step.locator('.bx-select-popover, [class*="select"]').first().click({ timeout: 5000 });
  await sleep(600);
  const search = page.locator('.tip-base input, .bx-dp input, input[placeholder]').filter({ visible: true }).first();
  if (await search.count().catch(() => 0)) await search.fill(coin, { timeout: 3000 }).catch(() => {});
  else await page.keyboard.type(coin, { delay: 30 });
  await sleep(1200);
  const items = page.locator('.tip-base .dp-item, .bx-dp .dp-item').filter({ visible: true });
  // Пустой список = монета не принимается на депозит этой биржей (Alpha-токены:
  // торгуются, но ввода-вывода нет). Это факт, а не отказ автоматики.
  await items.first().waitFor({ state: 'visible', timeout: 6000 })
    .catch(() => { throw new Error(`монета не найдена в списке депозита биржи (депозит ${coin} не поддерживается)`); });
  const exact = items.filter({ hasText: new RegExp(`(^|[^A-Za-z0-9])${coin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z0-9]|$)`, 'i') }).first();
  const pick = (await exact.count().catch(() => 0)) ? exact : items.first();
  const name = (await pick.innerText({ timeout: 3000 }).catch(() => '')).split('\n')[0].trim().slice(0, 30);
  await pick.click({ timeout: 5000 });
  await sleep(1500);
  log(`Монета выбрана через список: «${name || coin}»`);
}

/** Сеть не выбрана («Выберите»): открыть список сетей и взять первую. У монет с
 *  одной сетью страница выбирает её сама, у USDT/USDC — ждёт пользователя, и без
 *  сети блок «Информация про депозит» (а с ним и «Счёт получения») не рисуется. */
async function selectFirstNetwork(page, log) {
  // Разметка подтверждена отчётом 17.09: триггер — .recharge-chain .bx-select-popover,
  // список — .recharge-network-select-popper, пункты — .dp-item.network-option
  // (заголовок сети в .network-option__title). Меню шапки сюда не попадает.
  const trigger = page.locator('.recharge-chain .bx-select-popover').first();
  await trigger.click({ timeout: 5000 });
  const opts = page.locator('.recharge-network-select-popper .dp-item.network-option').filter({ visible: true });
  await opts.first().waitFor({ state: 'visible', timeout: 6000 });
  const opt = opts.first();
  const name = (await opt.locator('.network-option__title').first().innerText({ timeout: 3000 }).catch(() => '')).trim().slice(0, 40);
  await opt.click({ timeout: 5000 });
  await sleep(1500);
  log(`Сеть выбрана из списка: «${name || '?'}»`);
}

/** Выбранная сеть — текст триггера списка (не подсказка внутри выпадашки). */
async function readNetwork(page) {
  const t = await page.locator('.recharge-chain .bx-select-popover').first().innerText({ timeout: 4000 }).catch(() => '');
  const line = t.split('\n').map((x) => x.trim()).filter((x) => x && !/^не уверены/i.test(x))[0] || '';
  return line.slice(0, 60);
}

/** Разметка видимых модалок — в отчёт, если переключение не прошло (секретов там нет). */
async function visibleDialogsHtml(page) {
  return page.evaluate(() => {
    const vis = [...document.querySelectorAll('[class*="modal"],[class*="dialog"],[role="dialog"],[class*="popup"]')]
      .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    return vis.slice(0, 3).map((e) => e.outerHTML.slice(0, 2000)).join('\n---\n');
  }).catch(() => '');
}

/** ⇄ → «Спот счёт» → OK. Модалка «Выберите аккаунт» ищется по тексту: её
 *  разметка не подтверждена (пункты .asset-account-item из отчёта 17.09 оказались
 *  меню «Активы» в шапке, а не модалкой). */
async function setSpot(page, log) {
  const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
  // Триггер — значок ⇄ (ics-assets-huazhuan); текст рядом кликабелен не всегда.
  const icon = item.locator('.ics-assets-huazhuan, [class*="huazhuan"]').first();
  if (await icon.count()) await icon.click({ timeout: 5000 }); else await item.locator('.right-text').first().click({ timeout: 5000 });
  const title = page.getByText(/Выберите аккаунт|Select account|Choose account/i).filter({ visible: true }).first();
  await title.waitFor({ state: 'visible', timeout: 8000 });
  log('Модалка «Выберите аккаунт» открыта');
  const spot = page.getByText(/^\s*(Спот счет|Спот счёт|Spot account)\s*$/i).filter({ visible: true }).last();
  await spot.click({ timeout: 5000 });
  await sleep(400);
  // OK есть не всегда: выбор пункта сам закрывает окно. Нет кнопки — не ошибка
  // (17.09: клик по «Спот счёт» прошёл, а ожидание OK висело 8 с впустую).
  const ok = page.getByText(/^\s*(OK|ОК|Подтвердить|Confirm)\s*$/i).filter({ visible: true }).last();
  if (await ok.count().catch(() => 0)) await ok.click({ timeout: 3000 }).catch(() => {});
  await sleep(1500);
  log('Нажал ⇄ → «Спот счёт»' + ((await ok.count().catch(() => 0)) ? ' → OK' : ' (окно закрылось само)'));
}

/**
 * @param {import('playwright').BrowserContext} context
 * @param {{coins?: string[], set?: 'SPOT'|null, log?: (m:string)=>void}} opts
 */
async function probeDepositAccount(context, opts = {}) {
  const log = opts.log || (() => {});
  const coins = (Array.isArray(opts.coins) && opts.coins.length ? opts.coins : ['USDT']).slice(0, 40).map((c) => String(c).toUpperCase());
  const set = opts.set === 'SPOT' ? 'SPOT' : null;
  const page = await getDepositPage(context, log);
  const rec = attachRecorder(page);
  const results = [];
  try {
    for (const coin of coins) {
      const r = { coin, url: null, coinShown: null, network: null, before: null, after: null, changed: false, persisted: null, error: null, setAt: null, requests: [], otherRequests: 0, notes: [], debug: null };
      const t0 = Date.now();
      const idx0 = rec.rows.length;
      const note = (m) => { r.notes.push(String(m).slice(0, 200)); log(m); };
      try {
        // Сначала about:blank: повторный goto на тот же адрес не перезагружал SPA,
        // и вызовы страницы (в т.ч. чтение «Счёта получения») в отчёт не попадали.
        await page.goto('about:blank').catch(() => {});
        await page.goto(DEPOSIT_URL_TMPL.replace('{coin}', encodeURIComponent(coin)), { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 });
        await sleep(2000);
        r.url = scrubUrl(page.url());
        r.coinShown = await readStepValue(page, 0);
        if (!r.coinShown.toUpperCase().includes(coin)) {
          await selectCoin(page, coin, note).catch((e) => note(`Список монет: ${String(e.message).split('\n')[0].slice(0, 160)}`));
          r.coinShown = await readStepValue(page, 0);
          if (!r.coinShown.toUpperCase().includes(coin)) {
            r.debug = { ...(r.debug || {}), coinStepHtml: (await page.locator('.bx-step-content').nth(0).evaluate((el) => el.outerHTML).catch(() => '')).slice(0, 3000) };
          }
        }
        r.network = await readNetwork(page);
        if (!r.coinShown.toUpperCase().includes(coin)) {
          note(`${coin}: монета не выбрана на странице — сеть и счёт не читаем`);
        } else if (/выберите|select/i.test(r.network) || !(await readReceiveAccount(page, 3000))) {
          // Разметка шага «сеть» — до и после клика: селекторы списка сетей не
          // подтверждены, и пока «Счёт получения» не читается, отчёт несёт HTML,
          // по которому их можно уточнить (адресов/секретов в этом блоке нет).
          const stepHtml = await page.locator('.bx-step-content').nth(1).evaluate((el) => el.outerHTML).catch(() => '');
          await selectFirstNetwork(page, note).catch((e) => note(`Список сетей: ${e.message}`));
          r.network = await readNetwork(page);
          if (!(await readReceiveAccount(page))) {
            const openHtml = await page.evaluate(() => {
              const vis = [...document.querySelectorAll('[class*="dropdown"],[class*="popper"],[role="listbox"],[class*="select-menu"],[class*="options"]')]
                .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
              return vis.slice(0, 4).map((e) => e.outerHTML.slice(0, 1200)).join('\n---\n');
            }).catch(() => '');
            r.debug = { stepHtml: stepHtml.slice(0, 3000), openHtml: openHtml.slice(0, 4000) };
          }
        }
        r.before = await readReceiveAccount(page, 6000);
        note(`${coin}: показано «${r.coinShown}» / сеть «${r.network}» / счёт получения «${r.before || '?'}»`);
        if (set === 'SPOT' && r.before && !/Спот|Spot/i.test(r.before) && r.coinShown.toUpperCase().includes(coin)) {
          r.setAt = Date.now();
          try {
            await setSpot(page, note);
          } catch (e) {
            note(`переключение: ${String(e.message).split('\n')[0].slice(0, 160)}`);
            r.debug = { ...(r.debug || {}), dialogsHtml: (await visibleDialogsHtml(page)).slice(0, 6000) };
            await page.keyboard.press('Escape').catch(() => {});
          }
          r.after = await readReceiveAccount(page);
          // ⚠️ ВТОРОЙ МЕТОД (#34): значение на экране может быть только рисовкой UI.
          // Перезагружаем страницу и читаем заново — в отчёт идёт то, что биржа
          // реально запомнила.
          try {
            await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
            await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 });
            await sleep(1500);
            if (/выберите|select/i.test(await readNetwork(page))) await selectFirstNetwork(page, () => {}).catch(() => {});
            const persisted = await readReceiveAccount(page, 8000);
            if (persisted) { r.persisted = persisted; r.after = persisted; }
          } catch (e) { note(`проверка после перезагрузки: ${String(e.message).split('\n')[0].slice(0, 120)}`); }
          r.changed = !!r.after && /Спот|Spot/i.test(r.after);
          note(`${coin}: счёт получения после перезагрузки «${r.after || '?'}»`);
        }
      } catch (e) {
        r.error = e.message;
        note(`${coin}: ${e.message}`);
      }
      const mine = rec.rows.slice(idx0).filter((x) => x.t >= t0);
      // В фазе «set» фильтр по смыслу адреса НЕ применяем: вызов сохранения счёта
      // может называться как угодно, а пропустить его дороже, чем показать лишнее.
      const relevant = mine
        .map((x) => ({ ...x, phase: r.setAt && x.t >= r.setAt ? 'set' : 'load' }))
        .filter((x) => x.phase === 'set' || RELEVANT_RE.test(x.url));
      // Вызовы ПОСЛЕ нажатия OK — главное: среди них смена счёта. Их отдаём первыми.
      relevant.sort((a, b) => (a.phase === b.phase ? a.t - b.t : a.phase === 'set' ? -1 : 1));
      r.requests = relevant.slice(0, MAX_REQ_PER_COIN);
      r.otherRequests = mine.length - r.requests.length;
      if (r.setAt) {
        r.allReqs = rec.all.filter((x) => x.t >= r.setAt).slice(0, 60);
        r.wsFrames = rec.ws.filter((x) => x.t >= r.setAt).slice(0, 20);
      }
      const withId = mine.find((x) => /(assetId|coinId)=(\d+)/.test(x.url));
      if (withId) r.coinId = Number(withId.url.match(/(?:assetId|coinId)=(\d+)/)[1]);
      if (lastSupportCoins && !results.some((x) => x.supportCoins)) { r.supportCoins = lastSupportCoins; lastSupportCoins = null; }
      results.push(r);
      await sleep(1200); // темп: страница биржи, не API — но без залпа
    }
  } finally {
    rec.detach();
  }
  return { ok: true, set, results };
}

module.exports = { probeDepositAccount, scrub, scrubUrl };

'use strict';

/**
 * ourbit-withdraw-page.js — ВЫВОД OURBIT ЧЕРЕЗ ФОРМУ САЙТА (оператор 16.11).
 *
 * Подтверждение вывода (submit_withdraw) сайт принимает только после невидимой капчи Geetest, которую запускает
 * сама страница при нажатии «Вывести» (запись 16.11: check_chain → captcha/robot/robot.assets.withdraw → gcaptcha4
 * load/verify → save_withdraw → submit_withdraw). Прямой запрос — 60008 «验证码错误» при тех же заголовках и подписи.
 * Поэтому вывод делает страница: своя вкладка вывода, сеть, адрес и сумма вводятся настоящими нажатиями, «Вывести»,
 * окно подтверждения — «Подтвердить». Капча — дело страницы; потребовала пазл — вкладка вперёд, ждём человека.
 *
 * Деньги защищены сверкой ЗАПРОСА самой страницы, а не разметки: до «Подтвердить» читаем тело save_withdraw, которое
 * отправила страница, — сумма, адрес, сеть, монета должны совпасть с намерением терминала; иначе окно закрывается,
 * ничего не подтверждено. Исход — ответ submit_withdraw страницы (withdrawId / код ошибки). Разметки не видно из
 * среды разработки: элементы ищутся по подписям (ru/en); не нашли — в журнал структура формы без значений.
 */

const ORIGIN = 'https://www.ourbit.com';
const ourbitCaptcha = require('./ourbit-captcha');
const TAB = 'OURBIT-WD';
const ADDR = 'input[placeholder*="адрес" i], input[placeholder*="address" i], textarea[placeholder*="адрес" i], textarea[placeholder*="address" i]';
const HUMAN_MS = Math.max(30_000, Number(process.env.ARBI_OURBIT_WD_HUMAN_MS) || 120_000);
const lower = (s) => String(s || '').trim().toLowerCase();

/** Тело save_withdraw страницы против намерения. null — совпало, иначе причина (для отказа). */
function saveMismatch(bodyStr, want) {
  let b = null;
  try { b = JSON.parse(bodyStr || ''); } catch { return 'тело подготовки вывода не прочитано'; }
  if (String(b.currency || '').toUpperCase() !== want.coin) return `монета ${b.currency} вместо ${want.coin}`;
  if (lower(b.address) !== lower(want.address)) return 'адрес на странице не тот, что в терминале';
  if (String(b.chain || '') !== want.chainName) return `сеть «${b.chain}» вместо «${want.chainName}»`;
  const a = Number(b.amount);
  const w = Number(want.amount);
  if (!(a > 0) || Math.abs(a - w) > Math.max(1e-9, w * 1e-9)) return `сумма ${b.amount} вместо ${want.amount}`;
  return null;
}

/** Структура формы вывода без значений — для правки поиска элементов по журналу. */
async function dumpForm(page, log, why) {
  const d = await page.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); const st = getComputedStyle(e); return r.width > 2 && r.height > 2 && st.visibility !== 'hidden' && st.display !== 'none'; };
    const t = (s, n = 40) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
    const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter(Boolean).slice(0, 3).join('.');
    const inputs = [...document.querySelectorAll('input,textarea')].filter(vis).slice(0, 12).map((e) => `поле ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
    const sels = [...document.querySelectorAll('[class*="select" i]')].filter((e) => vis(e) && !e.querySelector('[class*="select" i]')).slice(0, 8).map((e) => `выбор ${cls(e)} «${t(e.textContent, 30)}»`);
    const btns = [...new Set([...document.querySelectorAll('button,[role="button"]')].filter(vis).map((b) => t(b.innerText, 24)).filter(Boolean))].slice(0, 20);
    const opts = [...document.querySelectorAll('.ant-select-item-option, .ant-modal-body')].filter(vis).slice(0, 3).map((o) => t(o.innerText, 300));
    return [...inputs, ...sels, `кнопки=[${btns.join(' | ')}]`, `пункты списка=[${opts.join(' | ')}]`].join(' ; ');
  }).catch((e) => `не снята: ${e.message}`);
  log(`[форма вывода] ${why}: ${d}`);
}

const urlOf = (coin) => `${ORIGIN}/ru-RU/assets/withdraw/${coin}`;
const NET_PLACEHOLDER = /выберите сеть|select.*network/i;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Вкладка вывода профиля: своя (OURBIT-WD) либо восстановленная из прошлой сессии — берём её, а не плодим вторую. */
function findTab(context) {
  try {
    const pages = context.pages().filter((p) => !p.isClosed());
    const pg = pages.find((p) => p.__arbiDuty === TAB) || pages.find((p) => !p.__arbiDuty && p.url().startsWith(`${ORIGIN}/`) && /\/assets\/withdraw\//.test(p.url()));
    if (pg) pg.__arbiDuty = TAB;
    return pg || null;
  } catch { return null; }
}

/**
 * Загрузка формы. Форма готова к вводу не когда видно поле адреса, а когда страница получила адресную книгу —
 * последний запрос загрузки (журнал 16.11, 20:36: адрес вставили раньше — страница перерисовалась, поле суммы не
 * появилось). Момент готовности — pg.__wdReady.
 */
function nav(pg, coin) {
  pg.__seccodeUsed = false; pg.__navAt = Date.now(); pg.__wdReady = 0;
  pg.waitForResponse((r) => /white_list\/get_all_address_by_currency/.test(r.url()), { timeout: 25_000 })
    .then(() => { pg.__wdReady = Date.now(); }).catch(() => {});
  return pg.goto(urlOf(coin), { waitUntil: 'domcontentloaded', timeout: 30_000 });
}
const loading = (pg) => !!pg && !pg.__wdReady && Date.now() - (pg.__navAt || 0) < 15_000;
async function whenReady(pg, ms) {
  const t0 = Date.now();
  while (!pg.__wdReady && Date.now() - t0 < ms && !pg.isClosed()) await sleep(100);
  if (pg.__wdReady) await sleep(Math.max(0, 300 - (Date.now() - pg.__wdReady))); // дорисоваться после ответа
  return !!pg.__wdReady;
}

/** Свежая форма вывода монеты: загружена до конца, адрес виден, сеть ещё не выбрана, капча страницы не израсходована. */
async function freshForm(pg, coin) {
  if (!pg || pg.__seccodeUsed || !pg.__wdReady || !pg.url().startsWith(urlOf(coin))) return false;
  if (!(await pg.locator(ADDR).first().isVisible().catch(() => false))) return false;
  return pg.locator('.ant-select-selection-placeholder').filter({ hasText: NET_PLACEHOLDER }).first().isVisible().catch(() => false);
}

/**
 * Вкладка вывода (16.11): загрузка формы — ~5 с (сети, адресная книга, капча), поэтому она держится ОТКРЫТОЙ заранее
 * (prewarmForm при открытой панели вывода в терминале) и обновляется в фоне. Свежая форма той же монеты — без загрузки.
 */
async function wdPage(context, coin, log) {
  let pg = findTab(context);
  if (pg && !pg.__seccodeUsed && pg.url().startsWith(urlOf(coin)) && loading(pg)) await whenReady(pg, 15_000); // уже грузится — дождаться
  if (await freshForm(pg, coin)) { log('вывод: форма уже открыта — без загрузки'); return pg; }
  if (!pg) { pg = await context.newPage(); pg.__arbiDuty = TAB; }
  log(`вывод: открываю форму ${urlOf(coin)}`);
  await nav(pg, coin);
  await pg.locator(ADDR).first().waitFor({ state: 'visible', timeout: 20_000 }).catch(() => {});
  await whenReady(pg, 15_000);
  return pg;
}

let warming = false;
let busy = false; // идёт вывод формой — вкладку не перезагружать
/**
 * Держать вкладку вывода с готовой капчей: вкладки нет — открыть (USDT); капча израсходована или ей больше 110 с —
 * перезагрузить (сама — не чаще раза в 30 с; force — сразу, после прямого вывода). Ничего не вводит.
 */
async function prewarmForm(context, coin = 'USDT', force = false) {
  if (warming || busy) return;
  let pg = findTab(context);
  // Обновлять капчу заранее нужно только прямому выводу; форме — нет: свою капчу страница проверяет и получает сама
  // (оператор 16.11: «страница вывода каждый раз перезагружается»).
  if (pg && !pg.__seccodeUsed && ((ourbitCaptcha.learned().level || 0) < 1 || !ourbitCaptcha.needRefresh(context))) return;
  if (loading(pg)) return;
  if (pg && !force && Date.now() - (pg.__navAt || 0) < 30_000) return;
  warming = true;
  try {
    if (!pg) { pg = await context.newPage(); pg.__arbiDuty = TAB; }
    const cur = (pg.url().match(/\/assets\/withdraw\/([A-Z0-9]+)/) || [])[1];
    await nav(pg, cur || coin).catch(() => {});
  } finally { warming = false; }
}

/** Прямой вывод идёт запросами ИЗ вкладки вывода — пока он идёт, вкладку не перезагружать. */
function setBusy(v) { busy = !!v; }

/** Дождаться свежей капчи вкладки вывода (открыв или обновив вкладку). true — есть. */
async function ensureCaptcha(context, coin, ms) {
  const t0 = Date.now();
  if (!ourbitCaptcha.hasFresh(context)) await prewarmForm(context, coin, true);
  while (!ourbitCaptcha.hasFresh(context) && Date.now() - t0 < ms) await sleep(100);
  return ourbitCaptcha.hasFresh(context);
}

/** После вывода формой — свежая форма той же монеты в фоне, чтобы следующий вывод не ждал загрузки. */
function reloadLater(pg, coin) {
  const t = setTimeout(() => { if (!pg.isClosed() && !busy) nav(pg, coin).catch(() => {}); }, 1500); // идёт следующий вывод — вкладку не трогать
  if (t.unref) t.unref();
}

/** Вставка целиком (fill): одно событие ввода, без запроса сайта на каждый символ (журнал 16.11: 25 × match_chain). */
async function pasteInto(loc, text) {
  await loc.fill(String(text), { timeout: 3000 });
}

const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();

/**
 * Сеть (журнал и снимок 16.11): щелчок по выбору «Выберите сеть вывода средств» открывает ОКНО со списком
 * (строка: «BSC» и под ней «BNB Smart Chain(BEP20)») и поиском. Пункт — по точному имени сети сайта; не видно —
 * имя в поиск окна. Ошибиться пунктом не страшно: деньги защищает сверка тела save_withdraw.
 */
async function pickNetwork(pg, chainName, log) {
  // Сеть уже выбрана самой страницей (17.11, PEPECOIN → ETH: «не нашлась сеть»): у монеты с одной подходящей сетью
  // сайт ставит её сам по вставленному адресу — поля «Выберите сеть…» на форме уже нет, открывать нечего.
  // Выбранное значение видно в поле; ошибиться не страшно — деньги защищает сверка тела save_withdraw.
  const chosen = async (ms = 0) => {
    const t0 = Date.now();
    for (;;) {
      const txt = await pg.locator('.ant-select-selection-item').allInnerTexts().catch(() => []);
      if (txt.some((t) => norm(t).includes(chainName))) return true;
      if (Date.now() - t0 >= ms) return false;
      await sleep(150);
    }
  };
  const auto = () => { log(`вывод: сеть «${chainName}» уже выбрана страницей`); return true; };
  if (await chosen()) return auto();
  const sel = pg.locator('.ant-select').filter({ has: pg.locator('.ant-select-selection-placeholder', { hasText: NET_PLACEHOLDER }) }).first();
  if (!(await sel.locator('.ant-select-selector').click({ timeout: 1500 }).then(() => true).catch(() => false))) {
    if (await chosen(1500)) return auto();
    await dumpForm(pg, log, 'не открылся выбор сети'); return false;
  }
  const modal = pg.locator('.ant-modal').filter({ hasText: NET_PLACEHOLDER }).last();
  let item = modal.getByText(chainName, { exact: true }).first();
  if (!(await item.waitFor({ state: 'visible', timeout: 2500 }).then(() => true).catch(() => false))) {
    await modal.locator('input').first().fill(chainName).catch(() => {});
    item = modal.getByText(chainName, { exact: true }).first();
    if (!(await item.waitFor({ state: 'visible', timeout: 1500 }).then(() => true).catch(() => false))) {
      await pg.keyboard.press('Escape').catch(() => {});
      if (await chosen(1000)) return auto();
      await dumpForm(pg, log, `нет пункта сети «${chainName}»`); return false;
    }
  }
  await item.click({ timeout: 3000 });
  await modal.waitFor({ state: 'hidden', timeout: 2000 }).catch(() => {});
  return true;
}

function waitPost(pg, re, ms) {
  return pg.waitForResponse((r) => re.test(r.url()) && r.request().method() === 'POST', { timeout: ms })
    .then(async (r) => ({ body: r.request().postData() || '', json: await r.json().catch(() => null) }))
    .catch(() => null);
}

/**
 * Вывод формой. want: { coin, chainName, address, amount }. Возврат — как у прямого пути:
 * { ok:true, withdrawId } | { ok:false, error, maybe? }.
 */
async function withdrawViaForm(context, want, log, hooks) {
  const t0 = Date.now();
  busy = true;
  try {
    const pc = want.pageCoin || want.coin; // имя монеты в адресе страницы (у сайта — отображаемое)
    const pg = await wdPage(context, pc, log);
    try { return await fillAndSubmit(pg, want, log, t0, hooks); } finally { reloadLater(pg, pc); }
  } finally { busy = false; }
}

async function fillAndSubmit(pg, want, log, t0, hooks) {
  log(`вывод: форма готова за ${Date.now() - t0} мс`);

  // Порядок полей на странице (журнал 16.11): адрес, затем сеть, затем сумма — сумма появляется после выбора сети.
  const addr = pg.locator(ADDR).first();
  if (!(await addr.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля адреса'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле адреса — вывод не отправлен' }; }
  await pasteInto(addr, want.address);

  if (!(await pickNetwork(pg, want.chainName, log))) return { ok: false, error: `Ourbit: на форме вывода не нашлась сеть «${want.chainName}» — вывод не отправлен` };

  // Страница могла перерисоваться и очистить адрес — без него поле суммы не появляется: вставить ещё раз.
  if (!(await addr.inputValue().catch(() => ''))) { log('вывод: страница очистила адрес — вставляю ещё раз'); await pasteInto(addr, want.address); }

  const amt = pg.locator('input[placeholder*="сумм" i], input[placeholder*="мин" i], input[placeholder*="количеств" i], input[placeholder*="amount" i], input[placeholder*="min" i]').first();
  await amt.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await amt.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет поля суммы'); return { ok: false, error: 'Ourbit: на форме вывода не нашлось поле суммы — вывод не отправлен' }; }
  await pasteInto(amt, want.amount);

  const btn = pg.getByRole('button', { name: /^(вывести|вывод|withdraw|отправить|submit)$/i }).last();
  await btn.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await btn.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Отправить»'); return { ok: false, error: 'Ourbit: на форме не нашлась кнопка «Отправить» — вывод не отправлен' }; }
  // Проверка «без кодов?» (шла одновременно с заполнением): отказ — «Отправить» не нажимаем.
  const refusal = hooks && hooks.gate ? await hooks.gate() : null;
  if (refusal) return refusal;
  const checked = waitPost(pg, /\/withdraw\/check_chain\//, 5000);
  const saved = waitPost(pg, /\/withdraw\/save_withdraw\//, HUMAN_MS);
  await btn.click({ timeout: 4000 });
  log('вывод: «Вывести» нажата — проверка и капча страницы');
  // Страница не начала проверку за 5 с — форма не приняла данные (ошибка поля): не ждём 2 мин капчу, которой не будет.
  const ck = await checked;
  if (!ck) { await dumpForm(pg, log, 'страница не проверила вывод'); return { ok: false, error: 'Ourbit: форма не приняла данные вывода (страница не начала проверку) — вывод не отправлен' }; }
  if (ck.json && ck.json.code !== 0) return { ok: false, error: `Ourbit: проверка вывода — отказ сайта (code=${ck.json.code} «${ck.json.msg || ''}») — вывод не отправлен` };
  // Капча попросила человека — пазл виден: вкладку вперёд.
  const nudge = setTimeout(() => { pg.bringToFront().catch(() => {}); log(`вывод: капча ждёт человека — вкладка Ourbit на переднем плане (до ${Math.round(HUMAN_MS / 1000)} с)`); }, 6000);
  const sv = await saved;
  clearTimeout(nudge);
  if (!sv) { await dumpForm(pg, log, 'нет подготовки вывода'); return { ok: false, error: 'Ourbit: страница не подготовила вывод (капча не пройдена или форма не приняла данные) — вывод не отправлен' }; }
  if (!sv.json || sv.json.code !== 0) return { ok: false, error: `Ourbit: подготовка вывода — отказ сайта (code=${sv.json && sv.json.code} «${sv.json && sv.json.msg || ''}») — вывод не отправлен` };
  const bad = saveMismatch(sv.body, want);
  if (bad) {
    await pg.keyboard.press('Escape').catch(() => {});
    log(`вывод: ⛔ страница готовит не то — ${bad}; окно закрыто`);
    return { ok: false, error: `Ourbit: ${bad} — вывод НЕ подтверждён` };
  }

  // Окно подтверждения (журнал 16.11): «Вы получите… Включена функция быстрого вывода», кнопка «Быстрый вывод».
  const confirm = pg.getByRole('button', { name: /^(быстрый вывод|quick withdraw(al)?|подтвердить|confirm)$/i }).last();
  await confirm.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (!(await confirm.isVisible().catch(() => false))) { await dumpForm(pg, log, 'нет кнопки «Быстрый вывод» в окне'); return { ok: false, error: 'Ourbit: окно подтверждения без кнопки «Быстрый вывод» — вывод не подтверждён' }; }
  const submitted = waitPost(pg, /\/withdraw\/submit_withdraw\//, 30_000);
  await confirm.click({ timeout: 4000 });
  const sb = await submitted;
  if (!sb || !sb.json) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true };
  if (sb.json.code !== 0) return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.json.code} «${sb.json.msg || ''}»)` };
  if (sb.json.data && sb.json.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit' };
  log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён формой сайта за ${Date.now() - t0} мс`);
  return { ok: true, withdrawId: String((sb.json.data && sb.json.data.withdrawId) || '') };
}

module.exports = { withdrawViaForm, prewarmForm, ensureCaptcha, setBusy, wdTab: findTab, _saveMismatch: saveMismatch, _pickNetwork: pickNetwork };

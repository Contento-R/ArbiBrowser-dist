'use strict';

/**
 * order-utils.js — чистые (без браузера) помощники money-path, общие для всех
 * web-исполнителей (MEXC/XT/BingX). Вынесены из order-page-файлов, чтобы:
 *   1) убрать копипасту одной и той же логики ×3 (реализации расходились);
 *   2) покрыть юнит-тестами БЕЗ живой биржи — самое дешёвое снижение денежного
 *      риска (см. docs/sessions/2026-07-11-code-review-money-path-findings.md).
 *
 * Тесты: src/integration/order-utils.test.js (`node --test`).
 */

/**
 * IM-1: развернуть экспоненциальную запись в обычную десятичную строку.
 * `String(1.2e-7)` === "1.2e-7" — если такое уйти посимвольно в поле ордера, XT
 * может отправить "1.2" вместо "0.00000012" (лимитка в миллионы раз выше рынка).
 * Число из intent приходит после JSON.parse уже числом → String() даёт экспоненту
 * для мелких цен Alpha-токенов. Нормализуем ДО ввода в поле.
 * Возвращает строку без e/E; вход без экспоненты не трогаем (уже плоский).
 */
function formatDecimal(value) {
  const s = String(value).trim();
  if (s === '' || !/[eE]/.test(s)) return s; // уже плоская запись — не трогаем
  const m = s.match(/^([+-]?)(\d*)(?:\.(\d+))?[eE]([+-]?\d+)$/);
  if (!m) return s; // не распознали — отдаём как есть (валидатор ниже отсечёт)
  const sign = m[1] === '-' ? '-' : '';
  const intPart = m[2] || '0';
  const fracPart = m[3] || '';
  const combined = intPart + fracPart;
  const point = intPart.length + parseInt(m[4], 10); // сдвиг точки на экспоненту
  let out;
  if (point <= 0) {
    out = '0.' + '0'.repeat(-point) + combined;
  } else if (point >= combined.length) {
    out = combined + '0'.repeat(point - combined.length);
  } else {
    out = combined.slice(0, point) + '.' + combined.slice(point);
  }
  // Прибрать хвостовые нули дробной части и ведущие нули целой (оставив один).
  if (out.includes('.')) out = out.replace(/\.?0+$/, '');
  out = out.replace(/^0+(?=\d)/, '');
  return sign + out;
}

/**
 * IM-1: годно ли числовое поле ордера к отправке — конечное, строго > 0 и БЕЗ
 * экспоненты (формат, который биржа может неверно распарсить). Применять к ЦЕНЕ
 * И КОЛИЧЕСТВУ ПОСЛЕ formatDecimal, перед вводом. Отсекает NaN/0/отрицательное/
 * "1.2e-7"/"" — то, из-за чего ордер ушёл бы мусорным.
 */
function isPlainPositive(value) {
  const s = String(value).trim();
  if (!/^\d+(\.\d+)?$/.test(s)) return false; // только плоские десятичные
  const f = parseFloat(s);
  return Number.isFinite(f) && f > 0;
}

/**
 * CR-1 (ядро): назван ли в тексте именно НАШ токен `base`, а не тикер-клон.
 * Для Binance Alpha норма — клоны (ART/ARTX, TIG/STIG/TIGER): подстрочный матч
 * `includes("ART")` ловит "ARTX" → ордер на чужом токене. Требуем границу:
 * слева/справа от `base` нет буквенно-цифрового символа (латиница/цифра). Для
 * CJK-имён (币安底裤) соседние символы — «/», пробел → граница тоже держит.
 */
function baseNamedIn(text, base) {
  if (!text || !base) return false;
  const esc = String(base).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp('(?<![A-Za-z0-9])' + esc + '(?![A-Za-z0-9])', 'i').test(String(text));
}

/**
 * CR-4/split-C3: распарсить лимит объёма BingX из локализованной строки-подсказки
 * («доступно только N USDT» / «N USDT»). Ломалось на: пробеле-разделителе тысяч
 * (RU: "5 000"), десятичной запятой ("5,5"), суффиксах K/M. Возвращает число
 * (в quote-валюте) или null, если лимит не распознан однозначно.
 *
 * Берём ПОСЛЕДНЕЕ число перед «USDT» (у BingX формулировка «...only 5 000 USDT»),
 * нормализуем тысячные/десятичные, разворачиваем K/M.
 */
/**
 * split-фильтр: похож ли текст подсказки/ошибки на сообщение о ЛИМИТЕ ОБЪЁМА заявки.
 * Формулировки BingX: «доступно только N USDT», «Стоимость не может быть больше
 * N USDT» (RU-кап на заявку), EN «cannot exceed / not be more than N USDT».
 * Используется внутри page.evaluate — передавать как .source (regex не сериализуется).
 */
const VOLUME_LIMIT_HINT_RE = /(only|лимит|доступн|максим|max\b|limit|не более|больше|превыша|exceed|more than|up to|上限|限|超过)/i;
// Подсказка о МИНИМУМЕ заявки («Мин. стоимость - 1 USDT», «Minimum 5 USDT») — НЕ лимит
// объёма (лог 15.09 21:05: проба приняла её за максимум, лимит=1 USDT лёг на диск).
const VOLUME_MIN_HINT_RE = /(мин\.?|миним|minimum|\bmin\b|не менее|меньше|at least|less than|最小|至少)/i;

function parseVolumeLimit(text) {
  if (!text) return null;
  const s = String(text);
  // Число (с тысячными пробелами/точками/запятыми и опц. K/M) непосредственно
  // перед USDT/USD. Требуем валюту рядом, чтобы не схватить проценты/id.
  const re = /([\d][\d.,\s ]*)\s*([kKmMкКмМ]?)\s*(?:usdt|usd)/gi;
  let match = null;
  let m;
  while ((m = re.exec(s)) !== null) match = m; // берём ПОСЛЕДНЕЕ совпадение
  if (!match) return null;
  const raw = match[1].replace(/[\s ]/g, ''); // убрать пробелы-разделители тысяч
  const suffix = match[2].toLowerCase();
  // Нормализация десятичного разделителя: если есть и «,» и «.», разделитель тысяч —
  // тот, что встречается раньше/повторно; десятичный — последний. Простое правило:
  // последний из [.,] считаем десятичным, остальные (тысячные) убираем.
  let num;
  const lastDot = raw.lastIndexOf('.');
  const lastComma = raw.lastIndexOf(',');
  const decPos = Math.max(lastDot, lastComma);
  if (decPos === -1) {
    num = parseFloat(raw);
  } else {
    const intDigits = raw.slice(0, decPos).replace(/[.,]/g, '');
    const fracDigits = raw.slice(decPos + 1).replace(/[.,]/g, '');
    num = parseFloat(intDigits + '.' + fracDigits);
  }
  if (!Number.isFinite(num)) return null;
  if (suffix === 'k' || suffix === 'к') num *= 1e3;
  else if (suffix === 'm' || suffix === 'м') num *= 1e6;
  return num > 0 ? num : null;
}

/**
 * CR-1 (learn-on-confirm): нужно ли ЗАБЛОКИРОВАТЬ ордер из-за несовпадения пары.
 * pageBase — базовый токен, реально показанный на странице (из заголовка пары).
 * intentBase — база из интента. alias — зарегистрированное оператором внутреннее
 * имя токена на бирже (GENSYN торгуется под «AI» на BingX).
 *
 * Блокируем СТРОГО, если pageBase прочитан и не совпал НИ с intentBase, НИ с alias.
 * fail-open ТОЛЬКО когда pageBase не прочитать (null/'') — тогда не блокируем, чтобы
 * не сорвать легит-ордер на нечитаемой вёрстке. Сравнение регистронезависимое.
 */
function pairMismatch(pageBase, intentBase, alias) {
  if (!pageBase) return false;                 // не прочитали пару — см. pairGate (fail-closed)
  const p = String(pageBase).toUpperCase();
  if (p === String(intentBase || '').toUpperCase()) return false; // это наш токен
  if (alias && p === String(alias).toUpperCase()) return false;   // зарегистрированный алиас
  return true;                                 // чужой токен → блок (оператор подтвердит алиас)
}

/**
 * M1 (CR-1 fail-closed): единый гейт «можно ли кликать сабмит». Различает ТРИ исхода,
 * чтобы закрыть дыру fail-open в pairMismatch на live-money-пути:
 *   • { block:true, reason:'unreadable' } — pageBase не прочитан (пустая вёрстка /
 *     медленный прокси). Раньше pairMismatch молча пропускал (return false) → ордер уходил
 *     на пару, ЗАГРУЖЕННУЮ в форме, без верификации — ровно там, где риск чужого токена
 *     максимален. Теперь БЛОК (позитивная проверка: без прочитанной пары не кликаем).
 *     Диалог «это верный токен?» НЕ показываем — подтверждать нечего, нужно повторить.
 *   • { block:true, reason:'mismatch' } — прочитан ЧУЖОЙ токен → диалог подтверждения.
 *   • { block:false } — пара прочитана и совпала (или подтверждённый alias) → клик разрешён.
 */
function pairGate(pageBase, intentBase, alias, learned) {
  if (!pageBase) return { block: true, reason: 'unreadable' };
  const p = String(pageBase).toUpperCase();
  if (p === String(intentBase || '').toUpperCase()) return { block: false, reason: 'own' };
  // Имя, под которым биржа показывает НАШ адрес пары (USEPAID на BingX = «PAID»),
  // выученное на прогреве формы (см. learnDisplayBase). Отдельный reason — для лога.
  if (learned && p === String(learned).toUpperCase()) return { block: false, reason: 'learned' };
  // M8: пропуск ПО АЛИАСУ (доверенный реестр терминала для этой пары). Выделяем как
  // отдельный reason, чтобы вызывающий залогировал применение алиаса — единая точка
  // доверия: неверный алиас пропустил бы чужой токен молча, аудит-лог даёт видимость.
  if (alias && p === String(alias).toUpperCase()) return { block: false, reason: 'alias' };
  return { block: true, reason: 'mismatch' };
}

/**
 * M3/CR-3: поле УЖЕ содержит нужное значение. Строгая — НЕ принимает близкое-но-чужое
 * значение прошлого ордера (92.37 vs 95.23 = 3%, «схлопнутое» 5 vs 5.9 = 15% — блок).
 * Допуск считаем от want, а НЕ от содержимого поля v: схлопнутое поле иначе раздувало
 * бы unit до ±1 → ~15% ошибка цены прошла бы мимо CR-3.
 *
 * ПЛЮС относительный люфт 0.5%: биржа легитимно УСЕКАЕТ значение по шагу пары/лота
 * (want=8.97129187 → поле «8.97»; подтверждено логом боевого XT-ордера) — усечение
 * всегда ≪0.5% от want, а опасные чужие значения (≥3%) по-прежнему блокируются.
 * Без люфта строгий unit(want)=1e-8 блокировал легитимный ордер («Поля не совпали»).
 * formatDecimal — чтобы экспонента (3.2e-10) не сломала подсчёт знаков.
 * Единая копия для MEXC/XT/BingX (была продублирована дословно в каждом).
 */
function fieldFresh(v, want) {
  const f = parseFloat(String(v).replace(/[,\s]/g, ''));
  if (!isFinite(f) || !(want > 0)) return false;
  // ОТНОСИТЕЛЬНЫЙ допуск (по умолчанию 0.1%): «поле экономически РАВНО желаемому».
  // Ловит и грубую подмену (снап цены к стакану 0.56% → ордер сидит в стакане вместо
  // немедленного исполнения; схлопывание 15%), и проходит биржевое округление по тику/
  // лоту (обычно ≪0.1%). Абсолютный unit-подход не годился в ОБЕ стороны: unit от поля
  // пропускал схлопнутое «5» для 5.9 (M3), unit от want — «чужую» цену при малом числе
  // значащих цифр (0.000000077: один шаг разряда = 1.3%, слишком широко). Тюнится ARBI_FIELD_TOL.
  //
  // ⚠️ 0.3% → 0.1% (оператор 2026-09-01, WOJAK/MEXC). Форма биржи ХРАНИТ цену прошлой
  // операции между ордерами. Оператор ввёл 0.00000005645, в форме сидела 0.00000005661
  // от правки предыдущей заявки — отклонение 0.283% пролезало под 0.3%, цена НЕ
  // перезаписывалась, и ордер уходил по ЧУЖОЙ цене (видно на скрине: в форме одно,
  // на бирже другое). Запас остался: биржевое усечение 0.014% и округление тика 0.039%
  // проходят с трёхкратным запасом, залипшая цена 0.283% — блокируется и перезаписывается.
  const tol = Number(process.env.ARBI_FIELD_TOL || 0.001);
  return Math.abs(f - want) <= want * tol;
}

/**
 * M5: сторона ордера из текста кнопки сабмита биржи ('buy'|'sell'|'' если не распознать).
 * Кнопка сабмита MEXC несёт сторону в тексте («Buy WOJAK»/«Sell WOJAK») — читаем её и
 * сверяем с intent.side ПЕРЕД кликом, иначе молча несработавший клик по вкладке Buy/Sell
 * отправил бы sell как buy.
 *
 * Язык интерфейса биржи следует за локалью антидетект-профиля (es-ES/de-DE от гео
 * прокси — реальные локали боевых профилей), поэтому словарь покрывает основные языки.
 * '' (не распознали, экзотический язык) — вызывающий НЕ блокирует, только предупреждает:
 * блок каждого ордера из-за неизвестного слова = регрессия хуже исходного риска (как M7).
 * Блокируется только ЯВНО ПРОТИВОПОЛОЖНАЯ сторона — ровно тот дефект, что ловим.
 */
function sideFromText(text) {
  const t = String(text || '').toLowerCase();
  if (/sell|продать|продати|卖|vender|verkaufen|vendre|vendi|sat[ıi]ş|sprzeda/.test(t)) return 'sell';
  if (/buy|купить|придбати|买|comprar|kaufen|acheter|acquista|compra|al[ıi]m|kup/.test(t)) return 'buy';
  return '';
}

/**
 * Лимит объёма из ТЕКСТА ОТКАЗА биржи (не из подсказки в форме).
 * Лог напарника 2026-09-08: «BingX отклонил ордер: Максимальная стоимость для ордера
 * - 500.0000» — валюты рядом с числом НЕТ, поэтому parseVolumeLimit (он требует
 * USDT/USD) здесь возвращает null, и заявка падала целиком вместо разбивки.
 * Берём число ТОЛЬКО из сообщения, которое действительно про максимум стоимости
 * ордера: иначе можно принять за лимит любое число из чужой ошибки (#54 — гейт по
 * реальному сигналу источника, а не по догадке).
 */
// ⚠️ \w в JS — это [A-Za-z0-9_], кириллицу он НЕ покрывает: «максимальн\w*» не
// съедало «ая» и русский отказ не распознавался. Явный кириллический класс.
const REJECT_LIMIT_RE = /(максимальн[а-яё]*\s+стоимост|макс[а-яё]*\.?\s*стоимост|maximum\s+(order\s+)?(value|amount)|max\s+(order\s+)?(value|amount)|order\s+value\s+(cannot|can't|must))/i;
function parseRejectLimit(msg) {
  if (!msg) return null;
  const s = String(msg);
  const withCurrency = parseVolumeLimit(s); // «… больше 500 USDT» — обычный путь
  if (withCurrency != null) return withCurrency;
  if (!REJECT_LIMIT_RE.test(s)) return null;
  const nums = s.match(/[\d][\d.,]*/g);
  if (!nums || !nums.length) return null;
  const raw = nums[nums.length - 1];
  const decPos = Math.max(raw.lastIndexOf('.'), raw.lastIndexOf(','));
  const n = decPos === -1
    ? parseFloat(raw)
    : parseFloat(raw.slice(0, decPos).replace(/[.,]/g, '') + '.' + raw.slice(decPos + 1).replace(/[.,]/g, ''));
  return isFinite(n) && n > 0 ? n : null;
}

/**
 * ТОЧНОСТЬ КОЛИЧЕСТВА, КОТОРУЮ БИРЖА РЕАЛЬНО ПРИНИМАЕТ.
 *
 * Поле количества и XT, и MEXC принимают только посимвольный ввод (~7-10 мс на
 * знак на MEXC, ~100 мс на XT), а лишние знаки биржа всё равно отрезает: вводим
 * `14003111802.62280464` — в поле остаётся `14003111802.`. Значит девять
 * символов набираются впустую в КАЖДОЙ заявке.
 *
 * Правило появилось на XT (замер оператора 18.09) и подтвердилось на MEXC
 * (21.09). Здесь — общая пара функций, чтобы копии бирж снова не разошлись, как
 * это уже было с хелперами ввода (см. page-driver.js).
 */

/** Усечь количество до `dec` знаков, если биржа принимает именно столько. */
function truncateQty(qty, dec) {
  const s = String(qty);
  if (dec == null || !/^\d+\.\d+$/.test(s)) return s;
  const [ip, fp] = s.split('.');
  if (fp.length <= dec) return s;
  return dec ? `${ip}.${fp.slice(0, dec)}` : ip;
}

/**
 * Чему научило фактическое значение поля: сколько знаков биржа оставила.
 *
 * Возвращает число знаков или null, если урока нет. Учимся ТОЛЬКО когда совпала
 * ЦЕЛАЯ часть: разошлась она — это усадка по доступному балансу, а не шаг лота,
 * и урок «столько-то знаков» был бы выдумкой (#54: догадка не становится фактом).
 * Хвостовая точка (`386204.`) — то же усечение до нуля знаков.
 */
function learnQtyDecimals(accepted, wanted) {
  const acc = String(accepted || '').replace(/[,\s]/g, '').replace(/\.$/, '');
  if (!/^\d+(\.\d+)?$/.test(acc)) return null;
  const want = String(wanted || '');
  const accDec = (acc.split('.')[1] || '').length;
  const wantDec = (want.split('.')[1] || '').length;
  if (accDec >= wantDec) return null;
  if (acc.split('.')[0] !== want.split('.')[0]) return null;
  return accDec;
}

/**
 * В поле количества РОВНО НОЛЬ (или пусто/мусор)? Отличать ноль от частичного
 * остатка важно на продаже: форма биржи сама ужимает количество под доступный
 * баланс, и ноль означает «страница ещё не знает о монете», а не «монеты нет».
 * Случай ANSEM 25.09: терминал только что перевёл монету на спот, в форме стояло
 * «0.00», и ожидание баланса сдалось как на «реальном остатке» — заявка сорвалась
 * и ушла лишь со второй попытки терминала, секундой позже.
 */
function isZeroQty(v) {
  const f = parseFloat(String(v ?? '').replace(/[,\s]/g, ''));
  return !isFinite(f) || f === 0;
}

// ── Имя пары у биржи, выученное на прогреве (оператор 2026-09-29) ──────────────
// Биржа может подписывать пару не тем именем, под которым она торгуется: на BingX
// страница bingx.com/ru/spot/USEPAIDUSDT называется «PAID/USDT». Сверка пары при
// заявке честно блокировала такой ордер, и продажа не уходила. Выучить имя можно
// только там, где подмены быть не может: на ПРОГРЕВЕ (форма полностью готова, заявки
// нет), когда вкладка стоит РОВНО на адресе нашей пары (без переадресации) и имя на
// странице одно и то же в двух чтениях с паузой. Чужое имя на странице при заявке
// по-прежнему блокирует ордер.
const displayBaseByPair = new Map();
async function readPageBase(page) {
  return page.evaluate(() => {
    for (const h of document.querySelectorAll('h1')) {
      const m = (h.textContent || '').trim().match(/([A-Za-z0-9一-鿿]+)\s*[/\-]\s*[A-Za-z]{2,}/);
      if (m) return m[1];
    }
    return null;
  }).catch(() => null);
}
/** Прочитать и запомнить имя пары у биржи. Возвращает его (или null — не удостоверено). */
async function learnDisplayBase(exchange, page, pair, urlHasPair, log) {
  const base = String(pair).split('_')[0].toUpperCase();
  const url = () => { try { return page.url(); } catch { return ''; } };
  if (!urlHasPair(url(), pair)) return null;
  const a = await readPageBase(page);
  if (!a) return null;
  await page.waitForTimeout(Number(process.env.ARBI_DISPLAY_BASE_RECHECK_MS || 300));
  const b = await readPageBase(page);
  if (!b || a.toUpperCase() !== b.toUpperCase() || !urlHasPair(url(), pair)) return null;
  const shown = a.toUpperCase();
  if (shown === base) return shown;
  const key = `${exchange}:${pair}`.toUpperCase();
  if (displayBaseByPair.get(key) !== shown) {
    log(`Имя пары у биржи: адрес ${pair} подписан «${shown}/…» (не ${base}) — запомнил, заявки по ${base} пройдут сверку пары`);
  }
  displayBaseByPair.set(key, shown);
  return shown;
}
function displayBaseFor(exchange, pair) {
  return displayBaseByPair.get(`${exchange}:${pair}`.toUpperCase()) || null;
}

module.exports = { readPageBase, learnDisplayBase, displayBaseFor, formatDecimal, isZeroQty, isPlainPositive, baseNamedIn, parseVolumeLimit, parseRejectLimit, VOLUME_LIMIT_HINT_RE, VOLUME_MIN_HINT_RE, pairMismatch, pairGate, fieldFresh, sideFromText, truncateQty, learnQtyDecimals };

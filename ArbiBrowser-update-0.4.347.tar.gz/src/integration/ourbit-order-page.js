'use strict';

/**
 * ourbit-order-page.js — исполнитель Ourbit через сайт (оператор 2026-11-16: «ourbit не даёт торговать спот
 * по api, делаем все токены через arbibr»).
 *
 * API Ourbit даёт ключам только чтение истории, поэтому заявки, отмены, открытые ордера и балансы — запросы
 * самого сайта из залогиненной вкладки профиля (fetch из страницы, cookie сессии). Проба 2 (0.4.322):
 * заявка без x-ourbit-sign/nonce принимается — подпись не нужна, формы нет, ≈0,3 с на заявку.
 * Остальные заголовки сайта (luminex-uid, language, …) берутся из любого его запроса к /api/ — значения
 * нигде не пишутся.
 *
 * ⛔ МОНЕТА ПО КОНТРАКТУ (оператор 16.11: «лучше не исполнить заявку и пропустить сделку, чем купить
 * однофамильца»). Заявка сайта называет монету тикером (`currency`). Тикер берётся ТОЛЬКО из intent.symbol,
 * и заявка уходит, только если терминал приложил сверку: hints.ourbit.ticker = этот тикер, и либо
 * verified (контракты, по которым Ourbit сам называет этот тикер; сверено ≤10 мин назад), либо manual
 * (ручная заявка человека с экрана — разрешено оператором). После постановки — проверка в открытых
 * ордерах, что встала та же монета; иначе отмена.
 */

const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { formatDecimal, isPlainPositive } = require('./order-utils');
const ourbitSign = require('./ourbit-sign');
const ourbitCaptcha = require('./ourbit-captcha');
const { withdrawViaForm, prewarmForm, ensureCaptcha, setBusy } = require('./ourbit-withdraw-page');

const ORIGIN = 'https://www.ourbit.com';
const SKIP_HDR = /^(cookie|host|content-length|content-type|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|cache-control|sec-|:|x-ourbit-(sign|nonce)$)/i;
const VERIFY_MAX_MS = 10 * 60_000;
const OPEN_PATH = '/api/platform/spot/order/current/orders/v2?orderTypes=1,2,3,4,5,100&pageNum=1&pageSize=100&states=0,1,3';

const hdrOf = new WeakMap(); // context → заголовки последнего запроса сайта к /api/ (без подписи и cookie)
const authOf = new WeakMap(); // context → заголовок authorization запроса check_risk страницы (только в памяти)
const attached = new WeakSet();

/**
 * authorization запроса check_risk страницы: значение — только в памяти; на диск — лишь ОТКУДА оно берётся (имя cookie
 * или заголовка), чтобы после перезапуска ArbiBrowser первый прямой вывод тоже шёл с check_risk.
 */
let authLogged = false;
async function learnAuth(context, auth) {
  authOf.set(context, auth);
  if (ourbitCaptcha.learned().authTpl) return;
  const src = { 'uc:ucenter-token': ourbitCaptcha.headersOf(context)['ucenter-token'] };
  for (const c of await context.cookies(ORIGIN).catch(() => [])) src[`cookie:${c.name}`] = c.value;
  const hit = Object.entries(src).find(([, v]) => v && v.length >= 16 && auth.includes(v));
  const tpl = hit ? auth.replace(hit[1], `{${hit[0]}}`) : '';
  if (hit && !/[A-Za-z0-9]{12,}/.test(tpl.replace(/\{[^}]+\}/, ''))) {
    ourbitCaptcha.learnedSet({ authTpl: tpl });
    console.log(`[ourbit-exec] заголовок authorization запроса check_risk разобран: «${tpl}»`);
  } else if (!authLogged) {
    authLogged = true;
    console.log(`[ourbit-exec] заголовок authorization запроса check_risk: источник не найден (длина ${auth.length}) — после перезапуска первый прямой вывод пойдёт без check_risk`);
  }
}
async function authFor(context) {
  const a = authOf.get(context);
  if (a) return a;
  const tpl = ourbitCaptcha.learned().authTpl;
  const m = tpl && tpl.match(/\{(uc|cookie):([^}]+)\}/);
  if (!m) return '';
  const v = m[1] === 'uc' ? ourbitCaptcha.headersOf(context)[m[2]] : ((await context.cookies(ORIGIN).catch(() => [])).find((c) => c.name === m[2]) || {}).value;
  return v ? tpl.replace(m[0], v) : '';
}

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('response', (resp) => {
    try {
      ourbitCaptcha.onResponse(page, resp);
      if (resp.url().startsWith(`${ORIGIN}/api/common/ping`)) {
        const at = Date.now();
        resp.json().then((j) => { if (j && validTime(j.time)) skewOf.set(page.context(), Number(j.time) - at); }).catch(() => {});
      }
    } catch { /* закрыта */ }
  });
  page.on('request', (req) => {
    try {
      ourbitCaptcha.onRequest(page, req);
      if (!req.url().startsWith(`${ORIGIN}/api/`) || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      const h = {};
      for (const [k, v] of Object.entries(req.headers() || {})) if (!SKIP_HDR.test(k)) h[k] = v;
      if (h['device-id']) rememberDevice(page, h['device-id'], h['luminex-uid']);
      delete h['device-id'];
      if (h.authorization) { if (/risk_material/.test(req.url())) learnAuth(page.context(), h.authorization).catch(() => {}); delete h.authorization; }
      if (h['luminex-uid']) hdrOf.set(page.context(), h);
      if (req.method() === 'POST' && (req.headers() || {})['x-ourbit-sign']) ourbitSign.probe(page, req, (m) => console.log('[ourbit-exec] ' + m)).catch(() => {});
    } catch { /* страница закрыта */ }
  });
}

/** Следить за запросами сайта Ourbit во всех вкладках профиля (для заголовков). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

const toPair = (symbol) => String(symbol || 'BTC/USDT').toUpperCase().replace('/', '_');
const usable = (pg, context) => { try { return !!pg && !pg.isClosed() && pg.context() === context && pg.url().startsWith(ORIGIN); } catch { return false; } };

const opening = new WeakMap();
/** Живая вкладка Ourbit профиля; нет — одна новая на страницу пары (навигация не параллелится). */
async function ensurePage(context, symbol, log) {
  let pages = [];
  try { pages = context.pages(); } catch { pages = []; }
  // Вкладку вывода (OURBIT-WD) не берём: она перезагружается под каждый вывод — запрос оборвался бы.
  const pg = pages.find((p) => p.__arbiDuty === 'OURBIT' && usable(p, context)) || pages.find((p) => usable(p, context) && p.__arbiDuty !== 'OURBIT-WD');
  if (pg) return pg;
  if (opening.has(context)) return opening.get(context);
  const p = (async () => {
    const page = await context.newPage();
    page.__arbiDuty = 'OURBIT';
    onPage(page);
    const url = `${ORIGIN}/exchange/${toPair(symbol)}`;
    log(`открываю вкладку ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    return page;
  })();
  opening.set(context, p);
  try { return await p; } finally { opening.delete(context); }
}

async function headers(context, waitMs = 8000) {
  const t0 = Date.now();
  while (!hdrOf.get(context) && Date.now() - t0 < waitMs) await new Promise((r) => setTimeout(r, 200));
  return { ...(hdrOf.get(context) || {}) };
}

async function call(page, method, path, hdr, body) {
  return page.evaluate(async ({ url, method, hdr, body }) => {
    try {
      // Предел 12 с: зависший запрос сайта держал намерение по 20 с (журнал 16.11).
      const init = { method, headers: hdr, body: body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)), credentials: 'include', signal: AbortSignal.timeout(12_000) };
      const res = await fetch(url, init);
      const txt = await res.text();
      let j = null;
      try { j = JSON.parse(txt); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, data: j ? j.data : null, time: j ? j.time : undefined, success: j ? j.success : undefined, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: ORIGIN + path, method, hdr, body }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
}

/*
 * ВРЕМЯ СЕРВЕРА ДЛЯ ПОДПИСИ (16.11, журнал 0.4.346). Страница перед каждым подписанным запросом шлёт GET
 * /api/common/ping → { time } и подписывает меткой времени сервера. Мы подписывали часами компьютера, а они спешат
 * (журнал: на ≈185 мс) — метка приходила на сервер «из будущего». Опыт показал, что отвергается именно наш запрос
 * подтверждения: ту же подготовку страница подтвердила через секунду после нашего отказа 60008.
 * skewOf — «время сервера − часы компьютера» по последнему ответу ping (страницы или нашему); оценка всегда чуть в
 * прошлом (ответ шёл к нам). Подтверждение вывода берёт метку своим ping прямо перед запросом, как страница.
 */
const skewOf = new WeakMap(); // context → мс
const validTime = (t) => Number.isFinite(Number(t)) && Math.abs(Number(t) - Date.now()) < 10 * 60_000;
const serverNow = (context) => (skewOf.has(context) ? Date.now() + skewOf.get(context) : 0);
/** Свой ping из вкладки → метка времени сервера (мс) либо 0 — сайт не ответил. */
async function pingTime(c) {
  const h = stepHdr(c.hdr);
  delete h['content-type']; delete h.language; // у ping страницы их нет
  const r = await call(c.page, 'GET', '/api/common/ping', h);
  return r && validTime(r.time) ? Number(r.time) : 0;
}

/** POST с подписью сайта (ourbit-sign.js): тело сериализуется ОДИН раз — подписывается ровно оно. */
async function signedPost(page, path, hdr, body, nonceAt) {
  const str = JSON.stringify(body);
  return call(page, 'POST', path, { ...hdr, ...(await ourbitSign.signFor(page, str, nonceAt || serverNow(page.context()))) }, str);
}

const ok = (r) => !!r && r.status === 200 && (r.code === 200 || r.code === 0);
const noLogin = (r) => !!r && (r.status === 401 || r.code === 401 || /log ?in|登录|未登录|session/i.test(String(r.msg || '')));
const fail = (what, r) => (noLogin(r)
  ? { ok: false, loginRequired: true, error: `Ourbit: нет входа в аккаунт в ArbiBrowser — ${what} не выполнено. Войдите в окне профиля.` }
  : { ok: false, error: `Ourbit: ${what} — отказ сайта (HTTP ${r && r.status != null ? r.status : '-'} code=${r && r.code != null ? r.code : '-'} «${(r && (r.msg || r.error)) || ''}»)` });

/** Проверка, которую обязан пройти каждый боевой ордер: монета подтверждена терминалом. null — можно. */
function coinGate(intent) {
  const base = String(intent.symbol || '').split('/')[0].toUpperCase();
  const g = intent.hints && intent.hints.ourbit;
  if (!g || String(g.ticker || '').toUpperCase() !== base) return 'терминал не подтвердил монету';
  if (g.manual === true) return null;
  if (!Array.isArray(g.verified) || !g.verified.length) return 'монета не сверена по контракту';
  const lag = Number(intent.createdAt) - Number(g.at);
  if (!(Number(g.at) > 0) || !(lag >= -60_000 && lag <= VERIFY_MAX_MS)) return 'сверка по контракту устарела';
  return null;
}

let loggedKeys = false;
const rowId = (x) => String((x && (x.id != null ? x.id : x.orderId)) || '');
const rowCoin = (x) => String((x && (x.currency || String(x.symbol || '').split(/[_/]/)[0])) || '').toUpperCase();

async function openRows(page, hdr) {
  const r = await call(page, 'GET', OPEN_PATH, hdr);
  if (!ok(r)) return { r };
  const rows = Array.isArray(r.data && r.data.resultList) ? r.data.resultList : [];
  return { rows };
}

async function cancel(page, hdr, orderId) {
  return call(page, 'DELETE', `/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(orderId)}`, hdr);
}

async function placeOrder(context, intent, log) {
  const why = coinGate(intent);
  if (why) return { ok: false, error: `Ourbit: ${why} — заявка не отправлена` };
  if (intent.type !== 'limit') return { ok: false, error: 'Ourbit: через сайт — только лимитные заявки (рыночная = агрессивная лимитка терминала)' };
  const [base, quote = 'USDT'] = String(intent.symbol).toUpperCase().split('/');
  const price = formatDecimal(intent.price);
  const quantity = formatDecimal(intent.quantity);
  if (!isPlainPositive(price) || !isPlainPositive(quantity)) return { ok: false, error: `Ourbit: цена/объём не числа (${intent.price} / ${intent.quantity})` };
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = { ...(await headers(context)), 'content-type': 'application/json' };
  const body = { currency: base, market: quote, tradeType: intent.side === 'sell' ? 'SELL' : 'BUY', price, quantity, orderType: 'LIMIT_ORDER' };
  const t0 = Date.now();
  const r = await call(page, 'POST', '/api/platform/spot/order/place', hdr, body);
  const ms = Date.now() - t0;
  if (r.error || (r.status >= 500)) return { ok: false, error: `Ourbit: ответа на заявку нет (${r.error || `HTTP ${r.status}`}) — заявка МОГЛА встать, проверьте открытые ордера` };
  const orderId = ok(r) && typeof r.data === 'string' && r.data ? r.data : null;
  if (!orderId) return fail(`заявка ${base}/${quote}`, r);
  log(`Ордер выставлен: ${orderId} — ${intent.side} ${quantity} ${base} @ ${price}, ответ ${ms} мс${intent.hints.ourbit.manual ? ' (ручная, без сверки контракта)' : ''}`);
  // Встала та же монета? Не нашли строку (уже исполнилась) — тело заявки и так несло подтверждённый тикер.
  const { rows } = await openRows(page, { ...hdr });
  const row = (rows || []).find((x) => rowId(x) === orderId);
  if (row && !loggedKeys) { loggedKeys = true; log(`поля открытого ордера сайта: ${Object.keys(row).join(',')}`); }
  const coin = row ? rowCoin(row) : '';
  if (coin && coin !== base) {
    const c = await cancel(page, hdr, orderId);
    return { ok: false, error: `Ourbit поставил заявку по ${coin} вместо ${base} — ${ok(c) ? 'заявка отменена' : `⚠ ОТМЕНИТЬ НЕ УДАЛОСЬ, снимите заявку ${orderId} руками`}` };
  }
  return { ok: true, orderId, direct: true };
}

// Сеть сайта (chainName «Solana(SOL)», walletType «SOL») → канон терминала (как canonChain в CEX exchange/ourbit.ts).
function canonChain(raw) {
  const s = String(raw || '').toLowerCase();
  if (s.includes('bep20') || s === 'bsc' || s === 'bnb' || s.includes('bnb smart')) return 'BSC';
  if (s.includes('erc20') || s === 'eth' || s === 'ethereum') return 'ETH';
  if (s.includes('trc20') || s === 'tron' || s === 'trx') return 'TRX';
  if (s === 'sol' || s.startsWith('solana')) return 'SOL';
  if (s === 'base' || s.startsWith('base(') || s.startsWith('base ')) return 'BASE';
  if (s.startsWith('arbitrum') || s === 'arb') return 'ARBITRUM';
  if (s.startsWith('polygon') || s === 'matic') return 'POLYGON';
  return String(raw || '').toUpperCase();
}

/**
 * Сеть монеты по справочнику сайта (`spot/currency/v3`, как страницы депозита и вывода). У сети своя «монета сайта»
 * (`currency`: USDT-BNB, USDT-ETH; USDT = TRC20), и адрес депозита выдаётся ПО НЕЙ (запись 16.11) — запрос с общим
 * «USDT» и сетью BSC давал адрес TRON. Ровно одна сеть под запрошенную, иначе отказ.
 */
const chainsMemo = new Map(); // монета → { at, r } — справочник сетей монеты (для вывода: до 5 мин, решает всё равно сайт)
async function chainOf(page, hdr, coin, chain, maxAgeMs = 0) {
  const hit = chainsMemo.get(coin);
  const r = hit && Date.now() - hit.at < maxAgeMs ? hit.r
    : await call(page, 'GET', `/api/platform/asset/api/asset/spot/currency/v3?currency=${encodeURIComponent(coin)}`, hdr);
  if (!ok(r) || !r.data || !Array.isArray(r.data.chains)) return { r };
  if (!hit || hit.r !== r) chainsMemo.set(coin, { at: Date.now(), r });
  const want = canonChain(chain);
  const hits = r.data.chains.filter((n) => canonChain(n.walletType) === want || canonChain(n.chainName) === want);
  if (hits.length !== 1) return { why: `у ${coin} на Ourbit ${hits.length ? 'несколько сетей' : 'нет сети'} ${chain} (есть: ${r.data.chains.map((n) => n.chainName).join(', ') || '—'})` };
  return { c: hits[0], available: r.data.available };
}

const fmtOf = (a) => (/^0x[0-9a-fA-F]{40}$/.test(a) ? 'EVM' : /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a) ? 'TRON' : /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a) ? 'base58' : 'другой');

const deviceOf = new WeakMap(); // context → заголовок device-id сайта (его шлёт только подтверждение вывода)

/*
 * device-id сайта (16.11): без него подтверждение быстрого вывода отвечает 60008 «неверный код» — сайт шлёт его только
 * в submit_withdraw. Запоминаем на диске по аккаунту Ourbit (luminex-uid) — переживает перезапуск ArbiBrowser, и один
 * раз ищем, где страница его хранит (в журнал — только ИМЯ ключа хранилища, не значение).
 */
const DEV_FILE = () => path.join(config.reportsDir, 'ourbit-device.json');
function devStore() { try { return JSON.parse(fs.readFileSync(DEV_FILE(), 'utf8')) || {}; } catch { return {}; } }
const devLogged = new Set();
function rememberDevice(page, dev, uid) {
  deviceOf.set(page.context(), dev);
  if (!uid) return;
  const st = devStore();
  if (st[uid] !== dev) {
    st[uid] = dev;
    try { fs.mkdirSync(path.dirname(DEV_FILE()), { recursive: true }); fs.writeFileSync(DEV_FILE(), JSON.stringify(st)); } catch { /* не записали — живёт до перезапуска */ }
  }
  if (devLogged.has(uid)) return;
  devLogged.add(uid);
  page.evaluate((v) => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (String(localStorage.getItem(k) || '').includes(v)) out.push(`localStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); if (String(sessionStorage.getItem(k) || '').includes(v)) out.push(`sessionStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (const c of document.cookie.split(';')) { const [k, ...r] = c.split('='); if (r.join('=').includes(v)) out.push(`cookie «${k.trim()}»`); } } catch { /* нет доступа */ }
    return out;
  }, dev).then((where) => console.log(`[ourbit-exec] device-id сайта запомнен (${dev.length} симв.); на странице — ${where.length ? where.join(', ') : 'не найден в хранилищах'}`))
    .catch(() => {});
}

/**
 * БЫСТРЫЙ ВЫВОД: сеть и check_chain/v3 — запросом (сайт сам говорит isQuickWithdraw: адрес в белом списке Ourbit,
 * сумма в лимите; иначе он попросит коды почты/Google — вывод не начинаем), дальше — форма сайта (ourbit-withdraw-page).
 */
const WD = '/api/platform/asset/api/withdraw';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const codeOf = (r) => (r ? (r.code ?? r.error ?? r.status ?? '-') : '-');

/**
 * Свежий luminex-trace-id того же вида, что у страницы: страница ставит новый на каждый запрос, а мы до 0.4.345
 * повторяли один перехваченный на всех шагах вывода (и на опросах) — для сайта это повтор уже виденного запроса.
 * Цифры → случайные цифры, буквы a–f → случайные a–f, прочие буквы → случайные буквы, 13 цифр времени → текущее.
 */
function freshTrace(v) {
  const now = String(Date.now());
  const rnd = (abc) => abc[Math.floor(Math.random() * abc.length)];
  return String(v || '').split(/(\d{13})/).map((part) => (/^\d{13}$/.test(part) && part.slice(0, 3) === now.slice(0, 3) ? now
    : part.replace(/[0-9]/g, () => rnd('0123456789')).replace(/[a-f]/g, () => rnd('abcdef')).replace(/[g-z]/g, () => rnd('ghijklmnopqrstuvwxyz'))
      .replace(/[A-F]/g, () => rnd('ABCDEF')).replace(/[G-Z]/g, () => rnd('GHIJKLMNOPQRSTUVWXYZ')))).join('');
}
/** Заголовки одного запроса вывода: общие + свой trace-id; чужие метки трассировки (sentry) не повторяем. */
function stepHdr(hdr, extra) {
  const h = { ...hdr, ...extra };
  delete h.baggage; delete h['sentry-trace'];
  if (h.pragma && !h['cache-control']) h['cache-control'] = h.pragma; // страница шлёт оба (no-cache); общий сбор заголовков cache-control пропускает
  if (h['luminex-trace-id']) h['luminex-trace-id'] = freshTrace(h['luminex-trace-id']);
  return h;
}

async function withdraw(page, context, hdr0, s, log) {
  const coin = String(s.coin || '').toUpperCase();
  const address = String(s.address || '').trim();
  const amount = formatDecimal(s.amount);
  if (!address || !isPlainPositive(amount)) return { ok: false, error: 'Ourbit: вывод без адреса или суммы' };
  const n = await chainOf(page, hdr0, coin, s.chain, 5 * 60_000);
  if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
  if (!n.c) return fail('справочник сетей', n.r);
  if (n.c.enableWithdraw === false) return { ok: false, error: `Ourbit: вывод ${coin} в сети ${n.c.chainName} закрыт` };
  const chainName = String(n.c.chainName);
  // Прямому выводу нужна свежая капча вкладки вывода: нет (вкладка закрыта / капча израсходована) — открыть или
  // обновить вкладку и дождаться (≈4–6 с) — это всё равно быстрее формы.
  if (ourbitCaptcha.known() && !ourbitCaptcha.hasFresh(context)) {
    const t = Date.now();
    const got = await ensureCaptcha(context, coin, 12_000);
    log(`вывод: свежей капчи не было — ${got ? `получена за ${Date.now() - t} мс` : 'не получена за 12 с'}`);
  }
  const uh = ourbitCaptcha.headersOf(context);
  const hdr = { ...hdr0, 'content-type': 'application/json' };
  if (!hdr.language && uh.language) hdr.language = uh.language; // страница шлёт language на каждом шаге вывода
  const want = { coin, chainName, address, amount };
  const ctx = { page, context, hdr, uh, want, log };
  const d = await withdrawDirect(ctx);
  if (d && !d.form) {
    prewarmForm(context, coin, true).catch(() => {}); // капча израсходована — сразу новая, к следующему выводу
    return d;
  }
  // Запасной путь — ФОРМА сайта: капчу проходит сама страница, сверка суммы/адреса/сети — по её запросу (16.11).
  // Перед формой — та же проверка сайта «без кодов?» (прямой путь мог её уже сделать).
  const cc = (d && d.cc) || await checkChain(ctx);
  const bad = quickRefusal(cc, want);
  if (bad) return bad;
  const hook = hybridHook(ctx);
  const r = await withdrawViaForm(context, want, log, hook);
  if (hook && hook.refused && !r.ok && !r.maybe) {
    // После нашего отказа 60008 страница ту же подготовку не подтвердила (отказ определённый, вывод не отправлен) —
    // похоже, первый отказ подготовку сжигает. Повторяем формой с начала, уже без опыта.
    log(`вывод: ОПЫТ — после нашего отказа страница вывод не подтвердила («${String(r.error || '').slice(0, 120)}») — вывод формой заново`);
    return withdrawViaForm(context, want, log);
  }
  return r;
}

const checkChain = (c) => signedPost(c.page, `${WD}/check_chain/v3`, stepHdr(c.hdr), { amount: c.want.amount, address: c.want.address, chainName: c.want.chainName, currency: c.want.coin });
const checkAddr = (c) => signedPost(c.page, '/api/platform/asset/api/address_mark/v2/withdraw_check_address', stepHdr(c.hdr), { currency: c.want.coin, address: c.want.address, chainName: c.want.chainName });
/** Запрос страницы перед проверкой и перед подтверждением; у него свой заголовок authorization (в памяти). Нет его — не шлём. */
const checkRisk = async (c) => { const a = await authFor(c.context); return a ? call(c.page, 'GET', '/api/customer/risk_material/check_risk', stepHdr(c.hdr, { authorization: a })) : null; };
const saveReq = (c) => signedPost(c.page, `${WD}/save_withdraw/v4`, stepHdr(c.hdr), {
  amount: c.want.amount, address: c.want.address, chain: c.want.chainName, currency: c.want.coin, isQuickWithdraw: true,
  drawImageRequest: { backGroundColor: { colorR: 248, colorG: 248, colorB: 249 }, fontColor: { colorR: 27, colorG: 28, colorB: 29 }, fontSize: 28, width: 616, alignRight: true },
});
/**
 * Подтверждение как у страницы: check_risk → ping (время сервера для подписи) → submit — не раньше gap мс после
 * подготовки (страница подтверждает через ≥1,1 с: человек жмёт «Быстрый вывод»). gap = 0 — check_risk не ждём.
 * ownPing = false (ускорение) — без своего ping, метка по последнему ответу ping этой вкладки.
 * Возврат — ответ submit + stamp: чем подписано (для журнала).
 */
async function confirm(c, dev, requestId, savedAt, gap, ownPing = true) {
  const risk = checkRisk(c);
  if (gap > 0) await Promise.all([risk, sleep(Math.max(0, gap - (Date.now() - savedAt)))]);
  const pinged = ownPing ? await pingTime(c) : 0;
  const at = pinged || serverNow(c.context) || Date.now() - 400; // нет времени сервера — часы компьютера с запасом в прошлое
  const stamp = pinged ? 'время сервера (свой ping)' : serverNow(c.context) ? 'время сервера (по последнему ping)' : 'часы компьютера −400 мс';
  const ahead = Date.now() - at;
  const r = await signedPost(c.page, `${WD}/submit_withdraw/v3`, stepHdr(c.hdr, { 'device-id': dev }), { isQuickWithdraw: 'true', requestId: String(requestId) }, at);
  return { ...r, stamp: `${stamp}; метка ${ahead >= 0 ? 'позади часов компьютера на' : 'впереди часов компьютера на'} ${Math.abs(ahead)} мс` };
}
/** Отказ по проверке сайта (нет ответа / просит коды) либо null — вывод без кодов возможен. */
function quickRefusal(cc, want) {
  if (!ok(cc) || !cc.data) return fail(`проверка вывода ${want.coin} ${want.chainName}`, cc);
  if (cc.data.isQuickWithdraw !== true) {
    return { ok: false, error: 'Ourbit просит коды почты/Google для этого вывода (сумма больше лимита быстрого вывода или адрес не в белом списке Ourbit) — сделайте вывод на сайте' };
  }
  return null;
}

/**
 * ОПЫТ «СВОЁ ПОДТВЕРЖДЕНИЕ ПОДГОТОВКИ СТРАНИЦЫ» (один раз, 0.4.346). Прямой вывод получал 60008 на подтверждении при
 * тех же заголовках, теле и подписи, что у страницы. Чтобы понять, что отвергнуто — само наше подтверждение или шаги
 * до него, — при выводе формой страница делает всё до подготовки, а подтверждаем мы своим запросом (как страница:
 * через 1,2 с, после check_risk). Прошло → наше подтверждение годится, дело в шагах до него; 60008 → дело в самом
 * запросе подтверждения. 60008 — определённый отказ: после него вывод подтверждает кнопка страницы.
 */
function hybridHook(c) {
  if (ourbitCaptcha.learned().hybridTried) return undefined;
  const dev = deviceOf.get(c.context) || devStore()[c.hdr['luminex-uid']] || '';
  if (!dev) return undefined;
  const hook = {
    refused: false,
    trySubmit: async (pg, requestId) => {
      ourbitCaptcha.learnedSet({ hybridTried: true });
      const sb = await confirm({ ...c, page: pg }, dev, requestId, Date.now(), GAP_MS);
      if (sb.error || sb.status == null) { c.log('вывод: ОПЫТ — своё подтверждение подготовки страницы: ответа нет'); return { ok: false, maybe: true, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов' }; }
      c.log(`вывод: ОПЫТ — своё подтверждение подготовки страницы (подпись: ${sb.stamp}) → code=${codeOf(sb)}${ok(sb) ? ' (прошло: наше подтверждение годится, дело в шагах до него)' : ' (отказ: дело в самом запросе подтверждения) — дальше подтверждает страница'}`);
      if (!ok(sb)) { hook.refused = true; return null; }
      if (sb.data && sb.data.needVerify) return null;
      return { ok: true, withdrawId: String((sb.data && sb.data.withdrawId) || '') };
    },
  };
  return hook;
}

const GAP_MS = 1200; // пауза страницы между подготовкой и подтверждением (журнал 16.11: ≥1,1 с)
/** Шаги порядка страницы, которые можно попробовать ослабить ради скорости (после паузы). */
const LADDER = ['pingEach', 'addrFirst', 'saveAfter', 'robotAfter'];
const LADDER_NAME = { pingEach: 'без своего ping перед подтверждением', addrFirst: 'без ожидания проверки адреса', saveAfter: 'подготовка одновременно с капчей', robotAfter: 'капча без задержки' };
const gapOf = (st) => (st.gapMs == null ? GAP_MS : st.gapMs);

/** Следующее ускорение для пробы (одно за вывод) либо null: сначала пауза (0, затем деление пополам), потом шаги. */
function nextTrial(st) {
  const good = gapOf(st);
  const bad = st.gapBad == null ? -1 : st.gapBad; // наибольшая пауза, при которой был отказ
  if (good > 0 && bad < 0) return { gapMs: 0, name: 'подтверждение без паузы' };
  if (good - bad > 200) { const g = Math.round((good + bad) / 100) * 50; return { gapMs: g, name: `пауза ${g} мс вместо ${good}` }; }
  const k = LADDER.find((x) => st[x] == null);
  return k ? { step: k, name: LADDER_NAME[k] } : null;
}

/**
 * ПРЯМОЙ ВЫВОД (16.11, оператор: «меньше секунды»). Запросы страницы вывода без формы, ИЗ вкладки вывода (тот же
 * адрес страницы, что у её собственных запросов), каждый — со своим trace-id. Базовый порядок — как у страницы:
 *   withdraw_check_address + check_risk → check_chain, через 120 мс GET robot.assets.withdraw с captcha-token (капча,
 *   решённая вкладкой заранее) → save_withdraw → пауза 1,2 с + check_risk → ping → submit_withdraw (device-id
 *   страницы, подпись — временем сервера из ping).
 * До 0.4.345 первое подтверждение уходило сразу после подготовки и получало 60008, повтор той же подготовки через
 * 1,2 с — тоже (первый отказ мог её «сжечь»); пауза ПЕРЕД первым подтверждением не проверялась.
 * Когда базовый порядок прошёл (learned.base), каждый следующий вывод пробует ОДНО ускорение (nextTrial); прошло —
 * остаётся, отказ 60008 — запоминается, и этот же вывод повторяется рабочим порядком на новой капче.
 * Возврат: итог | { form: true, cc } — прямой путь недоступен или отказан ДО денег: вывод формой. Подтверждение без
 * ответа — «мог пройти», ничего не повторяем (двойной вывод). Отказ 60008 — определённое «нет»: повтор безопасен.
 */
async function withdrawDirect(c) {
  const { context, hdr, uh, want, log } = c;
  if (!ourbitCaptcha.known()) { log('вывод: формат капчи ещё не разобран — этот вывод формой (он же его разберёт)'); return { form: true }; }
  if (!uh['ucenter-token']) { log('вывод: нет заголовков капчи сайта (вкладка вывода не открыта) — формой'); return { form: true }; }
  const dev = deviceOf.get(context) || devStore()[hdr['luminex-uid']] || '';
  if (!dev) { log('вывод: device-id подтверждения ещё не известен — этот вывод формой (он его запомнит)'); return { form: true }; }
  const st = ourbitCaptcha.learned();
  if (!st.base && (st.baseFails || 0) >= 2) { log('вывод: прямой порядок «как страница» отказан дважды — до следующей версии выводы формой'); return { form: true }; }
  const known = { gapMs: gapOf(st), pingEach: st.pingEach !== false, addrFirst: st.addrFirst !== false, saveAfter: st.saveAfter !== false, robotAfter: st.robotAfter !== false };
  const trial = st.base ? nextTrial(st) : null;
  const plan = !trial ? known : trial.step ? { ...known, [trial.step]: false } : { ...known, gapMs: trial.gapMs };
  let out = await runDirect(c, dev, plan, trial ? `проба: ${trial.name}` : (st.base ? 'рабочий порядок' : 'как страница'));
  if (out.rejected && trial) {
    ourbitCaptcha.learnedSet(trial.step ? { [trial.step]: true } : { gapBad: trial.gapMs });
    log(`вывод: проба «${trial.name}» отказана — повторяю этот вывод рабочим порядком на новой капче`);
    if (await ensureCaptcha(context, want.coin, 12_000)) out = await runDirect(c, dev, known, 'рабочий порядок');
  } else if (out.rejected) {
    if (!st.base && out.full) ourbitCaptcha.learnedSet({ baseFails: (st.baseFails || 0) + 1 }); // без check_risk порядок был неполным — не в счёт
  } else if (out.ok) {
    ourbitCaptcha.learnedSet(!trial ? { base: true } : trial.step ? { [trial.step]: false } : { gapMs: trial.gapMs });
  }
  return out.rejected ? { form: true, cc: out.cc } : out;
}

async function runDirect(c, dev, plan, note) {
  const { context, hdr, uh, want, log } = c;
  const cap = ourbitCaptcha.take(context);
  if (!cap) { log('вывод: нет свежей капчи вкладки вывода — формой'); return { form: true }; }
  const d = { ...c, page: cap.page }; // запросы — из вкладки вывода
  const t0 = Date.now();
  const lap = (() => { let t = t0; return () => { const x = Date.now() - t; t = Date.now(); return x; }; })();
  setBusy(true);
  try {
    const caP = checkAddr(d);
    const rkP = checkRisk(d);
    if (plan.addrFirst) await Promise.all([caP, rkP]);
    const tAddr = lap();
    const ccP = checkChain(d);
    if (plan.robotAfter) await sleep(120); // страница шлёт капчу через ~120 мс после проверки
    const rbP = call(d.page, 'GET', ourbitCaptcha.ROBOT_PATH, stepHdr(hdr, { ...uh, 'captcha-token': cap.token }));
    const svP = plan.saveAfter ? null : saveReq(d);
    const [cc, rb, ca, rk] = await Promise.all([ccP, rbP, caP, rkP]);
    const tCheck = lap();
    const refusal = quickRefusal(cc, want);
    if (refusal) return refusal;
    const side = `проверка адреса code=${codeOf(ca)}, check_risk ${rk ? `code=${codeOf(rk)}` : 'не слали (нет заголовка страницы)'}`;
    // Капча принята — ответ как у страницы: success, code=0, data пусто (данные в ответе = сайт просит показать капчу).
    if (!ok(rb) || rb.success === false || rb.data != null) {
      log(`вывод: капча не принята (code=${codeOf(rb)}, success=${rb.success}, данные ${rb.data == null ? 'нет' : 'есть'}) — формой`);
      return { form: true, cc };
    }
    const sv = await (svP || saveReq(d));
    const tSave = lap();
    if (!ok(sv) || !sv.data || !sv.data.requestId) { log(`вывод: подготовка отказана (code=${codeOf(sv)} «${sv.msg || ''}»; ${note}; ${side}) — формой`); return { form: true, cc }; }
    const sb = await confirm(d, dev, sv.data.requestId, Date.now(), plan.gapMs, plan.pingEach);
    const tSubmit = lap();
    const times = `адрес ${tAddr} мс, проверка и капча ${tCheck} мс, подготовка ${tSave} мс, подтверждение ${tSubmit} мс (из них пауза ${plan.gapMs}), всего ${Date.now() - t0} мс; подпись: ${sb.stamp}`;
    if (sb.error || sb.status == null) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true };
    if (!ok(sb)) {
      if (sb.code === 60008) { log(`вывод: подтверждение отказано 60008 (${note}; ${times}; ${side})`); return { rejected: true, cc, full: !!rk }; }
      return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.code} «${sb.msg || ''}»)` };
    }
    if (sb.data && sb.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit' };
    log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён прямым запросом (${note}): ${times}; ${side}`);
    return { ok: true, withdrawId: String((sb.data && sb.data.withdrawId) || '') };
  } finally { setBusy(false); }
}

async function siteCall(context, intent, log) {
  const t0 = Date.now();
  const r = await siteCallInner(context, intent, log);
  const ms = Date.now() - t0;
  if (ms > 3000) log(`запрос сайта ${intent.site && intent.site.op} шёл ${ms} мс${r && r.error ? ` (ошибка: ${String(r.error).slice(0, 80)})` : ''}`);
  return r;
}

async function siteCallInner(context, intent, log) {
  const s = intent.site || {};
  const t0 = Date.now();
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = await headers(context);
  if (Date.now() - t0 > 3000) log(`вкладка/заголовки сайта готовы за ${Date.now() - t0} мс`);
  if (s.op === 'cancel') {
    if (!s.orderId) return { ok: false, error: 'Ourbit: отмена без номера заявки' };
    const r = await cancel(page, hdr, s.orderId);
    return ok(r) ? { ok: true, canceled: s.orderId } : fail(`отмена ${s.orderId}`, r);
  }
  if (s.op === 'open') {
    const { rows, r } = await openRows(page, hdr);
    return rows ? { ok: true, rows } : fail('открытые ордера', r);
  }
  if (s.op === 'depositAddress') {
    const coin = String(s.coin || '').toUpperCase();
    const n = await chainOf(page, hdr, coin, s.chain);
    if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
    if (!n.c) return fail('справочник сетей', n.r);
    if (n.c.supportMemo === true) return { ok: false, error: `Ourbit: сеть ${n.c.chainName} с memo — адрес с сайта не выдаю, возьмите адрес и memo на сайте` };
    const vcoin = String(n.c.currency || coin);
    let address = String(n.c.address || '');
    if (!address) {
      const r = await call(page, 'POST', '/api/platform/deposit/address/create', { ...hdr, 'content-type': 'application/json' }, { currency: vcoin, chainName: n.c.chainName });
      if (!ok(r) || !r.data || !r.data.address) return fail(`адрес депозита ${vcoin} ${n.c.chainName}`, r);
      // Перепроверка: тот же адрес сайт показывает у ЭТОЙ сети монеты.
      const again = await chainOf(page, hdr, coin, s.chain);
      if (!again.c || String(again.c.address || '') !== String(r.data.address)) {
        return { ok: false, error: `Ourbit: выданный адрес ${vcoin} не совпал с адресом сети ${n.c.chainName} в списке сайта — адрес не показан` };
      }
      address = String(r.data.address);
    }
    log(`адрес депозита ${coin}: просили ${s.chain} → сеть сайта «${n.c.chainName}» (${vcoin}), адрес формата ${fmtOf(address)}`);
    return { ok: true, address, vcoin, chainName: n.c.chainName, enableDeposit: n.c.enableDeposit !== false };
  }
  if (s.op === 'withdraws') {
    prewarmForm(context).catch(() => {}); // панель вывода открыта в терминале — форма вывода ждёт заранее
    const r = await call(page, 'GET', '/api/platform/withdraw/latest', hdr);
    if (!ok(r)) return fail('история выводов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      id: String(x.id || ''), coin: String(x.vcoinName || '').toUpperCase(), chain: canonChain(x.walletType), address: String(x.address || ''),
      amount: String(x.amount || '0'), fee: x.fee != null ? String(x.fee) : undefined, txHash: String(x.txid || ''),
      state: String(x.state || ''), time: Number(x.createTime) || 0, updated: Number(x.updateTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'wdConfig') {
    const r = await call(page, 'GET', '/api/platform/asset/api/withdraw/query/config/v3', hdr);
    if (!ok(r) || !r.data) return fail('настройки вывода', r);
    return { ok: true, quick: r.data.quickWithdrawEnabled === true, perWithdraw: Number(r.data.perWithdrawAmount) || 0, whiteList: r.data.whiteListEnabled === true };
  }
  if (s.op === 'withdraw') return withdraw(page, context, hdr, s, log);
  if (s.op === 'deposits') {
    const r = await call(page, 'GET', '/api/platform/asset/api/deposit/v2/latest', hdr);
    if (!ok(r)) return fail('история депозитов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      coin: String(x.vcoinName || x.currency || '').toUpperCase(), chain: canonChain(x.walletType || x.chainName),
      amount: String(x.amount || '0'), txHash: String(x.transactionHash || String(x.txid || '').split(':')[0] || ''),
      confirmations: Number(x.confirmations) || 0, required: Number(x.requireConfirmations) || 0,
      state: String(x.state || ''), time: Number(x.receiptTime || x.createTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'balances') {
    // Список монет спота — из сводки, точные «доступно / в заявках» — запросом по этим монетам.
    const o = await call(page, 'GET', '/api/platform/asset/api/asset/overview/convert/v2', hdr);
    if (!ok(o)) return fail('балансы', o);
    const coins = (Array.isArray(o.data) ? o.data : []).filter((x) => Number(x && x.spot) > 0).map((x) => String(x.currency || '').toUpperCase()).filter(Boolean);
    if (!coins.includes('USDT')) coins.push('USDT');
    const b = await call(page, 'GET', `/api/platform/spot/asset/currency/balances?currency=${coins.map(encodeURIComponent).join(',')}`, hdr);
    if (!ok(b)) return fail('балансы', b);
    const rows = (Array.isArray(b.data) ? b.data : []).map((x) => ({ currency: String(x.currency || '').toUpperCase(), available: String(x.available || '0'), frozen: String(x.frozen || '0') }));
    return { ok: true, rows };
  }
  return { ok: false, error: `Ourbit: неизвестный запрос сайта ${s.op}` };
}

async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  attach(context);
  if (intent.site) return siteCall(context, intent, log);
  if (intent.warmup) { await ensurePage(context, intent.symbol, log); return { ok: true, warmed: true }; }
  if (intent.loginCheck || intent.closeStale || intent.balance || intent.orders || intent.cancelAll) {
    return intent.loginCheck || intent.closeStale ? { ok: true, skipped: true } : { ok: false, error: 'Ourbit: этот вид намерения не поддержан (балансы/ордера — запросом сайта)' };
  }
  return placeOrder(context, intent, log);
}

module.exports = { attach, executeIntent, toPair, _coinGate: coinGate, _rowCoin: rowCoin, _canonChain: canonChain, _withdrawDirect: withdrawDirect, _deviceOf: deviceOf, _freshTrace: freshTrace, _nextTrial: nextTrial, _authOf: authOf, _skewOf: skewOf };

'use strict';

/**
 * ourbit-capture.js — ЗАПИСЬ ЗАПРОСОВ САЙТА OURBIT (оператор 2026-11-16).
 *
 * API Ourbit отвечает ключу 700007 «No permission to access the endpoint» даже на баланс — торговать
 * Ourbit будем через сайт, как MEXC. Чтобы собрать исполнение, нужен формат запросов самого сайта:
 * какие адреса он зовёт, с какими полями, что отвечает. Оператор руками ставит на ourbit.com одну
 * лимитку далеко от рынка, отменяет её и открывает активы — ловушка пишет всё, что для этого нужно:
 *   1) ВЫЗОВ / ОТВЕТ — запросы вкладки Ourbit к API заявок, отмены, открытых ордеров, баланса, активов,
 *      депозита (метод, адрес, тело, ответ); у вызова — ИМЕНА заголовков (без значений): так видно,
 *      какой подписью сайт заверяет заявку;
 *   2) ФОРМА — разметка торговой формы спота (поля, кнопки, вкладки «Лимит/Рынок») без значений,
 *      один раз на страницу — запасной путь «нажать как человек», если прямой вызов не выйдет.
 * Значения заголовков и cookie НЕ читаются никогда; в телах вымарываются ключи вида token/sign/uid/
 * phone/email/код и длинные строки (адреса, подписи) — общий scrub. Действий ловушка не делает: только
 * смотрит. Всё — в журнал «[захват Ourbit] …» и в файл <данные>/reports/ourbit-capture.txt.
 * Бюджет — 600 строк на процесс. Выключить — ARBI_OURBIT_CAPTURE=0.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { scrub, scrubUrl } = require('./bingx-deposit-page');

const ON = () => (process.env.ARBI_OURBIT_CAPTURE || '1') !== '0';
const FILE = () => path.join(config.reportsDir, 'ourbit-capture.txt');
const SITE_RE = /(^|\.)ourbit\.com$/i;
// Что интересно: заявки, отмена, открытые/история ордеров, баланс и активы, депозит/вывод.
const API_RE = /order|place|cancel|revoke|trade|deal|entrust|asset|balance|account|wallet|deposit|withdraw|transfer|capital/i;
const NOISE_RE = /\.(js|css|png|jpe?g|svg|webp|woff2?|ico)(\?|$)|kline|depth|ticker|market\/|banner|notice|announce|i18n|locale|log(ger)?\/|track|report|sensor|captcha|site_info|fiat\/currencies|trade_fee|tiered_fee_rate|_next\/data|currency\/query|korean|accounts_transfer|placements|customer/i;
// Тела заявок могут нести одноразовые коды/пароль фонда — их ключи вымарываем дополнительно.
const CODE_KEY_RE = /code|otp|totp|pin|fund|pass|pwd|verif|captcha|sign|token/i;
const maskCodes = (v) => (Array.isArray(v) ? v.map(maskCodes) : v && typeof v === 'object'
  ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, CODE_KEY_RE.test(k) ? '[скрыто]' : maskCodes(x)])) : v);

let budget = 600;
let wdPaths = 0; // строк «СТРАНИЦА ВЫВОДА» за процесс
const attached = new WeakSet();
const forms = new Set(); // путь страницы → разметка формы уже снята

// Опросы, которые терминал сам шлёт через ArbiBrowser каждые 1–3 с (балансы, открытые ордера, депозиты) — формат
// известен; без этого фильтра они съедали бюджет до ручного вывода (16.11). Вывод/адреса/проверки — пишутся всегда.
const POLL_RE = /\/spot\/asset\/currency\/balances|\/spot\/order\/current\/orders\/v2|\/asset\/overview\/convert\/v2|\/deposit\/v2\/latest|\/spot\/statistic|deposit_withdraw\/status|\/spot\/convert\/v4|\/withdraw\/latest|withdraw\/query\/config|withdraw\/withdraw_amount|withdraw\/pre_check|white_list\/get_all|\/asset\/spot\/currency\/v3|bstock\/company-actions/;
const VIP_RE = /withdraw|address|verify|security|chain|whitelist|google|email|sms/i;

function out(line, force = false) {
  // Итоги проб пишутся всегда: проверки срока подписи идут через час, бюджет к тому времени может кончиться.
  const probe = force || line.startsWith('ПРОБА');
  if (!probe && budget <= 0) return;
  if (!probe) budget -= 1;
  console.log(`[захват Ourbit] ${line}`);
  try {
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    // Файл не больше ~300 КБ — его надо мочь отправить в чат (16.11): больше — старое уходит в .old.
    try { if (fs.statSync(FILE()).size > 300_000) fs.renameSync(FILE(), `${FILE()}.old`); } catch { /* файла ещё нет */ }
    fs.appendFileSync(FILE(), `${new Date().toISOString()} ${line}\n`);
  } catch { /* файл необязателен — журнал есть */ }
  if (budget === 0) console.log('[захват Ourbit] бюджет строк исчерпан — запись остановлена до перезапуска');
}

const isOurbit = (u) => { try { return SITE_RE.test(new URL(u).hostname); } catch { return false; } };

function body(text, req = false) {
  if (!text) return '';
  let v = null;
  try { v = JSON.parse(text); } catch {
    if (/^[\w.%[\]-]+=/.test(text)) v = Object.fromEntries(new URLSearchParams(text));
  }
  // 600 симв. хватает на поля ответа; длинные списки (справочник сетей, история) только раздували файл (16.11).
  return v == null ? `[не JSON, ${text.length} симв.]` : JSON.stringify(scrub(req ? maskCodes(v) : v)).slice(0, 600);
}

// Разметка торговой формы спота — поля, вкладки и кнопки БЕЗ значений, один раз на путь страницы.
const FORM_STRUCT = () => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const t = (s, n = 40) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, n);
  const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter((c) => !/^\w{1,3}$/.test(c)).slice(0, 3).join('.');
  const out = [];
  for (const e of Array.from(document.querySelectorAll('input,textarea')).filter(vis).slice(0, 24)) out.push(`поле[${e.type || 'text'}] ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
  const tabs = [...new Set(Array.from(document.querySelectorAll('[role="tab"],[class*="tab" i]')).filter((e) => vis(e) && !e.children.length).map((e) => t(e.textContent, 20)).filter(Boolean))].slice(0, 30);
  out.push(`вкладки=[${tabs.join(' | ')}]`);
  const btns = [...new Set(Array.from(document.querySelectorAll('button,[role="button"]')).filter(vis).map((b) => `${t(b.innerText, 24)}{${cls(b)}}`).filter((x) => !x.startsWith('{')))].slice(0, 30);
  out.push(`кнопки=[${btns.join(' | ')}]`);
  return `${location.pathname} ${out.join(' ; ')}`;
};

async function dumpForm(page) {
  let u = ''; try { u = String(page.url()); } catch { return; }
  if (!isOurbit(u)) return;
  let key = ''; try { key = new URL(u).pathname; } catch { return; }
  if (!/exchange|spot|trade/i.test(key) || forms.has(key)) return;
  forms.add(key);
  try {
    await page.waitForTimeout(3000); // форма дорисовывается после загрузки
    const s = await page.evaluate(FORM_STRUCT);
    if (s) out(`ФОРМА ${s.slice(0, 3500)}`);
  } catch (e) { out(`ФОРМА: не снята (${String((e && e.message) || e).slice(0, 80)})`); }
}

// ── ПРОБА ПОДПИСИ (оператор 16.11, «да, делай пробу подписи»). У MEXC подпись сайта (x-mxc-sign/nonce) не
// привязана к телу — по ней ArbiBrowser ставит заявки прямым запросом. Ourbit — клон MEXC; проверяем один раз:
// после РУЧНОЙ лимитки на покупку и её РУЧНОЙ отмены (деньги снова свободны) повторяем тот же запрос с той же
// ценой (её поставил человек — далеко от рынка) и количеством на один шаг меньше (тело другое), и сразу отменяем
// новую заявку. Ответ — в журнал: «подпись переиспользуется: да / нет». Один раз (файл-метка), значения
// заголовков и подписи никуда не пишутся. Выключить — ARBI_OURBIT_SIGN_PROBE=0.
const PROBE_ON = () => process.env.ARBI_OURBIT_SIGN_PROBE !== '0';
const PROBE_MARK = () => path.join(config.reportsDir, 'ourbit-sign-probe.done');
const SKIP_HDR = /^(cookie|host|content-length|user-agent|origin|referer|accept-encoding|connection|priority|sec-|:)/i;
const manual = new Map(); // orderId → { page, url, hdr, body } — ручные покупки этого процесса
let probing = false;

/** Количество на один шаг меньше в той же записи: «954.5» → «954.4», «100» → «99». null — нельзя. */
function stepDown(q) {
  const m = /^(\d+)(?:\.(\d+))?$/.exec(String(q || ''));
  if (!m) return null;
  const dec = (m[2] || '').length;
  const units = BigInt(m[1] + (m[2] || '')) - 1n;
  if (units <= 0n) return null;
  const str = units.toString().padStart(dec + 1, '0');
  return dec ? `${str.slice(0, -dec)}.${str.slice(-dec)}` : str;
}

async function rememberPlace(page, req) {
  let h = {};
  try { h = await req.allHeaders(); } catch { h = req.headers(); }
  let body = null;
  try { body = JSON.parse(req.postData() || ''); } catch { return null; }
  const hdr = {};
  for (const [k, v] of Object.entries(h || {})) if (!SKIP_HDR.test(k)) hdr[k] = v;
  return { page, url: req.url(), hdr, body };
}

async function runProbe(cap) {
  if (probing || !PROBE_ON()) return;
  try { if (fs.existsSync(PROBE_MARK())) return; } catch { /* нет доступа — пробуем */ }
  const qty = stepDown(cap.body.quantity);
  if (cap.body.tradeType !== 'BUY' || cap.body.orderType !== 'LIMIT_ORDER' || !qty) {
    out(`ПРОБА: пропущена — нужна ручная ЛИМИТНАЯ ПОКУПКА (была ${cap.body.tradeType}/${cap.body.orderType})`);
    return;
  }
  probing = true;
  try { fs.writeFileSync(PROBE_MARK(), new Date().toISOString()); } catch { /* метка необязательна */ }
  const body = { ...cap.body, quantity: qty };
  out(`ПРОБА: повторяю заявку ${body.currency}/${body.market} BUY по ${body.price} на ${qty} (было ${cap.body.quantity}) с подписью ручной заявки`);
  const res = await cap.page.evaluate(async ({ url, hdr, body }) => {
    try {
      const r = await fetch(url, { method: 'POST', headers: hdr, body: JSON.stringify(body), credentials: 'include' });
      let j = null; try { j = await r.json(); } catch { /* не JSON */ }
      return { status: r.status, code: j ? j.code : null, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON', data: j && typeof j.data === 'string' ? j.data : null };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: cap.url, hdr: cap.hdr, body }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
  if (res.error || res.status !== 200 || res.code !== 200 || !res.data) {
    out(`ПРОБА: подпись переиспользуется: НЕТ — HTTP ${res.status ?? '-'} code=${res.code ?? '-'} «${res.msg || res.error || ''}». Заявки Ourbit пойдут формой.`);
    probing = false;
    return;
  }
  out(`ПРОБА: подпись переиспользуется: ДА — заявка ${res.data} поставлена прямым запросом. Отменяю…`);
  const url = `${new URL(cap.url).origin}/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(res.data)}`;
  const hdr = {};
  for (const [k, v] of Object.entries(cap.hdr)) if (!/^content-type$/i.test(k)) hdr[k] = v;
  const c = await cap.page.evaluate(async ({ url, hdr }) => {
    try {
      const r = await fetch(url, { method: 'DELETE', headers: hdr, credentials: 'include' });
      let j = null; try { j = await r.json(); } catch { /* не JSON */ }
      return { status: r.status, code: j ? j.code : null, msg: j ? String(j.msg || '').slice(0, 120) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 120) }; }
  }, { url, hdr }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 120) }));
  out(c.status === 200 && c.code === 200
    ? 'ПРОБА: пробная заявка отменена — проба закончена'
    : `ПРОБА: ⚠ пробную заявку ${res.data} отменить НЕ удалось (HTTP ${c.status ?? '-'} code=${c.code ?? '-'} «${c.msg || c.error || ''}») — ОТМЕНИТЕ ЕЁ РУКАМИ в открытых ордерах Ourbit`);
  probing = false;
}

// ── ПРОБА 2 (оператор 16.11: «подпись — для пары или на сессию? при запуске ставим служебный ордер USDC/USDT на
// 50 % ниже, получаем подпись и дальше все сделки гоним с ней — реально?»). После следующей ручной лимитной покупки
// и её отмены: 1) та же заявка БЕЗ x-ourbit-sign/nonce — нужна ли подпись вообще; 2) покупка USDC/USDT по 0.5 (−50 %)
// на 10 USDC с подписью ручной заявки — подходит ли подпись к другой паре; 3) та же заявка с той же подписью через
// 10, 30 и 60 мин — сколько подпись живёт. Каждая встала — сразу отмена. Один раз (метка ourbit-sign-probe2.done).
const PROBE2_MARK = () => path.join(config.reportsDir, 'ourbit-sign-probe2.done');
const livePage = (cap) => {
  try { if (!cap.page.isClosed()) return cap.page; } catch { /* закрыта */ }
  try { return cap.page.context().pages().find((p) => !p.isClosed() && isOurbit(p.url())) || null; } catch { return null; }
};
async function placeCancel(cap, hdr, reqBody, label) {
  const page = livePage(cap);
  if (!page) { out(`ПРОБА 2 · ${label}: пропущена — нет открытой вкладки Ourbit в профиле`); return; }
  const r = await page.evaluate(async ({ url, hdr, body }) => {
    try {
      const res = await fetch(url, { method: 'POST', headers: hdr, body: JSON.stringify(body), credentials: 'include' });
      let j = null; try { j = await res.json(); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON', data: j && typeof j.data === 'string' ? j.data : null };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: cap.url, hdr, body: reqBody }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
  if (r.error || r.status !== 200 || r.code !== 200 || !r.data) {
    out(`ПРОБА 2 · ${label}: НЕТ — HTTP ${r.status ?? '-'} code=${r.code ?? '-'} «${r.msg || r.error || ''}»`);
    return;
  }
  out(`ПРОБА 2 · ${label}: ДА — заявка ${r.data} (${reqBody.currency}/${reqBody.market} ${reqBody.price} × ${reqBody.quantity}) встала. Отменяю…`);
  const ch = {};
  for (const [k, v] of Object.entries(hdr)) if (!/^content-type$/i.test(k)) ch[k] = v;
  const c = await page.evaluate(async ({ url, hdr }) => {
    try {
      const res = await fetch(url, { method: 'DELETE', headers: hdr, credentials: 'include' });
      let j = null; try { j = await res.json(); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, msg: j ? String(j.msg || '').slice(0, 120) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 120) }; }
  }, { url: `${new URL(cap.url).origin}/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(r.data)}`, hdr: ch })
    .catch((e) => ({ error: String((e && e.message) || e).slice(0, 120) }));
  out(c.status === 200 && c.code === 200
    ? `ПРОБА 2 · ${label}: заявка ${r.data} отменена`
    : `ПРОБА 2 · ${label}: ⚠ заявку ${r.data} отменить НЕ удалось (HTTP ${c.status ?? '-'} code=${c.code ?? '-'} «${c.msg || c.error || ''}») — ОТМЕНИТЕ РУКАМИ в открытых ордерах Ourbit`);
}

async function runProbe2(cap) {
  if (probing || !PROBE_ON()) return;
  try { if (fs.existsSync(PROBE2_MARK())) return; } catch { /* нет доступа — пробуем */ }
  if (cap.body.tradeType !== 'BUY' || cap.body.orderType !== 'LIMIT_ORDER') {
    out(`ПРОБА 2: пропущена — нужна ручная ЛИМИТНАЯ ПОКУПКА (была ${cap.body.tradeType}/${cap.body.orderType})`);
    return;
  }
  probing = true;
  try { fs.writeFileSync(PROBE2_MARK(), new Date().toISOString()); } catch { /* метка необязательна */ }
  try {
    const noSign = {};
    for (const [k, v] of Object.entries(cap.hdr)) if (!/^x-ourbit-(sign|nonce)$/i.test(k)) noSign[k] = v;
    await placeCancel(cap, noSign, cap.body, 'без подписи');
    await placeCancel(cap, cap.hdr, { currency: 'USDC', market: 'USDT', tradeType: 'BUY', price: '0.5', quantity: '10', orderType: 'LIMIT_ORDER' }, 'подпись другой пары → USDC/USDT');
  } finally { probing = false; }
  for (const min of [10, 30, 60]) {
    const t = setTimeout(() => { placeCancel(cap, cap.hdr, cap.body, `та же подпись через ${min} мин`).catch(() => {}); }, min * 60_000);
    if (t.unref) t.unref();
  }
  out('ПРОБА 2: проверки срока подписи — через 10, 30 и 60 мин (ArbiBrowser должен оставаться запущенным)');
}

/**
 * КУДА СТРАНИЦА ДЕВАЕТ РЕЗУЛЬТАТ КАПЧИ (16.11, ради прямого вывода за 1–2 с). В теле save/submit его нет, заголовки
 * те же, что у нас, — значит параметры адреса, cookie или ответ шага капчи. Пишем ТОЛЬКО имена (параметров, заголовков,
 * cookie, полей ответа) и форму значений (да/нет, число, «строка N симв.») — ни одного значения строк.
 */
// 16.11 вечер: формат капчи разобран — пишем только шаги самого вывода (капча-робот, подготовка, подтверждение) и два
// служебных запроса страницы перед подтверждением; загрузка страницы (config, geetest, статика) больше не пишется.
const WD_DIAG_RE = /captcha\/robot|check_chain|save_withdraw|submit_withdraw|common\/ping/i;
let pingDiag = 0;
let capDiagLines = 0;
const shapeOf = (v, pre = '', acc = []) => {
  if (acc.length > 40) return acc;
  if (Array.isArray(v)) { acc.push(`${pre}[${v.length}]`); return acc; }
  if (v && typeof v === 'object') { for (const [k, x] of Object.entries(v)) shapeOf(x, pre ? `${pre}.${k}` : k, acc); return acc; }
  acc.push(`${pre}=${typeof v === 'string' ? `«${v.length} симв.»` : String(v)}`);
  return acc;
};
let lastPing = null; // { time, at } — последний ответ ping вкладки вывода (время сервера — не секрет)
async function capDiagReq(req) {
  const at = Date.now();
  let x; try { x = new URL(req.url()); } catch { return; }
  let hn = []; let extra = '';
  try {
    const h = await req.allHeaders();
    // Метка trace-id (4 знака хэша, не значение): одинаковая у двух запросов = повтор одного id; и страница-источник.
    if (h['luminex-trace-id']) extra += ` trace=#${require('node:crypto').createHash('md5').update(h['luminex-trace-id']).digest('hex').slice(0, 4)}/${h['luminex-trace-id'].length}`;
    try { if (h.referer) extra += ` со страницы=${new URL(h.referer).pathname}`; } catch { /* не адрес */ }
    // Метка времени подписи относительно часов компьютера и последнего ответа ping (сама метка — время, не секрет).
    const n = Number(h['x-ourbit-nonce']);
    if (n) extra += ` nonce=часы${n - at >= 0 ? '+' : ''}${n - at}мс${lastPing ? `, ping${n - lastPing.time >= 0 ? '+' : ''}${n - lastPing.time}мс (ping был ${at - lastPing.at} мс назад)` : ''}`;
    hn = Object.keys(h).filter((k) => !/^(accept|accept-language|accept-encoding|connection|content-length|origin|referer|sec-|user-agent|cookie)/i.test(k));
  } catch { /* закрыта */ }
  let tok = '';
  try {
    const v = String((await req.allHeaders())['captcha-token'] || '');
    if (v) {
      let j = null; try { j = JSON.parse(v); } catch { try { j = JSON.parse(Buffer.from(v, 'base64').toString('utf8')); tok = ' (base64)'; } catch { j = null; } }
      tok = ` captcha-token: ${v.length} симв.${tok}, ${j && typeof j === 'object' ? `JSON поля=[${shapeOf(j).join(', ')}]` : `не JSON, начало «${v.slice(0, 1)}», символы ${/^[A-Za-z0-9+/=]+$/.test(v) ? 'base64' : /^[\w.-]+$/.test(v) ? 'слово/точки' : 'смешанные'}`}`;
    }
  } catch { /* закрыта */ }
  out(`КАПЧА-ДИАГ запрос ${req.method()} ${x.host}${x.pathname}${tok} параметры=[${[...x.searchParams.keys()].join(',')}] заголовки=[${hn.join(',')}]${extra}`, true);
}
async function capDiagResp(resp) {
  let x; try { x = new URL(resp.url()); } catch { return; }
  if (!/captcha\/robot|risk_material|common\/ping/i.test(x.href)) return;
  const t = await resp.text().catch(() => '');
  const m = t.match(/\{[\s\S]*\}/);
  let v = null; try { v = m ? JSON.parse(m[0]) : null; } catch { v = null; }
  const sc = String((resp.headers() || {})['set-cookie'] || '').split('\n').map((c) => c.split('=')[0].trim()).filter(Boolean);
  out(`КАПЧА-ДИАГ ответ ${x.host}${x.pathname} → ${resp.status()} поля=[${v ? shapeOf(v).join(', ') : `не JSON ${t.length} симв.`}]${sc.length ? ` set-cookie=[${sc.join(',')}]` : ''}`, true);
}

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('load', () => { if (ON()) dumpForm(page).catch(() => {}); });
  page.on('request', (req) => {
    try {
      const u = req.url();
      if (ON() && capDiagLines < 600 && /\/assets\/withdraw/.test(page.url()) && WD_DIAG_RE.test(u) && !(/common\/ping/.test(u) && (pingDiag += 1) > 4)) { capDiagLines += 1; capDiagReq(req).catch(() => {}); }
      // Страница вывода (16.11): подтверждение из терминала получает 60008 при тех же заголовках, подписи и теле —
      // ищем скрытый шаг страницы между подготовкой и подтверждением. Пишем ВСЕ её запросы (метод, хост, путь) без
      // фильтров и тел, до 300 строк на процесс.
      if (ON() && wdPaths < 300 && /\/assets\/withdraw/.test(page.url()) && /match_chain|check_address|check_chain|captcha\/robot|risk_material|save_withdraw|submit_withdraw|geetest\.com\/verify/.test(u)) {
        wdPaths += 1;
        let hp = u; try { const x = new URL(u); hp = x.host + x.pathname; } catch { /* как есть */ }
        out(`СТРАНИЦА ВЫВОДА ${req.method()} ${req.resourceType()} ${hp}`, true);
      }
      if (!ON() || (budget <= 0 && !VIP_RE.test(u)) || !isOurbit(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (!API_RE.test(u) || NOISE_RE.test(u)) return;
      if (req.method() === 'GET') return; // GET-ы пишем ответом ниже
      // Только ИМЕНА заголовков: значения (подписи, токены) не читаем и не пишем.
      const names = Object.keys(req.headers() || {}).filter((h) => !/^(accept|accept-language|accept-encoding|connection|content-length|origin|referer|sec-|user-agent|cookie)/i.test(h));
      out(`ВЫЗОВ ${req.method()} ${scrubUrl(u)} заголовки=[${names.join(',')}] тело=${body(req.postData(), true)}`, VIP_RE.test(u));
      if (PROBE_ON() && !probing && req.method() === 'POST' && /\/spot\/order\/place$/.test(new URL(u).pathname)) {
        rememberPlace(page, req).then((cap) => { if (cap) req.__ourbitCap = cap; }).catch(() => {});
      }
    } catch { /* диагностика */ }
  });
  page.on('response', async (resp) => {
    try {
      const req = resp.request();
      const u = resp.url();
      if (ON() && /\/assets\/withdraw/.test(page.url()) && /common\/ping/.test(u)) { const at = Date.now(); resp.json().then((j) => { if (j && Number(j.time)) lastPing = { time: Number(j.time), at }; }).catch(() => {}); }
      if (ON() && capDiagLines < 600 && /\/assets\/withdraw/.test(page.url()) && /captcha\/robot/i.test(u)) { capDiagLines += 1; capDiagResp(resp).catch(() => {}); }
      else if (ON() && pingDiag <= 4 && /\/assets\/withdraw/.test(page.url()) && /common\/ping/.test(u)) capDiagResp(resp).catch(() => {});
      if (!ON() || (budget <= 0 && !VIP_RE.test(u)) || !isOurbit(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (!API_RE.test(u) || NOISE_RE.test(u)) return;
      if (req.method() === 'GET' && POLL_RE.test(u)) return;
      const t = await resp.text().catch(() => '');
      out(`ОТВЕТ ${req.method()} ${scrubUrl(u)} → ${resp.status()} ${body(t)}`, VIP_RE.test(u));
      if (!PROBE_ON() || probing) return;
      let j = null; try { j = JSON.parse(t); } catch { return; }
      const pth = new URL(u).pathname;
      // Ручная заявка поставлена — запомнить её запрос; её же ручная отмена прошла — пробовать.
      if (req.method() === 'POST' && /\/spot\/order\/place$/.test(pth) && j && j.code === 200 && typeof j.data === 'string') {
        await new Promise((r) => setTimeout(r, 50)); // allHeaders запроса успевает разрешиться
        if (req.__ourbitCap) manual.set(j.data, req.__ourbitCap);
      } else if (req.method() === 'DELETE' && /\/spot\/order\/cancel\/v2$/.test(pth) && j && j.code === 200) {
        const id = new URL(u).searchParams.get('orderId');
        const cap = id && manual.get(id);
        if (cap) {
          manual.delete(id);
          let first = false; try { first = !fs.existsSync(PROBE_MARK()); } catch { first = true; }
          (first ? runProbe(cap) : runProbe2(cap)).catch(() => { probing = false; });
        }
      }
    } catch { /* диагностика */ }
  });
}

/** Подключить ловушку ко всем вкладкам профиля (текущим и будущим). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

module.exports = { attach, FILE, _isOurbit: isOurbit, _stepDown: stepDown };

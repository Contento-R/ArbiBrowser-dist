'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { hold, isHeld, release, _tick } = require('./login-hold');

const page = (url, wall, text, extra = {}) => ({ url: () => url, isClosed: () => false, evaluate: async () => extra.loadedAt || 0, __wall: { wall, text }, ...extra });
const ctxOf = (pages) => ({ pages: () => pages });
const cfg = (logs) => ({ ex: 'BINGX', name: 'BingX', origin: 'https://bingx.com', loginWall: async (p) => p.__wall, log: (m) => logs.push(m), onLogin: () => logs.push('ON_LOGIN') });

test('login-hold: пока стоит «Войти» — режим держится; кнопки заявки на месте — снят', async () => {
  const logs = [];
  const p = page('https://bingx.com/ru/spot/STONKUSDT', true, 'шапка: Войти');
  const ctx = ctxOf([p]);
  const c = cfg(logs);
  assert.equal(hold(ctx, c), true);
  assert.equal(hold(ctx, c), false, 'повторное включение — не новое');
  const info = { since: Date.now() - 1000, loginPage: null, candidate: 0 };
  await _tick(ctx, c, info);
  assert.equal(isHeld(ctx, 'BINGX'), true);
  p.__wall = { wall: false, text: 'Купить | Продать' };
  await _tick(ctx, c, info);
  assert.equal(isHeld(ctx, 'BINGX'), false);
  assert.ok(logs.includes('ON_LOGIN'));
});

test('login-hold: страница входа не считается входом; редирект на сайт — два тика подряд', async () => {
  const logs = [];
  const since = Date.now() - 5000;
  const login = page('https://bingx.com/ru/accounts/login?redirect=x', false, '');
  const ctx = ctxOf([login]);
  const c = cfg(logs);
  hold(ctx, c, { loginPage: login });
  const info = { since, loginPage: login, candidate: 0 };
  await _tick(ctx, c, info);
  assert.equal(isHeld(ctx, 'BINGX'), true, 'страница входа — не вход');
  login.url = () => 'https://bingx.com/ru/';
  login.evaluate = async () => Date.now();
  await _tick(ctx, c, info);
  assert.equal(isHeld(ctx, 'BINGX'), true, 'один тик — мало');
  await _tick(ctx, c, info);
  assert.equal(isHeld(ctx, 'BINGX'), false);
  release(ctx, c, 'x', false);
});

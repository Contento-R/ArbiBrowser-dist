'use strict';

/**
 * login-hold.js — РЕЖИМ «ИДЁТ ВХОД» (оператор 2026-10-18).
 *
 * Биржа разлогинила профиль → терминал продолжал слать прогревы и заявки, и каждая
 * перезагружала вкладку: человек вводил логин, а страница сбрасывалась под ним.
 * Теперь, как только «нет входа» подтверждено, вкладки этой биржи в профиле НЕ
 * трогаются вовсе (ни перезагрузок, ни переходов, ни кликов): исполнитель отвечает
 * «нет входа» сразу, а здесь раз в 2 с ТОЛЬКО ЧИТАЕМ страницы биржи и ждём входа:
 *   • кнопки заявки на месте и это не «Войти» — вход есть (точный признак);
 *   • или свежая страница (открыта после начала режима) ушла со страницы входа на
 *     сайт биржи и стены входа на ней нет — два тика подряд (редирект после входа).
 * Вход замечен → режим снят, page-driver.noteLogin (старые вкладки один раз
 * перезагрузятся при следующей заявке), onLogin → терминал снимает плашку.
 * Через 10 минут без входа режим снимается сам — дальше обычная проверка.
 */
const { isAsleep } = require('./pair-tabs');
const { noteLogin } = require('./page-driver');

const TICK_MS = 2000;
const MAX_HOLD_MS = 10 * 60_000;
const LOGIN_URL_RE = /log-?in|sign-?in|sign-?up|register|passport|verify|captcha|forget|reset-?pass/i;
const holds = new WeakMap(); // context → Map(ex → {since, loginPage, candidate, timer})

const mapOf = (ctx) => { let m = holds.get(ctx); if (!m) { m = new Map(); holds.set(ctx, m); } return m; };
const isHeld = (ctx, ex) => !!(ctx && holds.get(ctx) && holds.get(ctx).has(ex));

/**
 * @param {*} ctx контекст профиля
 * @param {{ex:string, name:string, origin:string, loginWall:Function, log:Function, onLogin?:Function}} cfg
 * @param {{loginPage?:*}} [opts]
 * @returns {boolean} true — режим включён сейчас (а не был уже)
 */
function hold(ctx, cfg, opts = {}) {
  const m = mapOf(ctx);
  const cur = m.get(cfg.ex);
  if (cur) { if (opts.loginPage) cur.loginPage = opts.loginPage; return false; }
  const info = { since: Date.now(), loginPage: opts.loginPage || null, candidate: 0, timer: null };
  m.set(cfg.ex, info);
  cfg.log(`[вход] ${cfg.name}: нет входа — режим «идёт вход»: вкладки биржи не трогаю (без перезагрузок и кликов), заявки сразу отвечают «нет входа»; жду входа`);
  info.timer = setInterval(() => { tick(ctx, cfg, info).catch(() => {}); }, TICK_MS);
  if (info.timer.unref) info.timer.unref();
  return true;
}

function release(ctx, cfg, why, loggedIn) {
  const m = holds.get(ctx);
  const info = m && m.get(cfg.ex);
  if (!info) return;
  clearInterval(info.timer);
  m.delete(cfg.ex);
  if (loggedIn) noteLogin(ctx);
  cfg.log(`[вход] ${cfg.name}: ${why} — режим «идёт вход» снят`);
  if (loggedIn && cfg.onLogin) { try { cfg.onLogin(ctx); } catch { /* событие необязательно */ } }
}

async function tick(ctx, cfg, info) {
  if (Date.now() - info.since > MAX_HOLD_MS) { release(ctx, cfg, '10 минут без входа — дальше обычная проверка', false); return; }
  let pages = [];
  try { pages = ctx.pages(); } catch { release(ctx, cfg, 'профиль закрыт', false); return; }
  let redirected = false;
  for (const p of pages) {
    let url = '';
    try { if (p.isClosed() || isAsleep(p)) continue; url = String(p.url()); } catch { continue; }
    if (!url.startsWith(cfg.origin) || LOGIN_URL_RE.test(url)) continue;
    const lw = await cfg.loginWall(p);
    if (lw.wall) continue;
    if (lw.text && !String(lw.text).startsWith('шапка')) { release(ctx, cfg, 'вход выполнен (кнопки заявки на месте)', true); return; }
    const loadedAt = await p.evaluate(() => (document.readyState === 'complete' ? performance.timeOrigin : 0)).catch(() => 0);
    if (p === info.loginPage ? loadedAt > 0 : loadedAt > info.since) redirected = true;
  }
  info.candidate = redirected ? info.candidate + 1 : 0;
  if (info.candidate >= 2) release(ctx, cfg, 'вход выполнен (страница входа ушла на сайт биржи)', true);
}

module.exports = { hold, isHeld, release, LOGIN_URL_RE, _tick: tick };

'use strict';

/**
 * events.js — события ArbiBrowser в терминал без намерения (оператор 2026-10-18):
 * «вход выполнен», «замер разлогина», «IP прокси сменился / идёт мимо прокси».
 * Старый терминал без эндпоинта ответит 404 — молча игнорируем.
 */
const { requestJson } = require('./executor-core');

function postEvent(body) {
  return requestJson('POST', '/api/integrations/arbibrowser/event', body, 10000).catch(() => {});
}

module.exports = { postEvent };

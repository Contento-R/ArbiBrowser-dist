'use strict';

/**
 * withdraw-capture.js — ЛОВУШКА ДЛЯ ОТМЕНЫ ВЫВОДА BingX (оператор 2026-10-18).
 *
 * Чтобы отменять вывод за ~1 с, нужен тот же вызов API, что делает сайт по кнопке
 * «Отменить». Снять его руками в DevTools нельзя: вывод уходит в обработку раньше,
 * чем успеваешь кликнуть. Поэтому ловим сами, во всех вкладках BingX профиля:
 *   1) КОД САЙТА: в загружаемых скриптах BingX ищем строки адресов API со словом
 *      withdraw (и cancel/revoke рядом) + кусок кода вокруг — так виден адрес отмены
 *      и имена полей, даже без отменяемого вывода;
 *   2) ВЫЗОВЫ: любой запрос вкладки BingX к API вывода — метод, адрес, тело, ответ.
 *   3) ФОРМА (Gate): структура полей страницы вывода (поля ввода, списки, кнопки — БЕЗ
 *      значений) — чтобы автозаполнение писалось по реальной разметке, а не вслепую.
 * Заголовки и cookie НЕ читаются никогда; в телах вымарываются ключи вида token/sign/
 * uid/phone и длинные строки (адреса). Всё — в журнал «[захват вывода] …» и в файл
 * <данные>/reports/withdraw-capture.txt. BingX — по ARBI_WD_CAPTURE=1; Gate (вывод через
 * сайт, 19.10) — всегда, пока вызов не найден. MEXC (вывод через сайт, 22.10) — только на
 * странице вывода: структура формы, выпадашек и окон подтверждения (адреса маскируются) и
 * вызовы вывода; скрипты MEXC не разбираем. Выключить — ARBI_MEXC_WD_CAPTURE=0.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { scrub, scrubUrl } = require('./bingx-deposit-page');
const { isContextBusy } = require('./context-lock');

// BingX: адрес отмены найден 18.10 (bingx-withdraw-page FAST) — только по ARBI_WD_CAPTURE=1.
// Gate: включено всегда, пока не найден вызов вывода через сайт (API закрывает вывод
// неликвидных монет, 19.10 EVO) — ловим его при первом ручном выводе на gate.com.
const ON = () => process.env.ARBI_WD_CAPTURE === '1';
const FILE = () => path.join(config.reportsDir, 'withdraw-capture.txt');
const MEXC_ON = () => (process.env.ARBI_MEXC_WD_CAPTURE || '1') !== '0';
const API_HOST_RE = /bingx|we-api|acc-de|qq-os|bb-os|gate\.(com|io)|mexc\./i;
// MEXC — только страница вывода: торговые вкладки MEXC ловушка не трогает вовсе.
const siteOf = (u) => (/gate\.(com|io)/i.test(u) ? 'gate' : /bingx\./i.test(u) ? 'bingx' : /mexc\.com\/.*assets\/withdraw/i.test(u) ? 'mexc' : null);
const enabledFor = (u) => { const s = siteOf(u); return s === 'gate' || (s === 'bingx' && ON()) || (s === 'mexc' && MEXC_ON()); };
// Тела вывода могут нести одноразовые коды/пароль фонда — их ключи тоже вымарываем.
const CODE_KEY_RE = /code|otp|totp|pin|fund|pass|pwd|verif|captcha|sign|token/i;
const maskCodes = (v) => (Array.isArray(v) ? v.map(maskCodes) : v && typeof v === 'object'
  ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, CODE_KEY_RE.test(k) ? '[скрыто]' : maskCodes(x)])) : v);
const WD_RE = /withdraw/i;
// BingX зовёт отмену вывода «back» (back-apply/recent-back — первая находка 18.10)
const CANCEL_RE = /cancel|revoke|undo|back/i;
const PATH_RE = /["'`](\/?(?:api\/)?[A-Za-z0-9_\-/{}.]*withdraw[A-Za-z0-9_\-/{}.]*)["'`]/gi;
const scannedForms = new Set(); // URL страницы вывода → структура формы уже снята
const scanned = new Set();  // URL скрипта → уже прочитан
const endpoints = new Map(); // путь → кусок кода вокруг
const attached = new WeakSet();

function out(line) {
  console.log(`[захват вывода] ${line}`);
  try {
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    fs.appendFileSync(FILE(), `${new Date().toISOString()} ${line}\n`);
  } catch { /* файл необязателен — журнал есть */ }
}

const body = (text, req = false) => {
  if (!text) return '';
  let v = null;
  try { v = JSON.parse(text); } catch {
    // Gate шлёт формы (a=1&b=2) — разбираем, чтобы видеть имена полей.
    if (/^[\w.%[\]-]+=/.test(text)) v = Object.fromEntries(new URLSearchParams(text));
  }
  return v == null ? `[не JSON, ${text.length} симв.]` : JSON.stringify(scrub(req ? maskCodes(v) : v)).slice(0, 3000);
};

// Структура формы вывода Gate — поля БЕЗ значений, тексты усечены. Снимается один раз
// на страницу вывода, в журнал «ФОРМА …»: по ней пишется реальное автозаполнение.
async function dumpForm(page) {
  let url = ''; try { url = String(page.url()); } catch { return; }
  if (!/gate\.(com|io)/i.test(url) || !/withdraw/i.test(url) || scannedForms.has(url)) return;
  scannedForms.add(url);
  try {
    await page.waitForTimeout(2500); // форма дорисовывается после загрузки
    const lines = await page.evaluate(() => {
      const t = (s) => String(s || '').replace(/\s+/g, ' ').trim().slice(0, 40);
      const vis = (e) => { try { return e.offsetParent !== null && e.getBoundingClientRect().width > 2; } catch { return false; } };
      const labelOf = (e) => t(e.getAttribute('placeholder') || e.getAttribute('aria-label')
        || (e.id && (document.querySelector('label[for="' + e.id + '"]') || {}).textContent) || '');
      const out = [];
      for (const e of Array.from(document.querySelectorAll('input,textarea')).filter(vis).slice(0, 40))
        out.push('input[type=' + (t(e.type) || 'text') + '] name=' + t(e.name) + ' метка="' + labelOf(e) + '"');
      for (const e of Array.from(document.querySelectorAll('select')).filter(vis).slice(0, 10))
        out.push('select метка="' + labelOf(e) + '" опции=[' + Array.from(e.options).slice(0, 8).map((o) => t(o.textContent)).join('|') + ']');
      const btns = Array.from(document.querySelectorAll('button,[role="button"],a')).filter(vis)
        .map((e) => t(e.textContent)).filter((x) => x && x.length > 1);
      out.push('кнопки=[' + [...new Set(btns)].slice(0, 25).join('|') + ']');
      return out;
    });
    for (const l of lines) out(`ФОРМА ${l}`);
  } catch (e) { out(`ФОРМА: не снята (${(e && e.message || e).toString().slice(0, 80)})`); }
}

// Страница вывода MEXC: структура формы, открытых выпадашек и окон — каждые 2 с первые
// 10 мин после загрузки, только когда изменилась. Значений полей нет, адреса — 0x12…cd.
const MEXC_STRUCT = () => {
  const vis = (e) => { if (!e || !e.getBoundingClientRect) return false; const r = e.getBoundingClientRect(); const s = getComputedStyle(e); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
  const t = (s, n = 50) => String(s || '').replace(/\s+/g, ' ').trim().replace(/\b(0x[0-9a-fA-F]{6,}|[1-9A-HJ-NP-Za-km-z]{26,})\b/g, (m) => `${m.slice(0, 4)}…${m.slice(-4)}`).slice(0, n);
  const cls = (e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className || '').split(/\s+/).filter((c) => !/^\w{1,3}$/.test(c)).slice(0, 3).join('.');
  const out = [];
  for (const e of Array.from(document.querySelectorAll('input,textarea')).filter(vis).slice(0, 20)) out.push(`поле[${e.type || 'text'}] ${cls(e)} «${t(e.placeholder || e.getAttribute('aria-label'))}»`);
  const labs = [...new Set(Array.from(document.querySelectorAll('label,dt,h3,h4,h5,div,span')).filter((e) => vis(e) && !e.children.length && /^[^\d]{2,30}$/.test(String(e.textContent || '').trim())).map((e) => t(e.textContent, 30)))].slice(0, 40);
  out.push(`подписи=[${labs.join(' | ')}]`);
  const btns = [...new Set(Array.from(document.querySelectorAll('button,[role="button"]')).filter(vis).map((b) => t(b.innerText, 30)).filter(Boolean))].slice(0, 25);
  out.push(`кнопки=[${btns.join(' | ')}]`);
  for (const p of Array.from(document.querySelectorAll('[class*="dropdown" i],[class*="popover" i],[class*="popup" i],[role="listbox"],[class*="drawer" i]')).filter(vis).slice(0, 3)) {
    const rows = Array.from(p.querySelectorAll('[role="option"],[class*="option" i],[class*="item" i],li')).filter(vis).slice(0, 15).map((o) => `${cls(o)}:«${t(o.innerText, 60)}»`);
    if (rows.length) out.push(`список ${cls(p)}=[${rows.join(' | ')}]`);
  }
  for (const d of Array.from(document.querySelectorAll('[role="dialog"],[class*="modal" i]')).filter(vis).slice(0, 3)) {
    out.push(`окно ${cls(d)}: «${t(d.innerText, 400)}» кнопки=[${Array.from(d.querySelectorAll('button,[role="button"]')).filter(vis).map((b) => t(b.innerText, 25)).join(' | ')}] поля=${Array.from(d.querySelectorAll('input')).filter(vis).length} iframe=${d.querySelectorAll('iframe,canvas').length}`);
  }
  return `${location.pathname} ${out.join(' ; ')}`;
};
// Один наблюдатель на вкладку: новая загрузка лишь продлевает срок (вкладку вывода
// перезагружают часто — по наблюдателю на загрузку они копились бы в общем процессе MEXC).
const mexcWatch = new WeakMap(); // page → { until, last }
// Бюджет на процесс: для захвата разметки хватает получаса снимков; вкладка вывода живёт
// всегда, и без потолка наблюдение шло бы постоянно в общем процессе MEXC (ревью 22.10).
let mexcTicksLeft = 900;
function watchMexc(page) {
  if (!MEXC_ON() || mexcTicksLeft <= 0) return;
  const w = mexcWatch.get(page);
  if (w) { w.until = Date.now() + 10 * 60_000; return; }
  const st = { until: Date.now() + 10 * 60_000, last: '' };
  mexcWatch.set(page, st);
  let busy = false;
  const t = setInterval(async () => {
    let url = ''; try { if (page.isClosed()) throw 0; url = String(page.url()); } catch { clearInterval(t); mexcWatch.delete(page); return; }
    if (Date.now() > st.until || siteOf(url) !== 'mexc') { clearInterval(t); mexcWatch.delete(page); return; }
    if (busy) return;
    // Идёт заявка этого профиля — не трогаем общий процесс MEXC.
    try { if (isContextBusy(page.context(), 'order')) return; } catch { return; }
    if (--mexcTicksLeft <= 0) { clearInterval(t); mexcWatch.delete(page); out('ФОРМА MEXC: бюджет снимков исчерпан — наблюдение остановлено'); return; }
    busy = true;
    const s = await page.evaluate(MEXC_STRUCT).catch(() => '');
    busy = false;
    if (s && s !== st.last) { st.last = s; out(`ФОРМА MEXC ${s.slice(0, 3500)}`); }
  }, 2000);
  if (t.unref) t.unref();
}

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  const pageOn = () => { try { return enabledFor(String(page.url())); } catch { return false; } };
  page.on('load', () => {
    dumpForm(page).catch(() => {});
    try { if (siteOf(String(page.url())) === 'mexc') watchMexc(page); } catch { /* закрыта */ }
  });
  page.on('request', (req) => {
    try {
      const u = req.url();
      if (!pageOn() || !API_HOST_RE.test(u) || !WD_RE.test(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (req.method() === 'GET' && !CANCEL_RE.test(u)) return; // GET-ы пишем ответом ниже
      out(`ВЫЗОВ ${req.method()} ${scrubUrl(u)} тело=${body(req.postData(), true)}`);
    } catch { /* диагностика */ }
  });
  page.on('response', async (resp) => {
    try {
      const req = resp.request();
      const u = resp.url();
      if (req.method() === 'OPTIONS') return;
      if (pageOn() && API_HOST_RE.test(u) && WD_RE.test(u) && /^(xhr|fetch)$/.test(req.resourceType())) {
        const t = await resp.text().catch(() => '');
        out(`ОТВЕТ ${req.method()} ${scrubUrl(u)} → ${resp.status()} ${body(t)}`);
        return;
      }
      if (req.resourceType() !== 'script' || !pageOn() || scanned.has(u)) return;
      try { if (siteOf(String(page.url())) === 'mexc') return; } catch { return; } // подпись MEXC — только доверенный ввод, адрес API из кода не нужен
      scanned.add(u);
      const src = await resp.text().catch(() => '');
      if (!src || src.length > 12_000_000) return;
      let m; let found = 0;
      PATH_RE.lastIndex = 0;
      while ((m = PATH_RE.exec(src)) && found < 200) {
        found += 1;
        const p = m[1];
        if (!p.includes('/') || endpoints.has(p)) continue; // ключи переводов (recharge_withdraw_…) — не адреса
        const around = src.slice(Math.max(0, m.index - 160), m.index + p.length + 220).replace(/\s+/g, ' ');
        endpoints.set(p, around);
        out(`КОД ${p}${CANCEL_RE.test(p) ? '  ← ОТМЕНА?' : ''} | ${around}`);
      }
    } catch { /* диагностика */ }
  });
}

/** Подключить ловушку ко всем вкладкам профиля (текущим и будущим). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

module.exports = { attach, FILE };

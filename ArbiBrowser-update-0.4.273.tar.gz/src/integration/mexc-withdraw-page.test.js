'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const m = require('./mexc-withdraw-page');

test('sameAmount: строго, как десятичные строки; обрезанный хвост — НЕ равно', () => {
  assert.ok(m.sameAmount('7200.65', '7200.650'));
  assert.ok(m.sameAmount('0012.5', '12.50'));
  assert.ok(m.sameAmount('1 234,5', '1234.5'));
  assert.ok(m.sameAmount('1,234.5', '1234.5'));
  assert.ok(!m.sameAmount('386204.', '386204.76'), 'биржа обрезала хвост — для вывода это отказ');
  assert.ok(!m.sameAmount('', '1'));
  assert.ok(!m.sameAmount('abc', 'abc'));
});

test('addrEq: EVM без учёта регистра, Solana — побайтно', () => {
  const evm = '0xAbCdEf0123456789abcdef0123456789ABCDEF01';
  assert.ok(m.addrEq(evm, evm.toLowerCase()));
  assert.ok(!m.addrEq(evm, evm.slice(0, -1) + '2'));
  const sol = '7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU';
  assert.ok(m.addrEq(sol, sol));
  assert.ok(!m.addrEq(sol, sol.toLowerCase()));
});

test('pickNetwork: полное имя сильнее кода; неоднозначность — отказ', () => {
  const opts = ['BNB Smart Chain(BEP20) ≈1 мин', 'Ethereum(ERC20)', 'Tron(TRC20)'];
  assert.equal(m.pickNetwork(opts, 'BNB Smart Chain(BEP20)'), 0);
  assert.equal(m.pickNetwork(['BEP20', 'ERC20'], 'BNB Smart Chain(BEP20)'), 0, 'страница показывает только код');
  assert.equal(m.pickNetwork(['BEP20 (BSC)', 'BEP20 старая'], 'BNB Smart Chain(BEP20)'), -1);
  assert.equal(m.pickNetwork(opts, 'Solana(SOL)'), -1);
});

test('pickCoin: тикер отдельным словом, не подстрокой (DEP ≠ COINDEPO, AI ≠ AIX)', () => {
  assert.equal(m.pickCoin(['COINDEPO CoinDepo', 'DEP DEAPcoin'], 'DEP'), 1);
  assert.equal(m.pickCoin(['AIX', 'AI Sleepless AI'], 'AI'), 1);
  assert.equal(m.pickCoin(['USDT Tether', 'USDC USD Coin'], 'USDT'), 0);
  assert.equal(m.pickCoin(['PEPE', 'PEPE PEPE 2.0'], 'PEPE'), -1);
});

test('pickAddress: полный адрес — сильное; начало+конец — только если один', () => {
  const a = '0x1234567890abcdef1234567890abcdef12345678';
  assert.deepEqual(m.pickAddress(['Мой DEX 0x1234567890ABCDEF1234567890ABCDEF12345678', 'Другой 0xffff'], a), { index: 0, strong: true });
  assert.deepEqual(m.pickAddress(['DEX 0x1234…5678', 'Gate 0x9999…0000'], a), { index: 0, strong: false });
  assert.equal(m.pickAddress(['A 0x1234…5678', 'B 0x1234…5678'], a).index, -1);
  assert.equal(m.pickAddress(['Gate 0x9999…0000'], a).index, -1);
});

test('maxWithin: «Макс» страницы — не больше суммы терминала +2 %, не меньше суммы − комиссия', () => {
  assert.ok(m.maxWithin('100', '100', '1'));
  assert.ok(m.maxWithin('99', '100', '1'), 'комиссия сверху (класс WOJAK)');
  assert.ok(m.maxWithin('101.5', '100', '1'), 'докупка в последнюю секунду');
  assert.ok(!m.maxWithin('103', '100', '1'));
  assert.ok(!m.maxWithin('90', '100', '1'));
  assert.ok(!m.maxWithin('', '100', '1'));
});

test('confirmProblem: монета, сумма, сеть, адрес из окна MEXC', () => {
  const w = { coin: 'USDT', network: 'BNB Smart Chain(BEP20)', address: '0x1234567890abcdef1234567890abcdef12345678' };
  const good = 'Подтверждение вывода Монета USDT Сеть BNB Smart Chain(BEP20) Адрес 0x1234...5678 Сумма 1,234.5 USDT Комиссия 0.01';
  assert.equal(m.confirmProblem(good, w, '1234.5'), null);
  assert.match(m.confirmProblem(good, w, '1234.6'), /суммы/);
  assert.match(m.confirmProblem(good.replace('USDT', 'USDC').replace('USDT', 'USDC'), w, '1234.5'), /монеты/);
  assert.match(m.confirmProblem(good.replace('BNB Smart Chain(BEP20)', 'Ethereum(ERC20)'), w, '1234.5'), /сети/);
  assert.match(m.confirmProblem(good.replace('0x1234...5678', '0x9999...0000'), w, '1234.5'), /адрес/);
});

test('verdict: ответ сайта на вывод', () => {
  assert.deepEqual(m.verdict({ status: 200, json: { code: 0, data: { id: 'abc' } } }), { ok: true, id: 'abc' });
  assert.deepEqual(m.verdict({ status: 200, json: { code: 200, data: 12345 } }), { ok: true, id: '12345' });
  assert.equal(m.verdict({ status: 200, json: { code: 30005, msg: 'insufficient' } }).ok, false);
  assert.equal(m.verdict({ status: 502, json: null }).ok, null, 'нет ясного ответа — «не знаю», не «не отправлено»');
  assert.equal(m.verdict(undefined).ok, null);
});

test('maxWithin: допуск снизу = комиссия, а не 0,1 % суммы (ревью 22.10)', () => {
  assert.ok(!m.maxWithin('999', '1000', '0.1'), 'комиссия 0.1 — 999 при 1000 вне допуска');
  assert.ok(m.maxWithin('999.9', '1000', '0.1'));
  assert.ok(m.maxWithin('999.2', '1000', ''), 'комиссия неизвестна — 0,1 %');
});

test('netValueOk: в поле ровно одна сеть; список/плитки всех сетей — не выбор', () => {
  const want = 'BNB Smart Chain(BEP20)';
  assert.ok(m.netValueOk('BNB Smart Chain(BEP20)', want));
  assert.ok(m.netValueOk('BEP20', want));
  assert.ok(!m.netValueOk('BNB Smart Chain(BEP20) Ethereum(ERC20) Tron(TRC20)', want), 'плитки всех сетей');
  assert.ok(!m.netValueOk('Ethereum(ERC20)', want));
  assert.ok(!m.netValueOk('Выберите сеть', want));
  assert.ok(m.netValueOk('Arbitrum One(ARB)', 'Arbitrum One(ARB)'));
});

'use strict';

/**
 * duty-tab.js — ДЕЖУРНАЯ ВКЛАДКА биржи (оператор 2026-10-18).
 *
 * BingX разлогинивал профиль, а XT — нет. Разница в коде: у XT всегда жива запасная
 * вкладка (usdc_usdt), у BingX запасная выключена, а вкладки пар закрывает уборка,
 * когда пару закрыли в терминале. Пока сайт биржи открыт, он сам продлевает сессию —
 * как у человека с открытой вкладкой. Здесь держим ОДНУ такую вкладку на биржу:
 * уборка её не закрывает (pair-tabs.tradeTabs), сторож не усыпляет (launcher), под
 * заявки её не берут. Никаких искусственных кликов — только открытая страница.
 * Открывается в затишье торговли (20 с без заявок), в фоновой дорожке.
 * Выключить: ARBI_DUTY_TAB=0. Набор бирж — ARBI_DUTY_EXCHANGES (по умолчанию bingx,mexc:
 * у XT ту же роль уже играет запасная вкладка).
 */
const { isContextBusy, laneIdleMs, withContextLock } = require('./context-lock');
const { markOwned, newBackgroundPage } = require('./pair-tabs');

const timers = new WeakMap(); // context → Set(ex)

const enabledFor = (ex) => (process.env.ARBI_DUTY_TAB || '1') !== '0'
  && String(process.env.ARBI_DUTY_EXCHANGES ?? 'bingx,mexc').toLowerCase().split(',').map((s) => s.trim()).includes(String(ex).toLowerCase());

/**
 * Включить дежурство для биржи в профиле (идемпотентно).
 * @param {*} ctx
 * @param {{ex:string, name:string, url:string, log:Function, blocked?:Function}} cfg
 */
function ensure(ctx, cfg) {
  if (!ctx || !cfg.url || !enabledFor(cfg.ex)) return;
  let set = timers.get(ctx);
  if (!set) { set = new Set(); timers.set(ctx, set); }
  if (set.has(cfg.ex)) return;
  set.add(cfg.ex);
  const again = (ms) => { const t = setTimeout(tick, ms); if (t.unref) t.unref(); };
  const tick = async () => {
    let pages = [];
    try { pages = ctx.pages(); } catch { set.delete(cfg.ex); return; }
    if (!pages.length) { set.delete(cfg.ex); return; }
    const has = pages.some((p) => { try { return p.__arbiDuty === cfg.ex && !p.isClosed(); } catch { return false; } });
    if (!has && !(cfg.blocked && cfg.blocked()) && !isContextBusy(ctx, 'order') && laneIdleMs(ctx, 'order') >= 20_000) {
      try {
        await withContextLock(ctx, async () => {
          const p = markOwned(await newBackgroundPage(ctx));
          p.__arbiDuty = cfg.ex;
          await p.goto(cfg.url, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
          cfg.log(`[дежурная вкладка] ${cfg.name}: открыта — сайт биржи держит сессию живой, вход не истекает по простою`);
        }, { lane: 'bg' });
      } catch (e) { cfg.log(`[дежурная вкладка] ${cfg.name}: не открылась (${e && e.message}) — попробую позже`); }
    }
    again(60_000);
  };
  again(5_000);
}

module.exports = { ensure, enabledFor };

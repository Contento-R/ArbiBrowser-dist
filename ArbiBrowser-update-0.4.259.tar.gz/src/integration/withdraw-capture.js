'use strict';

/**
 * withdraw-capture.js — ЛОВУШКА ДЛЯ ОТМЕНЫ ВЫВОДА BingX (оператор 2026-10-18).
 *
 * Чтобы отменять вывод за ~1 с, нужен тот же вызов API, что делает сайт по кнопке
 * «Отменить». Снять его руками в DevTools нельзя: вывод уходит в обработку раньше,
 * чем успеваешь кликнуть. Поэтому ловим сами, во всех вкладках BingX профиля:
 *   1) КОД САЙТА: в загружаемых скриптах BingX ищем строки адресов API со словом
 *      withdraw (и cancel/revoke рядом) + кусок кода вокруг — так виден адрес отмены
 *      и имена полей, даже без отменяемого вывода;
 *   2) ВЫЗОВЫ: любой запрос вкладки BingX к API вывода — метод, адрес, тело, ответ.
 * Заголовки и cookie НЕ читаются никогда; в телах вымарываются ключи вида token/sign/
 * uid/phone и длинные строки (адреса). Всё — в журнал «[захват вывода] …» и в файл
 * <данные>/reports/bingx-withdraw-capture.txt. Выключить: ARBI_WD_CAPTURE=0.
 */
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { scrub, scrubUrl } = require('./bingx-deposit-page');

const ON = () => (process.env.ARBI_WD_CAPTURE || '1') !== '0';
const FILE = () => path.join(config.reportsDir, 'bingx-withdraw-capture.txt');
const API_HOST_RE = /bingx|we-api|acc-de|qq-os|bb-os/i;
const WD_RE = /withdraw/i;
// BingX зовёт отмену вывода «back» (back-apply/recent-back — первая находка 18.10)
const CANCEL_RE = /cancel|revoke|undo|back/i;
const PATH_RE = /["'`](\/?(?:api\/)?[A-Za-z0-9_\-/{}.]*withdraw[A-Za-z0-9_\-/{}.]*)["'`]/gi;
const scanned = new Set();  // URL скрипта → уже прочитан
const endpoints = new Map(); // путь → кусок кода вокруг
const attached = new WeakSet();

function out(line) {
  console.log(`[захват вывода] ${line}`);
  try {
    fs.mkdirSync(path.dirname(FILE()), { recursive: true });
    fs.appendFileSync(FILE(), `${new Date().toISOString()} ${line}\n`);
  } catch { /* файл необязателен — журнал есть */ }
}

const body = (text) => {
  if (!text) return '';
  try { return JSON.stringify(scrub(JSON.parse(text))).slice(0, 3000); } catch { return `[не JSON, ${text.length} симв.]`; }
};

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  const isBingx = () => { try { return String(page.url()).includes('bingx.'); } catch { return false; } };
  page.on('request', (req) => {
    try {
      const u = req.url();
      if (!API_HOST_RE.test(u) || !WD_RE.test(u) || req.method() === 'OPTIONS' || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      if (req.method() === 'GET' && !CANCEL_RE.test(u)) return; // GET-ы пишем ответом ниже
      out(`ВЫЗОВ ${req.method()} ${scrubUrl(u)} тело=${body(req.postData())}`);
    } catch { /* диагностика */ }
  });
  page.on('response', async (resp) => {
    try {
      const req = resp.request();
      const u = resp.url();
      if (req.method() === 'OPTIONS') return;
      if (API_HOST_RE.test(u) && WD_RE.test(u) && /^(xhr|fetch)$/.test(req.resourceType())) {
        const t = await resp.text().catch(() => '');
        out(`ОТВЕТ ${req.method()} ${scrubUrl(u)} → ${resp.status()} ${body(t)}`);
        return;
      }
      if (req.resourceType() !== 'script' || !isBingx() || scanned.has(u)) return;
      scanned.add(u);
      const src = await resp.text().catch(() => '');
      if (!src || src.length > 12_000_000) return;
      let m; let found = 0;
      PATH_RE.lastIndex = 0;
      while ((m = PATH_RE.exec(src)) && found < 200) {
        found += 1;
        const p = m[1];
        if (!p.includes('/') || endpoints.has(p)) continue; // ключи переводов (recharge_withdraw_…) — не адреса
        const around = src.slice(Math.max(0, m.index - 160), m.index + p.length + 220).replace(/\s+/g, ' ');
        endpoints.set(p, around);
        out(`КОД ${p}${CANCEL_RE.test(p) ? '  ← ОТМЕНА?' : ''} | ${around}`);
      }
    } catch { /* диагностика */ }
  });
}

/** Подключить ловушку ко всем вкладкам профиля (текущим и будущим). */
function attach(context) {
  if (!ON() || !context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

module.exports = { attach, FILE };

'use strict';

/**
 * ip-watch.js — КРАСНЫЙ ФЛАГ ПО IP ПРОКСИ (оператор 2026-10-18: «смена IP — red flag:
 * все пользователи ArbiBrowser ходят ТОЛЬКО через свои прокси, без исключений»).
 *
 * Раз в 5 минут для каждого запущенного профиля узнаём выходной IP через ЕГО прокси
 * (тот же сервер, что у браузера профиля) и сравниваем:
 *   • профиль без прокси или прокси-агент не создался — флаг;
 *   • выходной IP совпал с реальным IP этого ПК — трафик идёт мимо прокси — флаг;
 *   • выходной IP сменился с прошлого замера — флаг (биржа видит вход с нового адреса).
 * Флаг → строка в журнале и событие в терминал (плашка). Повтор одного и того же
 * флага по профилю — не чаще раза в 30 минут. Выключить: ARBI_IP_WATCH=0.
 */
const geoip = require('../network/geoip');
const { agentFor } = require('../network');

function startIpWatch({ getRunning, log, post }) {
  if ((process.env.ARBI_IP_WATCH || '1') === '0') return () => {};
  const last = new Map();      // профиль → последний выходной IP
  const flaggedAt = new Map(); // `${профиль}|${вид}` → время флага
  let realIp = null; let realAt = 0;
  const flag = (name, kind, text) => {
    const k = `${name}|${kind}`;
    if (Date.now() - (flaggedAt.get(k) || 0) < 30 * 60_000) return;
    flaggedAt.set(k, Date.now());
    log(`[ip] ⛔ ${text}`);
    post({ kind: 'ip-alert', profile: name, alert: kind, text });
  };
  const tick = async () => {
    if (!realIp || Date.now() - realAt > 30 * 60_000) {
      try { realIp = await geoip.lookupExitIp(undefined); realAt = Date.now(); } catch { /* сеть ПК — следующий тик */ }
    }
    for (const [name, rec] of getRunning()) {
      if (!rec || !rec.context) continue;
      if (!rec.proxy) { flag(name, 'no-proxy', `Профиль ${name} запущен БЕЗ прокси — биржа видит реальный IP этого ПК. Задайте прокси профилю.`); continue; }
      const agent = agentFor(rec.proxy);
      if (!agent) { flag(name, 'no-agent', `Профиль ${name}: прокси задан, но не подключился — проверьте прокси.`); continue; }
      let ip;
      try { ip = await geoip.lookupExitIp(agent); } catch (e) { log(`[ip] ${name}: выходной IP не узнан (${e && e.message}) — следующий замер через 5 мин`); continue; }
      rec.exitIp = ip;
      if (realIp && ip === realIp) flag(name, 'leak', `Профиль ${name}: выходной IP ${ip} совпадает с реальным IP ПК — трафик идёт мимо прокси.`);
      const prev = last.get(name);
      last.set(name, ip);
      if (!prev) log(`[ip] ${name}: выходной IP ${ip}`);
      else if (prev !== ip) flag(name, `changed:${ip}`, `Профиль ${name}: выходной IP прокси сменился ${prev} → ${ip}. Биржа видит вход с нового адреса — частая причина разлогина. Закрепите IP у прокси.`);
    }
  };
  const t0 = setTimeout(() => { tick().catch(() => {}); }, 15_000);
  const iv = setInterval(() => { tick().catch(() => {}); }, 5 * 60_000);
  if (iv.unref) iv.unref();
  return () => { clearTimeout(t0); clearInterval(iv); };
}

module.exports = { startIpWatch };

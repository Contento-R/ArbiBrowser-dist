'use strict';

/**
 * mexc-order-page.js — Стадия 3: РЕАЛЬНОЕ исполнение web-ордера MEXC в живой
 * странице браузера профиля.
 *
 * Почему в браузере, а не реплеем на сервере: серверный replay режет Akamai по
 * TLS/JA3-отпечатку (пустой 200, ордер не встаёт). В реальном залогиненном
 * Chromium профиля TLS + куки + поведенческий сенсор совпадают по построению.
 *
 * Почему НЕ page.evaluate(fetch(order/place)) и НЕ JS-.click():
 *   Проверено 2026-06-06 (session-note терминала): синтетический submit из JS
 *   (даже прямой вызов React-onClick) НЕ порождает анти-бот-подпись — MEXC
 *   завязан на ПОВЕДЕНЧЕСКИЙ fingerprint (SDK trochilus/watchman). Поэтому
 *   форму надо нажимать ДОВЕРЕННЫМ вводом. Нативные Playwright `page.fill` /
 *   `page.click` идут через CDP Input-домен (Input.dispatchMouseEvent и т.п.) →
 *   события `isTrusted=true`, как у настоящего пользователя. ЭТО и есть путь,
 *   отличный от провалившегося JS-синтетик-клика.
 *
 * ⚠️ НЕ ПРОВЕРЕНО против живого MEXC из среды разработки. Селекторы формы взяты
 * из наблюдений терминала (docs/exchange-web/08-mexc-web-trading.md) и могут
 * разойтись с текущей вёрсткой (хешированные классы). Все селекторы
 * ПЕРЕОПРЕДЕЛЯЕМЫ через env (см. SELECTORS ниже), чтобы починить без правки кода.
 * Живой прогон обязателен ДО включения live-режима — см. session-note.
 */

const { formatDecimal, isPlainPositive, pairGate, fieldFresh, priceFresh, learnDisplayBase, displayBaseFor, sideFromText, truncateQty, learnQtyDecimals, pickBaseAvail } = require('./order-utils');
const { canOpenPairTab, markPairTab, markOwned, ensureTabInFront, newBackgroundPage, pageRenders, isAsleep, probeLag } = require('./pair-tabs');
const { isContextBusy, laneIdleMs } = require('./context-lock');
const { makeSpare } = require('./spare-tab');
const { lightBlocked } = require('./light-pages');

const MEXC_ORIGIN = 'https://www.mexc.com';
// M4: переопределяемо через env (как ARBI_XT_ORDER_RE у XT). Если MEXC сменит endpoint,
// захардкоженный RE не поймает POST ордера → orderReqFired не выставится → повтор клика
// вслепую → дубль. Без пересборки правится в .env, коли путь окажется иным.
const ORDER_PLACE_RE = new RegExp(process.env.ARBI_MEXC_ORDER_RE || '/api/platform/spot/order/place', 'i');

/**
 * Сколько знаков после точки MEXC реально ПРИНЯЛ в поле количества по этой паре.
 *
 * Замер оператора 2026-09-21 (WOJAK/USDT): вводим `14003111802.62280464`, поле
 * показывает `14003111802.` — биржа отсекает дробную часть целиком, но мы каждый
 * раз честно набираем 9 лишних символов. Ввод на MEXC — только посимвольный
 * (анти-бот «вооружает» кнопку потоком доверенных клавиш), по ~7-10 мс на знак,
 * значит лишние символы — чистая потеря на КАЖДОЙ заявке.
 *
 * Механика ровно та же, что уже работает на XT (`XT_QTY_DEC`): запоминаем урок
 * из фактического ответа биржи и со второй заявки печатаем сразу столько, сколько
 * она принимает. Итоговая заявка та же — усекала её всё равно биржа.
 */
const MEXC_QTY_DEC = new Map();

/**
 * Принимает ли MEXC вставку значения целиком (Ctrl+V) в этой сессии.
 *
 * Включено по умолчанию (0.4.203): оператор проверил вставку руками. Но кнопку
 * сабмита «вооружает» анти-бот, и теоретически он может считать вставку
 * недостаточной. Поэтому: если заявка после вставки НЕ ушла (POST order/place не
 * состоялся), флаг гасится на всю сессию, и следующие заявки идут прежним
 * посимвольным набором. Максимальная цена ошибки — одна упущенная заявка, а не
 * молчаливое повторение проблемы (#58: причина пишется в журнал).
 */
let MEXC_INSERT_OK = (process.env.ARBI_MEXC_INSERT_TEXT || '1') !== '0';

// Селекторы формы ордера MEXC. Хешированные суффиксы классов у MEXC меняются —
// поэтому каждый переопределяется через env без пересборки.
const SELECTORS = {
  // Поля ввода цены/количества/всего (у MEXC один класс на все три инпута).
  // ДВЕ вёрстки (снимок напарника 12.10, BKN): в новой класс mx-motion-input-inner стоит на
  // обёртке, а само поле — input.ant-input внутри неё. Маленькие ant-input-sm там же — поиск
  // в шапке и в списке рынков; их исключаем, иначе [0]/[1] видимых полей стали бы поиском.
  input: process.env.ARBI_MEXC_SEL_INPUT || 'input.mx-motion-input-inner, .mx-motion-input-inner > input.ant-input:not(.ant-input-sm)',
  // Кнопка сабмита ордера (Buy/Sell): старая вёрстка do-submit_doBtn__HASH, новая
  // index-module-scss-module__HASH__doBtn — общая часть «_doBtn». Один простой селектор,
  // не список через запятую: к нему дописывается :visible.
  submit: process.env.ARBI_MEXC_SEL_SUBMIT || 'button[class*="_doBtn"]',
  // Вкладки Limit/Market (best-effort по тексту).
  limitTab: process.env.ARBI_MEXC_SEL_LIMIT || 'text=/^Limit$/i',
  // Вкладки Buy/Sell. ПОДТВЕРЖДЕНО оператором: <div class="actions_sellBtn__HASH">Sell</div>
  // (хеш-суффикс меняется между сборками → префиксный матч класса). Симметрично buyBtn.
  // Фолбэк по тексту (ensureSide стратегия B) остаётся, если класс сменится.
  // Новая вёрстка (BKN 12.10): index-module-scss-module__HASH__buyBtn — ровно «__buyBtn» в
  // конце класса; «__buyBtnWrapper» у кнопки сабмита по этим правилам не попадает.
  buyTab: process.env.ARBI_MEXC_SEL_BUY || '[class*="actions_buyBtn__"], [class*="__buyBtn "], [class$="__buyBtn"]',
  sellTab: process.env.ARBI_MEXC_SEL_SELL || '[class*="actions_sellBtn__"], [class*="__sellBtn "], [class$="__sellBtn"]',
  // Кнопка подтверждения в модалке ордера (появляется не всегда). Дефолт — кнопка
  // с текстом Confirm/Buy/Place внутри диалога; переопределяемо через ARBI_MEXC_SEL_CONFIRM.
  confirm: process.env.ARBI_MEXC_SEL_CONFIRM || 'button:has-text("Confirm")',
  // Строка поиска ПАРЫ. Заголовок пары <h1>/стрелка открывает выпадашку поиска (см.
  // focusSearchInput). Инпут ищем по классам компонента поиска + placeholder «contract
  // address» + ant-input-sm как фолбэк (чтобы поле ВСЕГДА находилось). Переопределяемо env.
  search: process.env.ARBI_MEXC_SEL_SEARCH
    || '[class*="search-bar_"] input,[class*="searchInputField"] input,[class*="_searchInput_"] input,[class*="searchInputWrapper"] input,input[placeholder*="contract address" i],input[class*="ant-input-sm"]',
  // Открывашка поповера поиска ПАРЫ. ⚠️ БЕЗ `[class*="searchIcon"]` — он ловил иконку-лупу
  // ГЛОБАЛЬНОГО поиска в шапке и открывал его (увод ввода в верхнюю строку). Реальная
  // открывашка — клик по заголовку пары <h1> (см. focusSearchInput); тут — доп. фолбэки
  // по классам самой выпадашки, кликаются ТОЛЬКО если заголовок не открыл поле.
  searchOpen: process.env.ARBI_MEXC_SEL_SEARCH_ICON || '[class*="search-bar_"] [class*="searchPlaceholder"],[class*="searchPlaceholder"],[class*="searchInputWrapper"],[class*="searchInputField"]',
  // Кликабельная строка результата поиска. ⚠️ ПОДТВЕРЖДЕНО ЖИВЫМ ДИАГОМ исполнителя
  // 2026-07-13: строка — <div class="search-bar_item__HASH"> (тикер «WOJAK/USDT» в её
  // textContent через search-bar_itemContent__). Ставим `search-bar_item__` ПЕРВЫМ:
  // прежние `result-item_item`/`responsive-item` были из ДРУГОГО поповера (ручной дамп) и
  // строку исполнителя НЕ матчили → шаг result-item падал в timeout → перезагрузка каждый
  // ⚠️ ПОДТВЕРЖДЕНО ЖИВЫМ ДИАГОМ 2026-07-14: результат ЛЕВОГО поиска пары лежит в
  // контейнере `search-bar_resultWrapper__` (его textContent содержит «…Spot (1)
  // WOJAK/USDT…»), а сами строки — `responsive-item`. КРИТИЧНО скоупить именно этим
  // контейнером: `responsive-item` с текстом «PUMP DEXE ZEC…» — это hot-searches ШАПКИ,
  // они ВНЕ wrapper; без scope .first() кликнул бы чужую строку. Держим result-item_item/
  // search-bar_item__ фолбэками (иные сборки вёрстки). Переопределяемо env.
  searchResult: process.env.ARBI_MEXC_SEL_SEARCH_RESULT
    || '[class*="search-bar_resultWrapper__"] [class*="responsive-item"],[class*="search-bar_resultWrapper__"] [class*="result-item_item"],[class*="search-bar_resultWrapper__"] [class*="search-bar_item__"]',
  // Фолбэк «верхняя строка» — тот же scope на wrapper левого поиска (первый responsive-item
  // = верхний результат = наш токен, т.к. ввели точный тикер). Переопределяемо env.
  searchResultScoped: process.env.ARBI_MEXC_SEL_SEARCH_RESULT_SCOPED
    || '[class*="search-bar_resultWrapper__"] [class*="responsive-item"],[class*="search-bar_resultWrapper__"] [class*="result-item_item"],[class*="search-bar_resultWrapper__"] [class*="search-bar_item__"]',
};
// Общие хелперы страницы (ввод/оверлеи/модалки/готовность сабмита) — один код на три
// биржи, различия — в профиле `page-driver.js`.
const { typeNumber, fastSetInputs, isSubmitReady, dismissBlockingModal, dismissOverlays, loginWall, loginWallFresh } = require('./page-driver').driverFor('mexc', SELECTORS);
const { runPrefill, clampBuyToQuote } = require('./prefill');
const { loginRequiredError, checkLogin: driverCheckLogin, uncoverSubmit, clickPointFacts } = require('./page-driver');
const config = require('../../config');

// Канон "BASE/QUOTE" (или "BASE_QUOTE") → путь пары MEXC "BASE_USDT".
function toMexcPair(symbol) {
  return String(symbol).toUpperCase().replace('/', '_');
}

/** Экранировать строку для вставки в RegExp (тикеры бывают с точками и т.п.). */
function escRe(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Страница пары отдала 404 «Sorry! The page you're looking for cannot be found»?
 * У части MEXC-токенов (напр. PIN) прямой URL /exchange/PAIR 404-ит — пара открывается
 * ТОЛЬКО через поиск (?_from=search_spot_trade). Прогрев/восстановление вкладки прямым
 * goto оставляет вкладку на 404, а executeIntent долбит впустую. Детект → внятная
 * ошибка вместо тихого срыва. best-effort (по тексту/отсутствию формы).
 */
async function isMexcNotFound(page) {
  return page.evaluate((inputSel) => {
    // Форма на месте — это не 404 (ответ тот же, что ниже). Проверяем её ПЕРВОЙ:
    // innerText всей страницы (стакан, сделки, список рынков) — дорогая сериализация
    // на каждой заявке и прогреве, а нужна она только когда формы нет (ревизия 26.09).
    if (document.querySelector(inputSel)) return false;
    const t = (document.body && document.body.innerText || '');
    // Маркеры 404-страницы MEXC (EN/RU) + отсутствие торговой формы.
    if (/cannot be found|Back to Home|Trade MX\/USDT|страница не найдена|не удалось найти/i.test(t)) {
      return !document.querySelector(inputSel);
    }
    return false;
  }, SELECTORS.input).catch(() => false);
}

/**
 * Страница = Akamai «Access Denied» (edgesuite)? Это НЕ ошибка пары, а блок профиля/
 * выходного IP биржей. Долбить MEXC в этом состоянии бессмысленно и ВРЕДНО (продлевает
 * бан, мешает ручному восстановлению). Детект → глобальный бэкофф MEXC (mexcBlocked).
 */
async function isMexcAccessDenied(page) {
  return page.evaluate((inputSel) => {
    if (document.querySelector(inputSel)) return false; // форма есть — не блок (см. isMexcNotFound)
    const t = (document.body && document.body.innerText || '');
    return /Access Denied|don't have permission|edgesuite\.net|Reference #\d/i.test(t)
      && !document.querySelector(inputSel);
  }, SELECTORS.input).catch(() => false);
}

// ── Глобальный бэкофф MEXC при Access Denied ─────────────────────────────────
// Пока активен — исполнитель НЕ навигирует к MEXC (ни ордер, ни прогрев, ни чтение):
// биржа блокирует профиль/IP, любые заходы только продлевают бан и мешают оператору
// восстановиться (сменить IP прокси / подождить / почистить куки). Переопускаемо env.
let mexcAdUntil = 0;
function mexcBlocked() { return Date.now() < mexcAdUntil; }
function mexcBlockedMsLeft() { return Math.max(0, mexcAdUntil - Date.now()); }
function noteMexcAccessDenied(log) {
  const ms = Number(process.env.ARBI_MEXC_AD_COOLDOWN_MS || 300000); // 5 мин
  mexcAdUntil = Date.now() + ms;
  if (log) log(`MEXC Access Denied (Akamai) — навигация к MEXC приостановлена на ${Math.round(ms / 1000)}с (бан профиля/IP). Смените IP прокси или подождите.`);
}

/**
 * Содержит ли URL нужную пару — терпимо к percent-кодировке (non-ASCII имена
 * токенов в адресе кодируются, сырое includes их не находит → ложная «не
 * открыта» и ложный timeout завершения SPA). Зеркало xt-order-page.urlHasPair.
 */
function urlHasPair(u, pair) {
  const needle = ('/exchange/' + String(pair)).toLowerCase();
  let dec = u;
  try { dec = decodeURIComponent(u); } catch { /* битый % — оставляем сырой */ }
  return String(u).toLowerCase().includes(needle) || String(dec).toLowerCase().includes(needle);
}

/**
 * Кэш «какая пара открыта на этой вкладке» (page.__arbiPair = {pair, path}) —
 * зеркало page.__arbiSide. Валиден, только пока pathname вкладки совпадает с
 * записанным (ручная навигация оператора инвалидирует кэш сама собой). Пишем
 * ТОЛЬКО в точках ПОДТВЕРЖДЁННОГО перехода (finishSpa / точный URL-матч) —
 * кэш не может «узаконить» непроверенное состояние и увести ордер на чужую
 * пару. Убирает повторные DOM-проверки/итерации поиска между интентами одного
 * токена (warmup → ордер → следующий ордер) — особенно для пар, у которых
 * displayName ≠ coinName и urlHasPair не совпадает никогда.
 */
function rememberPair(page, pair) {
  try { page.__arbiPair = { pair: String(pair), path: new URL(page.url()).pathname }; }
  catch { page.__arbiPair = null; }
}
function cachedPairWarm(page, u, pair) {
  const c = page.__arbiPair;
  if (!c || c.pair !== String(pair)) return false;
  try { return new URL(u).pathname === c.path; } catch { return false; }
}

/**
 * Находит уже открытую страницу mexc.com в контексте профиля, либо открывает
 * новую. Возвращает Playwright Page.
 */
// ЗАПАСНАЯ ТЁПЛАЯ ВКЛАДКА — общий модуль spare-tab.js. На MEXC ВЫКЛЮЧЕНА по замеру 11.10
// (SPA-смена 2148 мс + форма 758 > холодное открытие 2057–2482 мс в лёгком режиме);
// включить для повторного замера: ARBI_MEXC_SPARE_PAIR=USDC_USDT.
const spare = makeSpare({ name: 'MEXC', envKey: 'ARBI_MEXC_SPARE_PAIR', defaultPair: '', origin: MEXC_ORIGIN,
  pairUrl: (pair) => `${MEXC_ORIGIN}/exchange/${String(pair).toUpperCase()}`, inputSel: SELECTORS.input, submitSel: SELECTORS.submit, blocked: mexcBlocked });

async function getMexcPage(context, pair, log) {
  spare.schedule(context, log);
  const wantUrl = `${MEXC_ORIGIN}/exchange/${pair}`;
  const [base, quote = 'USDT'] = String(pair).split('_');
  // Собираем все вкладки mexc.com (там живая залогиненная сессия).
  const mexcPages = [];
  let sleepingMexc = null;
  let sleepingSame = null; // спящая вкладка ИМЕННО этой пары // спящая вкладка MEXC — запасной вариант вместо дубля
  for (const p of context.pages()) {
    let u = '';
    try { u = p.url(); } catch { /* закрыта */ }
    // Вкладка пары ЕЩЁ ГРУЗИТСЯ после старта (восстановление сессии, __arbiPendingUrl):
    // ждём её, дубль не открываем (лог 11.10 08:10: две WOJAK по 677 МБ грузились разом).
    if (typeof p.__arbiPendingUrl === 'string' && urlHasPair(p.__arbiPendingUrl, pair)) {
      log(`Вкладка пары ${pair} ещё грузится после старта — жду её, дубль не открываю`);
      await p.waitForLoadState('domcontentloaded', { timeout: 30000 }).catch(() => {});
      return { page: markPairTab(p), cold: true, switched: true };
    }
    // Фоновую вкладку истории ордеров (__arbiOrdersBg) НЕ отдаём под реальный ордер:
    // read-only, её навигирует параллельное чтение истории — ордер ушёл бы в скрытый таб.
    try { if (p.__arbiOrdersBg === true || p.__arbiNoInput === true) continue; } catch { /* игнор */ }
    // Запасная вкладка — не кандидат на «уже на паре»: она отдаётся новой паре ниже.
    try { if (p.__arbiSpare === true || p.__arbiDuty) continue; } catch { /* игнор */ }
    // Спящая вкладка (экономия памяти) физически на about:blank, но помнит свой
    // URL. Запоминаем как запасной вариант: разбудить ЕЁ дешевле и безопаснее,
    // чем открыть дубль — в ней живая залогиненная сессия биржи.
    // Спящая вкладка помнит свой URL в метке. Раньше её узнавали по «url НЕ на
    // бирже» (заглушка на about:blank) — но вкладка, усыплённая ИЗ ЗАГРУЖЕННОГО
    // состояния, сохраняет прежний торговый адрес (проверено 25.09), и такая
    // спящая проходила дальше как ЖИВАЯ: заявка ушла бы заполнять заглушку
    // «💤 вкладка спит». Признак сна — метка, а не адрес.
    if (isAsleep(p) && String(p.__arbiSleepUrl).startsWith(MEXC_ORIGIN)) {
      if (urlHasPair(p.__arbiSleepUrl, pair)) sleepingSame = p;
      if (!sleepingMexc) sleepingMexc = p;
      continue;
    }
    if (u.startsWith(MEXC_ORIGIN)) mexcPages.push({ p, u });
  }
  // 0) Кэш пары (__arbiPair): та же пара И pathname не менялся с подтверждённого
  //    перехода → тёплая сразу, без DOM-проверок и повторного поиска.
  for (const { p, u } of mexcPages) {
    if (cachedPairWarm(p, u, pair)) return { page: markPairTab(p), cold: false };
  }
  // 1) Вкладка УЖЕ на нужной паре — тёплая, ордер напрямую (без навигации).
  for (const { p, u } of mexcPages) {
    if (urlHasPair(u, pair)) {
      // Вкладка могла быть ТОЛЬКО ЧТО открыта авто-запуском (startUrl уже на паре),
      // а React-форма ещё сырая: «тёплая» = есть ≥2 видимых поля формы. Иначе cold —
      // путь с ожиданием гидрации (иначе клик до готовности = срыв первого ордера).
      const readyInputs = await p.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).length).catch(() => 0);
      rememberPair(p, pair);
      return { page: markPairTab(p), cold: readyInputs < 2 };
    }
    // CR-1: граница токена — иначе ARTX-вкладка ложно тёплая для ART (STIG⊃TIG).
    // Только ТОРГОВЫЕ вкладки (/exchange/) и ПОЛНАЯ пара base/quote: h1 «ART/USDC»
    // или «ART Staking» на /earn не должны сойти за тёплую вкладку ART_USDT.
    if (!/\/exchange\//i.test(u)) continue;
    const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/\\s*' + escRe(quote) + '(?![A-Za-z0-9])', 'i') })
      .first().isVisible().catch(() => false);
    if (h1Match) return { page: markPairTab(p), cold: false };
  }
  // 2) Вкладка на ЛЮБОЙ торговой странице (/exchange/*) — с неё смена пары идёт быстрым
  //    SPA-поиском (React не перезагружается). ПРЕДПОЧИТАЕМ её вкладке на /earn и т.п.:
  //    раньше брали ПЕРВУЮ mexc-вкладку, и если это /earn — SPA не работал → перезагрузка
  //    (жалоба: медленный первый ордер по паре). Теперь торговая вкладка в приоритете.
  // 1.5) ПУЛ ТЁПЛЫХ ВКЛАДОК: есть место — открываем паре СВОЮ вкладку вместо
  //      смены пары в чужой. Вкладка прежней пары остаётся тёплой, и обе пары
  //      дальше работают без навигации (оператор ведёт несколько одновременно).
  //      Пул полон → прежний путь: SPA-смена пары ниже.
  // СПЯЩАЯ ВКЛАДКА ЭТОЙ ЖЕ ПАРЫ — будим её, а не открываем соседку. Лог оператора
  // 2026-09-08 06:48: после рестарта пара STONK лежала спящей (about:blank с
  // запомненным URL), но живая вкладка другой пары дала «место в пуле» → открылась
  // ВТОРАЯ вкладка STONK, и уборка потом закрыла обе. Дубль невозможен, если
  // спящую своей пары проверять ДО пула.
  if (sleepingSame) {
    log(`Бужу спящую вкладку своей пары: ${wantUrl}`);
    sleepingSame.__arbiSleepUrl = null;
    await sleepingSame.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleepingSame.url(), pair)) rememberPair(sleepingSame, pair);
    return { page: markPairTab(sleepingSame), cold: true };
  }
  // ЗАПАСНАЯ ВКЛАДКА ГОТОВА — отдаём её паре SPA-сменой вместо холодного открытия.
  const sp = spare.take(context);
  if (sp) {
    const tS = Date.now();
    const r = await changePairSpa(sp, pair, log);
    log(`[запасная вкладка] MEXC: отдана паре ${pair}: смена пары ${Date.now() - tS} мс ${r.spa ? 'без перезагрузки' : '(перезагрузкой — SPA не вышел)'}`);
    spare.schedule(context, log);
    return { page: markPairTab(sp), cold: !r.spa };
  }
  if (canOpenPairTab(context, MEXC_ORIGIN)) {
    log(`Открываю отдельную вкладку под пару (пул тёплых вкладок): ${pair}`);
    const fresh = markPairTab(markOwned(await newBackgroundPage(context)));
    await fresh.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    // Навигация не состоялась (прокси/сеть) — не оставляем пустую about:blank вкладку
    // и не заполняем форму на пустой странице: закрываем и честно отказываем.
    if (String(fresh.url()).startsWith('about:')) {
      await fresh.close().catch(() => {});
      throw new Error(`страница пары не открылась (${wantUrl}) — проверьте прокси/сеть профиля`);
    }
    if (urlHasPair(fresh.url(), pair)) rememberPair(fresh, pair);
    return { page: fresh, cold: true };
  }
  const trade = mexcPages.find(({ u }) => /\/exchange\//i.test(u));
  if (trade) {
    const r = await changePairSpa(trade.p, pair, log);
    return { page: trade.p, cold: !r.spa };
  }
  // 3) Есть mexc-вкладка, но не торговая (/earn, промо) — changePairSpa сам сделает
  //    прямой goto на пару (v0.4.48: со страницы вне /exchange не тратим время на SPA).
  if (mexcPages.length) {
    const r = await changePairSpa(mexcPages[0].p, pair, log);
    return { page: mexcPages[0].p, cold: !r.spa };
  }
  // 3.5) Живых mexc-вкладок нет, но есть СПЯЩАЯ — будим её вместо открытия
  //      дубля: в ней уже прогретая залогиненная сессия биржи.
  if (sleepingMexc) {
    log(`Бужу спящую вкладку MEXC: ${wantUrl}`);
    sleepingMexc.__arbiSleepUrl = null;
    await sleepingMexc.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleepingMexc.url(), pair)) rememberPair(sleepingMexc, pair);
    return { page: sleepingMexc, cold: true };
  }
  // 4) Вкладок mexc нет — открываем новую сразу на паре.
  log(`Открываю страницу MEXC: ${wantUrl}`);
  const page = markOwned(await newBackgroundPage(context));
  await page.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  // goto резолвится и на РЕДИРЕКТЕ (логин/регион-блок) — кэшируем только
  // подтверждённый URL пары, иначе отравленный кэш вечно отдаёт чужую страницу.
  if (urlHasPair(page.url(), pair)) rememberPair(page, pair);
  return { page, cold: true }; // первая загрузка вкладки → форма «сырая»
}

/**
 * Смена торговой пары БЕЗ перезагрузки страницы — через строку поиска сайта, как
 * это делает пользователь вручную (<1с). MEXC-биржа это SPA (Next.js): переход по
 * внутренней ссылке `/exchange/PAIR` = client-side навигация, React-приложение и
 * гидрация СОХРАНЯЮТСЯ, меняются только данные пары → форма ордера готова почти
 * мгновенно. Это убирает «холодные» ~5с на каждый новый токен: после ОДНОЙ загрузки
 * вкладки при старте любой токен становится тёплым.
 * Полностью best-effort: любой сбой (не нашли поиск/ссылку/URL не сменился) →
 * фолбэк на page.goto (текущее поведение). Селекторы — env-переопределяемые.
 * @returns {Promise<{spa:boolean}>} spa=true если сменили без перезагрузки.
 */
/**
 * Открыть поиск пары и сфокусировать его строку (см. разбор в xt-order-page.js).
 * MEXC (скрины оператора 2026-07-09): на ШИРОКОМ окне поиск инлайн (список слева), на
 * УЗКОМ он скрыт и открывается кликом по ЗАГОЛОВКУ текущей пары <h1>BASE/USDT>. Поэтому
 * сперва кликаем заголовок (на широком окне безвредно), затем фокусируем поле поиска
 * (<input class="ant-input ant-input-sm">). НЕ page-level Ctrl+A/JS focus (выделяли
 * всю страницу).
 */
async function focusSearchInput(page) {
  // Залипшая risk/ошибка-модалка от прошлого токена перехватывает pointer events →
  // клик по h1/opener не открывает дропдаун поиска → поле не visible → перезагрузка.
  // Закрываем ПЕРЕД кликом (дёшево, ~мс). Зеркало XT-фикса.
  await dismissBlockingModal(page);
  // Нормализация: залипшую открытую выпадашку закрываем Escape (иначе клик по заголовку
  // её ЗАКРОЕТ toggle). Без фиксированной паузы — waitForFunction ниже сам дождётся.
  await page.keyboard.press('Escape').catch(() => {});
  // Заголовок пары (h1 с "/") — открывашка дропдауна поиска ПАРЫ.
  const h1 = page.locator('h1', { hasText: '/' }).first();
  await h1.click({ timeout: 2000 }).catch(() => {});
  // Пометить поле поиска ПАРЫ (не ШАПКИ) ОДНИМ in-page waitForFunction. Различитель НЕ по
  // классу (шапка и пара — один компонент search-bar_*), а по позиции: шапка вверху (top≤90),
  // поле пары ниже заголовка (top>90) в левой половине. Прежде это был Node-цикл 34×150мс со
  // сканом DOM на каждой итерации (раундтрип Node↔браузер) — ГЛАВНЫЙ лишний груз фазы focus
  // (регресс скорости). waitForFunction поллит ВНУТРИ страницы и возвращается СРАЗУ по
  // появлении поля — заметно быстрее. Функция помечает найденный инпут data-атрибутом.
  const markFn = () => {
    const vis = (el) => el.offsetParent !== null && el.getBoundingClientRect().width > 40;
    document.querySelectorAll('[data-arbi-pairsearch]').forEach((e) => e.removeAttribute('data-arbi-pairsearch'));
    const cands = Array.from(document.querySelectorAll('input')).filter(vis);
    const isOrder = (el) => /mx-motion-input/i.test(el.className);
    const isHeader = (el) => el.getBoundingClientRect().top <= 90;
    const searchish = (el) => /contract|token|search|искать|buscar|such|recherch|地址|搜索/i
      .test((el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || ''));
    let pick = cands.find((el) => !isHeader(el) && !isOrder(el) && searchish(el));
    if (!pick) pick = cands.find((el) => !isHeader(el) && !isOrder(el) && el.getBoundingClientRect().left < window.innerWidth * 0.5);
    if (!pick) return false;
    pick.setAttribute('data-arbi-pairsearch', '1');
    return true;
  };
  const waitOpts = { timeout: Number(process.env.ARBI_MEXC_MARK_WAIT_MS || 2500), polling: 100 };
  let opened = await page.waitForFunction(markFn, null, waitOpts).then(() => true).catch(() => false);
  if (!opened) {
    // Дропдаун не открылся с первого клика — добиваем открывашкой + повторным кликом и ждём ещё.
    await dismissBlockingModal(page);
    const opener = await page.$(SELECTORS.searchOpen).catch(() => null);
    if (opener) await opener.click({ timeout: 800 }).catch(() => {});
    await h1.click({ timeout: 1200, force: true }).catch(() => {});
    opened = await page.waitForFunction(markFn, null, { timeout: 3000, polling: 100 }).then(() => true).catch(() => false);
  }
  // Дропдаун поиска ПАРЫ так и не открылся → НЕ печатаем в поиск ШАПКИ (гарантированный
  // провал + лишние 4.5с). Бросаем: changePairSpa уйдёт в быстрый goto-фолбэк.
  if (!opened) throw new Error('поле поиска пары не открылось (дропдаун не прогрузился)');
  const input = page.locator('[data-arbi-pairsearch="1"]').first();
  // Надёжный фокус: голый .focus() — синтетический и на React-контроле не всегда
  // реально переводит фокус (наблюдалась долгая непредсказуемая focus-фаза 439-1551мс
  // в тайминге без гарантии, что ввод далее попадёт в нужное поле). Доверенный клик
  // (CDP Input, как и весь остальной ввод формы) + проверка document.activeElement;
  // один ретрай, если первый клик не дал фокуса (перекрытие анимацией/оверлеем).
  const focusMs = Number(process.env.ARBI_MEXC_SEARCH_FOCUS_MS || 1200);
  const isFocused = () => page.evaluate(
    () => document.activeElement && document.activeElement.getAttribute('data-arbi-pairsearch') === '1',
  ).catch(() => false);
  for (let i = 0; i < 2 && !(await isFocused()); i++) {
    await input.click({ timeout: focusMs, force: i > 0 }).catch(() => {});
  }
  if (!(await isFocused())) await input.focus({ timeout: 500 }).catch(() => {}); // best-effort фолбэк
  await input.selectText({ timeout: 1500 }).catch(() => {});
  // Settle перед вводом: свежему полю нужно мгновение на инициализацию React, иначе быстрый
  // keyboard.type иногда не триггерит фильтрацию (список остаётся общим → в диаге только
  // хот-серчи шапки → провал). 50мс оказалось мало (регресс на WOJAK 2026-07-14) — 100мс.
  await page.waitForTimeout(Number(process.env.ARBI_MEXC_SEARCH_SETTLE_MS || 100));
  return input;
}

async function changePairSpa(page, pair, log) {
  page.__arbiPair = null; // уходим со старой пары — кэш вкладки недействителен
  const [base, quote = 'USDT'] = String(pair).split('_');
  const pairLink = `a[href*="/exchange/${pair}"]`;
  // ── ДИАГНОСТИКА «первый поиск в длинной сессии тормозит» ──────────────────────
  // Разбиваем поиск на фазы с таймингом (лог [поиск-тайминг]). Что означают цифры:
  //   • wake — первый доступ к DOM (page.evaluate). БОЛЬШОЙ wake = Chromium заморозил/
  //     выгрузил простаивавшую вкладку, и первое обращение её «будит» (главный подозреваемый
  //     для длинной сессии).
  //   • focus — открытие выпадашки поиска (Escape+клик по заголовку+ожидание поля).
  //   • type — ввод тикера. results — ожидание строк удалённого поиска (БОЛЬШОЙ = прокси/
  //     сеть «остыли» или поиск MEXC медленный). click — клик по строке. finish — смена URL.
  const tStart = Date.now();
  // Путь ДО перехода — чтобы finishSpa засчитал успех по САМОМУ ФАКТУ смены URL для
  // токенов, где displayName ≠ coinName (в адресе внутренний тикер, а не имя): ни pair,
  // ни base в h1 не совпадут, и раньше finishSpa падал в timeout 4с → перезагрузка.
  let prevPath = '';
  try { prevPath = await page.evaluate(() => location.pathname); } catch { /* игнор */ }
  const tWake = Date.now(); // page.evaluate разбудил вкладку — вот и «wake»
  // Вкладка НЕ на торговой странице (восстановленная сессия могла встать на /earn и
  // т.п.)? SPA-поиск оттуда НЕ навигирует на /exchange (другой роутер-контекст) — ловили:
  // ввод и клик по результату проходят, а URL остаётся /earn → 2.5с таймаут → reload.
  // Не тратим 6-8с на заведомо провальные попытки — сразу прямой переход на пару.
  if (prevPath && !/\/exchange\//i.test(prevPath)) {
    log(`Вкладка на «${prevPath}» (не /exchange) — сразу прямой переход на пару`);
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(page.url(), pair)) rememberPair(page, pair); // goto с catch — кэшируем только подтверждённый URL
    page.__arbiSide = null;
    return { spa: false };
  }
  // Общий финал SPA-перехода: дождаться смену URL БЕЗ перезагрузки + инпуты формы.
  const finishSpa = async () => {
    // Терпимо к кодировке URL и к внутреннему id в адресе: успех если decoded
    // pathname содержит пару ИЛИ h1 показывает base токена.
    await page.waitForFunction((args) => {
      let dec = location.pathname;
      try { dec = decodeURIComponent(location.pathname); } catch { /* оставляем сырой */ }
      const path = (dec + ' ' + location.pathname).toLowerCase();
      if (path.includes('/exchange/' + args.pair)) return true;
      // ЛЮБОЙ видимый h1 с base (не только первый в DOM: первый может быть
      // ещё не перерисован/скрыт баннером → ложный «не перешли» → лишний reload).
      // CR-1: граница токена — подстрочный includes('ART') матчил «SMART/USDT» →
      // мгновенный ЛОЖНЫЙ успех SPA-перехода на клоне-тикере.
      const baseRe = new RegExp(args.baseRe, 'i');
      for (const h1 of document.querySelectorAll('h1')) {
        if (h1.offsetParent !== null && baseRe.test(h1.textContent || '')) return true;
      }
      // displayName ≠ coinName: URL сменился на ДРУГУЮ пару (не прежнюю).
      return !!(args.prev && location.pathname !== args.prev && /\/exchange\//i.test(location.pathname));
    }, { pair: String(pair).toLowerCase(), baseRe: '(?<![A-Za-z0-9])' + escRe(base) + '(?![A-Za-z0-9])', prev: prevPath },
      // 2500 → 5000: клик по строке уже состоялся, SPA неликвидной пары может
      // обновлять URL/h1 дольше 2.5с — ранний timeout вёл в полный reload
      // («итерации поиска повторяются, хотя токен уже выбран»).
      { timeout: Number(process.env.ARBI_MEXC_SPA_WAIT_MS || 5000) });
    await page.waitForSelector(SELECTORS.input, { timeout: 4000 }).catch(() => {});
    rememberPair(page, pair); // переход подтверждён — следующие интенты без DOM-проверок
    // На новой паре активная сторона Buy/Sell неизвестна — пусть executeIntent
    // подтвердит её кликом заново (безопасность направления ордера).
    page.__arbiSide = null;
  };

  // Способ A: ссылка на пару уже есть на странице (watchlist/список рынков) —
  // клик по внутренней ссылке = client-side переход Next (SPA), без поиска.
  try {
    const link = await page.$(pairLink);
    if (link) {
      await link.click({ timeout: 2000 });
      await finishSpa();
      log(`Смена пары по ссылке на странице (SPA): ${pair}`);
      return { spa: true };
    }
  } catch (_) { /* нет прямой ссылки — пробуем поиск */ }

  // Способ B: строка поиска сайта → ввод символа → клик по строке результата
  // (кликабельный div с текстом «BASE/USDT», React onClick → client-side SPA).
  let step = 'search-input';
  try {
    await focusSearchInput(page);
    const tFocus = Date.now();
    // Печать через keyboard в УЖЕ сфокусированное поле (focusSearchInput сделал focus),
    // а НЕ input.pressSequentially: тот перепроверяет актуальность локатора и на протухшем
    // после ре-рендера дропдауна поле висел до дефолтных 30с (фриз ~36с, жалоба оператора
    // 2026-07-14). keyboard.type печатает в АКТИВНЫЙ элемент без проверки локатора —
    // устойчивее и без 30с-зависания. delay переопределяем ARBI_MEXC_SEARCH_DELAY.
    await page.keyboard.type(base, { delay: Number(process.env.ARBI_MEXC_SEARCH_DELAY || 0) });
    const tType = Date.now();
    step = 'result-item';
    // Строка результата — ЖДЁМ И КЛИКАЕМ ТОЛЬКО строку с ТОЧНЫМ текстом «BASE/USDT»,
    // никогда «первую попавшуюся». Раньше сперва ждали ЛЮБУЮ строку по searchResultScoped
    // (scoped на search-bar_resultWrapper__), а текстовый матч проверяли ОДНИМ снимком
    // ПОСЛЕ — на неликвидных токенах (ALVA) это ловило карусель горячих токенов шапки
    // (диаг: строки «SNDK AKE ESPORTS» и т.п., без ALVA) — либо scoped-строка вовсе не
    // появлялась за 4500мс (обёртка иногда не рендерится/переименована) → пустое ожидание
    // впустую, а конечный клик всё равно уходил мимо → SPA не выйдет, только время слито.
    // Теперь ОДИН waitForFunction поллит и помечает нужную строку по ТЕКСТУ, коротким
    // бюджетом: если реального результата нет — бэйлим СРАЗУ (быстрее, чем достаивать
    // старые 4500мс ради заведомого промаха), не кликая чужое.
    // CR-1: экран + левая граница токена — «ART» без границы матчил строку «SMART/USDT»
    // и клик уходил в ЧУЖУЮ пару (pairGate поймал бы, но ордер срывался и время терялось).
    const wantRe = new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/?\\s*' + escRe(quote), 'i');
    // P0-1 (сохранено): hasText+.first() на однорезультатном поиске (напр. ALVA) ловил
    // ВНЕШНИЙ контейнер («All Spot Futures Spot(1) ALVA/USDT») — клик в его центр мимо
    // строки. Ищем в браузере САМЫЙ ГЛУБОКИЙ видимый элемент, чей textContent матчит
    // BASE/USDT и у которого НЕТ потомка с тем же матчем (строка тикера, не обёртка).
    // Скоуп — контейнер результатов, если он есть; иначе весь дропдаун (document), чтобы
    // переименование/отсутствие класса обёртки не топило матч по тексту.
    const matchBudget = Number(process.env.ARBI_MEXC_RESULT_MATCH_MS || 2500);
    const found = await page.waitForFunction((wantReSrc) => {
      const vis = (el) => el && el.offsetParent !== null;
      const re = new RegExp(wantReSrc, 'i');
      document.querySelectorAll('[data-arbi-searchrow]').forEach((e) => e.removeAttribute('data-arbi-searchrow'));
      const scope = document.querySelector('[class*="search-bar_resultWrapper__"]') || document.body;
      const matches = Array.from(scope.querySelectorAll('*')).filter((el) => vis(el) && re.test((el.textContent || '').trim()));
      const deepest = matches.find((el) => !matches.some((other) => other !== el && el.contains(other)));
      const pick = deepest || matches[0];
      if (!pick) return false;
      pick.setAttribute('data-arbi-searchrow', '1');
      return true;
    }, wantRe.source, { timeout: matchBudget, polling: 100 }).then(() => true).catch(() => false);
    if (!found) {
      // Нет строки с нужным текстом за бюджет — карусель/чужие токены вместо результата,
      // это нормальный сигнал «SPA не выйдет»: бросаем сразу в reload-фолбэк ниже,
      // без клика мимо и без досиживания старого 4500мс таймаута.
      throw new Error(`строка «${base}/USDT» не найдена в результатах за ${matchBudget}мс`);
    }
    const tResults = Date.now();
    await page.click('[data-arbi-searchrow]', { force: true, timeout: Number(process.env.ARBI_MEXC_RESULT_CLICK_MS || 2500) });
    const tClick = Date.now();
    step = 'url-change';
    await finishSpa();
    const tFinish = Date.now();
    log(`Смена пары через поиск (SPA, без перезагрузки): ${pair}`);
    log(`[поиск-тайминг] wake=${tWake - tStart} focus=${tFocus - tWake} type=${tType - tFocus} results=${tResults - tType} click=${tClick - tResults} finish=${tFinish - tClick} ИТОГО=${tFinish - tStart}мс`);
    return { spa: true };
  } catch (e) {
    // Диагностика: какие поля ввода / элементы поиска реально есть на странице —
    // чтобы подобрать точный ARBI_MEXC_SEL_SEARCH без гадания (как чинили форму).
    if (step === 'search-input') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 12)
          .map((i) => ({ ph: i.placeholder || '', al: i.getAttribute('aria-label') || '', cls: String(i.className || '').slice(0, 45), t: i.type }));
        const searchish = Array.from(document.querySelectorAll('[class*="earch" i],[aria-label*="search" i],[aria-label*="uscar" i]')).filter(vis).slice(0, 6)
          .map((e) => ({ tag: e.tagName, al: e.getAttribute('aria-label') || '', cls: String(e.className || '').slice(0, 45) }));
        return { inputs, searchish };
      }).catch(() => ({}));
      console.log('[mexc-exec] [diag поиск] ' + JSON.stringify(diag).slice(0, 950));
    }
    // Диагностика провала на строке-результате: какие строки реально в выпадающем
    // списке (класс+текст) — чтобы подобрать точный ARBI_MEXC_SEL_SEARCH_RESULT / понять,
    // почему нужная пара не подхватилась (частая причина медленного 1-го ордера).
    if (step === 'result-item') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const rows = Array.from(document.querySelectorAll('[class*="result-item"],[class*="earch" i] [class*="item" i],[class*="result" i],[class*="option" i]'))
          .filter(vis).slice(0, 10)
          .map((e) => ({ cls: String(e.className || '').slice(0, 50), txt: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40) }));
        return { rows };
      }).catch(() => ({}));
      console.log('[mexc-exec] [diag результат] ' + JSON.stringify(diag).slice(0, 950));
    }
    // На провале url-change логируем, где реально остались (URL не сменился = клик по
    // строке результата не навигировал; сменился на другое = не туда). По этому можно
    // прицельно чинить сам SPA-переход для конкретного токена.
    if (step === 'url-change') {
      const cur = await page.evaluate(() => location.pathname).catch(() => '?');
      console.log(`[mexc-exec] [diag url-change] осталось на «${cur}», ждали пару «${pair}»`);
    }
    log(`SPA-навигация не удалась на шаге «${step}» (${String(e.message).slice(0, 50)}) — фолбэк на перезагрузку`);
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(page.url(), pair)) rememberPair(page, pair); // goto с catch — кэшируем только подтверждённый URL
    page.__arbiSide = null;
    return { spa: false };
  }
}

/**
 * Подтверждает модалку ордера MEXC (ant-modal-v2-confirm и т.п.), нажимая её
 * основную кнопку (Confirm/Подтвердить/确认/Buy или .ant-btn-primary внутри диалога).
 * Trusted-клик через Playwright. Возвращает true, если кликнули. Перебирает селекторы,
 * т.к. текст/вёрстка модалки меняются между версиями MEXC.
 */
async function confirmOrderModal(page, log) {
  // Модалка подтверждения MEXC: «Order Confirmation … Cancel | Buy <SYM>». Кнопка
  // подтверждения имеет ДИНАМИЧЕСКИЙ текст ("Buy WOJAK"/"Sell WOJAK"/确认/Confirm),
  // футер кастомный (не ant-btn-primary). Ищем модалку по тексту и жмём её НЕ-Cancel
  // кнопку (trusted, scoped внутрь модалки — чтобы не задеть кнопку сабмита формы с
  // тем же текстом). Подтверждение = именно этот клик отправляет order/place.
  // Надёжно: в браузере находим модалку подтверждения и ПОМЕЧАЕМ её кнопку-подтверждение
  // (НЕ-Cancel) уникальным атрибутом, затем жмём её trusted-кликом по этому атрибуту.
  // Так исключаем двусмысленность с одноимённой кнопкой сабмита формы («Buy <SYM>»).
  const marked = await page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('[class*="ant-modal"],[class*="odal-v2"],[class*="odal-wrap"],[role="dialog"]')).filter(vis);
    for (const m of modals) {
      const txt = (m.innerText || '');
      if (!/confirmation|подтвер|confirm|订单确认|订单|risk|риск/i.test(txt)) continue;
      // Отметить «No more reminders» — чтобы MEXC больше НЕ показывал это подтверждение
      // (следующие ордера пойдут напрямую, без модалки → быстрее и надёжнее).
      try {
        const cb = m.querySelector('input[type="checkbox"]');
        if (cb && !cb.checked) cb.click();
      } catch (_) { /* нет чекбокса */ }
      const btns = Array.from(m.querySelectorAll('button')).filter(vis);
      const notCancel = (b) => { const t = (b.innerText || '').trim(); return t && !/cancel|отмена|取消|no more|reminder|напоминан|close|закрыть|annuler|fermer/i.test(t); };
      // Сначала кнопка с текстом согласия/подтверждения (у окна риска рядом может быть
      // «Подробнее»), иначе первая не-Cancel, как раньше.
      const btn = btns.find((b) => notCancel(b) && /confirm|подтвер|agree|соглас|understand|понятно|got it|ok|continue|продолж|\bbuy\b|\bsell\b|купить|продать|确认|确定|同意/i.test((b.innerText || '').trim()))
        || btns.find(notCancel);
      if (btn) { btn.setAttribute('data-arbi-confirm', '1'); return (btn.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 24); }
    }
    return null;
  }).catch(() => null);
  if (!marked) return false;
  try {
    await page.click('button[data-arbi-confirm="1"]', { timeout: 1500, noWaitAfter: true, force: true });
    if (log) log('Подтвердил модалку ордера: ' + marked);
    return true;
  } catch { return false; }
}

/**
 * M6: ЗАКРЫТЬ (Cancel/крестик) висящую модалку подтверждения ордера — НЕ подтверждать.
 * Вызывать В НАЧАЛЕ обработки intent: если от ПРОШЛОГО ордера осталась открытая модалка
 * (со старыми ценой/кол-вом), confirmOrderModal ниже подтвердила бы ЕЁ → ушёл бы чужой
 * ордер, а текущему intent приписался бы её orderId (ложный ok) + возможен второй ордер.
 * Закрываем чужую модалку заранее → в цикле клика confirmOrderModal видит только НАШУ.
 */
async function dismissOrderModal(page, log) {
  const closed = await page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('[class*="ant-modal"],[class*="odal-v2"],[class*="odal-wrap"],[role="dialog"]')).filter(vis);
    let did = false;
    for (const m of modals) {
      if (!/confirmation|подтвер|confirm|订单确认|订单/i.test(m.innerText || '')) continue;
      const btns = Array.from(m.querySelectorAll('button')).filter(vis);
      const cancel = btns.find((b) => /cancel|отмена|取消|close|закрыть/i.test((b.innerText || '')));
      const x = m.querySelector('[aria-label="Close"],[aria-label="close"],[class*="close"]');
      if (cancel) { cancel.click(); did = true; }
      else if (x && x.click) { x.click(); did = true; }
    }
    return did;
  }).catch(() => false);
  if (closed && log) log('M6: закрыл лефтовер-модалку подтверждения прошлого ордера (чужой ордер НЕ подтверждаю)');
  return closed;
}

// У MEXC в DOM ОДНОВРЕМЕННО присутствуют обе кнопки сабмита (Buy… и Sell…), но ВИДИМА
// только активная (неактивная скрыта 0×0). Раньше $eval/click брали ПЕРВУЮ в DOM (часто
// скрытую Buy) → на стороне Sell это ломало и чтение стороны, и клик по заявке. Работаем
// ТОЛЬКО с видимой кнопкой (подтверждено diag layout: Sell WOJAK v:true, Buy WOJAK v:false).
async function readVisibleSubmitText(page) {
  return page.evaluate((sel) => {
    const vis = (el) => el && el.offsetParent !== null && el.getBoundingClientRect().width > 2;
    const b = Array.from(document.querySelectorAll(sel)).filter(vis)[0];
    return b ? (b.textContent || '').trim() : '';
  }, SELECTORS.submit).catch(() => '');
}
/** Locator ВИДИМОЙ кнопки сабмита (активной стороны) — для клика и проверки готовности. */
function visibleSubmit(page) {
  const s = SELECTORS.submit;
  const sel = /^(text=|xpath=|\/\/)/.test(s) ? s : `${s}:visible`;
  return page.locator(sel).first();
}

// ── Факты формы, когда клик по кнопке ордера молча глотается (OTC 08.10: три заявки
// подряд «order/place не ушёл» без единой модалки, четвёртая с теми же полями ушла
// через 27 с). На «количество больше доступного» MEXC не показывает модалку — только
// подпись под полем, а кнопка ничего не отправляет. Собираем доступный баланс монеты
// по подписи «Available», видимые подписи-ошибки у формы и состояние кнопки. Это след
// (#58), а не догадка (#54): число не прочиталось → null, гейт по нему не срабатывает.
const AVAIL_RE = /(Available|Avbl|Доступно|Дост\.|可用)/i;
async function formFacts(page, asset) {
  const f = await page.evaluate(({ sel, availRs }) => {
    const vis = (e) => e && e.offsetParent !== null;
    const availRe = new RegExp(availRs, 'i');
    const avail = []; const errors = [];
    for (const e of document.querySelectorAll('div,span,label,p')) {
      if (!vis(e) || e.children.length > 3) continue;
      const t = (e.textContent || '').replace(/\s+/g, ' ').trim();
      if (!t || t.length > 120) continue;
      if (availRe.test(t) && /\d/.test(t)) avail.push(t);
      if (/insufficient|not enough|exceed|недостаточн|превыша|минимал|minimum|余额不足/i.test(t)) errors.push(t);
    }
    const btn = Array.from(document.querySelectorAll(sel)).filter(vis)[0];
    return {
      avail: [...new Set(avail)].slice(0, 4),
      errors: [...new Set(errors)].slice(0, 3),
      btn: btn ? { text: (btn.textContent || '').trim().slice(0, 30), disabled: !!(btn.disabled || btn.getAttribute('aria-disabled') === 'true' || /disabled/i.test(btn.className)) } : null,
    };
  }, { sel: SELECTORS.submit, availRs: AVAIL_RE.source }).catch(() => ({ avail: [], errors: [], btn: null }));
  return { ...f, availNum: pickBaseAvail(f.avail, asset) };
}

// Что стоит на месте формы, когда наших полей/кнопок нет (#58). Лог напарника 12.10
// (MEXC BKN, свой аккаунт): поля на странице есть, цена заполнена, а кнопок сабмита и
// вкладок стороны в DOM нет вовсе — прогрев писал «полей 0», заявка «осталась «»», и
// причина не видна. Снимок отличает «форма ещё грузится» (полей нет вообще) от «вёрстка
// другая / вместо кнопок согласие с риском, запрет региона, вход» — по текстам кнопок
// панели заявки (предок поля с ценой, крупный настолько, чтобы вместить кнопку).
async function formPanelSnapshot(page) {
  return page.evaluate(() => {
    const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
    const inputs = Array.from(document.querySelectorAll('input')).filter(vis);
    let panel = inputs.find((i) => /^\d/.test(i.value || '')) || null;
    // Классы поля цены и кнопок стороны — по ним подбираются селекторы под новую вёрстку
    // (12.10: на BKN у напарника поля и кнопка «Buy BKN» видны, а наши классы не находятся).
    const cls = (e) => String((e && e.className) || '').slice(0, 80);
    const priceCls = panel ? [cls(panel), cls(panel.parentElement)] : [];
    const sideBtns = Array.from(document.querySelectorAll('button,[role="button"],div,span')).filter(vis)
      .filter((e) => /^(buy|sell|купить|продать|acheter|vendre)(\s+\S{1,12})?$/i.test((e.textContent || '').trim()))
      .slice(0, 6).map((e) => `${(e.textContent || '').trim()}=${e.tagName.toLowerCase()}.${cls(e)}`);
    for (let k = 0; panel && k < 10; k++) {
      const r = panel.getBoundingClientRect();
      if (r.height >= 300 && r.width >= 250) break;
      panel = panel.parentElement;
    }
    const buttons = panel ? Array.from(panel.querySelectorAll('button,[role="button"]')).filter(vis)
      .map((b) => (b.textContent || '').replace(/\s+/g, ' ').trim()).filter(Boolean) : [];
    const text = panel ? (panel.innerText || '').replace(/\s+/g, ' ').trim() : '';
    return { inputs: inputs.length, panel: !!panel, buttons: [...new Set(buttons)].slice(0, 6), tail: text.slice(-160), priceCls, sideBtns };
  }).catch(() => ({ inputs: 0, panel: false, buttons: [], tail: '' }));
}
/** Короткая строка «что на месте кнопок» для журнала и ошибки. */
function panelSays(snap) {
  return (snap.tail || snap.buttons.join(' | ') || 'пусто').slice(0, 160);
}

/** Текущая сторона формы по тексту ВИДИМОЙ кнопки сабмита ('buy'|'sell'|''). ЕДИНЫЙ
 * источник правды направления (та же кнопка, что жмём): «Buy WOJAK»→buy, «Sell WOJAK»→sell. */
async function readFormSide(page) {
  return sideFromText(await readVisibleSubmitText(page));
}

/**
 * ПЕРЕКЛЮЧИТЬ форму на нужную сторону (Buy/Sell) НАДЁЖНО и с ПРОВЕРКОЙ по кнопке сабмита.
 * Раньше был один клик по `text=/^Sell$/i` с тихим catch: на cold-форме (после reload)
 * он не успевал/не находил вкладку → форма оставалась на Buy → sell блокировался M5
 * (продажа на MEXC не работала совсем). Теперь: цикл ретраев, на каждом — (A) клик по
 * env-селектору вкладки, (B) поиск в DOM ВИДИМОГО короткого элемента с точным словом
 * стороны (НЕ кнопка сабмита — do-submit исключён, ордер не жмём) и trusted-клик по нему,
 * с локализацией под язык интерфейса. Успех = кнопка сабмита показала нужную сторону.
 * @returns {Promise<boolean>} удалось ли встать на нужную сторону.
 */
async function ensureSide(page, wantSide, log) {
  if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
  const sel = wantSide === 'sell' ? SELECTORS.sellTab : SELECTORS.buyTab;
  const words = wantSide === 'sell'
    ? ['sell', 'продать', 'vender', 'verkaufen', 'vendre', 'vendi', 'sat', '卖', '卖出']
    : ['buy', 'купить', 'comprar', 'kaufen', 'acheter', 'compra', 'al', '买', '买入'];
  const attempts = Number(process.env.ARBI_MEXC_SIDE_ATTEMPTS || 5);
  for (let i = 0; i < attempts; i++) {
    // P0-2: поздний промо/риск-оверлей перехватывает клик по вкладке стороны — глушим
    // ПЕРЕД каждой попыткой (дёшево, зеркало фикса focusSearchInput).
    await dismissBlockingModal(page);
    await dismissOverlays(page);
    // A: селектор-вкладка (env/дефолт). На повторах — force (вдруг перекрыта анимацией).
    try { await page.click(sel, { timeout: Number(process.env.ARBI_MEXC_SIDE_CLICK_MS || 900), force: i > 0 }); } catch { /* пробуем DOM ниже */ }
    // Settle: дать React перерендерить кнопку сабмита после клика по вкладке ДО проверки.
    await page.waitForTimeout(Number(process.env.ARBI_MEXC_SIDE_SETTLE_MS || 120));
    if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
    // B: найти ВИДИМЫЙ короткий кликабельный элемент с точным словом стороны (кроме
    // кнопки сабмита do-submit — её НЕ жмём) и trusted-кликнуть.
    const marked = await page.evaluate((ws) => {
      const vis = (el) => el && el.offsetParent !== null && !/do-submit|_doBtn/i.test(String(el.className || ''));
      for (const el of Array.from(document.querySelectorAll('div,span,button,li,a,label')).filter(vis)) {
        const t = (el.textContent || '').trim().toLowerCase();
        // ТОЧНОЕ слово стороны: startsWith кликал чужие элементы — «buy crypto» (пункт
        // шапки) по 'buy', «alva» по турецкому 'al'. Вкладка стороны — ровно одно слово.
        if (t.length <= 10 && ws.some((w) => t === w)) { el.setAttribute('data-arbi-side', '1'); return true; }
      }
      return false;
    }, words).catch(() => false);
    if (marked) {
      await page.click('[data-arbi-side="1"]', { timeout: 500, force: true }).catch(() => {});
      await page.evaluate(() => { const e = document.querySelector('[data-arbi-side="1"]'); if (e) e.removeAttribute('data-arbi-side'); }).catch(() => {});
      if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
    }
    await page.waitForTimeout(250);
  }
  const ok = (await readFormSide(page)) === wantSide;
  if (ok) page.__arbiSide = wantSide; // кэш стороны актуален и на этом пути успеха
  return ok;
}

/**
 * ПРОГРЕВ формы БЕЗ выставления ордера — БЕЗОПАСНО, ничего не покупаем/продаём.
 * Грузит страницу пары, закрывает промо-оверлеи, дожидается готовности лимит-формы
 * (инпуты + активная кнопка сабмита = React догидрировался). Это и есть «холодная»
 * задержка (~несколько секунд), но здесь она платится В ФОНЕ, ДО ордера пользователя,
 * чтобы его ПЕРВЫЙ реальный ордер по этой паре пошёл по тёплому пути (~0.5-0.7с).
 */
/**
 * Окно «Напоминание о делистинге» (ST) на странице пары закрываем КРЕСТИКОМ доверенным
 * кликом (по команде терминала, оператор 19.10). Не «Принять и продолжить»: после неё
 * MEXC перезагружал страницу, и окно всплывало снова (0.4.267). Кнопка «Принять» — только
 * если крестика нет. Ждём окно до 4 с — оно дорисовывается после загрузки пары.
 * true — закрыли, false — окна нет. quiet — без строки «не найдено» (сторож вкладки).
 */
async function acceptDelistModal(page, log, quiet = false) {
  for (let i = 0; i < 16; i++) {
    const marked = await page.evaluate(() => {
      const vis = (el) => el && el.offsetParent !== null;
      for (const m of Array.from(document.querySelectorAll('[class*="ant-modal"],[class*="odal"],[role="dialog"]')).filter(vis)) {
        if (!/делистинг|delist|\bST\b/i.test(m.innerText || '')) continue;
        const x = Array.from(m.querySelectorAll('.ant-modal-close,[aria-label*="close" i],button[class*="close" i],[class*="close" i]')).filter(vis)[0];
        const b = x || Array.from(m.querySelectorAll('button')).filter(vis)
          .find((e) => /принять|accept|продолж|continue|confirm|agree|понятно|got it/i.test(e.innerText || ''));
        if (b) { document.querySelectorAll('[data-arbi-st]').forEach((e) => e.removeAttribute('data-arbi-st')); b.setAttribute('data-arbi-st', '1'); return x ? 'крестиком' : '«Принять и продолжить»'; }
      }
      return false;
    }).catch(() => false);
    if (marked) {
      try {
        await page.click('[data-arbi-st="1"]', { timeout: 1500, noWaitAfter: true });
        log(`Окно делиста (ST) закрыто ${marked}`);
        return true;
      } catch { /* перерисовалось — попробуем ещё раз */ }
    }
    await page.waitForTimeout(250);
  }
  if (!quiet) log('Окно делиста (ST) не найдено на странице пары');
  return false;
}

// Сторож вкладки: после команды терминала окно делиста закрывается и после каждой
// следующей загрузки этой вкладки (перезагрузка, переход на другую ST-пару).
function guardDelistModal(page, log) {
  if (page.__arbiStGuard) return;
  page.__arbiStGuard = true;
  page.on('load', () => {
    let u = ''; try { u = page.url(); } catch { return; }
    if (/\/exchange\//i.test(u)) acceptDelistModal(page, log, true).catch(() => {});
  });
}

async function warmupForm(context, pair, log, opts = {}) {
  spyCancel(context);
  // Тайминг прогрева (это и есть «первый поиск токена» при выборе в терминале). page —
  // сколько заняли ПОИСК вкладки + смена пары (getMexcPage: тут же будится замороженная
  // вкладка и идёт SPA-поиск, детальный разбор — в [поиск-тайминг]); form — догрузка формы.
  const tW0 = Date.now();
  const { page, cold } = await getMexcPage(context, pair, log);
  if (opts.acceptSt) {
    guardDelistModal(page, log);
    return { ok: true, cold, stAccepted: await acceptDelistModal(page, log) };
  }
  // ГОРЯЧАЯ форма — греть нечего. Терминал повторяет прогрев активной пары каждые 20 с и
  // после каждой заявки; на тёплой вкладке он стоил 270–340 мс + 350 мс сверки имени пары
  // уже ПОСЛЕ строки тайминга, и всё это время дорожка заявок занята (лог оператора 11.10,
  // снайпер BKN: выстрел ждал прогрев 1571 мс, следующий шёл 1408 мс по занятой странице).
  // Вкладка, где за последние ARBI_WARMUP_HOT_MS (60 с) прошёл прогрев или заявка, заведомо
  // прогрета и залогинена — отвечаем сразу, не трогая страницу. Остывшая греется как раньше.
  const hotMs = Number(process.env.ARBI_WARMUP_HOT_MS || 60000);
  if (!cold && hotMs > 0 && Date.now() - (page.__arbiHotAt || 0) < hotMs) {
    log(`Форма ${pair} горячая (заявка/прогрев ${Math.round((Date.now() - page.__arbiHotAt) / 1000)} с назад) — прогрев пропущен, ${Date.now() - tW0} мс`);
    return { ok: true, cold: false, displayBase: displayBaseFor('mexc', pair) || undefined };
  }
  await probeLag(page, log);
  const tW1 = Date.now();
  // Akamai «Access Denied» (блок профиля/IP) — бэкофф + выход, не долбим биржу.
  if (await isMexcAccessDenied(page)) {
    noteMexcAccessDenied(log);
    return { ok: false, error: `MEXC заблокировал доступ (Access Denied, Akamai) — навигация к MEXC приостановлена.` };
  }
  // Пара 404-ит по прямой ссылке (делистнута/только через поиск) — прогревать нечего,
  // и НЕ долбим 9-секундными ожиданиями формы, которой не будет. Внятный ответ.
  if (await isMexcNotFound(page)) {
    log(`Прогрев пропущен: страница пары ${pair} на MEXC отдаёт 404 (токен делистнут/только через поиск)`);
    return { ok: false, notFound: true, error: `MEXC: страница пары ${pair} недоступна (404 по прямой ссылке).` };
  }
  await dismissOverlays(page);
  let inputs = await page.$$(SELECTORS.input);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: 1000 }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.input, { timeout: 9000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.input);
  }
  // Полей так и нет — формы на странице НЕТ. Ждать следом ещё 9 с кнопку сабмита
  // бессмысленно: она часть той же формы. Лог оператора 2026-09-20 (TRUU/MEXC):
  // `form=19903` — это ровно два таймаута подряд, после которых прогрев всё равно
  // отрапортовал «Форма прогрета», хотя греть было нечего. Молчаливого успеха на
  // пустом месте не бывает: 20 с профиль был занят впустую, а следующая заявка
  // ждала их в очереди (прогрев и ордер сериализованы в одном профиле).
  if (inputs.length < 2) {
    const snap = await formPanelSnapshot(page);
    log(`Прогрев не удался: форма лимит-ордера ${pair} не догрузилась (полей ${inputs.length}) за ${Date.now() - tW1} мс`
      + (snap.panel ? ` — но форма другой вёрстки (полей ${snap.inputs}, цена заполнена); на панели: «${panelSays(snap)}»` : ''));
    if (snap.panel) log(`[diag вёрстка] поле цены: ${JSON.stringify(snap.priceCls)}; кнопки стороны: ${JSON.stringify(snap.sideBtns)}`.slice(0, 900));
    log(`[прогрев-тайминг] page(поиск+вкладка)=${tW1 - tW0} form=${Date.now() - tW1} ИТОГО=${Date.now() - tW0}мс${cold ? ' [холодная]' : ''} [форма не догрузилась]`);
    return { ok: false, cold, error: `MEXC: форма лимит-ордера ${pair} не догрузилась (полей ${inputs.length}).` };
  }
  // ВИДИМУЮ кнопку сабмита, не первую по DOM (лог оператора 10.10: прогрев 9,3 с на КАЖДОМ
  // вызове после первой продажи — form=9300 при 300 мс до неё). Селектор ловит кнопки обеих
  // сторон формы; после продажи форма стоит на Sell, первой в DOM идёт СПРЯТАННАЯ кнопка Buy,
  // а waitForSelector смотрит только на первый элемент и ждёт её «видимости» до таймаута.
  // Заявка, пришедшая в эти 9 с, ждала прогрева в очереди («возраст 8910 мс»). Поля формы
  // уже найдены, поэтому 3 с с запасом; не дождались — говорим об этом, не молчим (#58).
  await page.waitForSelector(`${SELECTORS.submit}:visible`, { timeout: 3000 })
    .catch(() => log(`Прогрев: видимой кнопки сабмита нет за 3 с — продолжаю без неё`));
  // НЕ ждём enabled-состояния кнопки на ПУСТОЙ форме прогрева: если кнопка сабмита
  // без значений disabled, цикл ожидания крутил бы ~5с (25×200мс) ВПУСТУЮ, и
  // реальный ордер, пришедший следом, эти 5с ждал бы в очереди (warmup и ордер
  // сериализованы в одном профиле). Форма уже готова; enabled проверит executeIntent
  // ПОСЛЕ заполнения. Короткая догидрация React.
  await page.waitForTimeout(Number(process.env.ARBI_MEXC_WARMUP_SETTLE_MS || 250));
  await dismissOverlays(page);
  const tW2 = Date.now();
  {
    const lw = await loginWallFresh(page, log);
    if (lw.wall) { log(`Нет входа в аккаунт MEXC в этом профиле (на форме: «${lw.text}») — прогрев невозможен`); return { ok: false, cold, loginRequired: true, error: loginRequiredError('MEXC', 'Прогрев формы не выполнен — войдите ДО выставления заявки.') }; }
  }
  log(`Форма прогрета (${pair})${cold ? ' [была холодная]' : ''} — ордер НЕ ставился`);
  log(`[прогрев-тайминг] page(поиск+вкладка)=${tW1 - tW0} form=${tW2 - tW1} ИТОГО=${tW2 - tW0}мс${cold ? ' [холодная]' : ''}${lightBlocked(page) ? ` лёгкий=${lightBlocked(page)}` : ''}`);
  // Имя пары у биржи — пока ждём депозит, чтобы заявка потом прошла сверку за раз.
  // Имя пары у биржи учим ОДИН РАЗ на вкладку: сверка стоит 0,3–1,7 с под замком заявок
  // (лог 11.10 08:31: форма за 274 мс, результат через 1,7 с). Дальше — из кэша.
  let displayBase = displayBaseFor('mexc', pair) || undefined;
  if (page.__arbiBaseLearned !== pair) {
    displayBase = await learnDisplayBase('mexc', page, pair, urlHasPair, log).catch(() => null);
    if (displayBase) page.__arbiBaseLearned = pair;
  }
  page.__arbiHotAt = Date.now();
  return { ok: true, cold, displayBase };
}

/**
 * Исполняет ОДНО намерение в живой странице MEXC.
 *
 * @param {import('playwright').BrowserContext} context  контекст профиля аккаунта
 * @param {object} intent  { id, accountId, symbol, side, type, price, quantity, dryRun }
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{ok:boolean, orderId?:string, error?:string}>}
 */
// Нулевой баланс на СТРАНИЦЕ при продаже (оператор 2026-10-30, DEOD): терминал по API уже видел
// зачисление и снайпер стрелял, а вкладка MEXC держала устаревшее «Доступно 0» и кнопку «Депозит».
// Перещёлкиваем вкладки формы «Купить» → «Продать» на той же странице (оператор: так MEXC быстрее
// перечитывает баланс, чем при перезагрузке; навигации нет — Akamai не задевается) и повторяем ту же
// заявку. Один раз на заявку; обе «нулевые» ветки выходят до клика — двойной заявки нет.
async function executeIntent(context, intent, opts = {}) {
  spyCancel(context);
  const first = await executeIntentOnce(context, intent, opts);
  if (!first || first.ok || !first.zeroBalance || intent.side !== 'sell') return first;
  const log = opts.log || (() => {});
  const pair = toMexcPair(intent.symbol);
  log(`Страница показывает 0 ${pair.split('_')[0]} — перещёлкиваю «Купить» → «Продать» (MEXC перечитает баланс) и повторяю заявку`);
  try {
    const { page } = await getMexcPage(context, pair, log);
    // Прямые клики по вкладкам: ensureSide узнаёт сторону по кнопке заявки, а при нуле там «Депозит» —
    // он крутил бы попытки ~6 с впустую.
    await page.click(SELECTORS.buyTab, { timeout: 900 }).catch(() => {});
    await page.waitForTimeout(200);
    await page.click(SELECTORS.sellTab, { timeout: 900 }).catch(() => {});
    let ready = false;
    for (let i = 0; i < 8 && !ready; i++) { await page.waitForTimeout(200); ready = (await readFormSide(page)) === 'sell'; }
    page.__arbiSide = null; // повтор сам сверит сторону (на месте — без кликов)
    log(ready ? 'Баланс подтянулся — кнопка «Продать» на месте' : 'После перещёлкивания всё ещё «Депозит» — пробую заявку ещё раз');
  } catch (e) {
    log(`Перещёлкнуть вкладки не вышло (${String(e?.message || e).slice(0, 80)}) — оставляю первый ответ`);
    return first;
  }
  const second = await executeIntentOnce(context, intent, opts);
  if (second && !second.ok && second.zeroBalance) {
    return { ...second, error: `${second.error} (вкладки «Купить/Продать» перещёлкнуты — страница по-прежнему показывает 0)` };
  }
  return second;
}

// ── ПРЯМЫЕ ЗАЯВКИ (оператор 2026-11-03, опыт PROM): подпись страницы MEXC (x-mxc-sign/nonce +
// p0/k0/mhash/… в теле) работает много раз и параллельно. Заявка кнопкой запоминает свой запрос
// (пара + сторона); следующие заявки той же пары и стороны идут fetch-ем из этой страницы — без
// формы и без замка вкладки, каждая сама ждёт свой ответ. Любой сбой (не JSON, 401/403, код≠200)
// → подпись выбрасывается, заявка уходит обычным путём (форма). Только по флагу из терминала
// (intent.hints.direct, CEX MEXC_WEB_DIRECT=1). Подпись/cookies/тело в журнал не пишутся.
const directCaps = new Map(); // `${pair}|${side}` → { page, url, hdr, body, at }
const DIRECT_SKIP_HDR = /^(cookie|host|content-length|user-agent|origin|referer|accept-encoding|connection|priority|sec-|:)/i;
async function rememberDirect(page, pair, side, req) {
  if (!req) return;
  let h = {};
  try { h = await req.allHeaders(); } catch { h = req.headers(); }
  let body = null;
  try { body = JSON.parse(req.postData() || ''); } catch { return; }
  const hdr = {};
  for (const [k, v] of Object.entries(h || {})) if (!DIRECT_SKIP_HDR.test(k)) hdr[k] = v;
  const key = `${pair}|${side}`;
  if (!directCaps.has(key)) console.log(`[mexc-exec] [прямая] подпись ${pair} ${side} запомнена; поля тела: ${Object.keys(body).join(',')}`);
  directCaps.set(key, { page, url: req.url(), hdr, body, at: Date.now() });
}

// РАЗВЕДКА ОТМЕНЫ ОДНОЙ ЗАЯВКИ (оператор 03.11: «заявка сильно ниже рынка и сразу отмена» при
// взведении снайпера). Своей отмены одной заявки у нас нет — только «Отменить все», которая
// сняла бы и заявки оператора. Пишем, каким запросом сайт отменяет ОДНУ заявку: путь и имена
// полей тела (значения, подписи, cookies — не пишутся). Один слушатель на профиль.
function spyCancel(context) {
  if (!context || context.__arbiCancelSpy) return;
  context.__arbiCancelSpy = true;
  context.on('response', async (r) => {
    try {
      const q = r.request();
      if (q.method() !== 'POST' && q.method() !== 'DELETE') return;
      const u = new URL(q.url());
      if (!/mexc\./i.test(u.hostname) || !/cancel/i.test(u.pathname)) return;
      let keys = '—';
      try { keys = Object.keys(JSON.parse(q.postData() || '{}')).join(',') || '—'; } catch { keys = 'не JSON'; }
      let code = null;
      try { code = (await r.json()).code; } catch { /* не JSON */ }
      console.log(`[mexc-exec] [разведка отмены] ${q.method()} ${u.pathname} поля тела: ${keys}; параметры адреса: ${[...u.searchParams.keys()].join(',') || '—'}; ответ HTTP ${r.status()} code=${code}`);
    } catch { /* разведка не мешает работе */ }
  });
}

/** Прямая заявка. null — прямой путь не применим или сорвался (тогда — обычный путь через форму). */
async function tryDirect(context, intent, log) {
  if (!(intent && intent.hints && intent.hints.direct) || intent.type !== 'limit' || intent.dryRun || intent.warmup) return null;
  const pair = toMexcPair(intent.symbol);
  const key = `${pair}|${intent.side}`;
  const cap = directCaps.get(key);
  if (!cap) return null;
  let closed = true;
  try { closed = cap.page.isClosed() || cap.page.context() !== context; } catch { closed = true; }
  if (closed) {
    // Подпись не привязана к вкладке (это заголовки и тело запроса) — закрылась вкладка пары,
    // шлём из любой живой вкладки MEXC того же профиля. Не сработает — как всегда, форма.
    let alt = null;
    try { alt = context.pages().find((pg) => !pg.isClosed() && pg.url().startsWith(MEXC_ORIGIN)) || null; } catch { alt = null; }
    if (!alt) { directCaps.delete(key); return null; }
    cap.page = alt;
  }
  const price = formatDecimal(intent.price);
  const qty = formatDecimal(intent.quantity);
  if (!isPlainPositive(price) || !isPlainPositive(qty)) return null;
  const t0 = Date.now();
  const r = await cap.page.evaluate(async ({ url, hdr, body }) => {
    try {
      const res = await fetch(url, { method: 'POST', headers: hdr, body, credentials: 'include' });
      const txt = await res.text();
      let j = null;
      try { j = JSON.parse(txt); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, data: j ? j.data : null, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON' };
    } catch (e) { return { error: String(e && e.message || e).slice(0, 160) }; }
  }, { url: cap.url, hdr: cap.hdr, body: JSON.stringify({ ...cap.body, price, quantity: qty }) }).catch((e) => ({ error: String(e && e.message || e).slice(0, 160) }));
  const ms = Date.now() - t0;
  const orderId = r && r.status >= 200 && r.status < 300 && (r.code === 200 || r.code === 0)
    ? (typeof r.data === 'string' ? r.data : (r.data && r.data.orderId ? String(r.data.orderId) : null)) : null;
  if (orderId) {
    log(`[прямая] Ордер выставлен: ${orderId} — ${intent.side} ${qty} @ ${price}, ответ ${ms} мс (подпись живёт ${Math.round((Date.now() - cap.at) / 1000)} с)`);
    return { ok: true, orderId, direct: true };
  }
  directCaps.delete(key);
  log(`[прямая] не прошла за ${ms} мс (${r && r.error ? r.error : `HTTP ${r && r.status} code=${r && r.code} «${r && r.msg}»`}) — подпись сброшена, заявка идёт через форму`);
  return null;
}

/** Окно «серии»: заявка на той же вкладке прошла недавно — проверки вкладки пропускаются. */
const HOT_ORDER_MS = Math.max(0, Number(process.env.ARBI_MEXC_HOT_ORDER_MS ?? 5000));

async function executeIntentOnce(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  const pair = toMexcPair(intent.symbol);

  // v1: только limit (как и терминал-реплей). Market — отдельная вёрстка формы.
  if (intent.type !== 'limit' || intent.price == null) {
    return { ok: false, error: 'Стадия 3 v1: поддержан только limit-ордер с ценой' };
  }
  // IM-1: развернуть экспоненту (1.2e-7 → 0.00000012) и отсечь мусорные значения
  // ДО любого ввода в форму. Экспоненциальная строка в поле → биржа парсит неверно.
  const priceStr = formatDecimal(intent.price);
  const qtyStr = formatDecimal(intent.quantity);
  if (!isPlainPositive(priceStr) || !isPlainPositive(qtyStr)) {
    return { ok: false, error: `Некорректные цена/количество: price=${intent.price} qty=${intent.quantity}. Ордер НЕ отправлен.` };
  }
  intent = { ...intent, price: priceStr, quantity: qtyStr };

  const t0 = Date.now();
  let { page, cold } = await getMexcPage(context, pair, log);
  // СЕРИЯ ЗАЯВОК (оператор 2026-11-02, снайпер PROM: «стрелять быстрее раза в 0,6–0,7 с»): заявка на
  // ЭТОЙ вкладке прошла < HOT_ORDER_MS назад — вкладка доказанно живая, впереди, с входом и не
  // 404/Akamai. Проверки отклика/кадров/блока/входа (4–6 обращений к странице, 50–400 мс) пропускаем;
  // зачистка модалок прошлой заявки — остаётся. ARBI_MEXC_HOT_ORDER_MS, 0 — выкл.
  const hot = !cold && HOT_ORDER_MS > 0 && Date.now() - (page.__arbiOrderOkAt || 0) < HOT_ORDER_MS;
  if (!hot) await probeLag(page, log);
  const front = hot ? { renders: true } : await ensureTabInFront(page, log); // скрытая вкладка = клики ждут кадров (см. pair-tabs)
  // Оператор 15.09: две заявки подряд сорвались в вкладке WOJAK, восстановленной при
  // старте в окне профиля (фокус на <body>, клавиши «набраны» за 35 мс = выброшены
  // скрытым виджетом), и прошли в свежей вкладке в своём окне. visibilityState тут
  // врал — проверяем ФАКТ (кадры): нет → вперёд → всё равно нет → эту вкладку под
  // ордера больше не берём и открываем паре свежую в своём окне.
  // Кадры уже проверены в ensureTabInFront — второй rAF подряд стоил 100–250 мс на
  // занятой странице (оператор 22.10: page=240–370 мс на горячей вкладке BKN).
  const tProbe = Date.now();
  if (!(front && front.renders) && !(await pageRenders(page))) {
    log(`Вкладка пары не рисует кадры (${Date.now() - tProbe} мс без rAF) — вывожу вперёд`);
    await page.bringToFront().catch(() => {});
    if (!(await pageRenders(page))) {
      page.__arbiNoInput = true;
      log(`Вкладка пары не рисует кадры даже после вывода вперёд — ввод в неё глотается; открываю паре свежую вкладку`);
      ({ page, cold } = await getMexcPage(context, pair, log));
    }
  }
  const tPage = Date.now();

  // Akamai «Access Denied» (блок профиля/IP) — ставим глобальный бэкофф и выходим,
  // чтобы не долбить биржу (это продлевает бан и мешает восстановлению).
  if (!hot && await isMexcAccessDenied(page)) {
    noteMexcAccessDenied(log);
    return { ok: false, error: `MEXC заблокировал доступ (Access Denied, Akamai) — профиль/IP под баном биржи. Смените IP прокси или подождите; навигация к MEXC приостановлена.` };
  }
  // Пара 404-ит по прямой ссылке (напр. PIN — торгуется только через поиск/делистнута):
  // форма не появится, дальше долбить бессмысленно. Внятная ошибка вместо срыва.
  if (!hot && await isMexcNotFound(page)) {
    return { ok: false, error: `MEXC: страница пары ${pair} недоступна (404 по прямой ссылке — токен делистнут или торгуется только через поиск на бирже). Ордер НЕ отправлен.` };
  }

  // Закрыть блокирующую модалку-ошибку от ПРОШЛОГО ордера (нехватка баланса/риск),
  // иначе ant-modal-v2 перехватит клики и завалит эту заявку.
  await dismissBlockingModal(page);
  // Закрыть промо-оверлеи (Market Movers и т.п.), которые перекрывают форму/кнопку.
  await dismissOverlays(page);

  const TAB_TIMEOUT = Number(process.env.ARBI_MEXC_TAB_TIMEOUT_MS || 400);

  // Быстрая проверка: лимит-форма уже готова? Если ≥2 инпутов есть — вкладку Limit
  // НЕ трогаем (в устойчивом состоянии это убирает главный тормоз — ожидание
  // отсутствующей/ненужной вкладки). Клик по Limit нужен только если формы ещё нет.
  let inputs = await page.$$(SELECTORS.input);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: TAB_TIMEOUT }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.input, { timeout: 8000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.input);
  }
  // M6: закрыть висящую модалку подтверждения ПРОШЛОГО ордера ДО заполнения/клика —
  // иначе confirmOrderModal в цикле клика подтвердила бы её (чужой ордер, ложный orderId).
  await dismissOrderModal(page, log);
  // РАЗЛОГИН — ПЕРВЫМ ДЕЛОМ, ДО переключения стороны (оператор 25.09). На
  // странице без входа кнопок Buy/Sell нет, ensureSide не встаёт на сторону и
  // раньше заявка падала с «не удалось переключить форму на buy (осталась «»)» —
  // терминал получал невнятную ошибку вёрстки вместо «залогинься». Проверка
  // дешёвая (один evaluate) и должна стоять раньше любой работы с формой.
  if (!hot) {
    const lw = await loginWallFresh(page, log);
    if (lw.wall) { log(`Нет входа в аккаунт MEXC в этом профиле (на форме: «${lw.text}») — заявка НЕ отправлена`); return { ok: false, loginRequired: true, error: loginRequiredError('MEXC') }; }
  }
  // Сторона (Buy/Sell): клик дорогой (~120-430мс). Пропускаем, если на ЭТОЙ вкладке
  // мы уже выставили нужную сторону и вкладку не переоткрывали (cold). Скрытый
  // браузер пользователь не трогает → активная сторона извне не меняется, поэтому
  // на тёплой форме при совпадении стороны повторный клик — чистая потеря времени.
  // На cold (новая/сменили пару) кликаем всегда: форма свежая, сторона неизвестна.
  // Сторона (Buy/Sell): НАДЁЖНОЕ переключение с проверкой по кнопке сабмита (ensureSide).
  // На cold или несовпадении — переключаем; если не удалось встать на нужную сторону,
  // НЕ отправляем ордер (иначе sell ушёл бы как buy) и дампим кандидаты-вкладки, чтобы
  // при необходимости пиновать ARBI_MEXC_SEL_BUY/SELL под вёрстку биржи.
  // Условие дешёвое (в памяти): cold или сторона в памяти не та. Лишний DOM-read стороны
  // на КАЖДЫЙ ордер убран — __arbiSide сбрасывается при смене пары/прогреве, а если он
  // всё же разойдётся с формой, ошибочную сторону поймает M5-страж перед самым кликом.
  if (cold || page.__arbiSide !== intent.side) {
    const ok = await ensureSide(page, intent.side, log);
    if (!ok) {
      const btnText = await readVisibleSubmitText(page);
      // Подробный снимок РАСКЛАДКИ: кнопки сабмита (текст/видимость/координаты), видимые
      // числовые поля (индекс/координаты/значение) и вкладки Buy/Sell. По координатам видно,
      // табовая раскладка (одна кнопка, переключатель) или split (Buy-панель + Sell-панель).
      const layout = await page.evaluate(({ sel, tabSel }) => {
        const rc = (el) => { const r = el.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; };
        const vis = (el) => el && el.offsetParent !== null && el.getBoundingClientRect().width > 2;
        const submits = Array.from(document.querySelectorAll(sel)).slice(0, 8).map((b) => ({ t: (b.textContent || '').trim().slice(0, 16), v: vis(b), ...rc(b) }));
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 8).map((i, idx) => ({ i: idx, val: String(i.value || '').slice(0, 8), ...rc(i) }));
        const tabs = Array.from(document.querySelectorAll(tabSel)).slice(0, 6).map((b) => ({ t: (b.textContent || '').trim().slice(0, 10), v: vis(b), ...rc(b) }));
        return { submits, inputs, tabs };
      }, { sel: SELECTORS.submit, tabSel: `${SELECTORS.buyTab}, ${SELECTORS.sellTab}` }).catch(() => ({}));
      const snap = await formPanelSnapshot(page);
      console.log('[mexc-exec] [diag layout] ' + JSON.stringify({ ...layout, panel: snap }).slice(0, 1600));
      // Кнопок сабмита по нашему селектору нет В DOM вовсе (ни видимых, ни скрытых) — это не
      // «не переключилась вкладка», а другая форма: иная вёрстка пары (BKN 12.10 — «Buy BKN»
      // на экране есть) или окно биржи вместо кнопок. Классы — в [diag layout] выше.
      if (Array.isArray(layout.submits) && !layout.submits.length) {
        return { ok: false, error: `MEXC: кнопки заявки на форме ${pair} не опознаны (вёрстка не та, что у других пар, или биржа показывает что-то вместо них); на панели: «${panelSays(snap)}». Ордер НЕ отправлен.` };
      }
      // «Депозит» вместо кнопки заявки — у MEXC так выглядит НУЛЕВОЙ баланс, а не застрявшая сторона
      // (оператор 2026-10-30, DEOD: вкладка «Продать» активна, «Доступно 0 DEOD»; три попытки ушли
      // с «форма не переключилась» вместо правды). Говорим, чего не хватает, с первой попытки.
      if (/депозит|deposit/i.test(btnText)) {
        const asset = intent.side === 'sell' ? String(pair).split('_')[0] : 'USDT';
        return { ok: false, zeroBalance: true, error: `MEXC: страница показывает 0 ${asset} — «Депозит» вместо кнопки заявки (депозит ещё не дошёл до страницы, монета на Фонде или в открытой заявке). Ордер НЕ отправлен.` };
      }
      return { ok: false, error: `MEXC: не удалось переключить форму на «${intent.side}» (осталась «${btnText}») — ордер НЕ отправлен.` };
    }
  }
  const tTabs = Date.now();
  const forceClickOn = (process.env.ARBI_MEXC_INPUT_FORCE_CLICK || '1') !== '0';
  // Разбор фазы fill по шагам (#66: тюнить только по замеру). Счётчики локальны для
  // executeIntent; typeNumber принимает их отдельным необязательным параметром.
  const fm = { read: 0, readN: 0, vis: 0, visN: 0, click: 0, point: 0, clear: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0, btn: 0, inserted: 0, fastFocus: 0 };
  // Разбор фазы submit+resp (#66): зачистки / модалка подтверждения / клик / ожидание / медленная ветка.
  const ms = { clean: 0, confirm: 0, click: 0, wait: 0, slow: 0, retry: 0 };

  if (inputs.length < 2) {
    return { ok: false, error: `Форма ордера MEXC не распознана (найдено инпутов: ${inputs.length}). Проверьте ARBI_MEXC_SEL_INPUT.` };
  }
  log(`Заполняю форму: price=${intent.price} amount=${intent.quantity} (${intent.side})${cold ? ' [холодная]' : ''}`);
  // СТРОГАЯ проверка ФАКТИЧЕСКИХ значений полей (как на XT/BingX). Нельзя опираться
  // только на isSubmitReady: MEXC держит кнопку сабмита активной даже при устаревшем/
  // неполном КОЛИЧЕСТВЕ (быстрый ввод не всегда прижимает это поле) → ордер мог уйти с
  // ЧУЖИМ количеством от прошлой заявки. Поэтому сверяем сами значения полей, добиваем
  // клавиатурой то, что не прижалось, а ПЕРЕД кликом строго проверяем близость к нужным
  // (иначе ордер НЕ отправляется).
  // Покупка больше доступных USDT — на доступное (оператор 22.10, только когда черновик видел нехватку).
  intent = await clampBuyToQuote(page, intent, log);
  const wantPrice = String(intent.price);
  let wantQty = String(intent.quantity);
  const knownDec = MEXC_QTY_DEC.get(pair);
  const shortQty = truncateQty(wantQty, knownDec);
  if (shortQty !== wantQty) {
    wantQty = shortQty;
    log(`Количество усечено до ${knownDec} зн. по прошлому ответу MEXC: ${wantQty}`);
  }
  const wantP = parseFloat(wantPrice);
  const wantQ = parseFloat(wantQty);
  // ТОЛЬКО ВИДИМЫЕ поля: MEXC держит в DOM несколько mx-motion-input-inner (разные
  // панели/стороны); скрытые сбивали индексацию и приводили к клику по НЕВИДИМОМУ полю
  // (30с зависание на WOJAK). Видимые = поля активной формы: [0]=цена,[1]=кол-во,[2]=всего.
  const readVals = async () => {
    const _s = Date.now();
    try { return await page.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).map((e) => e.value)); }
    finally { fm.read += Date.now() - _s; fm.readN++; }
  };
  const visibleInputs = async () => {
    const _s = Date.now();
    const all = await page.$$(SELECTORS.input);
    // isVisible по всем хэндлам ОДНИМ заходом, а не россыпью (#35): последовательный
    // цикл — это N круговых CDP-рейсов подряд (MEXC держит в DOM несколько
    // mx-motion-input-inner), и вызывается он дважды за попытку заполнения. Promise.all
    // кладёт их в один тик: порядок и результат те же, меняется только число ожиданий.
    const flags = await Promise.all(all.map((h) => h.isVisible().catch(() => false)));
    const vis = all.filter((_, i) => flags[i]);
    fm.vis += Date.now() - _s; fm.visN++;
    return vis;
  };
  // Хэндлы видимых полей на ОДНУ попытку заполнения: форма между цена→количество
  // не пересобирается, а каждый лишний visibleInputs — это полный обход
  // mx-motion-input-inner с проверкой видимости по каждому (в замере 2026-09-21
  // «видимость=164x2»). Кэш сбрасывается на следующей попытке: если ввод не
  // прижался, форму мог перерисовать React, и хэндлы надо перечитать. Устаревший
  // хэндл не опасен — click по нему бросает, и typeNumber уходит в свою ветку
  // с повтором, а перед сабмитом всё равно стоит строгая сверка значений.
  let visCache = null;
  // direct=true — «мимо вставки, сразу посимвольно» (см. MEXC_INSERT_OK).
  const typeOpts = () => ({ st: fm, direct: !MEXC_INSERT_OK });
  const setField = async (idx, val) => {
    if (!visCache) visCache = await visibleInputs();
    if (visCache[idx]) await typeNumber(page, visCache[idx], val, typeOpts());
  };
  const settleMs = Number(process.env.ARBI_MEXC_FILL_SETTLE_MS || 40);
  const logFill = () => log(`[timing fill] клик-в-поле=${fm.click}(наведение=${fm.point} очистка=${fm.clear}${fm.fallback ? ` срыв-клика=${fm.fallback}` : ''}${forceClickOn ? ' force' : ''}) фокус=${fm.fastFocus ? 'без мыши' : 'клик'} вставка=${fm.inserted || 0}пол набор=${fm.keys}(${fm.keysN}зн/${fm.typeN}пол) чтение=${fm.read}x${fm.readN} видимость=${fm.vis}x${fm.visN} кнопка=${fm.btn}`);
  // Строгая: поле уже содержит НУЖНОЕ значение в пределах шага последнего разряда
  // (MEXC усекает по шагу токена) — но НЕ принимает близкое-но-ЧУЖОЕ значение прошлого
  // ордера. Именно это отличает её от closeEnough (широкая, ±%, для усадки по балансу).
  // fieldFresh — единая строгая проверка из order-utils (M3: допуск от want, см. там).
  const closeEnough = (v, want) => {
    const f = parseFloat(String(v).replace(/[,\s]/g, ''));
    return isFinite(f) && want > 0 && f <= want * 1.03 && f >= want * 0.85;
  };
  const bothFresh = (v) => priceFresh(v[0], wantP) && fieldFresh(v[1], wantQ);
  if (cold) {
    // ХОЛОДНАЯ форма (только открыли/сменили пару): setReactInput на «сырой» React
    // не регистрируется. Надёжный посимвольный ввод. Ждём готовность кнопки перед вводом.
    await page.waitForSelector(`${SELECTORS.submit}:visible`, { timeout: 10000 }).catch(() => {}); // видимую, не первую по DOM (см. warmupForm)
    // P1-2: залипший промо/риск-оверлей перехватывает клики по полям холодной формы.
    await dismissOverlays(page);
    // Заполняем ВИДИМЫЕ поля активной формы (не скрытые из других панелей).
    const vi = await visibleInputs();
    await typeNumber(page, vi[0] || inputs[0], intent.price, typeOpts());
    await typeNumber(page, vi[1] || inputs[1], intent.quantity, typeOpts());
    // Дождаться, пока форма РЕАЛЬНО готова (кнопка активна): на только что загруженной
    // странице React ещё «сырой», клик слишком рано не порождает order/place. Шаг 100мс
    // (было 200) — выходим по готовности раньше, потолок ~2.5с вместо 5с.
    // P2: пороги вынесены в env (без пересборки, если готовность формы окажется дольше).
    const coldReadyTries = Number(process.env.ARBI_MEXC_COLD_READY_TRIES || 25);
    const coldReadyStepMs = Number(process.env.ARBI_MEXC_COLD_READY_STEP_MS || 100);
    for (let i = 0; i < coldReadyTries; i++) {
      if (await isSubmitReady(page)) break;
      await new Promise((r) => setTimeout(r, coldReadyStepMs));
    }
  }
  let finalVals = [];
  // Быстрый ввод (fastSetInputs) для MEXC по умолчанию ОТКЛЮЧЁН. Причина: MEXC
  // завязан на ПОВЕДЕНЧЕСКИЙ анти-бот (SDK trochilus/watchman) — кнопка сабмита
  // «вооружается» только ДОВЕРЕННЫМ вводом (реальные события клавиатуры/мыши через
  // CDP, isTrusted=true). fastSetInputs — нативный сеттер + dispatchEvent (isTrusted=
  // false) → поля визуально заполнены и строгая fieldFresh проходит, но клик по кнопке
  // НЕ порождает order/place (ловили: «Поля заполнены … order/place не ушёл»).
  // Поэтому MEXC заполняем ТОЛЬКО доверенным typeNumber (цикл ниже). Включить залп
  // осознанно: ARBI_MEXC_FAST_FILL=1.
  if ((process.env.ARBI_MEXC_FAST_FILL || '0') === '1' && !cold) {
    await fastSetInputs(page, intent.price, intent.quantity).catch(() => {});
    await page.waitForTimeout(settleMs);
  }
  finalVals = await readVals().catch(() => []);
  // Добиваем клавиатурой ЛЮБОЕ поле, которое ещё не содержит НУЖНОГО значения (строгая
  // проверка — чтобы не оставить количество прошлого ордера). На cold после typeNumber
  // значения уже должны быть свежими → цикл не сработает.
  for (let attempt = 0; attempt < 3 && !bothFresh(finalVals); attempt++) {
    if (!priceFresh(finalVals[0], wantP)) {
      await setField(0, wantPrice);
      // diag: значение поля цены СРАЗУ после ввода (до settle). Если тут наш ${wantPrice},
      // а в «Поля заполнены» другое — биржа СНАПит цену (price cage/тик). Если тут сразу
      // чужое — проблема ввода. По этому чиним прицельно (цена ушла не туда — деньги).
      // По умолчанию ВЫКЛЮЧЕН: вопрос закрыт замерами 19-21.09 (поле всегда принимало
      // нашу цену «сразу»), а лишнее чтение стоит места в каждой заявке. Включается
      // ARBI_MEXC_DIAG_PRICE=1, когда цена снова окажется под подозрением.
      if (attempt === 0 && process.env.ARBI_MEXC_DIAG_PRICE === '1') {
        const jt = (await readVals().catch(() => []))[0];
        console.log(`[mexc-exec] [diag цена] ввёл «${wantPrice}» → поле сразу «${jt}» (хотели ${wantP})`);
      }
    }
    if (!fieldFresh(finalVals[1], wantQ)) await setField(1, wantQty);
    await page.waitForTimeout(settleMs);
    finalVals = await readVals().catch(() => []);
    // Поля не приняли ввод с первого захода — самое частое объяснение в проде —
    // промо/риск-оверлей поверх формы: клик уходит в него, поле не получает фокус,
    // набор летит в никуда, и в поле остаётся ПОДСТАВЛЕННАЯ БИРЖЕЙ рыночная цена.
    // Перед повтором убираем перехватчиков теми же зачистками, что и на холодной
    // форме. На успешном пути (bothFresh с первого раза) сюда не заходим.
    if (!bothFresh(finalVals)) { await dismissOverlays(page); await dismissBlockingModal(page); visCache = null; }
  }
  // Урок точности: чему биржа нас научила этим заполнением. Учимся ТОЛЬКО когда
  // совпала ЦЕЛАЯ часть — тогда MEXC отрезал именно точность. Разошлась целая
  // часть = усадка по доступному балансу, и урок «столько-то знаков» был бы
  // выдумкой (#54: догадка не имеет права стать фактом). Хвостовая точка
  // («14003111802.») — то же усечение до нуля знаков, поэтому её снимаем.
  {
    const lesson = learnQtyDecimals(finalVals[1], wantQty);
    if (lesson != null) MEXC_QTY_DEC.set(pair, lesson);
  }
  // Предохранитель ПЕРЕД кликом. CR-3: ЦЕНА — строгая (fieldFresh, ±1 шаг разряда),
  // НЕ closeEnough: широкий ±15% на цене пропускал бы sell на 15% ниже рынка
  // (значение прошлого ордера, если добивание сорвалось). Широкий допуск оставлен
  // ТОЛЬКО количеству (усадка по доступному балансу — легитимна).
  if (!priceFresh(finalVals[0], wantP) || !closeEnough(finalVals[1], wantQ)) {
    console.log('[mexc-exec] [diag заполнение] ' + JSON.stringify({ finalVals, wantPrice, wantQty }));
    logFill();
    // Количество усеклось до 0 при корректной цене — почти всегда означает, что
    // ДОСТУПНЫЙ баланс = 0: монета уже продана или ЗАБЛОКИРОВАНА в открытой заявке
    // (ловили на ALVA: заявка выставилась, а повторные sell-интенты MEXC усекал в 0).
    // Понятная причина вместо загадочного «поля не совпали».
    // ТОЛЬКО на продаже и только когда цена принята СТРОГО (fieldFresh): на покупке
    // количество не ограничено монетой, а «цена близко, количество пусто» на любой
    // стороне — это перехваченный ввод (лог 15.09 22:01: системное окно логина прокси,
    // поля ["0.00000004899","",""] → ложное «баланс для продажи = 0» на BUY).
    const qtyZero = parseFloat(String(finalVals[1] || '0').replace(/[,\s]/g, '')) === 0;
    if (intent.side === 'sell' && qtyZero && priceFresh(finalVals[0], wantP)) {
      return { ok: false, zeroBalance: true, error: `MEXC: доступный баланс для продажи = 0 (монета уже продана или заблокирована в открытой заявке — проверьте открытые ордера). Заявка НЕ отправлена.` };
    }
    // ЦЕНА не приняла наш ввод — разделяем два РАЗНЫХ отказа, которые до сих пор
    // выглядели одинаково. Если после клика фокус не на поле ввода, значит клик и
    // клавиши вообще не доходят до страницы: поверх окна профиля висит СИСТЕМНОЕ
    // окно Chromium (запрос логина/пароля прокси, скачивание, разрешение) — оно
    // живёт в браузере, а не в DOM, поэтому ни dismissOverlays, ни Playwright его
    // не видят и закрыть не могут. Пять сорванных заявок 2026-09-07 21:51–21:52
    // были именно этим (в поле оставалась подставленная биржей рыночная цена).
    if (!priceFresh(finalVals[0], wantP)) {
      // Факты вместо догадки (#54/#58, оператор 15.09: «мекс не ставит ордера» при
      // фокусе на <body>): текст видимой кнопки формы (у разлогиненного MEXC там
      // «Log In»), disabled/readOnly поля цены, видимые модалки и идут ли кадры
      // (rAF за 200 мс — окно свёрнуто/скрыто не рисует, ввод глотается).
      const d = await page.evaluate((sel) => new Promise((resolve) => {
        const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
        const inp = Array.from(document.querySelectorAll(sel.input)).filter(vis)[0];
        const btn = Array.from(document.querySelectorAll(sel.submit)).filter(vis)[0];
        const out = {
          focus: (document.activeElement && document.activeElement.tagName) || '',
          btn: btn ? (btn.textContent || '').trim().slice(0, 30) : '(нет)',
          disabled: !!(inp && (inp.disabled || inp.readOnly)),
          modals: Array.from(document.querySelectorAll('[role="dialog"],[class*="ant-modal"],[class*="odal-v2"]')).filter(vis).length,
          frames: false,
        };
        requestAnimationFrame(() => { out.frames = true; resolve(out); });
        setTimeout(() => resolve(out), 200);
      }), { input: SELECTORS.input, submit: SELECTORS.submit }).catch(() => null);
      if (d && /log ?in|sign ?in|войти|вход|登录/i.test(d.btn)) {
        return { ok: false, error: `MEXC: в этом профиле вы НЕ вошли в аккаунт биржи — на форме кнопка «${d.btn}» вместо Buy/Sell. Откройте окно профиля, войдите на MEXC и повторите. Заявка НЕ отправлена.` };
      }
      if (!d || d.focus !== 'INPUT') {
        const facts = d ? ` [факты: кнопка=«${d.btn}» поле_заблокировано=${d.disabled} модалок=${d.modals} кадры=${d.frames ? 'идут' : 'НЕТ'}]` : '';
        return { ok: false, error: `MEXC: клик и ввод не доходят до страницы (после клика фокус на <${((d && d.focus) || '?').toLowerCase()}>, в поле цены осталось «${finalVals[0]}»).${facts} Если кадры НЕТ — окно профиля свёрнуто/скрыто, разверните его; если модалка — закройте её; иначе поверх окна системное окно Chromium (логин прокси) — закройте его («Отмена»). Заявка НЕ отправлена.` };
      }
    }
    return { ok: false, error: `Поля не совпали с ордером: хотели цена=${wantPrice} кол-во=${wantQty}, в форме ${JSON.stringify(finalVals)}. Ордер НЕ отправлен.` };
  }
  // M5: ВЕРИФИКАЦИЯ СТОРОНЫ из DOM перед кликом. Клик по вкладке Buy/Sell (выше) мог
  // молча не сработать (таймаут → catch), и ордер ушёл бы с ЧУЖОЙ стороной (sell как
  // buy). Кнопка сабмита MEXC несёт сторону в тексте («Buy WOJAK»/«Comprar WOJAK»…).
  // Блокируем ТОЛЬКО явно ПРОТИВОПОЛОЖНУЮ сторону (ровно тот дефект, что ловим).
  // Нераспознанный текст (язык вне словаря) — предупреждение, НЕ блок: иначе любой
  // новый язык интерфейса останавливал бы все MEXC-ордера (регрессия класса M7).
  const _sBtn = Date.now();
  const btnText = await readVisibleSubmitText(page);
  fm.btn = Date.now() - _sBtn;
  const domSide = sideFromText(btnText);
  if (domSide && domSide !== intent.side) {
    return { ok: false, error: `MEXC: сторона на форме (${domSide}) ≠ запрошенной (${intent.side}) — ордер НЕ отправлен. Кнопка: «${btnText}».` };
  }
  if (!domSide) log(`M5: сторона по кнопке «${btnText}» не распознана (язык вне словаря?) — продолжаю без DOM-сверки стороны`);
  log(`Поля заполнены: ${JSON.stringify(finalVals)} (хотели ${wantPrice}/${wantQty})${domSide ? `, сторона ${domSide} подтверждена` : ''}`);
  const tFill = Date.now();
  logFill();

  // CR-1 (learn-on-confirm): строгая сверка токена на странице с базой интента.
  // Токены с displayName≠coinName (GENSYN на бирже = «AI») легитимны — оператор
  // подтверждает их разово в терминале, тогда сюда приходит hints.coinAlias и блока
  // нет. Без алиаса (клон ART/ARTX ИЛИ ещё не подтверждённый) — блок со структурным
  // pairMismatch: терминал покажет «это верный токен?», сохранит алиас и повторит.
  // Проверка ДО подписки листенеров ниже → cleanup не нужен.
  const base = String(pair).split('_')[0];
  const pageBase = await page.evaluate(() => {
    for (const h of document.querySelectorAll('h1')) {
      const m = (h.textContent || '').trim().match(/([A-Za-z0-9一-鿿]+)\s*[/\-]\s*[A-Za-z]{2,}/);
      if (m) return m[1];
    }
    return null;
  }).catch(() => null);
  const gate = pairGate(pageBase, base, intent.hints && intent.hints.coinAlias, displayBaseFor('mexc', pair));
  if (gate.block) {
    // Кэш пары вкладки НЕДЕЙСТВИТЕЛЕН: страница показала не тот/нечитаемый токен — иначе
    // cachedPairWarm вечно отдавал бы её «тёплой», и следующий интент того же токена
    // повторял бы блок без ре-навигации (застревание на mismatch/unreadable).
    page.__arbiPair = null;
  }
  if (gate.block && gate.reason === 'unreadable') {
    return { ok: false, error: `Не удалось прочитать пару на странице MEXC (ожидался ${base}) — ордер НЕ отправлен. Обновите страницу пары и повторите.` };
  }
  if (gate.block) {
    return { ok: false, pairMismatch: true, pageBase, wanted: base,
      error: `Биржа показывает пару ${pageBase}/…, а ордер для ${base}. Подтвердите, что это верный токен.` };
  }
  if (gate.reason === 'learned') log(`MEXC: ордер по ${base} — страница подписана «${pageBase}», это имя нашей пары у биржи (выучено на прогреве)`);
  if (gate.reason === 'alias') log(`M8: MEXC — ордер по ${base} пропущен по подтверждённому алиасу «${pageBase}» (доверенный реестр терминала для этой пары)`);

  // Защита от ЗАДВОЕНИЯ (зеркало XT/BingX): следим, УШЁЛ ли реальный POST order/place,
  // и постоянно захватываем его ОТВЕТ. Раньше MEXC повторял клик вслепую — при
  // медленном ответе прокси повтор мог задвоить ордер; а повторный waitForResponse
  // пропускает ответ, пришедший до новой подписки (ложная «не ушёл»).
  let orderReqFired = false;
  // CR-2: множество POST-запросов ордера, реально ушедших В ЭТОЙ попытке. Ответ
  // захватываем ТОЛЬКО на запрос из этого множества — иначе на тёплой вкладке
  // capturedOrderResp мог поймать ПОЗДНИЙ ответ ПРОШЛОГО ордера (чужой orderId,
  // ложный успех). Листенеры подписаны после t0, так что запрос прошлого ордера,
  // ушедший до подписки, сюда не попадёт.
  const firedReqs = new Set();
  const onReq = (req) => { try { if (req.method() === 'POST' && ORDER_PLACE_RE.test(req.url())) { orderReqFired = true; firedReqs.add(req); } } catch { /* игнор */ } };
  page.on('request', onReq);
  let capturedOrderResp = null;
  const onRespCap = (r) => { try { if (!capturedOrderResp && firedReqs.has(r.request())) capturedOrderResp = r; } catch { /* игнор */ } };
  page.on('response', onRespCap);
  const offListeners = () => { page.off('request', onReq); page.off('response', onRespCap); };
  // Страховка от накопления слушателей на ДОЛГОЖИВУЩЕЙ тёплой вкладке
  // (оператор 2026-09-21: «после перезагрузки работает лучше»). Снятие ниже
  // расставлено по каждому раннему return руками, и любой пропущенный путь —
  // или исключение по дороге — оставлял пару слушателей на вкладке навсегда:
  // за сотни заявок вкладка начинает прогонять каждый ответ сети через сотни
  // обработчиков. Снимаем ОСТАВШИЕСЯ ОТ ПРОШЛОЙ заявки на этой же вкладке —
  // утечка ограничена одной парой, сколько бы путей ни пропустили.
  try { if (typeof page.__arbiOffOrderListeners === 'function') page.__arbiOffOrderListeners(); } catch { /* вкладка закрыта */ }
  page.__arbiOffOrderListeners = offListeners;

  // Один клик + ожидание ответа. Если ответа нет за attemptMs — возвращаем null
  // (order/place НЕ ушёл — значит клик не отправил ордер, повтор безопасен).
  const clickAndWait = async (attemptMs) => {
    // v0.4.119 (скорость, замер оператора 2026-09-07:
    // submit+resp=9506мс из 18332): ожидание ответа ВООРУЖАЛОСЬ ЗДЕСЬ — до
    // dismissOverlays / dismissBlockingModal / confirmOrderModal. Все они
    // ходят в страницу через прокси, поэтому к моменту РЕАЛЬНОГО клика от
    // бюджета attemptMs оставались крохи: `waitForResponse` истекал не
    // потому, что биржа молчит, а потому, что бюджет съели зачистки. Дальше
    // внешний код видел «ответа нет», решал, что клик не отправил ордер, и
    // гонял весь блок повторно — те самые ~7 секунд второго прохода.
    //
    // Теперь ожидание вооружается ПРЯМО перед кликом (ниже), и attemptMs —
    // честный бюджет ответа биржи. Ничего не теряется: запрос и ответ ордера
    // ловят page-листенеры onReq/onRespCap (выставлены до этой функции) в
    // orderReqFired/capturedOrderResp, и ветка «POST уже ушёл» читает именно
    // их. Константы не трогаю — правится причина, а не таймаут (#66).
    let respOrNull = null;
    let _t = Date.now();
    // ПРЯМО перед кликом закрываем промо-оверлеи («Market Movers» и т.п.) и окно
    // риска/ошибки: они всплывают УЖЕ ПОСЛЕ заполнения формы и перехватывали trusted-
    // клик — order/place не уходил (ловили на ALVA: 3 срыва подряд с «Market Movers»
    // в диагностике). Один вызов в начале ордера не спасает — попап поздний.
    // ⚠️ ПОРЯДОК (0.4.251, пользователь 2026-10-11, BKN: «окна моргают и закрываются,
    // ордер не выставляется»): окно риска MEXC по новой/ST-монете («Risk warning …
    // [галка] … Confirm») по тексту «risk/warning» попадало под dismissBlockingModal и
    // закрывалось крестиком РАНЬШЕ, чем confirmOrderModal успевала его подтвердить;
    // следующий клик открывал его снова — и так каждую попытку, заявка не уходила
    // никогда. Поэтому СНАЧАЛА подтверждаем модалку ордера/риска (галка + Confirm —
    // именно это и отправляет order/place), и только потом закрываем промо и ошибки.
    // Если от прошлой попытки осталась модалка подтверждения — то же самое: иначе
    // ant-modal-v2 перехватит клик по сабмиту (page.click висит 5с → падает).
    // ГОНКА CDP: клик по Confirm сам отправляет order/place, но событие 'request'
    // долетает в Node асинхронно — orderReqFired в момент проверки ниже мог ещё не
    // выставиться → повторный клик сабмита ЗАДВОИЛ бы ордер (модалка после галки
    // «No more reminders» больше не появляется — второй POST ушёл бы напрямую).
    // Поэтому после РЕАЛЬНОГО клика по Confirm даём событию долететь.
    if (await confirmOrderModal(page, log)) {
      for (let i = 0; i < 6 && !orderReqFired; i++) await page.waitForTimeout(100);
    }
    ms.confirm += Date.now() - _t; _t = Date.now();
    if (!orderReqFired) {
      await dismissOverlays(page);
      await dismissBlockingModal(page);
    }
    ms.clean += Date.now() - _t; _t = Date.now();
    // CR-2: если POST ордера УЖЕ ушёл (мог уйти, пока закрывали модалки/подтверждали) —
    // повторный клик ЗАДВОИТ ордер. Не кликаем: ждём захваченный ответ и возвращаем его.
    if (orderReqFired) {
      let cap = capturedOrderResp;
      for (let i = 0; !cap && i < Math.ceil(attemptMs / 100); i++) { await page.waitForTimeout(100); cap = capturedOrderResp; }
      return cap;
    }
    // Доверенный клик по ВИДИМОЙ кнопке сабмита (активной стороны — неактивная скрыта в
    // DOM). Короткий таймаут + catch: модалка не должна подвесить весь ордер на 5с.
    // Ожидание ответа вооружаем ПЕРЕД самым кликом (см. комментарий выше):
    // раньше бюджет утекал в зачистку оверлеев до клика.
    respOrNull = page
      .waitForResponse((r) => firedReqs.has(r.request()), { timeout: attemptMs })
      .then((r) => r, () => null);
    // force (по умолчанию, ARBI_MEXC_INPUT_FORCE_CLICK=0 выключает): на этой странице
    // проверка актуальности Playwright стабильно не сходится (поля — срыв на каждом
    // ордере до 0.4.129), кнопка сабмита — тот же DOM и тот же анти-бот. Локатор уже
    // берёт только :visible; промах ловится ответом биржи/медленной веткой ниже.
    // force-клик уходит самому верхнему элементу в точке кнопки — накладку убираем (BKN 29.10).
    await uncoverSubmit(page, SELECTORS.submit, log);
    await visibleSubmit(page).click({ timeout: 3000, noWaitAfter: true, force: forceClickOn }).catch(() => {});
    ms.click += Date.now() - _t; _t = Date.now();
    // Ответ за ~1.2с? Иначе — подтверждаем модалку ордера (широкий селектор) и ждём.
    let r = await Promise.race([
      respOrNull,
      new Promise((res) => setTimeout(() => res('__slow__'), 1200)),
    ]);
    ms.wait += Date.now() - _t; _t = Date.now();
    if (r === '__slow__') {
      ms.retry++;
      // Клик открыл модалку подтверждения/риска — СНАЧАЛА подтверждаем её (см. порядок
      // выше: закрыть крестиком = отменить заявку), и лишь потом гасим поздний промо/
      // риск-попап, который мог перехватить клик.
      // Та же гонка CDP, что выше: после клика по Confirm ждём долёта 'request',
      // прежде чем решать про повторный клик сабмита (иначе дубль).
      if (await confirmOrderModal(page, log)) {
        for (let i = 0; i < 6 && !orderReqFired; i++) await page.waitForTimeout(100);
      }
      if (!orderReqFired) {
        await dismissOverlays(page);
        await dismissBlockingModal(page);
      }
      // P1-1: ордер ВСЁ ЕЩЁ не ушёл (оверлей перехватил первый клик по сабмиту) —
      // повторный клик по видимой кнопке нужной стороны. Guard orderReqFired: если POST
      // уже ушёл (мог уйти пока закрывали модалки), повтор ЗАДВОИТ ордер — не кликаем.
      if (!orderReqFired) {
        await uncoverSubmit(page, SELECTORS.submit, log);
        await visibleSubmit(page).click({ timeout: 1500, noWaitAfter: true, force: forceClickOn }).catch(() => {});
      }
      r = await respOrNull;
      ms.slow += Date.now() - _t;
    }
    return r;
  };

  // Доверенный клик по кнопке сабмита + ОДИН повтор, если ордер не ушёл
  // (клик иногда «не регистрируется» / промах → order/place не летит).
  log('Нажимаю кнопку ордера (trusted-клик)...');
  let resp = await clickAndWait(Number(process.env.ARBI_MEXC_RESP_TIMEOUT_MS || 2500));
  if (!resp) {
    if (orderReqFired) {
      // POST УЖЕ ушёл — повтор клика ЗАДВОИТ ордер. Ждём ответ через захват листенера.
      log('Запрос ордера УЖЕ ушёл — ответ медленный, жду без повтора (не дублируем)');
      resp = capturedOrderResp;
      for (let i = 0; !resp && i < 80; i++) { // до 8с, шаг 100мс
        await page.waitForTimeout(100);
        resp = capturedOrderResp;
      }
    } else {
      // Клик молча проглочен: ни POST, ни модалки. Прежде чем кликать снова — факты (#58).
      const base = pair.split('_')[0];
      let f = await formFacts(page, base);
      log(`Ответа нет — форма: доступно=${f.availNum ?? '?'} ${base}, подписи=${JSON.stringify(f.errors)}, кнопка=${f.btn ? `«${f.btn.text}»${f.btn.disabled ? ' disabled' : ''}` : '?'}`);
      // Продажа больше доступного на СТРАНИЦЕ (после зачисления баланс формы отстаёт от
      // биржи): MEXC ничего не отправляет и ничего не показывает. Освежаем переключением
      // стороны (как на BingX) и ждём, пока страница покажет нужное количество.
      if (intent.side === 'sell' && f.availNum != null && f.availNum < wantQ * 0.999) {
        const until = Date.now() + Number(process.env.ARBI_MEXC_BAL_WAIT_MS || 4000);
        await ensureSide(page, 'buy', log); await ensureSide(page, 'sell', log);
        f = await formFacts(page, base);
        while (f.availNum != null && f.availNum < wantQ * 0.999 && Date.now() < until) { await page.waitForTimeout(300); f = await formFacts(page, base); }
        if (f.availNum == null || f.availNum < wantQ * 0.999) {
          offListeners();
          return { ok: false, error: `MEXC: на странице доступно ${f.availNum ?? '?'} ${base}, заявка на ${wantQty} — баланс формы ещё не обновился после зачисления. Заявка НЕ отправлена, повторите через несколько секунд.` };
        }
        log(`Баланс на странице обновился: доступно ${f.availNum} ${base} — повторяю`);
      }
      // Поля набираем ЗАНОВО доверенной клавиатурой: значения в DOM на месте, но форма
      // могла остаться «невооружённой» (вставка/прошлый ордер) — голый повтор клика это
      // не лечит, а повторные заявки терминала раньше вообще ничего не набирали («набор=0»).
      visCache = null;
      const inputs = await visibleInputs();
      if (inputs[0]) await typeNumber(page, inputs[0], wantPrice, { st: fm, direct: true }).catch(() => {});
      if (inputs[1]) await typeNumber(page, inputs[1], wantQty, { st: fm, direct: true }).catch(() => {});
      await page.waitForTimeout(settleMs);
      const vals = await readVals().catch(() => []);
      if (!priceFresh(vals[0], wantP) || !closeEnough(vals[1], wantQ)) {
        offListeners();
        return { ok: false, error: `Поля не совпали с ордером при повторе: хотели цена=${wantPrice} кол-во=${wantQty}, в форме ${JSON.stringify(vals)}. Ордер НЕ отправлен.` };
      }
      log('Ответа нет — поля набраны заново, повтор клика');
      resp = await clickAndWait(6000);
    }
  }
  if (!resp && capturedOrderResp) resp = capturedOrderResp; // последний шанс — захваченный ответ
  offListeners();
  // POST ордера ушёл, но ответ не получен — заявка, вероятно, стоит на бирже.
  if (!resp && orderReqFired) {
    return {
      ok: false,
      // CR-6: НЕ «точно не выставлено», а НЕОПРЕДЕЛЁННОСТЬ — структурный флаг, чтобы
      // терминал НЕ авторетраил (риск дубля), а показал «проверьте открытые ордера».
      ambiguous: true,
      error: 'Запрос ордера отправлен на MEXC, но ответ не получен (медленный прокси). Заявка, вероятно, ВЫСТАВЛЕНА — проверьте «Открытые ордера» перед повтором. Повторная отправка не выполнялась (защита от дублирования).',
    };
  }

  if (!resp) {
    // Диагностика: кто в точке клика кнопки и что за окна на странице (класс/размер/
    // iframe/canvas — капча текста не имеет; BKN 29.10: «три окна без текста и кнопок»).
    const diag = await clickPointFacts(page, SELECTORS.submit);
    // Снимок страницы — на диске профиля, наружу не уходит: по нему видно, что легло на кнопку.
    const shot = require('path').join(config.dataDir, 'diag', `mexc-no-order-${pair}-${Date.now()}.png`);
    try { require('fs').mkdirSync(require('path').dirname(shot), { recursive: true }); await page.screenshot({ path: shot, timeout: 3000 }); log(`Снимок страницы: ${shot}`); } catch { /* не критично */ }
    console.log('[mexc-exec] [diag таймаут] ' + JSON.stringify(diag));
    const ff = await formFacts(page, pair.split('_')[0]);
    console.log('[mexc-exec] [diag форма] ' + JSON.stringify({ avail: ff.avail, errors: ff.errors, btn: ff.btn }));
    // Закрыть блокирующую модалку-ошибку (иначе заблокирует следующий ордер) и
    // вернуть понятную причину; кнопки модалки в diag выше — если подтверждение не
    // сработало, по ним подберём точный ARBI_MEXC_SEL_CONFIRM.
    const modalText = (diag.dialogs || []).map((d) => d.text).join(' | ');
    const closed = await dismissBlockingModal(page);
    if (/insufficient|not enough|недостаточн/i.test(modalText + ' ' + (closed.text || ''))) {
      return { ok: false, error: `MEXC отклонил: недостаточно баланса для ордера.` };
    }
    if (diag.captcha) {
      return { ok: false, error: 'MEXC показал проверку безопасности (капча) — пройдите её в окне ArbiBrowser и повторите заявку. Заявка НЕ отправлена.' };
    }
    // Заявка не ушла, а поля заполнялись ВСТАВКОЙ — единственное, что отличает этот
    // путь от прежнего посимвольного. Гасим вставку до конца сессии: следующая
    // заявка пойдёт как раньше, и если дело было в ней, проблема не повторится.
    if (MEXC_INSERT_OK && fm.inserted) {
      MEXC_INSERT_OK = false;
      log('Заявка не ушла после вставки значений — дальше ввожу посимвольно (вставка отключена до перезапуска)');
    }
    return {
      ok: false,
      error: `order/place не ушёл. Форма: доступно=${ff.availNum ?? '?'}, подписи=${JSON.stringify(ff.errors).slice(0, 120)}, кнопка=${ff.btn ? `«${ff.btn.text}»${ff.btn.disabled ? ' disabled' : ''}` : '?'}${diag.hit && !diag.hit.reachesSubmit ? `, нажатие перехватил ${diag.hit.el}` : ''}. Модалки/кнопки: ${JSON.stringify(diag.dialogs || []).slice(0, 200)}`,
    };
  }

  const tResp = Date.now();
  log(`[timing submit] зачистки=${ms.clean} подтв-модалка=${ms.confirm} клик=${ms.click} ожидание=${ms.wait}${ms.retry ? ` медленная-ветка=${ms.slow}` : ''}`);
  // Тайминг по фазам — чтобы видеть, где уходит время (цель ≤500мс на тёплой странице).
  log(`[timing] page=${tPage - t0} tabs=${tTabs - tPage} fill=${tFill - tTabs} submit+resp=${tResp - tFill} ИТОГО=${tResp - t0}мс`);

  const status = resp.status();
  let json = null;
  try { json = await resp.json(); } catch { /* не JSON */ }
  // Тело ответа читается ПОСЛЕ «ИТОГО» (оператор 22.10: 250–550 мс между таймингом и
  // «Ордер выставлен») — замер до правки (#66).
  const bodyMs = Date.now() - tResp;
  // Конверт MEXC: { code:200, msg:"success", data:"<orderId>" }.
  const okCode = json && (json.code === 200 || json.code === 0);
  if (status >= 200 && status < 300 && okCode) {
    const orderId = typeof json.data === 'string' ? json.data
      : (json.data && json.data.orderId) ? String(json.data.orderId)
      : (json.orderId ? String(json.orderId) : null);
    if (!orderId) return { ok: false, error: `success, но нет orderId: ${JSON.stringify(json).slice(0, 160)}` };
    log(`Ордер выставлен: ${orderId} (тело ответа ${bodyMs} мс)${hot ? ' [серия]' : ''}`);
    rememberDirect(page, pair, intent.side, resp.request()).catch(() => {});
    page.__arbiHotAt = Date.now(); // форма доказанно живая — ближайшие прогревы пропускаются
    page.__arbiOrderOkAt = Date.now(); // и следующая заявка серии — без проверок вкладки (см. hot)
    return { ok: true, orderId };
  }
  const msg = json ? String(json.msg || json.message || json.code) : `HTTP ${status}`;
  return { ok: false, error: `MEXC отклонил ордер: ${String(msg).slice(0, 200)}` };
}

/**
 * ПРОВЕРКА «серии без ожидания ответа» (оператор 2026-11-02, перед параллельными выстрелами
 * снайпера): N заявок подряд на одной форме, следующая — сразу после клика по предыдущей, БЕЗ
 * ожидания ответа MEXC. Меряем: сколько запросов order/place ушло (= не проглочен ли второй
 * клик), что ответила биржа на каждый (номер или отказ), за сколько. Только ручной запуск
 * (POST /api/test/mexc-burst в панели), ≤3 заявки по ≤$10, только limit.
 */
async function burstTest(context, intent, log) {
  const pair = toMexcPair(intent.symbol);
  const n = Math.min(Number(intent.tabs) === 2 ? 4 : 3, Math.max(2, Number(intent.n) || 2));
  const gapMs = Math.max(0, Math.min(1000, Number(intent.gapMs) || 0));
  const price = formatDecimal(intent.price);
  const qty = formatDecimal(intent.quantity);
  if (intent.side !== 'buy' && intent.side !== 'sell') return { ok: false, error: 'side: buy или sell' };
  if (!isPlainPositive(price) || !isPlainPositive(qty)) return { ok: false, error: 'некорректные цена/количество' };
  if (Number(price) * Number(qty) > 10) return { ok: false, error: 'проверка: не больше $10 на заявку' };
  const { page } = await getMexcPage(context, pair, log);
  // tabs=2 (оператор 03.11): вторая вкладка той же пары — заявки по очереди А, Б, А… Пока А ждёт
  // ответа MEXC (её форма не шлёт вторую заявку), Б уже отправляет свою.
  const pages = [page];
  let extra = null;
  if (Number(intent.tabs) === 2) {
    extra = markOwned(await newBackgroundPage(context));
    await extra.goto(page.url(), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    await extra.waitForSelector(`${SELECTORS.submit}:visible`, { timeout: 15000 }).catch(() => {});
    pages.push(extra);
  }
  for (const pg of pages) {
    await pg.bringToFront().catch(() => {});
    await dismissBlockingModal(pg);
    await dismissOverlays(pg);
    await dismissOrderModal(pg, log);
    if (!(await ensureSide(pg, intent.side, log))) {
      if (extra) await extra.close().catch(() => {});
      return { ok: false, error: `форма не встала на ${intent.side}` };
    }
  }
  const t0 = Date.now();
  const reqs = [];
  const resps = [];
  const isPlace = (r) => { try { return r.method() === 'POST' && ORDER_PLACE_RE.test(r.url()); } catch { return false; } };
  const onReqOf = (tab) => (r) => { if (isPlace(r)) reqs.push(`${tab}+${Date.now() - t0}`); };
  const onRespOf = (tab) => async (r) => {
    if (!isPlace(r.request())) return;
    const at = Date.now() - t0;
    let j = null;
    try { j = await r.json(); } catch { /* не JSON */ }
    const id = j && (typeof j.data === 'string' ? j.data : (j.data && j.data.orderId) || null);
    resps.push({ tab, at, status: r.status(), code: j ? j.code : null, id, msg: j ? String(j.msg || '').slice(0, 80) : '' });
  };
  const subs = pages.map((pg, k) => {
    const tab = 'АБ'[k];
    const a = onReqOf(tab);
    const b = onRespOf(tab);
    pg.on('request', a);
    pg.on('response', b);
    return () => { pg.off('request', a); pg.off('response', b); };
  });
  const clicks = [];
  try {
    for (let i = 0; i < n; i++) {
      if (i && gapMs) await page.waitForTimeout(gapMs);
      const pg = pages[i % pages.length];
      if (pages.length > 1) await pg.bringToFront().catch(() => {});
      const all = await pg.$$(SELECTORS.input);
      const flags = await Promise.all(all.map((h) => h.isVisible().catch(() => false)));
      const vis = all.filter((_, k) => flags[k]);
      if (vis.length < 2) { clicks.push({ i, error: 'на форме нет полей цены/количества' }); break; }
      const tf = Date.now();
      await typeNumber(pg, vis[0], price, { direct: !MEXC_INSERT_OK });
      await typeNumber(pg, vis[1], qty, { direct: !MEXC_INSERT_OK });
      const vals = await pg.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).map((e) => e.value)).catch(() => []);
      const tc = Date.now();
      let clickErr = '';
      await visibleSubmit(pg).click({ timeout: 2000, noWaitAfter: true, force: true }).catch((e) => { clickErr = String(e && e.message || e).slice(0, 80); });
      clicks.push({ i, tab: 'АБ'[i % pages.length], fillMs: tc - tf, clickAt: tc - t0, vals: vals.slice(0, 2), reqsBefore: reqs.length, clickErr });
    }
    // Ждём ответы: столько, сколько ушло запросов (не меньше одного), до 6 с.
    for (let k = 0; k < 60 && resps.length < Math.max(reqs.length, 1); k++) await page.waitForTimeout(100);
    await page.waitForTimeout(300); // поздний запрос второго клика
  } finally {
    for (const off of subs) off();
    if (extra) await extra.close().catch(() => {});
  }
  log(`[burst] ${pair} ${intent.side} ${n}× ${qty} @ ${price}, вкладок ${pages.length}, пауза ${gapMs} мс: кликов ${clicks.length}, запросов ушло ${reqs.length} (${reqs.join(' ')} мс), ответов ${resps.length}`);
  for (const c of clicks) log(`[burst] клик #${c.i + 1} (вкладка ${c.tab}): +${c.clickAt} мс, заполнение ${c.fillMs} мс, в полях ${JSON.stringify(c.vals)}${c.clickErr ? `, ошибка клика: ${c.clickErr}` : ''}${c.error ? `, ${c.error}` : ''}`);
  for (const r of resps) log(`[burst] ответ вкладки ${r.tab} +${r.at} мс: HTTP ${r.status} code=${r.code} ${r.id ? `заявка ${r.id}` : `отказ «${r.msg}»`}`);
  for (const pg of pages) pg.__arbiSide = null; // форму трогали вне обычного пути — следующая заявка сверит сторону
  return { ok: true, clicks, reqs, resps };
}

/**
 * ПРОВЕРКА «прямого запроса из страницы» (оператор 2026-11-03): форма MEXC не шлёт вторую
 * заявку, пока первая в пути, а две вкладки дороже одной. Здесь: (1) одна настоящая заявка
 * кнопкой — запоминаем её запрос order/place (адрес, заголовки, тело); (2) тот же запрос
 * N раз ОДНОВРЕМЕННО из этой же страницы через fetch (её cookies, её браузер — для MEXC/Akamai
 * это запрос страницы). Узнаём: переиспользуется ли подпись (x-mxc-sign/nonce, p0/k0/mhash…)
 * и принимает ли MEXC заявки параллельно. Подпись, cookies и тело в журнал НЕ пишутся.
 * Только ручной запуск (POST /api/test/mexc-burst с mode:'replay'), ≤3 повтора по ≤$10, limit.
 */
async function replayTest(context, intent, log) {
  const pair = toMexcPair(intent.symbol);
  const reps = Math.min(3, Math.max(1, Number(intent.n) || 2));
  const parallel = intent.parallel !== false;
  const price = formatDecimal(intent.price);
  const qty = formatDecimal(intent.quantity);
  if (intent.side !== 'buy' && intent.side !== 'sell') return { ok: false, error: 'side: buy или sell' };
  if (!isPlainPositive(price) || !isPlainPositive(qty)) return { ok: false, error: 'некорректные цена/количество' };
  if (Number(price) * Number(qty) > 10) return { ok: false, error: 'проверка: не больше $10 на заявку' };
  const { page } = await getMexcPage(context, pair, log);
  await page.bringToFront().catch(() => {});
  await dismissBlockingModal(page);
  await dismissOverlays(page);
  await dismissOrderModal(page, log);
  if (!(await ensureSide(page, intent.side, log))) return { ok: false, error: `форма не встала на ${intent.side}` };
  // (1) настоящая заявка кнопкой + снимок её запроса
  let cap = null;
  let firstResp = null;
  const isPlace = (r) => { try { return r.method() === 'POST' && ORDER_PLACE_RE.test(r.url()); } catch { return false; } };
  const onReq = async (r) => {
    if (cap || !isPlace(r)) return;
    let h = {};
    try { h = await r.allHeaders(); } catch { h = r.headers(); }
    cap = { url: r.url(), headers: h, body: r.postData() };
  };
  const onResp = async (r) => {
    if (firstResp || !isPlace(r.request())) return;
    let j = null;
    try { j = await r.json(); } catch { /* не JSON */ }
    firstResp = { status: r.status(), code: j ? j.code : null, id: j && typeof j.data === 'string' ? j.data : null, msg: j ? String(j.msg || '') : '' };
  };
  page.on('request', onReq);
  page.on('response', onResp);
  try {
    const all = await page.$$(SELECTORS.input);
    const flags = await Promise.all(all.map((h) => h.isVisible().catch(() => false)));
    const vis = all.filter((_, k) => flags[k]);
    if (vis.length < 2) return { ok: false, error: 'на форме нет полей цены/количества' };
    await typeNumber(page, vis[0], price, { direct: !MEXC_INSERT_OK });
    await typeNumber(page, vis[1], qty, { direct: !MEXC_INSERT_OK });
    await visibleSubmit(page).click({ timeout: 2000, noWaitAfter: true, force: true }).catch(() => {});
    for (let k = 0; k < 50 && !firstResp; k++) await page.waitForTimeout(100);
  } finally {
    page.off('request', onReq);
    page.off('response', onResp);
  }
  if (!cap || !cap.body) return { ok: false, error: 'запрос заявки не пойман (кнопка не отправила заявку)', firstResp };
  let body = null;
  try { body = JSON.parse(cap.body); } catch { return { ok: false, error: 'тело заявки не JSON — повтор не делаю', firstResp }; }
  // Заголовки, которые браузер ставит сам (fetch их запрещает или перепишет), не передаём.
  const skip = /^(cookie|host|content-length|user-agent|origin|referer|accept-encoding|connection|priority|sec-|:)/i;
  const hdr = {};
  for (const [k, v] of Object.entries(cap.headers || {})) if (!skip.test(k)) hdr[k] = v;
  const bodies = Array.from({ length: reps }, () => JSON.stringify({ ...body, price, quantity: qty }));
  // (2) повторы из страницы: параллельно (по умолчанию) или подряд
  const res = await page.evaluate(async ({ url, hdr, bodies, parallel }) => {
    const t0 = performance.now();
    const one = async (b, i) => {
      const s = performance.now();
      try {
        const r = await fetch(url, { method: 'POST', headers: hdr, body: b, credentials: 'include' });
        const txt = await r.text();
        let j = null;
        try { j = JSON.parse(txt); } catch { /* не JSON */ }
        return { i, startAt: Math.round(s - t0), ms: Math.round(performance.now() - s), status: r.status, code: j ? j.code : null, id: j && typeof j.data === 'string' ? j.data : null, msg: j ? String(j.msg || '').slice(0, 120) : txt.slice(0, 120) };
      } catch (e) { return { i, error: String(e && e.message || e).slice(0, 120) }; }
    };
    if (parallel) return Promise.all(bodies.map(one));
    const out = [];
    for (let i = 0; i < bodies.length; i++) out.push(await one(bodies[i], i));
    return out;
  }, { url: cap.url, hdr, bodies, parallel }).catch((e) => [{ error: String(e && e.message || e).slice(0, 160) }]);
  const keys = Object.keys(hdr).filter((k) => /^x-|mtoken|^mh/i.test(k));
  log(`[replay] ${pair} ${intent.side} ${qty} @ ${price}: заявка кнопкой → ${firstResp ? `HTTP ${firstResp.status} code=${firstResp.code} ${firstResp.id ? 'заявка ' + firstResp.id : '«' + firstResp.msg + '»'}` : 'ответа нет'}; повторов ${reps} ${parallel ? 'одновременно' : 'подряд'}, особые заголовки: ${keys.join(',') || '—'}`);
  for (const r of res) log(`[replay] повтор #${(r.i ?? 0) + 1}: ${r.error ? 'ошибка ' + r.error : `старт +${r.startAt} мс, ответ за ${r.ms} мс, HTTP ${r.status} code=${r.code} ${r.id ? 'заявка ' + r.id : '«' + r.msg + '»'}`}`);
  page.__arbiSide = null;
  return { ok: true, firstResp, replays: res, headerKeys: keys };
}

/**
 * Отмена ВСЕХ открытых ордеров через нативную кнопку биржи «Cancel all» — для
 * web-only токенов, которые нельзя отменить по API. Навигируем на пару и жмём кнопку
 * (текст EN/RU + класс, env-переопределяемо), затем подтверждаем модалку, если есть.
 */
async function cancelAllOrders(context, pair, log) {
  const { page } = await getMexcPage(context, pair, log);
  await dismissOverlays(page);
  await dismissBlockingModal(page);
  const sel = process.env.ARBI_MEXC_SEL_CANCEL_ALL;
  // MEXC: кнопка — <span>Cancel All</span> (НЕ button) → getByText ловит и span, и button.
  const btn = sel ? page.locator(sel).first()
    : page.getByText(/^\s*(cancel all|отменить\s+вс[её]|отмена всех)\s*$/i).first();
  try { await btn.waitFor({ state: 'visible', timeout: 8000 }); }
  catch { return { ok: false, error: 'Кнопка «Отменить все» не найдена (задайте ARBI_MEXC_SEL_CANCEL_ALL).' }; }
  // Клик ОБЯЗАН пройти: проглоченный сбой + ok:true = терминал считает ордера
  // отменёнными, хотя они висят (web-only нельзя отменить по API — это единственный путь).
  try { await btn.click({ timeout: 4000 }); }
  catch (e) { return { ok: false, error: `Клик по «Отменить все» не прошёл: ${String(e.message).slice(0, 80)} — ордера НЕ отменены.` }; }
  // Подтверждение отмены (MEXC «Confirm», XT «OK»): якорный матч — НЕ трогаем «Отмена».
  // Жмём СРАЗУ по появлению кнопки (force → без ожидания анимации/стабильности модалки),
  // чтобы отмена всех ордеров проходила быстрее. Ждём только visible (короткий таймаут).
  // Кнопка подтверждения у MEXC — не обязательно <button> (оператор 2026-11-03: окно «Вы уверены,
  // что хотите отменить все…? Отменить | Подтвердить» висело, а терминал считал заявки снятыми).
  // Ищем ПО ТЕКСТУ любой видимый элемент внутри окна, помечаем ближайший кликабельный и жмём
  // доверенным кликом. «Отменить» в окне = отказ от отмены — его НЕ трогаем (якорный матч).
  const markConfirm = () => page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('[class*="modal" i],[role="dialog"]')).filter(vis);
    for (const m of modals) {
      const hit = Array.from(m.querySelectorAll('button,[role="button"],a,div,span'))
        .filter(vis)
        .find((e) => e.children.length <= 2 && /^\s*(confirm|подтвердить|ok|да|yes|确认|确定)\s*$/i.test(e.innerText || ''));
      if (hit) {
        const t = hit.closest('button,[role="button"]') || hit;
        t.setAttribute('data-arbi-cancelall', '1');
        return true;
      }
    }
    return false;
  }).catch(() => false);
  const askVisible = () => page.evaluate(() => Array.from(document.querySelectorAll('[class*="modal" i],[role="dialog"]'))
    .some((m) => m.offsetParent !== null && /отменить\s+все|cancel\s+all/i.test(m.innerText || ''))).catch(() => false);
  const waitMs = Number(process.env.ARBI_MEXC_CANCEL_CONFIRM_MS || 2500);
  let marked = false;
  for (let t = 0; t < waitMs && !(marked = await markConfirm()); t += 100) await page.waitForTimeout(100);
  if (marked) {
    await page.click('[data-arbi-cancelall="1"]', { timeout: 1200, force: true, noWaitAfter: true }).catch(() => {});
    for (let t = 0; t < 1500 && await askVisible(); t += 100) await page.waitForTimeout(100);
  }
  // Окно «отменить все?» всё ещё на экране — подтверждения не было, заявки ВИСЯТ.
  if (await askVisible()) {
    log(`Отмена всех ордеров (${pair}): окно подтверждения MEXC не нажалось — ордера НЕ отменены`);
    return { ok: false, error: 'MEXC спросил подтверждение «Отменить все», но нажать «Подтвердить» не удалось — ордера НЕ отменены.' };
  }
  log(`Отмена всех ордеров (${pair}): ${marked ? 'подтверждено' : 'окна подтверждения не было'}`);
  return { ok: true, cancelledAll: true };
}

// ── Чтение истории ордеров MEXC со страницы (web-only токены, API не отдаёт) ──
// Зеркало bingx-order-page.readOrders. MEXC-биржа держит «Историю ордеров» в нижней
// панели (вкладка «Order History»/«История ордеров»/«历史委托»); строки — div-таблица.
// Все селекторы/тексты env-переопределяемы.
const ORD_TAB_RE = new RegExp(process.env.ARBI_MEXC_ORDHIST_TAB_RE || '^\\s*(Order History|История ордеров|历史委托|订单历史)\\s*$', 'i');
const ORD_HDR = {
  pair: process.env.ARBI_MEXC_ORDHIST_PAIR_RE || '^(trading pair|pair|торговая пара|пара|交易对)',
  time: process.env.ARBI_MEXC_ORDHIST_TIME_RE || '(time|время|时间)',
  side: process.env.ARBI_MEXC_ORDHIST_SIDE_RE || '(side|сторона|направление|方向)',
  avg: process.env.ARBI_MEXC_ORDHIST_AVG_RE || '(average|avg|средн|均价|成交均价)',
  // Заголовки с якорем «^»: в шапке MEXC есть и «Average Filled Price», и «Executed» —
  // без якоря `filled` ловил колонку средней цены (снимок 15.09).
  executed: process.env.ARBI_MEXC_ORDHIST_EXEC_RE || '^(executed|filled|исполнено|成交)',
  qty: process.env.ARBI_MEXC_ORDHIST_QTY_RE || '^(quantity|amount|количество|кол-во|数量)',
  status: process.env.ARBI_MEXC_ORDHIST_STATUS_RE || '^(all|status|state|статус|状态)$',
};

/**
 * Чистый разбор строк истории: на вход массивы текстов ячеек (первая подходящая —
 * шапка с «Time» и «Side»), на выход строки ордеров. Вынесен из evaluate, чтобы
 * проверяться тестом на снимке страницы (test/page-contract.test.js).
 */
function parseOrderRows(cellsList, hdr = ORD_HDR, limit = 60) {
  const rex = Object.fromEntries(Object.entries(hdr).map(([k, v]) => [k, new RegExp(v, 'i')]));
  let map = null;
  const out = [];
  for (const cells of cellsList) {
    if (cells.length < 4) continue;
    if (!map) {
      const joined = cells.join(' | ');
      if (rex.time.test(joined) && rex.side.test(joined)) {
        map = {};
        cells.forEach((c, i) => {
          for (const k of Object.keys(rex)) { if (map[k] == null && rex[k].test(c)) map[k] = i; }
        });
      }
      continue;
    }
    const pick = (k) => (map[k] != null && map[k] < cells.length ? cells[map[k]] : '');
    const side = pick('side') || cells.find((c) => /^(buy|sell|купить|продать|покупка|продажа)$/i.test(c)) || '';
    if (!side) continue;
    out.push({
      pair: pick('pair'),
      time: pick('time'),
      side,
      avgPrice: pick('avg'),
      executed: pick('executed'),
      quantity: pick('qty'),
      status: pick('status'),
      raw: cells.join(' | ').slice(0, 300),
    });
    if (out.length >= limit) break;
  }
  return out;
}

/**
 * Найти УЖЕ ОТКРЫТУЮ вкладку, стоящую на нужной паре — БЕЗ КАКОЙ-ЛИБО НАВИГАЦИИ.
 * Инцидент 2026-07-20: свежая фоновая вкладка + голый goto = Akamai «Access Denied»
 * (редирект на логин, бан-риск профиля). Тёплая вкладка пары прошла Akamai «как
 * человек» (SPA-поиск/клики), читать с неё безопасно. Нет такой вкладки → null:
 * вызывающий ПРОПУСКАЕТ чтение (никогда не навигирует ради read-only интента).
 * Матч: кэш пары / точный URL / полная пара base/quote в h1 (клоны отсечены границей).
 */
async function findWarmPairPage(context, pair) {
  const [base, quote = 'USDT'] = String(pair).split('_');
  for (const p of context.pages()) {
    let u = '';
    try { if (p.isClosed()) continue; u = p.url(); } catch { continue; }
    if (!u.startsWith(MEXC_ORIGIN)) continue;
    // Своя фоновая страница истории «тёплой вкладкой пары» НЕ считается: иначе
    // она сама себя оправдывала бы и чтение продолжалось после того, как
    // оператор закрыл пару (гейт «пара открыта» перестал бы работать).
    try { if (p.__arbiOrdersBg === true) continue; } catch { /* игнор */ }
    // Спящая вкладка «тёплой» не бывает: её адрес прежний, а внутри заглушка —
    // чтение по ней снимало ноль строк, потратив своё ожидание (25.09).
    if (isAsleep(p)) continue;
    if (cachedPairWarm(p, u, pair)) return p;
    if (urlHasPair(u, pair)) return p;
    if (!/\/exchange\//i.test(u)) continue;
    const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/\\s*' + escRe(quote) + '(?![A-Za-z0-9])', 'i') })
      .first().isVisible().catch(() => false);
    if (h1Match) return p;
  }
  return null;
}

/**
 * Снимает историю ордеров пары со страницы MEXC: кликает вкладку «История ордеров»,
 * маппит колонки по заголовкам и возвращает видимые строки. Read-only (без ордеров).
 * @returns {Promise<{ok:boolean, pair:string, rows:Array, error?:string}>}
 */
async function readOrders(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const page = opts.page || (await getMexcPage(context, pair, log)).page;
    await dismissOverlays(page).catch(() => {});
    await dismissBlockingModal(page).catch(() => {});
    // Вкладка «История ордеров» нижней панели (лист-элемент с точным текстом).
    const clicked = await page.evaluate((reSrc) => {
      const rx = new RegExp(reSrc, 'i');
      const tab = Array.from(document.querySelectorAll('span,div,li,a,button'))
        .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null);
      if (!tab) return false;
      try { tab.click(); return true; } catch (_) { return false; }
    }, ORD_TAB_RE.source).catch(() => false);
    if (!clicked) log('История ордеров MEXC: вкладка не найдена (ARBI_MEXC_ORDHIST_TAB_RE)');
    // Снимок 15.09: строки — div.orders_tableRow, ячейки orders_cell вложены в две
    // группы (fixed/extend), у строки 2 прямых потомка → прежний разбор по children
    // отбрасывал ВСЕ строки («снято строк 0» при 100 строках на странице). Ячейки
    // берём листовыми [class*="cell"], если прямых потомков меньше четырёх.
    const snapshot = () => page.evaluate(() => {
      const vis = (el) => el && el.offsetParent !== null;
      const txt = (c) => (c.innerText || '').replace(/\s+/g, ' ').trim();
      const cellTexts = (row) => {
        let cs = Array.from(row.children);
        if (cs.length < 4) cs = Array.from(row.querySelectorAll('[class*="cell" i]')).filter((c) => !c.querySelector('[class*="cell" i]'));
        return cs.map(txt);
      };
      const rows = new Set([
        ...Array.from(document.querySelectorAll('tr')).filter(vis),
        ...Array.from(document.querySelectorAll('[class*="tableRow" i],[class*="table" i] [class*="row" i]')).filter(vis),
      ]);
      const empty = Array.from(document.querySelectorAll('div,span,p')).some((e) => e.children.length === 0 && vis(e) && /^(no data|нет данных|暂无数据)$/i.test(txt(e)));
      return { cells: Array.from(rows).map(cellTexts).filter((c) => c.length >= 4), empty };
    }).catch(() => ({ cells: [], empty: false }));
    // Ждём ПО ФАКТУ, а не фиксированную секунду: на свежей фоновой странице биржа
    // догружает строки дольше (лог 15.09: первое чтение после открытия — 0 строк,
    // следующее — 60), а на тёплой они есть сразу — тогда и ждать нечего.
    // Выход: строки есть / биржа показала «No data» (не раньше 600 мс — плашка
    // мелькает и во время загрузки) / потолок ARBI_MEXC_ORDHIST_WAIT_MS.
    const t0 = Date.now();
    const deadline = t0 + Number(process.env.ARBI_MEXC_ORDHIST_WAIT_MS || 3000);
    let rows = [];
    for (;;) {
      await page.waitForTimeout(Number(process.env.ARBI_MEXC_ORDHIST_STEP_MS || 200));
      // ЗАЯВКА ПРИШЛА, пока мы ждём строки, — уступаем ей браузер целиком: каждый
      // снимок таблицы — evaluate на тяжёлой странице, и на загруженном браузере он
      // стоит сотни миллисекунд денежному пути (лог 11.10: заявка ждала 6,1 с, пока
      // чтение истории крутило снимки 3,4 с). Чтение повторится следующим кругом.
      if (isContextBusy(context, 'order')) {
        log(`История ордеров MEXC ${pair}: пришла заявка — чтение уступило ей браузер (повтор следующим кругом, ждали ${Date.now() - t0} мс)`);
        return { ok: false, skipped: true, pair, rows: [], error: 'браузер занят выставлением заявки — чтение истории отложено' };
      }
      const snap = await snapshot();
      rows = parseOrderRows(snap.cells);
      if (rows.length || Date.now() >= deadline || (snap.empty && Date.now() - t0 >= 600)) break;
    }

    // Панель показывает ВСЕ пары (снимок 15.09: WOJAK и ANYONE в одном списке), а
    // сервер пишет строки под ЗАПРОШЕННЫЙ символ — фильтруем по колонке пары.
    // Колонки нет и страница не на паре → строк не отдаём (чужой журнал хуже пустого).
    const all = rows;
    let read = all.length > 0;   // таблица разобрана — чтение состоялось
    const want = String(pair).toUpperCase().replace(/[^A-Z0-9]/g, '');
    const hasPairCol = all.some((r) => r.pair);
    if (hasPairCol) rows = all.filter((r) => !r.pair || r.pair.toUpperCase().replace(/[^A-Z0-9]/g, '') === want);
    else if (!urlHasPair(page.url(), pair)) { rows = []; read = false; log(`История ордеров MEXC ${pair}: колонки пары нет, а страница на другой паре — строки не беру`); }
    log(`История ордеров MEXC ${pair}: снято строк ${rows.length}${all.length !== rows.length ? ` (из ${all.length} на странице, остальные — другие пары)` : ''} (ожидание ${Date.now() - t0} мс)`);
    // Таблицы нет вовсе — причиной бывает РАЗЛОГИН (без входа панели ордеров на
    // странице нет), а не только вёрстка биржи. Называем причину (оператор 25.09).
    if (!read) {
      const lw = await loginWall(page);
      if (lw.wall) {
        log(`Нет входа в аккаунт MEXC в этом профиле (на странице: «${lw.text}») — историю ордеров не прочитать`);
        return { ok: false, loginRequired: true, pair, rows: [], error: loginRequiredError('MEXC', 'История ордеров не прочитана.') };
      }
    }
    // Симметрия с BingX: пустой список при разобранной таблице — это ответ, а не отказ.
    // allRows — строки всех пар панели (с прочитанной парой) для остальных web-токенов (оператор 30.09).
    return { ok: read, empty: read && rows.length === 0, pair, rows, allRows: hasPairCol ? all.filter((r) => r.pair) : [] };
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/**
 * Как readOrders, но ТОЛЬКО с уже открытой тёплой вкладки пары — БЕЗ навигации
 * (безопасно для Akamai). Нет тёплой вкладки → мягкий пропуск (ok:false, skipped):
 * терминал покажет историю из своего журнала, а чтение случится, когда пара
 * реально открыта (прогрев/ордер её открывает — тогда вкладка уже тёплая).
 */
async function readOrdersWarm(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const warm = await findWarmPairPage(context, pair);
    if (!warm) {
      log(`История ордеров ${pair}: нет открытой вкладки пары — чтение пропущено (без навигации)`);
      return { ok: false, skipped: true, pair, rows: [], error: 'нет открытой вкладки пары — историю не читаем (защита от Akamai: без навигации)' };
    }
    // Тёплая вкладка пары есть — значит профиль на MEXC живой и пара открыта
    // оператором. Читаем НЕ в ней (иначе раз в минуту в рабочей вкладке
    // переключается нижняя панель и фильтр типа — жалоба оператора 11.09), а в
    // СВОЕЙ фоновой странице, как это давно сделано у BingX (#27 — симметрия).
    // Инвариант «ради чтения к бирже не ходим» сохранён: навигация бывает только
    // при СМЕНЕ пары фоновой страницы, а не на каждом чтении, и только когда
    // пара и так открыта. Рубильник ARBI_MEXC_ORDHIST_BG=0 — читать по-старому.
    let page = warm;
    if ((process.env.ARBI_MEXC_ORDHIST_BG || '1') !== '0') {
      // Фоновая страница недоступна — ПРОПУСК круга, а не чтение в торговой
      // вкладке: чтение идёт в фоновой дорожке замка (параллельно заявке), и
      // переключать нижнюю панель во вкладке, где сейчас ставится ордер, нельзя
      // (ревизия 26.09). Чтение повторится на следующем круге терминала.
      try { page = await getOrdersBgPage(context, pair, log); } catch (e) {
        log(`История ордеров ${pair}: фоновая страница недоступна (${e.message}) — пропуск круга`);
        return { ok: false, skipped: true, pair, rows: [], error: `фоновая страница истории недоступна: ${e.message}` };
      }
    }
    return await readOrders(context, pair, { ...opts, page });
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/**
 * Фоновая страница ИСТОРИИ MEXC (`__arbiOrdersBg`) — одна на профиль, живёт
 * между чтениями; сборщик памяти усыпляет её после простоя (ARBI_BG_IDLE_MIN),
 * следующее чтение поднимает её обычной навигацией. Если страница не доехала до
 * нужной пары — бросаем: читать историю ЧУЖОЙ пары нельзя (строки уйдут в чужой
 * журнал), вызывающий отступит на тёплую вкладку.
 */
async function getOrdersBgPage(context, pair, log) {
  let page = context.pages().find((p) => { try { return p.__arbiOrdersBg === true && !p.isClosed(); } catch { return false; } });
  // ОДНА страница на биржу, без навигации по парам (оператор 15.09): панель истории
  // показывает все пары, readOrders фильтрует по колонке пары. Навигация — только
  // если страницы нет или она не на торговой странице MEXC (свежая / разбужена из сна).
  // Спящая страница держит ПРЕЖНИЙ URL (см. isAsleep) — иначе читалка разбирает
  // заглушку «💤 вкладка спит» и всегда возвращает ноль строк.
  const onTrade = (p) => { const u = String(p.url()); return u.startsWith(MEXC_ORIGIN) && /\/exchange\//i.test(u); };
  const heavy = !page || isAsleep(page) || !onTrade(page);
  if (heavy) {
    // Поднять/разбудить страницу истории = загрузить ВТОРУЮ тяжёлую торговую страницу
    // MEXC в том же браузере и через тот же прокси. Делать это сразу после прогрева
    // или между выстрелами нельзя: лог оператора 11.10 (WOJAK) — прогрев 16.98,
    // чтение подняло страницу 17.9, заявка 19.8 ставилась 6117 мс (page=746, tabs=2499,
    // наведение=1113) против 564–701 мс у следующих. Тяжёлое — только в затишье
    // денежной дорожки (ARBI_MEXC_ORDHIST_BG_QUIET_MS, 20 с); до него — пропуск круга,
    // терминал показывает историю из своего журнала и спросит снова. Проверка ДО
    // открытия вкладки — иначе оставалась бы пустая about:blank.
    const quietMs = Number(process.env.ARBI_MEXC_ORDHIST_BG_QUIET_MS || 20000);
    const idle = laneIdleMs(context, 'order');
    if (idle < quietMs) {
      throw new Error(`торговля шла ${Math.round(idle / 1000)} с назад — тяжёлую страницу истории подниму в затишье (${Math.round(quietMs / 1000)} с без заявок и прогревов)`);
    }
  }
  if (!page) {
    page = markOwned(await newBackgroundPage(context));
    page.__arbiOrdersBg = true;
    log('Открыл фоновую страницу истории MEXC (активная вкладка оператора не трогается)');
  }
  if (heavy) {
    if (isAsleep(page)) log('Фоновая страница истории спала — бужу навигацией');
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (!String(page.url()).startsWith(MEXC_ORIGIN)) throw new Error(`фоновая страница истории не открылась (URL ${String(page.url()).slice(0, 60)})`);
    page.__arbiSleepUrl = null;
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

/**
 * Проверка входа в аккаунт MEXC — без торговых действий, общий код в page-driver.
 * Нужна «обходу логинов» при открытии веб-токена после простоя (оператор 25.09).
 */
function checkLogin(context, log = () => {}) {
  return driverCheckLogin(context, { origin: MEXC_ORIGIN, tradeUrl: `${MEXC_ORIGIN}/exchange/BTC_USDT`, loginWall, exchange: 'MEXC', log });
}

const DUTY_URL = `${MEXC_ORIGIN}/exchange/USDC_USDT`; // дежурная вкладка (duty-tab.js)
const LOGIN_URL = process.env.ARBI_MEXC_LOGIN_URL || MEXC_ORIGIN; // сайт: «Войти» в шапке

/** Черновик заявки (prefill.js): сторона/цена/количество в форму пары заранее, без клика. */
async function prefillForm(context, pair, pf, log) {
  let { page, cold } = await getMexcPage(context, pair, log);
  if (cold) { await warmupForm(context, pair, log); ({ page } = await getMexcPage(context, pair, log)); }
  return runPrefill(context, page, pair, pf, {
    setSide: (pg, side) => ensureSide(pg, side, log),
    readVals: (pg) => pg.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).map((e) => e.value)),
    write: async (pg, price, qty) => {
      const all = await pg.$$(SELECTORS.input);
      const flags = await Promise.all(all.map((h) => h.isVisible().catch(() => false)));
      const vis = all.filter((_, i) => flags[i]);
      // Доверенный ввод: быстрый сеттер на MEXC выключен (анти-бот, isTrusted=false).
      if (price != null && vis[0]) await typeNumber(pg, vis[0], price, { direct: !MEXC_INSERT_OK });
      if (qty === '' && vis[1]) { await vis[1].click({ clickCount: 3, timeout: 1500 }).catch(() => {}); await pg.keyboard.press('Backspace').catch(() => {}); }
      else if (qty != null && vis[1]) await typeNumber(pg, vis[1], qty, { direct: !MEXC_INSERT_OK });
    },
  }, log);
}

module.exports = { tryDirect, burstTest, replayTest, prefillForm, loginWall, DUTY_URL, LOGIN_URL, ORIGIN: MEXC_ORIGIN, executeIntent, getMexcPage, warmupForm, cancelAllOrders, readOrders, readOrdersWarm, parseOrderRows, mexcBlocked, mexcBlockedMsLeft, toMexcPair, SELECTORS, checkLogin };

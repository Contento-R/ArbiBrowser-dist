'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { canOpenPairTab, exchangeTabs, mainTradeTabs, pairTabLimit, markPairTab, pageRenders } = require('./pair-tabs');

// Минимальный дубль страницы Playwright: нужен только url() и флаги.
const page = (url, extra = {}) => ({ url: () => url, isClosed: () => false, ...extra });
const ctx = (pages) => ({ pages: () => pages });

const BINGX = 'https://bingx.com';
const MEXC = 'https://www.mexc.com';

test('пул считает только вкладки СВОЕЙ биржи', () => {
  const c = ctx([page(`${BINGX}/en-us/spot/WOJAKUSDT`), page(`${MEXC}/exchange/TIG_USDT`), page('about:blank')]);
  assert.equal(exchangeTabs(c, BINGX).length, 1);
  assert.equal(exchangeTabs(c, MEXC).length, 1);
});

test('служебные фоновые страницы в пул не входят', () => {
  const c = ctx([
    page(`${BINGX}/en-us/spot/AUSDT`),
    page(`${BINGX}/en-us/spot/BUSDT`, { __arbiBalanceBg: true }),
    page(`${BINGX}/en-us/spot/CUSDT`, { __arbiOrdersBg: true }),
  ]);
  assert.equal(exchangeTabs(c, BINGX).length, 1, 'считается только торговая вкладка');
});

test('спящая вкладка биржи занимает место в пуле (её будят, а не плодят дубли)', () => {
  const c = ctx([page('about:blank', { __arbiSleepUrl: `${BINGX}/en-us/spot/AUSDT` })]);
  assert.equal(exchangeTabs(c, BINGX).length, 1);
});

test('место есть до лимита, дальше — прежний путь со сменой пары', () => {
  const limit = pairTabLimit();
  assert.equal(limit, 6, 'по умолчанию шесть пар на биржу (все вкладки терминала должны греться)');
  const pages = [];
  for (let i = 0; i < limit - 1; i++) pages.push(page(`${BINGX}/en-us/spot/T${i}USDT`));
  assert.equal(canOpenPairTab(ctx(pages), BINGX), true, 'ниже лимита — открываем свою вкладку');
  pages.push(page(`${BINGX}/en-us/spot/TXUSDT`));
  assert.equal(canOpenPairTab(ctx(pages), BINGX), false, 'на лимите — меняем пару в существующей');
  // Лимит на КАЖДУЮ биржу свой: забитый BingX не мешает MEXC.
  assert.equal(canOpenPairTab(ctx(pages), MEXC), true);
});

test('вкладки-части пары места в пуле НЕ занимают (лог 22.09: STONK×3 + FONE×3 = потолок 6, TGC без частей)', () => {
  const limit = pairTabLimit();
  const pages = [page(`${BINGX}/en-us/spot/STONKUSDT`), page(`${BINGX}/en-us/spot/FONEUSDT`)];
  // По две вкладки-части на каждую пару — ровно то, что забивало пул раньше.
  for (const pair of ['STONK', 'FONE']) {
    for (let i = 0; i < 2; i++) pages.push(page(`${BINGX}/en-us/spot/${pair}USDT`, { __arbiSplitTab: true }));
  }
  const c = ctx(pages);
  assert.equal(pages.length, 6, 'всего шесть вкладок — прежний потолок пула');
  assert.equal(mainTradeTabs(c, BINGX).length, 2, 'пар всего две');
  assert.equal(canOpenPairTab(c, BINGX), true, 'третья пара должна получить свою тёплую вкладку');
  assert.equal(limit, 6);
});

test('нерыночные страницы (кошелёк, вывод) место в пуле НЕ занимают (кейс 02.09: MEY уводило под BASECAT)', () => {
  const limit = pairTabLimit();
  const pages = [page(`${BINGX}/en-us/assets/withdraw`), page(`${BINGX}/en-us/assets/wallet`)];
  for (let i = 0; i < limit - 1; i++) pages.push(page(`${BINGX}/en-us/spot/T${i}USDT`));
  assert.equal(canOpenPairTab(ctx(pages), BINGX), true, 'кошелёк и вывод не в счёт — место под пару есть');
});

test('markPairTab помечает вкладку — сборщик памяти такие не усыпляет', () => {
  const p = page(`${BINGX}/en-us/spot/AUSDT`);
  assert.equal(markPairTab(p).__arbiPairTab, true);
  assert.doesNotThrow(() => markPairTab(null), 'null не роняет');
});

// ── Закрытие вкладок пар, закрытых в терминале ──────────────────────────────
const { urlIsPair, isTradePairUrl, closeStalePairTabs, isFreshPairTab } = require('./pair-tabs');

test('urlIsPair: клон тикера не считается той же парой', () => {
  assert.equal(urlIsPair(`${BINGX}/en-us/spot/WOJAK-USDT`, 'WOJAK_USDT'), true);
  assert.equal(urlIsPair(`${MEXC}/exchange/TIG_USDT`, 'TIG/USDT'), true);
  assert.equal(urlIsPair('https://www.xt.com/en/trade/tig_usdt', 'TIG_USDT'), true);
  // STIG ≠ TIG: без границы вкладку STIG закрыли бы как «лишнюю».
  assert.equal(urlIsPair(`${MEXC}/exchange/STIG_USDT`, 'TIG_USDT'), false);
  assert.equal(urlIsPair(`${MEXC}/exchange/ARTX_USDT`, 'ART_USDT'), false);
  // Другая квота — другая книга.
  assert.equal(urlIsPair(`${MEXC}/exchange/TIG_BTC`, 'TIG_USDT'), false);
});

// evaluate возвращает «на вкладку СМОТРЯТ» (активна в своём окне И окно в
// фокусе). По умолчанию — не смотрят: браузер в фоне, оператор в терминале.
// __arbiOwned: вкладку открыл сам ArbiBrowser (иначе уборка считает её ручной и не трогает).
const closable = (url, extra = {}) => ({
  url: () => url, isClosed: () => false, __arbiPairTab: true, __arbiOwned: true,
  evaluate: async () => false,
  close: async function () { this.closed = true; },
  ...extra,
});

test('закрывается только вкладка пары, которой больше нет в терминале', async () => {
  const keep = closable(`${BINGX}/en-us/spot/WOJAK-USDT`);
  const stale = closable(`${BINGX}/en-us/spot/OLD-USDT`);
  const r = await closeStalePairTabs(ctx([keep, stale]), BINGX, ['WOJAK_USDT']);
  assert.equal(r.closed, 1);
  assert.equal(stale.closed, true);
  assert.equal(keep.closed, undefined, 'открытую пару не трогаем');
});

// Разбор лога оператора 2026-09-20 (MEXC/WOJAK): уборка закрывала вкладку через
// 6-12 с после прогрева, и следующая заявка платила за холодный старт 6 с.
test('свежую вкладку уборка не закрывает, устаревшую — закрывает', async () => {
  const justUsed = closable(`${BINGX}/en-us/spot/WOJAK-USDT`, { __arbiPairTabAt: Date.now() - 12_000 });
  const longIdle = closable(`${BINGX}/en-us/spot/OLD-USDT`, { __arbiPairTabAt: Date.now() - 10 * 60_000 });
  const r = await closeStalePairTabs(ctx([justUsed, longIdle]), BINGX, []);
  assert.equal(justUsed.closed, undefined, 'вкладку, которой пользовались 12 с назад, не трогаем');
  assert.equal(longIdle.closed, true, 'давно брошенная закрывается как раньше');
  assert.equal(r.closed, 1);
});

test('окно защиты выключается ARBI_TAB_CLOSE_GRACE_SEC=0', async () => {
  const prev = process.env.ARBI_TAB_CLOSE_GRACE_SEC;
  process.env.ARBI_TAB_CLOSE_GRACE_SEC = '0';
  try {
    const justUsed = closable(`${BINGX}/en-us/spot/WOJAK-USDT`, { __arbiPairTabAt: Date.now() });
    const r = await closeStalePairTabs(ctx([justUsed]), BINGX, []);
    assert.equal(justUsed.closed, true);
    assert.equal(r.closed, 1);
  } finally {
    if (prev === undefined) delete process.env.ARBI_TAB_CLOSE_GRACE_SEC;
    else process.env.ARBI_TAB_CLOSE_GRACE_SEC = prev;
  }
});

test('вкладка без метки пула тоже убирается (кейс 02.09)', async () => {
  // Метка ставится только когда через вкладку идёт работа, а по ЗАКРЫТОЙ паре
  // работы нет — раньше такие вкладки висели вечно. Отбор идёт по смыслу URL.
  const stale = closable(`${BINGX}/en-us/spot/B-USDT`, { __arbiPairTab: false });
  const other = closable(`${BINGX}/en-us/spot/C-USDT`);
  const r = await closeStalePairTabs(ctx([stale, other]), BINGX, ['C_USDT']);
  assert.equal(r.closed, 1);
  assert.equal(stale.closed, true, 'непомеченная вкладка закрытой пары убрана');
  assert.equal(other.closed, undefined);
});

test('НЕ торговые страницы не трогаем: кошелёк, вывод, логин', async () => {
  assert.equal(isTradePairUrl(`${BINGX}/en-us/spot/WOJAK-USDT`), true);
  assert.equal(isTradePairUrl(`${MEXC}/exchange/HEMI_USDT`), true);
  assert.equal(isTradePairUrl('https://www.xt.com/ru/trade/btc_usdt'), true);
  assert.equal(isTradePairUrl(`${BINGX}/en-us/assets/withdraw`), false);
  assert.equal(isTradePairUrl(`${MEXC}/assets/wallet`), false);
  assert.equal(isTradePairUrl(`${MEXC}/login`), false);
  assert.equal(isTradePairUrl(`${MEXC}/futures/BTC_USDT`), false, 'фьючерсы — не наша спот-страница');

  const wallet = closable(`${BINGX}/en-us/assets/withdraw`);
  const stale = closable(`${BINGX}/en-us/spot/B-USDT`);
  await closeStalePairTabs(ctx([wallet, stale]), BINGX, []);
  assert.equal(wallet.closed, undefined, 'страницу вывода оператора не трогаем');
  assert.equal(stale.closed, true);
});

test('последняя вкладка биржи тоже закрывается, если её пары нет в терминале (оператор 05.09)', async () => {
  // Раньше единственная вкладка оставалась «на следующий ордер» и висела вечно
  // без строки в логе; исполнители открывают новую страницу сами.
  const only = closable(`${BINGX}/en-us/spot/E-USDT`);
  const r = await closeStalePairTabs(ctx([only]), BINGX, []);
  assert.equal(r.closed, 1);
  assert.equal(only.closed, true);
});

test('«видимость» страницы уборку не останавливает (кейс 02.09 ×3: Playwright эмулирует фокус всем)', async () => {
  // Все вкладки под Playwright отвечают hidden=false и hasFocus()=true — по
  // этому признаку уборка пропускала ВСЕ вкладки. Правило: вкладки браузера =
  // вкладки терминала, видимость не учитывается.
  const a = closable(`${BINGX}/en-us/spot/OLD-USDT`, { evaluate: async () => true });
  const b = closable(`${BINGX}/en-us/spot/OLD2-USDT`, { evaluate: async () => true });
  const keep = closable(`${BINGX}/en-us/spot/KEEP-USDT`, { evaluate: async () => true });
  const r = await closeStalePairTabs(ctx([a, b, keep]), BINGX, ['KEEP_USDT']);
  assert.equal(r.closed, 2);
  assert.equal(a.closed, true);
  assert.equal(b.closed, true);
  assert.equal(keep.closed, undefined);
});

test('метка пула протухает — брошенные вкладки снова можно усыплять', () => {
  const fresh = markPairTab({ __arbiPairTab: false });
  assert.equal(isFreshPairTab(fresh), true);
  const old = { __arbiPairTab: true, __arbiPairTabAt: Date.now() - 31 * 60_000 };
  assert.equal(isFreshPairTab(old), false, 'после TTL защита снимается');
  assert.equal(isFreshPairTab({}), false, 'непомеченная вкладка не защищена');
});

test('вкладка, открытая руками (без метки владения), НЕ закрывается уборкой (оператор 08.09)', async () => {
  const manual = closable(`${BINGX}/en-us/spot/BTC-USDT`, { __arbiOwned: undefined });
  const ours = closable(`${BINGX}/en-us/spot/STALE-USDT`);
  const r = await closeStalePairTabs(ctx([manual, ours]), BINGX, []);
  assert.equal(r.closed, 1, 'закрывается только наша вкладка');
  assert.equal(manual.closed, undefined, 'ручная вкладка BTC осталась');
  assert.equal(ours.closed, true, 'наша вкладка чужой пары закрыта');
});

// ── newBackgroundPage: вкладка открывается В ФОНЕ, активную не перехватывает ──
const { newBackgroundPage } = require('./pair-tabs');

// Мок CDP: окно профиля стоит в (100,50) 900×700; создание цели добавляет страницу.
function cdpMock(pages, sent) {
  return async () => ({
    send: async (m, p) => {
      sent.push([m, p]);
      if (m === 'Browser.getWindowForTarget') return { windowId: 7 };
      if (m === 'Browser.getWindowBounds') return { bounds: { left: 100, top: 50, width: 900, height: 700, windowState: 'normal' } };
      if (m === 'Target.createTarget') pages.push(page('about:blank'));
      return {};
    },
    detach: async () => {},
  });
}

test('своя страница открывается в ОТДЕЛЬНОМ окне фоном и встаёт на место окна профиля', async () => {
  const pages = [page(`${BINGX}/en-us/spot/AUSDT`)];
  const sent = [];
  const c = {
    pages: () => pages,
    newPage: async () => { throw new Error('newPage не должен вызываться: страница открыта через CDP'); },
    newCDPSession: cdpMock(pages, sent),
  };
  delete process.env.ARBI_PAIR_WINDOWS;
  const fresh = await newBackgroundPage(c);
  assert.equal(fresh.url(), 'about:blank');
  assert.equal(fresh.__arbiOwnWindow, true);
  const create = sent.find(([m]) => m === 'Target.createTarget');
  assert.deepEqual(create[1], { url: 'about:blank', background: true, newWindow: true });
  const placed = sent.find(([m]) => m === 'Browser.setWindowBounds');
  assert.deepEqual(placed[1].bounds, { left: 100, top: 50, width: 900, height: 700, windowState: 'normal' });
});

test('ARBI_PAIR_WINDOWS=0 → прежняя фоновая вкладка в общем окне, без позиционирования', async () => {
  const pages = [page(`${BINGX}/en-us/spot/AUSDT`)];
  const sent = [];
  const c = { pages: () => pages, newPage: async () => { throw new Error('newPage'); }, newCDPSession: cdpMock(pages, sent) };
  process.env.ARBI_PAIR_WINDOWS = '0';
  try {
    const fresh = await newBackgroundPage(c);
    assert.equal(fresh.url(), 'about:blank');
    assert.notEqual(fresh.__arbiOwnWindow, true);
    const create = sent.find(([m]) => m === 'Target.createTarget');
    assert.deepEqual(create[1], { url: 'about:blank', background: true, newWindow: false });
    assert.equal(sent.some(([m]) => m === 'Browser.setWindowBounds'), false);
  } finally { delete process.env.ARBI_PAIR_WINDOWS; }
});

test('CDP недоступен → обычная вкладка (поведение как раньше, без отказа)', async () => {
  const pages = [page(`${BINGX}/en-us/spot/AUSDT`)];
  const fallback = page('about:blank');
  const c = {
    pages: () => pages,
    newPage: async () => fallback,
    newCDPSession: async () => { throw new Error('CDP недоступен'); },
  };
  assert.equal(await newBackgroundPage(c), fallback);
});

test('newBackgroundPage({tab:true}): вкладка в существующем окне, не своё окно', async () => {
  const { newBackgroundPage } = require('./pair-tabs');
  const sent = [];
  const pages = [page('https://bingx.com/ru/spot/AUSDT')];
  const cdp = { send: async (m, a) => { sent.push([m, a]); if (m === 'Target.createTarget') pages.push(page('about:blank')); return {}; }, detach: async () => {} };
  const ctx = { pages: () => pages, newCDPSession: async () => cdp, newPage: async () => page('about:blank') };
  const fresh = await newBackgroundPage(ctx, { tab: true });
  const create = sent.find(([m]) => m === 'Target.createTarget');
  assert.deepEqual(create[1], { url: 'about:blank', background: true, newWindow: false });
  assert.notEqual(fresh.__arbiOwnWindow, true);
});

test('pageRenders: кадры идут → true; rAF не сработал за окно → false; страница закрыта → false', async () => {
  const run = (fn, t) => fn(t);
  const live = { evaluate: async (fn, t) => run(fn, t) };
  global.requestAnimationFrame = (cb) => setTimeout(cb, 0);
  assert.equal(await pageRenders(live, 50), true);
  global.requestAnimationFrame = () => {}; // скрытый виджет: rAF молчит
  assert.equal(await pageRenders(live, 20), false);
  delete global.requestAnimationFrame;
  assert.equal(await pageRenders({ evaluate: async () => { throw new Error('closed'); } }), false);
});

'use strict';

/**
 * no-proxy.js — ПРОФИЛЬ БЕЗ ПРОКСИ (оператор 2026-10-19: «на Gate я торгую без прокси —
 * ArbiBrowser открывает его отдельным профилем без прокси, в шапке написано, что без прокси»).
 *
 * Правило «только через свой прокси» (ip-watch.js) остаётся. Исключение — профиль, ВСЕ
 * биржи которого в списке ARBI_NO_PROXY_OK (по умолчанию gateio): аккаунт в терминале
 * заведён без прокси намеренно. Ручной профиль или другая биржа без прокси — по-прежнему
 * красный флаг.
 *
 * Импорт (terminal-sync): аккаунт такой биржи получает свой профиль БЕЗ прокси, даже если
 * в терминале у него прокси, — прокси терминала остаётся для его API-ключа, а на сайт
 * оператор ходит со своего IP (19.10: у Gate g@… в терминале прокси EspAll, профиль
 * открывался через него).
 *
 * Пометка: первая вкладка профиля — служебная страница «⚠ БЕЗ ПРОКСИ». Заголовок окна
 * Chromium не задать (--window-name не действует на окна Playwright), а надпись внутри
 * страницы биржи видна её скриптам; data:-вкладка видна только оператору в полосе
 * вкладок. Закрыли — через минуту откроется снова.
 */
const { newBackgroundPage, markOwned } = require('./pair-tabs');

const okSet = () => new Set(String(process.env.ARBI_NO_PROXY_OK ?? 'gateio').toLowerCase().split(',').map((s) => s.trim()).filter(Boolean));

/** Биржи профиля из заметки синхронизации («… / биржи: GATEIO,MEXC / …»). */
function exchangesOf(profile) {
  const m = profile && typeof profile.note === 'string' && profile.note.match(/биржи:\s*([^/\n]*)/i);
  return m ? m[1].split(',').map((s) => s.trim().toLowerCase()).filter(Boolean) : [];
}

/** Профиль без прокси, и это задумано: все его биржи — из списка исключений. */
function noProxyOk(profile) {
  if (!profile || profile.proxy) return false;
  const ex = exchangesOf(profile);
  const ok = okSet();
  return ex.length > 0 && ex.every((e) => ok.has(e));
}

function markerUrl(name, ok) {
  const title = ok ? '⚠ БЕЗ ПРОКСИ · реальный IP этого ПК' : '⛔ БЕЗ ПРОКСИ · задайте прокси профилю';
  const text = ok
    ? `Профиль <b>${name}</b> открыт <b>без прокси</b>: сайты видят реальный IP этого компьютера.<br>Так задумано — аккаунт биржи заведён в терминале без прокси.`
    : `Профиль <b>${name}</b> открыт <b>без прокси</b>: биржа видит реальный IP этого компьютера.<br>Задайте прокси профилю или аккаунту в терминале.`;
  return 'data:text/html;charset=utf-8,' + encodeURIComponent(
    `<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>${title}</title>`
    + '<style>html,body{height:100%;margin:0}body{display:flex;align-items:center;justify-content:center;'
    + `background:#12161c;color:#c9d4e3;font:16px/1.6 system-ui,Segoe UI,Arial,sans-serif;text-align:center}h1{color:${ok ? '#f0b232' : '#ff5c5c'};font-size:26px}</style>`
    + `</head><body><div><h1>${title}</h1>${text}<br><small>Служебная вкладка ArbiBrowser — закроете, откроется снова.</small></div></body></html>`,
  );
}

/** Держать вкладку-пометку в профиле без прокси (идемпотентно). */
function ensureMarker(ctx, name, ok, log = () => {}) {
  if (!ctx || ctx.__arbiNoProxyMarker) return;
  ctx.__arbiNoProxyMarker = true;
  const url = markerUrl(name, ok);
  const tick = async () => {
    let pages;
    try { pages = ctx.pages(); } catch { return; }
    if (!pages.length) return; // контекст закрыт
    if (!pages.some((p) => { try { return p.__arbiNoProxy && !p.isClosed(); } catch { return false; } })) {
      try {
        const p = markOwned(await newBackgroundPage(ctx, { tab: true }));
        p.__arbiNoProxy = true;
        await p.goto(url).catch(() => {});
      } catch (e) { log(`[без прокси] ${name}: вкладка-пометка не открылась (${e && e.message})`); }
    }
    const t = setTimeout(tick, 60_000);
    if (t.unref) t.unref();
  };
  tick();
}

module.exports = { exchangesOf, noProxyOk, ensureMarker, markerUrl, okSet };

'use strict';

/**
 * mexc-order-page.js — Стадия 3: РЕАЛЬНОЕ исполнение web-ордера MEXC в живой
 * странице браузера профиля.
 *
 * Почему в браузере, а не реплеем на сервере: серверный replay режет Akamai по
 * TLS/JA3-отпечатку (пустой 200, ордер не встаёт). В реальном залогиненном
 * Chromium профиля TLS + куки + поведенческий сенсор совпадают по построению.
 *
 * Почему НЕ page.evaluate(fetch(order/place)) и НЕ JS-.click():
 *   Проверено 2026-06-06 (session-note терминала): синтетический submit из JS
 *   (даже прямой вызов React-onClick) НЕ порождает анти-бот-подпись — MEXC
 *   завязан на ПОВЕДЕНЧЕСКИЙ fingerprint (SDK trochilus/watchman). Поэтому
 *   форму надо нажимать ДОВЕРЕННЫМ вводом. Нативные Playwright `page.fill` /
 *   `page.click` идут через CDP Input-домен (Input.dispatchMouseEvent и т.п.) →
 *   события `isTrusted=true`, как у настоящего пользователя. ЭТО и есть путь,
 *   отличный от провалившегося JS-синтетик-клика.
 *
 * ⚠️ НЕ ПРОВЕРЕНО против живого MEXC из среды разработки. Селекторы формы взяты
 * из наблюдений терминала (docs/exchange-web/08-mexc-web-trading.md) и могут
 * разойтись с текущей вёрсткой (хешированные классы). Все селекторы
 * ПЕРЕОПРЕДЕЛЯЕМЫ через env (см. SELECTORS ниже), чтобы починить без правки кода.
 * Живой прогон обязателен ДО включения live-режима — см. session-note.
 */

const { formatDecimal, isPlainPositive, pairGate, fieldFresh, sideFromText, truncateQty, learnQtyDecimals } = require('./order-utils');
const { canOpenPairTab, markPairTab, markOwned, ensureTabInFront, newBackgroundPage, pageRenders } = require('./pair-tabs');

const MEXC_ORIGIN = 'https://www.mexc.com';
// M4: переопределяемо через env (как ARBI_XT_ORDER_RE у XT). Если MEXC сменит endpoint,
// захардкоженный RE не поймает POST ордера → orderReqFired не выставится → повтор клика
// вслепую → дубль. Без пересборки правится в .env, коли путь окажется иным.
const ORDER_PLACE_RE = new RegExp(process.env.ARBI_MEXC_ORDER_RE || '/api/platform/spot/order/place', 'i');

/**
 * Сколько знаков после точки MEXC реально ПРИНЯЛ в поле количества по этой паре.
 *
 * Замер оператора 2026-09-21 (WOJAK/USDT): вводим `14003111802.62280464`, поле
 * показывает `14003111802.` — биржа отсекает дробную часть целиком, но мы каждый
 * раз честно набираем 9 лишних символов. Ввод на MEXC — только посимвольный
 * (анти-бот «вооружает» кнопку потоком доверенных клавиш), по ~7-10 мс на знак,
 * значит лишние символы — чистая потеря на КАЖДОЙ заявке.
 *
 * Механика ровно та же, что уже работает на XT (`XT_QTY_DEC`): запоминаем урок
 * из фактического ответа биржи и со второй заявки печатаем сразу столько, сколько
 * она принимает. Итоговая заявка та же — усекала её всё равно биржа.
 */
const MEXC_QTY_DEC = new Map();

// Селекторы формы ордера MEXC. Хешированные суффиксы классов у MEXC меняются —
// поэтому каждый переопределяется через env без пересборки.
const SELECTORS = {
  // Поля ввода цены/количества/всего (у MEXC один класс на все три инпута).
  input: process.env.ARBI_MEXC_SEL_INPUT || 'input.mx-motion-input-inner',
  // Кнопка сабмита ордера (Buy/Sell) — префикс класса стабилен дольше суффикса.
  submit: process.env.ARBI_MEXC_SEL_SUBMIT || 'button[class*="do-submit_doBtn__"]',
  // Вкладки Limit/Market (best-effort по тексту).
  limitTab: process.env.ARBI_MEXC_SEL_LIMIT || 'text=/^Limit$/i',
  // Вкладки Buy/Sell. ПОДТВЕРЖДЕНО оператором: <div class="actions_sellBtn__HASH">Sell</div>
  // (хеш-суффикс меняется между сборками → префиксный матч класса). Симметрично buyBtn.
  // Фолбэк по тексту (ensureSide стратегия B) остаётся, если класс сменится.
  buyTab: process.env.ARBI_MEXC_SEL_BUY || '[class*="actions_buyBtn__"]',
  sellTab: process.env.ARBI_MEXC_SEL_SELL || '[class*="actions_sellBtn__"]',
  // Кнопка подтверждения в модалке ордера (появляется не всегда). Дефолт — кнопка
  // с текстом Confirm/Buy/Place внутри диалога; переопределяемо через ARBI_MEXC_SEL_CONFIRM.
  confirm: process.env.ARBI_MEXC_SEL_CONFIRM || 'button:has-text("Confirm")',
  // Строка поиска ПАРЫ. Заголовок пары <h1>/стрелка открывает выпадашку поиска (см.
  // focusSearchInput). Инпут ищем по классам компонента поиска + placeholder «contract
  // address» + ant-input-sm как фолбэк (чтобы поле ВСЕГДА находилось). Переопределяемо env.
  search: process.env.ARBI_MEXC_SEL_SEARCH
    || '[class*="search-bar_"] input,[class*="searchInputField"] input,[class*="_searchInput_"] input,[class*="searchInputWrapper"] input,input[placeholder*="contract address" i],input[class*="ant-input-sm"]',
  // Открывашка поповера поиска ПАРЫ. ⚠️ БЕЗ `[class*="searchIcon"]` — он ловил иконку-лупу
  // ГЛОБАЛЬНОГО поиска в шапке и открывал его (увод ввода в верхнюю строку). Реальная
  // открывашка — клик по заголовку пары <h1> (см. focusSearchInput); тут — доп. фолбэки
  // по классам самой выпадашки, кликаются ТОЛЬКО если заголовок не открыл поле.
  searchOpen: process.env.ARBI_MEXC_SEL_SEARCH_ICON || '[class*="search-bar_"] [class*="searchPlaceholder"],[class*="searchPlaceholder"],[class*="searchInputWrapper"],[class*="searchInputField"]',
  // Кликабельная строка результата поиска. ⚠️ ПОДТВЕРЖДЕНО ЖИВЫМ ДИАГОМ исполнителя
  // 2026-07-13: строка — <div class="search-bar_item__HASH"> (тикер «WOJAK/USDT» в её
  // textContent через search-bar_itemContent__). Ставим `search-bar_item__` ПЕРВЫМ:
  // прежние `result-item_item`/`responsive-item` были из ДРУГОГО поповера (ручной дамп) и
  // строку исполнителя НЕ матчили → шаг result-item падал в timeout → перезагрузка каждый
  // ⚠️ ПОДТВЕРЖДЕНО ЖИВЫМ ДИАГОМ 2026-07-14: результат ЛЕВОГО поиска пары лежит в
  // контейнере `search-bar_resultWrapper__` (его textContent содержит «…Spot (1)
  // WOJAK/USDT…»), а сами строки — `responsive-item`. КРИТИЧНО скоупить именно этим
  // контейнером: `responsive-item` с текстом «PUMP DEXE ZEC…» — это hot-searches ШАПКИ,
  // они ВНЕ wrapper; без scope .first() кликнул бы чужую строку. Держим result-item_item/
  // search-bar_item__ фолбэками (иные сборки вёрстки). Переопределяемо env.
  searchResult: process.env.ARBI_MEXC_SEL_SEARCH_RESULT
    || '[class*="search-bar_resultWrapper__"] [class*="responsive-item"],[class*="search-bar_resultWrapper__"] [class*="result-item_item"],[class*="search-bar_resultWrapper__"] [class*="search-bar_item__"]',
  // Фолбэк «верхняя строка» — тот же scope на wrapper левого поиска (первый responsive-item
  // = верхний результат = наш токен, т.к. ввели точный тикер). Переопределяемо env.
  searchResultScoped: process.env.ARBI_MEXC_SEL_SEARCH_RESULT_SCOPED
    || '[class*="search-bar_resultWrapper__"] [class*="responsive-item"],[class*="search-bar_resultWrapper__"] [class*="result-item_item"],[class*="search-bar_resultWrapper__"] [class*="search-bar_item__"]',
};
// Общие хелперы страницы (ввод/оверлеи/модалки/готовность сабмита) — один код на три
// биржи, различия — в профиле `page-driver.js`.
const { typeNumber, fastSetInputs, isSubmitReady, dismissBlockingModal, dismissOverlays, loginWall } = require('./page-driver').driverFor('mexc', SELECTORS);
const { loginRequiredError } = require('./page-driver');

// Канон "BASE/QUOTE" (или "BASE_QUOTE") → путь пары MEXC "BASE_USDT".
function toMexcPair(symbol) {
  return String(symbol).toUpperCase().replace('/', '_');
}

/** Экранировать строку для вставки в RegExp (тикеры бывают с точками и т.п.). */
function escRe(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Страница пары отдала 404 «Sorry! The page you're looking for cannot be found»?
 * У части MEXC-токенов (напр. PIN) прямой URL /exchange/PAIR 404-ит — пара открывается
 * ТОЛЬКО через поиск (?_from=search_spot_trade). Прогрев/восстановление вкладки прямым
 * goto оставляет вкладку на 404, а executeIntent долбит впустую. Детект → внятная
 * ошибка вместо тихого срыва. best-effort (по тексту/отсутствию формы).
 */
async function isMexcNotFound(page) {
  return page.evaluate(() => {
    const t = (document.body && document.body.innerText || '');
    // Маркеры 404-страницы MEXC (EN/RU) + отсутствие торговой формы.
    if (/cannot be found|Back to Home|Trade MX\/USDT|страница не найдена|не удалось найти/i.test(t)) {
      return !document.querySelector('input.mx-motion-input-inner');
    }
    return false;
  }).catch(() => false);
}

/**
 * Страница = Akamai «Access Denied» (edgesuite)? Это НЕ ошибка пары, а блок профиля/
 * выходного IP биржей. Долбить MEXC в этом состоянии бессмысленно и ВРЕДНО (продлевает
 * бан, мешает ручному восстановлению). Детект → глобальный бэкофф MEXC (mexcBlocked).
 */
async function isMexcAccessDenied(page) {
  return page.evaluate(() => {
    const t = (document.body && document.body.innerText || '');
    return /Access Denied|don't have permission|edgesuite\.net|Reference #\d/i.test(t)
      && !document.querySelector('input.mx-motion-input-inner');
  }).catch(() => false);
}

// ── Глобальный бэкофф MEXC при Access Denied ─────────────────────────────────
// Пока активен — исполнитель НЕ навигирует к MEXC (ни ордер, ни прогрев, ни чтение):
// биржа блокирует профиль/IP, любые заходы только продлевают бан и мешают оператору
// восстановиться (сменить IP прокси / подождить / почистить куки). Переопускаемо env.
let mexcAdUntil = 0;
function mexcBlocked() { return Date.now() < mexcAdUntil; }
function mexcBlockedMsLeft() { return Math.max(0, mexcAdUntil - Date.now()); }
function noteMexcAccessDenied(log) {
  const ms = Number(process.env.ARBI_MEXC_AD_COOLDOWN_MS || 300000); // 5 мин
  mexcAdUntil = Date.now() + ms;
  if (log) log(`MEXC Access Denied (Akamai) — навигация к MEXC приостановлена на ${Math.round(ms / 1000)}с (бан профиля/IP). Смените IP прокси или подождите.`);
}

/**
 * Содержит ли URL нужную пару — терпимо к percent-кодировке (non-ASCII имена
 * токенов в адресе кодируются, сырое includes их не находит → ложная «не
 * открыта» и ложный timeout завершения SPA). Зеркало xt-order-page.urlHasPair.
 */
function urlHasPair(u, pair) {
  const needle = ('/exchange/' + String(pair)).toLowerCase();
  let dec = u;
  try { dec = decodeURIComponent(u); } catch { /* битый % — оставляем сырой */ }
  return String(u).toLowerCase().includes(needle) || String(dec).toLowerCase().includes(needle);
}

/**
 * Кэш «какая пара открыта на этой вкладке» (page.__arbiPair = {pair, path}) —
 * зеркало page.__arbiSide. Валиден, только пока pathname вкладки совпадает с
 * записанным (ручная навигация оператора инвалидирует кэш сама собой). Пишем
 * ТОЛЬКО в точках ПОДТВЕРЖДЁННОГО перехода (finishSpa / точный URL-матч) —
 * кэш не может «узаконить» непроверенное состояние и увести ордер на чужую
 * пару. Убирает повторные DOM-проверки/итерации поиска между интентами одного
 * токена (warmup → ордер → следующий ордер) — особенно для пар, у которых
 * displayName ≠ coinName и urlHasPair не совпадает никогда.
 */
function rememberPair(page, pair) {
  try { page.__arbiPair = { pair: String(pair), path: new URL(page.url()).pathname }; }
  catch { page.__arbiPair = null; }
}
function cachedPairWarm(page, u, pair) {
  const c = page.__arbiPair;
  if (!c || c.pair !== String(pair)) return false;
  try { return new URL(u).pathname === c.path; } catch { return false; }
}

/**
 * Находит уже открытую страницу mexc.com в контексте профиля, либо открывает
 * новую. Возвращает Playwright Page.
 */
async function getMexcPage(context, pair, log) {
  const wantUrl = `${MEXC_ORIGIN}/exchange/${pair}`;
  const [base, quote = 'USDT'] = String(pair).split('_');
  // Собираем все вкладки mexc.com (там живая залогиненная сессия).
  const mexcPages = [];
  let sleepingMexc = null;
  let sleepingSame = null; // спящая вкладка ИМЕННО этой пары // спящая вкладка MEXC — запасной вариант вместо дубля
  for (const p of context.pages()) {
    let u = '';
    try { u = p.url(); } catch { /* закрыта */ }
    // Фоновую вкладку истории ордеров (__arbiOrdersBg) НЕ отдаём под реальный ордер:
    // read-only, её навигирует параллельное чтение истории — ордер ушёл бы в скрытый таб.
    try { if (p.__arbiOrdersBg === true || p.__arbiNoInput === true) continue; } catch { /* игнор */ }
    // Спящая вкладка (экономия памяти) физически на about:blank, но помнит свой
    // URL. Запоминаем как запасной вариант: разбудить ЕЁ дешевле и безопаснее,
    // чем открыть дубль — в ней живая залогиненная сессия биржи.
    if (!u.startsWith(MEXC_ORIGIN) && typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl.startsWith(MEXC_ORIGIN)) {
      if (urlHasPair(p.__arbiSleepUrl, pair)) sleepingSame = p;
      if (!sleepingMexc) sleepingMexc = p;
      continue;
    }
    if (u.startsWith(MEXC_ORIGIN)) mexcPages.push({ p, u });
  }
  // 0) Кэш пары (__arbiPair): та же пара И pathname не менялся с подтверждённого
  //    перехода → тёплая сразу, без DOM-проверок и повторного поиска.
  for (const { p, u } of mexcPages) {
    if (cachedPairWarm(p, u, pair)) return { page: markPairTab(p), cold: false };
  }
  // 1) Вкладка УЖЕ на нужной паре — тёплая, ордер напрямую (без навигации).
  for (const { p, u } of mexcPages) {
    if (urlHasPair(u, pair)) {
      // Вкладка могла быть ТОЛЬКО ЧТО открыта авто-запуском (startUrl уже на паре),
      // а React-форма ещё сырая: «тёплая» = есть ≥2 видимых поля формы. Иначе cold —
      // путь с ожиданием гидрации (иначе клик до готовности = срыв первого ордера).
      const readyInputs = await p.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).length).catch(() => 0);
      rememberPair(p, pair);
      return { page: markPairTab(p), cold: readyInputs < 2 };
    }
    // CR-1: граница токена — иначе ARTX-вкладка ложно тёплая для ART (STIG⊃TIG).
    // Только ТОРГОВЫЕ вкладки (/exchange/) и ПОЛНАЯ пара base/quote: h1 «ART/USDC»
    // или «ART Staking» на /earn не должны сойти за тёплую вкладку ART_USDT.
    if (!/\/exchange\//i.test(u)) continue;
    const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/\\s*' + escRe(quote) + '(?![A-Za-z0-9])', 'i') })
      .first().isVisible().catch(() => false);
    if (h1Match) return { page: markPairTab(p), cold: false };
  }
  // 2) Вкладка на ЛЮБОЙ торговой странице (/exchange/*) — с неё смена пары идёт быстрым
  //    SPA-поиском (React не перезагружается). ПРЕДПОЧИТАЕМ её вкладке на /earn и т.п.:
  //    раньше брали ПЕРВУЮ mexc-вкладку, и если это /earn — SPA не работал → перезагрузка
  //    (жалоба: медленный первый ордер по паре). Теперь торговая вкладка в приоритете.
  // 1.5) ПУЛ ТЁПЛЫХ ВКЛАДОК: есть место — открываем паре СВОЮ вкладку вместо
  //      смены пары в чужой. Вкладка прежней пары остаётся тёплой, и обе пары
  //      дальше работают без навигации (оператор ведёт несколько одновременно).
  //      Пул полон → прежний путь: SPA-смена пары ниже.
  // СПЯЩАЯ ВКЛАДКА ЭТОЙ ЖЕ ПАРЫ — будим её, а не открываем соседку. Лог оператора
  // 2026-09-08 06:48: после рестарта пара STONK лежала спящей (about:blank с
  // запомненным URL), но живая вкладка другой пары дала «место в пуле» → открылась
  // ВТОРАЯ вкладка STONK, и уборка потом закрыла обе. Дубль невозможен, если
  // спящую своей пары проверять ДО пула.
  if (sleepingSame) {
    log(`Бужу спящую вкладку своей пары: ${wantUrl}`);
    sleepingSame.__arbiSleepUrl = null;
    await sleepingSame.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleepingSame.url(), pair)) rememberPair(sleepingSame, pair);
    return { page: markPairTab(sleepingSame), cold: true };
  }
  if (canOpenPairTab(context, MEXC_ORIGIN)) {
    log(`Открываю отдельную вкладку под пару (пул тёплых вкладок): ${pair}`);
    const fresh = markPairTab(markOwned(await newBackgroundPage(context)));
    await fresh.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    // Навигация не состоялась (прокси/сеть) — не оставляем пустую about:blank вкладку
    // и не заполняем форму на пустой странице: закрываем и честно отказываем.
    if (String(fresh.url()).startsWith('about:')) {
      await fresh.close().catch(() => {});
      throw new Error(`страница пары не открылась (${wantUrl}) — проверьте прокси/сеть профиля`);
    }
    if (urlHasPair(fresh.url(), pair)) rememberPair(fresh, pair);
    return { page: fresh, cold: true };
  }
  const trade = mexcPages.find(({ u }) => /\/exchange\//i.test(u));
  if (trade) {
    const r = await changePairSpa(trade.p, pair, log);
    return { page: trade.p, cold: !r.spa };
  }
  // 3) Есть mexc-вкладка, но не торговая (/earn, промо) — changePairSpa сам сделает
  //    прямой goto на пару (v0.4.48: со страницы вне /exchange не тратим время на SPA).
  if (mexcPages.length) {
    const r = await changePairSpa(mexcPages[0].p, pair, log);
    return { page: mexcPages[0].p, cold: !r.spa };
  }
  // 3.5) Живых mexc-вкладок нет, но есть СПЯЩАЯ — будим её вместо открытия
  //      дубля: в ней уже прогретая залогиненная сессия биржи.
  if (sleepingMexc) {
    log(`Бужу спящую вкладку MEXC: ${wantUrl}`);
    sleepingMexc.__arbiSleepUrl = null;
    await sleepingMexc.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleepingMexc.url(), pair)) rememberPair(sleepingMexc, pair);
    return { page: sleepingMexc, cold: true };
  }
  // 4) Вкладок mexc нет — открываем новую сразу на паре.
  log(`Открываю страницу MEXC: ${wantUrl}`);
  const page = markOwned(await newBackgroundPage(context));
  await page.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  // goto резолвится и на РЕДИРЕКТЕ (логин/регион-блок) — кэшируем только
  // подтверждённый URL пары, иначе отравленный кэш вечно отдаёт чужую страницу.
  if (urlHasPair(page.url(), pair)) rememberPair(page, pair);
  return { page, cold: true }; // первая загрузка вкладки → форма «сырая»
}

/**
 * Смена торговой пары БЕЗ перезагрузки страницы — через строку поиска сайта, как
 * это делает пользователь вручную (<1с). MEXC-биржа это SPA (Next.js): переход по
 * внутренней ссылке `/exchange/PAIR` = client-side навигация, React-приложение и
 * гидрация СОХРАНЯЮТСЯ, меняются только данные пары → форма ордера готова почти
 * мгновенно. Это убирает «холодные» ~5с на каждый новый токен: после ОДНОЙ загрузки
 * вкладки при старте любой токен становится тёплым.
 * Полностью best-effort: любой сбой (не нашли поиск/ссылку/URL не сменился) →
 * фолбэк на page.goto (текущее поведение). Селекторы — env-переопределяемые.
 * @returns {Promise<{spa:boolean}>} spa=true если сменили без перезагрузки.
 */
/**
 * Открыть поиск пары и сфокусировать его строку (см. разбор в xt-order-page.js).
 * MEXC (скрины оператора 2026-07-09): на ШИРОКОМ окне поиск инлайн (список слева), на
 * УЗКОМ он скрыт и открывается кликом по ЗАГОЛОВКУ текущей пары <h1>BASE/USDT>. Поэтому
 * сперва кликаем заголовок (на широком окне безвредно), затем фокусируем поле поиска
 * (<input class="ant-input ant-input-sm">). НЕ page-level Ctrl+A/JS focus (выделяли
 * всю страницу).
 */
async function focusSearchInput(page) {
  // Залипшая risk/ошибка-модалка от прошлого токена перехватывает pointer events →
  // клик по h1/opener не открывает дропдаун поиска → поле не visible → перезагрузка.
  // Закрываем ПЕРЕД кликом (дёшево, ~мс). Зеркало XT-фикса.
  await dismissBlockingModal(page);
  // Нормализация: залипшую открытую выпадашку закрываем Escape (иначе клик по заголовку
  // её ЗАКРОЕТ toggle). Без фиксированной паузы — waitForFunction ниже сам дождётся.
  await page.keyboard.press('Escape').catch(() => {});
  // Заголовок пары (h1 с "/") — открывашка дропдауна поиска ПАРЫ.
  const h1 = page.locator('h1', { hasText: '/' }).first();
  await h1.click({ timeout: 2000 }).catch(() => {});
  // Пометить поле поиска ПАРЫ (не ШАПКИ) ОДНИМ in-page waitForFunction. Различитель НЕ по
  // классу (шапка и пара — один компонент search-bar_*), а по позиции: шапка вверху (top≤90),
  // поле пары ниже заголовка (top>90) в левой половине. Прежде это был Node-цикл 34×150мс со
  // сканом DOM на каждой итерации (раундтрип Node↔браузер) — ГЛАВНЫЙ лишний груз фазы focus
  // (регресс скорости). waitForFunction поллит ВНУТРИ страницы и возвращается СРАЗУ по
  // появлении поля — заметно быстрее. Функция помечает найденный инпут data-атрибутом.
  const markFn = () => {
    const vis = (el) => el.offsetParent !== null && el.getBoundingClientRect().width > 40;
    document.querySelectorAll('[data-arbi-pairsearch]').forEach((e) => e.removeAttribute('data-arbi-pairsearch'));
    const cands = Array.from(document.querySelectorAll('input')).filter(vis);
    const isOrder = (el) => /mx-motion-input/i.test(el.className);
    const isHeader = (el) => el.getBoundingClientRect().top <= 90;
    const searchish = (el) => /contract|token|search|искать|buscar|such|recherch|地址|搜索/i
      .test((el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || ''));
    let pick = cands.find((el) => !isHeader(el) && !isOrder(el) && searchish(el));
    if (!pick) pick = cands.find((el) => !isHeader(el) && !isOrder(el) && el.getBoundingClientRect().left < window.innerWidth * 0.5);
    if (!pick) return false;
    pick.setAttribute('data-arbi-pairsearch', '1');
    return true;
  };
  const waitOpts = { timeout: Number(process.env.ARBI_MEXC_MARK_WAIT_MS || 2500), polling: 100 };
  let opened = await page.waitForFunction(markFn, null, waitOpts).then(() => true).catch(() => false);
  if (!opened) {
    // Дропдаун не открылся с первого клика — добиваем открывашкой + повторным кликом и ждём ещё.
    await dismissBlockingModal(page);
    const opener = await page.$(SELECTORS.searchOpen).catch(() => null);
    if (opener) await opener.click({ timeout: 800 }).catch(() => {});
    await h1.click({ timeout: 1200, force: true }).catch(() => {});
    opened = await page.waitForFunction(markFn, null, { timeout: 3000, polling: 100 }).then(() => true).catch(() => false);
  }
  // Дропдаун поиска ПАРЫ так и не открылся → НЕ печатаем в поиск ШАПКИ (гарантированный
  // провал + лишние 4.5с). Бросаем: changePairSpa уйдёт в быстрый goto-фолбэк.
  if (!opened) throw new Error('поле поиска пары не открылось (дропдаун не прогрузился)');
  const input = page.locator('[data-arbi-pairsearch="1"]').first();
  // Надёжный фокус: голый .focus() — синтетический и на React-контроле не всегда
  // реально переводит фокус (наблюдалась долгая непредсказуемая focus-фаза 439-1551мс
  // в тайминге без гарантии, что ввод далее попадёт в нужное поле). Доверенный клик
  // (CDP Input, как и весь остальной ввод формы) + проверка document.activeElement;
  // один ретрай, если первый клик не дал фокуса (перекрытие анимацией/оверлеем).
  const focusMs = Number(process.env.ARBI_MEXC_SEARCH_FOCUS_MS || 1200);
  const isFocused = () => page.evaluate(
    () => document.activeElement && document.activeElement.getAttribute('data-arbi-pairsearch') === '1',
  ).catch(() => false);
  for (let i = 0; i < 2 && !(await isFocused()); i++) {
    await input.click({ timeout: focusMs, force: i > 0 }).catch(() => {});
  }
  if (!(await isFocused())) await input.focus({ timeout: 500 }).catch(() => {}); // best-effort фолбэк
  await input.selectText({ timeout: 1500 }).catch(() => {});
  // Settle перед вводом: свежему полю нужно мгновение на инициализацию React, иначе быстрый
  // keyboard.type иногда не триггерит фильтрацию (список остаётся общим → в диаге только
  // хот-серчи шапки → провал). 50мс оказалось мало (регресс на WOJAK 2026-07-14) — 100мс.
  await page.waitForTimeout(Number(process.env.ARBI_MEXC_SEARCH_SETTLE_MS || 100));
  return input;
}

async function changePairSpa(page, pair, log) {
  page.__arbiPair = null; // уходим со старой пары — кэш вкладки недействителен
  const [base, quote = 'USDT'] = String(pair).split('_');
  const pairLink = `a[href*="/exchange/${pair}"]`;
  // ── ДИАГНОСТИКА «первый поиск в длинной сессии тормозит» ──────────────────────
  // Разбиваем поиск на фазы с таймингом (лог [поиск-тайминг]). Что означают цифры:
  //   • wake — первый доступ к DOM (page.evaluate). БОЛЬШОЙ wake = Chromium заморозил/
  //     выгрузил простаивавшую вкладку, и первое обращение её «будит» (главный подозреваемый
  //     для длинной сессии).
  //   • focus — открытие выпадашки поиска (Escape+клик по заголовку+ожидание поля).
  //   • type — ввод тикера. results — ожидание строк удалённого поиска (БОЛЬШОЙ = прокси/
  //     сеть «остыли» или поиск MEXC медленный). click — клик по строке. finish — смена URL.
  const tStart = Date.now();
  // Путь ДО перехода — чтобы finishSpa засчитал успех по САМОМУ ФАКТУ смены URL для
  // токенов, где displayName ≠ coinName (в адресе внутренний тикер, а не имя): ни pair,
  // ни base в h1 не совпадут, и раньше finishSpa падал в timeout 4с → перезагрузка.
  let prevPath = '';
  try { prevPath = await page.evaluate(() => location.pathname); } catch { /* игнор */ }
  const tWake = Date.now(); // page.evaluate разбудил вкладку — вот и «wake»
  // Вкладка НЕ на торговой странице (восстановленная сессия могла встать на /earn и
  // т.п.)? SPA-поиск оттуда НЕ навигирует на /exchange (другой роутер-контекст) — ловили:
  // ввод и клик по результату проходят, а URL остаётся /earn → 2.5с таймаут → reload.
  // Не тратим 6-8с на заведомо провальные попытки — сразу прямой переход на пару.
  if (prevPath && !/\/exchange\//i.test(prevPath)) {
    log(`Вкладка на «${prevPath}» (не /exchange) — сразу прямой переход на пару`);
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(page.url(), pair)) rememberPair(page, pair); // goto с catch — кэшируем только подтверждённый URL
    page.__arbiSide = null;
    return { spa: false };
  }
  // Общий финал SPA-перехода: дождаться смену URL БЕЗ перезагрузки + инпуты формы.
  const finishSpa = async () => {
    // Терпимо к кодировке URL и к внутреннему id в адресе: успех если decoded
    // pathname содержит пару ИЛИ h1 показывает base токена.
    await page.waitForFunction((args) => {
      let dec = location.pathname;
      try { dec = decodeURIComponent(location.pathname); } catch { /* оставляем сырой */ }
      const path = (dec + ' ' + location.pathname).toLowerCase();
      if (path.includes('/exchange/' + args.pair)) return true;
      // ЛЮБОЙ видимый h1 с base (не только первый в DOM: первый может быть
      // ещё не перерисован/скрыт баннером → ложный «не перешли» → лишний reload).
      // CR-1: граница токена — подстрочный includes('ART') матчил «SMART/USDT» →
      // мгновенный ЛОЖНЫЙ успех SPA-перехода на клоне-тикере.
      const baseRe = new RegExp(args.baseRe, 'i');
      for (const h1 of document.querySelectorAll('h1')) {
        if (h1.offsetParent !== null && baseRe.test(h1.textContent || '')) return true;
      }
      // displayName ≠ coinName: URL сменился на ДРУГУЮ пару (не прежнюю).
      return !!(args.prev && location.pathname !== args.prev && /\/exchange\//i.test(location.pathname));
    }, { pair: String(pair).toLowerCase(), baseRe: '(?<![A-Za-z0-9])' + escRe(base) + '(?![A-Za-z0-9])', prev: prevPath },
      // 2500 → 5000: клик по строке уже состоялся, SPA неликвидной пары может
      // обновлять URL/h1 дольше 2.5с — ранний timeout вёл в полный reload
      // («итерации поиска повторяются, хотя токен уже выбран»).
      { timeout: Number(process.env.ARBI_MEXC_SPA_WAIT_MS || 5000) });
    await page.waitForSelector(SELECTORS.input, { timeout: 4000 }).catch(() => {});
    rememberPair(page, pair); // переход подтверждён — следующие интенты без DOM-проверок
    // На новой паре активная сторона Buy/Sell неизвестна — пусть executeIntent
    // подтвердит её кликом заново (безопасность направления ордера).
    page.__arbiSide = null;
  };

  // Способ A: ссылка на пару уже есть на странице (watchlist/список рынков) —
  // клик по внутренней ссылке = client-side переход Next (SPA), без поиска.
  try {
    const link = await page.$(pairLink);
    if (link) {
      await link.click({ timeout: 2000 });
      await finishSpa();
      log(`Смена пары по ссылке на странице (SPA): ${pair}`);
      return { spa: true };
    }
  } catch (_) { /* нет прямой ссылки — пробуем поиск */ }

  // Способ B: строка поиска сайта → ввод символа → клик по строке результата
  // (кликабельный div с текстом «BASE/USDT», React onClick → client-side SPA).
  let step = 'search-input';
  try {
    await focusSearchInput(page);
    const tFocus = Date.now();
    // Печать через keyboard в УЖЕ сфокусированное поле (focusSearchInput сделал focus),
    // а НЕ input.pressSequentially: тот перепроверяет актуальность локатора и на протухшем
    // после ре-рендера дропдауна поле висел до дефолтных 30с (фриз ~36с, жалоба оператора
    // 2026-07-14). keyboard.type печатает в АКТИВНЫЙ элемент без проверки локатора —
    // устойчивее и без 30с-зависания. delay переопределяем ARBI_MEXC_SEARCH_DELAY.
    await page.keyboard.type(base, { delay: Number(process.env.ARBI_MEXC_SEARCH_DELAY || 0) });
    const tType = Date.now();
    step = 'result-item';
    // Строка результата — ЖДЁМ И КЛИКАЕМ ТОЛЬКО строку с ТОЧНЫМ текстом «BASE/USDT»,
    // никогда «первую попавшуюся». Раньше сперва ждали ЛЮБУЮ строку по searchResultScoped
    // (scoped на search-bar_resultWrapper__), а текстовый матч проверяли ОДНИМ снимком
    // ПОСЛЕ — на неликвидных токенах (ALVA) это ловило карусель горячих токенов шапки
    // (диаг: строки «SNDK AKE ESPORTS» и т.п., без ALVA) — либо scoped-строка вовсе не
    // появлялась за 4500мс (обёртка иногда не рендерится/переименована) → пустое ожидание
    // впустую, а конечный клик всё равно уходил мимо → SPA не выйдет, только время слито.
    // Теперь ОДИН waitForFunction поллит и помечает нужную строку по ТЕКСТУ, коротким
    // бюджетом: если реального результата нет — бэйлим СРАЗУ (быстрее, чем достаивать
    // старые 4500мс ради заведомого промаха), не кликая чужое.
    // CR-1: экран + левая граница токена — «ART» без границы матчил строку «SMART/USDT»
    // и клик уходил в ЧУЖУЮ пару (pairGate поймал бы, но ордер срывался и время терялось).
    const wantRe = new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/?\\s*' + escRe(quote), 'i');
    // P0-1 (сохранено): hasText+.first() на однорезультатном поиске (напр. ALVA) ловил
    // ВНЕШНИЙ контейнер («All Spot Futures Spot(1) ALVA/USDT») — клик в его центр мимо
    // строки. Ищем в браузере САМЫЙ ГЛУБОКИЙ видимый элемент, чей textContent матчит
    // BASE/USDT и у которого НЕТ потомка с тем же матчем (строка тикера, не обёртка).
    // Скоуп — контейнер результатов, если он есть; иначе весь дропдаун (document), чтобы
    // переименование/отсутствие класса обёртки не топило матч по тексту.
    const matchBudget = Number(process.env.ARBI_MEXC_RESULT_MATCH_MS || 2500);
    const found = await page.waitForFunction((wantReSrc) => {
      const vis = (el) => el && el.offsetParent !== null;
      const re = new RegExp(wantReSrc, 'i');
      document.querySelectorAll('[data-arbi-searchrow]').forEach((e) => e.removeAttribute('data-arbi-searchrow'));
      const scope = document.querySelector('[class*="search-bar_resultWrapper__"]') || document.body;
      const matches = Array.from(scope.querySelectorAll('*')).filter((el) => vis(el) && re.test((el.textContent || '').trim()));
      const deepest = matches.find((el) => !matches.some((other) => other !== el && el.contains(other)));
      const pick = deepest || matches[0];
      if (!pick) return false;
      pick.setAttribute('data-arbi-searchrow', '1');
      return true;
    }, wantRe.source, { timeout: matchBudget, polling: 100 }).then(() => true).catch(() => false);
    if (!found) {
      // Нет строки с нужным текстом за бюджет — карусель/чужие токены вместо результата,
      // это нормальный сигнал «SPA не выйдет»: бросаем сразу в reload-фолбэк ниже,
      // без клика мимо и без досиживания старого 4500мс таймаута.
      throw new Error(`строка «${base}/USDT» не найдена в результатах за ${matchBudget}мс`);
    }
    const tResults = Date.now();
    await page.click('[data-arbi-searchrow]', { force: true, timeout: Number(process.env.ARBI_MEXC_RESULT_CLICK_MS || 2500) });
    const tClick = Date.now();
    step = 'url-change';
    await finishSpa();
    const tFinish = Date.now();
    log(`Смена пары через поиск (SPA, без перезагрузки): ${pair}`);
    log(`[поиск-тайминг] wake=${tWake - tStart} focus=${tFocus - tWake} type=${tType - tFocus} results=${tResults - tType} click=${tClick - tResults} finish=${tFinish - tClick} ИТОГО=${tFinish - tStart}мс`);
    return { spa: true };
  } catch (e) {
    // Диагностика: какие поля ввода / элементы поиска реально есть на странице —
    // чтобы подобрать точный ARBI_MEXC_SEL_SEARCH без гадания (как чинили форму).
    if (step === 'search-input') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 12)
          .map((i) => ({ ph: i.placeholder || '', al: i.getAttribute('aria-label') || '', cls: String(i.className || '').slice(0, 45), t: i.type }));
        const searchish = Array.from(document.querySelectorAll('[class*="earch" i],[aria-label*="search" i],[aria-label*="uscar" i]')).filter(vis).slice(0, 6)
          .map((e) => ({ tag: e.tagName, al: e.getAttribute('aria-label') || '', cls: String(e.className || '').slice(0, 45) }));
        return { inputs, searchish };
      }).catch(() => ({}));
      console.log('[mexc-exec] [diag поиск] ' + JSON.stringify(diag).slice(0, 950));
    }
    // Диагностика провала на строке-результате: какие строки реально в выпадающем
    // списке (класс+текст) — чтобы подобрать точный ARBI_MEXC_SEL_SEARCH_RESULT / понять,
    // почему нужная пара не подхватилась (частая причина медленного 1-го ордера).
    if (step === 'result-item') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const rows = Array.from(document.querySelectorAll('[class*="result-item"],[class*="earch" i] [class*="item" i],[class*="result" i],[class*="option" i]'))
          .filter(vis).slice(0, 10)
          .map((e) => ({ cls: String(e.className || '').slice(0, 50), txt: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40) }));
        return { rows };
      }).catch(() => ({}));
      console.log('[mexc-exec] [diag результат] ' + JSON.stringify(diag).slice(0, 950));
    }
    // На провале url-change логируем, где реально остались (URL не сменился = клик по
    // строке результата не навигировал; сменился на другое = не туда). По этому можно
    // прицельно чинить сам SPA-переход для конкретного токена.
    if (step === 'url-change') {
      const cur = await page.evaluate(() => location.pathname).catch(() => '?');
      console.log(`[mexc-exec] [diag url-change] осталось на «${cur}», ждали пару «${pair}»`);
    }
    log(`SPA-навигация не удалась на шаге «${step}» (${String(e.message).slice(0, 50)}) — фолбэк на перезагрузку`);
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(page.url(), pair)) rememberPair(page, pair); // goto с catch — кэшируем только подтверждённый URL
    page.__arbiSide = null;
    return { spa: false };
  }
}

/**
 * Подтверждает модалку ордера MEXC (ant-modal-v2-confirm и т.п.), нажимая её
 * основную кнопку (Confirm/Подтвердить/确认/Buy или .ant-btn-primary внутри диалога).
 * Trusted-клик через Playwright. Возвращает true, если кликнули. Перебирает селекторы,
 * т.к. текст/вёрстка модалки меняются между версиями MEXC.
 */
async function confirmOrderModal(page, log) {
  // Модалка подтверждения MEXC: «Order Confirmation … Cancel | Buy <SYM>». Кнопка
  // подтверждения имеет ДИНАМИЧЕСКИЙ текст ("Buy WOJAK"/"Sell WOJAK"/确认/Confirm),
  // футер кастомный (не ant-btn-primary). Ищем модалку по тексту и жмём её НЕ-Cancel
  // кнопку (trusted, scoped внутрь модалки — чтобы не задеть кнопку сабмита формы с
  // тем же текстом). Подтверждение = именно этот клик отправляет order/place.
  // Надёжно: в браузере находим модалку подтверждения и ПОМЕЧАЕМ её кнопку-подтверждение
  // (НЕ-Cancel) уникальным атрибутом, затем жмём её trusted-кликом по этому атрибуту.
  // Так исключаем двусмысленность с одноимённой кнопкой сабмита формы («Buy <SYM>»).
  const marked = await page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('[class*="ant-modal"],[class*="odal-v2"],[class*="odal-wrap"],[role="dialog"]')).filter(vis);
    for (const m of modals) {
      const txt = (m.innerText || '');
      if (!/confirmation|подтвер|confirm|订单确认|订单|risk|риск/i.test(txt)) continue;
      // Отметить «No more reminders» — чтобы MEXC больше НЕ показывал это подтверждение
      // (следующие ордера пойдут напрямую, без модалки → быстрее и надёжнее).
      try {
        const cb = m.querySelector('input[type="checkbox"]');
        if (cb && !cb.checked) cb.click();
      } catch (_) { /* нет чекбокса */ }
      const btns = Array.from(m.querySelectorAll('button')).filter(vis);
      const btn = btns.find((b) => {
        const t = (b.innerText || '').trim();
        return t && !/cancel|отмена|取消|no more|reminder|напоминан|close|закрыть/i.test(t);
      });
      if (btn) { btn.setAttribute('data-arbi-confirm', '1'); return (btn.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 24); }
    }
    return null;
  }).catch(() => null);
  if (!marked) return false;
  try {
    await page.click('button[data-arbi-confirm="1"]', { timeout: 1500, noWaitAfter: true, force: true });
    if (log) log('Подтвердил модалку ордера: ' + marked);
    return true;
  } catch { return false; }
}

/**
 * M6: ЗАКРЫТЬ (Cancel/крестик) висящую модалку подтверждения ордера — НЕ подтверждать.
 * Вызывать В НАЧАЛЕ обработки intent: если от ПРОШЛОГО ордера осталась открытая модалка
 * (со старыми ценой/кол-вом), confirmOrderModal ниже подтвердила бы ЕЁ → ушёл бы чужой
 * ордер, а текущему intent приписался бы её orderId (ложный ok) + возможен второй ордер.
 * Закрываем чужую модалку заранее → в цикле клика confirmOrderModal видит только НАШУ.
 */
async function dismissOrderModal(page, log) {
  const closed = await page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('[class*="ant-modal"],[class*="odal-v2"],[class*="odal-wrap"],[role="dialog"]')).filter(vis);
    let did = false;
    for (const m of modals) {
      if (!/confirmation|подтвер|confirm|订单确认|订单/i.test(m.innerText || '')) continue;
      const btns = Array.from(m.querySelectorAll('button')).filter(vis);
      const cancel = btns.find((b) => /cancel|отмена|取消|close|закрыть/i.test((b.innerText || '')));
      const x = m.querySelector('[aria-label="Close"],[aria-label="close"],[class*="close"]');
      if (cancel) { cancel.click(); did = true; }
      else if (x && x.click) { x.click(); did = true; }
    }
    return did;
  }).catch(() => false);
  if (closed && log) log('M6: закрыл лефтовер-модалку подтверждения прошлого ордера (чужой ордер НЕ подтверждаю)');
  return closed;
}

// У MEXC в DOM ОДНОВРЕМЕННО присутствуют обе кнопки сабмита (Buy… и Sell…), но ВИДИМА
// только активная (неактивная скрыта 0×0). Раньше $eval/click брали ПЕРВУЮ в DOM (часто
// скрытую Buy) → на стороне Sell это ломало и чтение стороны, и клик по заявке. Работаем
// ТОЛЬКО с видимой кнопкой (подтверждено diag layout: Sell WOJAK v:true, Buy WOJAK v:false).
async function readVisibleSubmitText(page) {
  return page.evaluate((sel) => {
    const vis = (el) => el && el.offsetParent !== null && el.getBoundingClientRect().width > 2;
    const b = Array.from(document.querySelectorAll(sel)).filter(vis)[0];
    return b ? (b.textContent || '').trim() : '';
  }, SELECTORS.submit).catch(() => '');
}
/** Locator ВИДИМОЙ кнопки сабмита (активной стороны) — для клика и проверки готовности. */
function visibleSubmit(page) {
  const s = SELECTORS.submit;
  const sel = /^(text=|xpath=|\/\/)/.test(s) ? s : `${s}:visible`;
  return page.locator(sel).first();
}

/** Текущая сторона формы по тексту ВИДИМОЙ кнопки сабмита ('buy'|'sell'|''). ЕДИНЫЙ
 * источник правды направления (та же кнопка, что жмём): «Buy WOJAK»→buy, «Sell WOJAK»→sell. */
async function readFormSide(page) {
  return sideFromText(await readVisibleSubmitText(page));
}

/**
 * ПЕРЕКЛЮЧИТЬ форму на нужную сторону (Buy/Sell) НАДЁЖНО и с ПРОВЕРКОЙ по кнопке сабмита.
 * Раньше был один клик по `text=/^Sell$/i` с тихим catch: на cold-форме (после reload)
 * он не успевал/не находил вкладку → форма оставалась на Buy → sell блокировался M5
 * (продажа на MEXC не работала совсем). Теперь: цикл ретраев, на каждом — (A) клик по
 * env-селектору вкладки, (B) поиск в DOM ВИДИМОГО короткого элемента с точным словом
 * стороны (НЕ кнопка сабмита — do-submit исключён, ордер не жмём) и trusted-клик по нему,
 * с локализацией под язык интерфейса. Успех = кнопка сабмита показала нужную сторону.
 * @returns {Promise<boolean>} удалось ли встать на нужную сторону.
 */
async function ensureSide(page, wantSide, log) {
  if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
  const sel = wantSide === 'sell' ? SELECTORS.sellTab : SELECTORS.buyTab;
  const words = wantSide === 'sell'
    ? ['sell', 'продать', 'vender', 'verkaufen', 'vendre', 'vendi', 'sat', '卖', '卖出']
    : ['buy', 'купить', 'comprar', 'kaufen', 'acheter', 'compra', 'al', '买', '买入'];
  const attempts = Number(process.env.ARBI_MEXC_SIDE_ATTEMPTS || 5);
  for (let i = 0; i < attempts; i++) {
    // P0-2: поздний промо/риск-оверлей перехватывает клик по вкладке стороны — глушим
    // ПЕРЕД каждой попыткой (дёшево, зеркало фикса focusSearchInput).
    await dismissBlockingModal(page);
    await dismissOverlays(page);
    // A: селектор-вкладка (env/дефолт). На повторах — force (вдруг перекрыта анимацией).
    try { await page.click(sel, { timeout: Number(process.env.ARBI_MEXC_SIDE_CLICK_MS || 900), force: i > 0 }); } catch { /* пробуем DOM ниже */ }
    // Settle: дать React перерендерить кнопку сабмита после клика по вкладке ДО проверки.
    await page.waitForTimeout(Number(process.env.ARBI_MEXC_SIDE_SETTLE_MS || 120));
    if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
    // B: найти ВИДИМЫЙ короткий кликабельный элемент с точным словом стороны (кроме
    // кнопки сабмита do-submit — её НЕ жмём) и trusted-кликнуть.
    const marked = await page.evaluate((ws) => {
      const vis = (el) => el && el.offsetParent !== null && !/do-submit/i.test(String(el.className || ''));
      for (const el of Array.from(document.querySelectorAll('div,span,button,li,a,label')).filter(vis)) {
        const t = (el.textContent || '').trim().toLowerCase();
        // ТОЧНОЕ слово стороны: startsWith кликал чужие элементы — «buy crypto» (пункт
        // шапки) по 'buy', «alva» по турецкому 'al'. Вкладка стороны — ровно одно слово.
        if (t.length <= 10 && ws.some((w) => t === w)) { el.setAttribute('data-arbi-side', '1'); return true; }
      }
      return false;
    }, words).catch(() => false);
    if (marked) {
      await page.click('[data-arbi-side="1"]', { timeout: 500, force: true }).catch(() => {});
      await page.evaluate(() => { const e = document.querySelector('[data-arbi-side="1"]'); if (e) e.removeAttribute('data-arbi-side'); }).catch(() => {});
      if (await readFormSide(page) === wantSide) { page.__arbiSide = wantSide; return true; }
    }
    await page.waitForTimeout(250);
  }
  const ok = (await readFormSide(page)) === wantSide;
  if (ok) page.__arbiSide = wantSide; // кэш стороны актуален и на этом пути успеха
  return ok;
}

/**
 * ПРОГРЕВ формы БЕЗ выставления ордера — БЕЗОПАСНО, ничего не покупаем/продаём.
 * Грузит страницу пары, закрывает промо-оверлеи, дожидается готовности лимит-формы
 * (инпуты + активная кнопка сабмита = React догидрировался). Это и есть «холодная»
 * задержка (~несколько секунд), но здесь она платится В ФОНЕ, ДО ордера пользователя,
 * чтобы его ПЕРВЫЙ реальный ордер по этой паре пошёл по тёплому пути (~0.5-0.7с).
 */
async function warmupForm(context, pair, log) {
  // Тайминг прогрева (это и есть «первый поиск токена» при выборе в терминале). page —
  // сколько заняли ПОИСК вкладки + смена пары (getMexcPage: тут же будится замороженная
  // вкладка и идёт SPA-поиск, детальный разбор — в [поиск-тайминг]); form — догрузка формы.
  const tW0 = Date.now();
  const { page, cold } = await getMexcPage(context, pair, log);
  const tW1 = Date.now();
  // Akamai «Access Denied» (блок профиля/IP) — бэкофф + выход, не долбим биржу.
  if (await isMexcAccessDenied(page)) {
    noteMexcAccessDenied(log);
    return { ok: false, error: `MEXC заблокировал доступ (Access Denied, Akamai) — навигация к MEXC приостановлена.` };
  }
  // Пара 404-ит по прямой ссылке (делистнута/только через поиск) — прогревать нечего,
  // и НЕ долбим 9-секундными ожиданиями формы, которой не будет. Внятный ответ.
  if (await isMexcNotFound(page)) {
    log(`Прогрев пропущен: страница пары ${pair} на MEXC отдаёт 404 (токен делистнут/только через поиск)`);
    return { ok: false, notFound: true, error: `MEXC: страница пары ${pair} недоступна (404 по прямой ссылке).` };
  }
  await dismissOverlays(page);
  let inputs = await page.$$(SELECTORS.input);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: 1000 }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.input, { timeout: 9000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.input);
  }
  // Полей так и нет — формы на странице НЕТ. Ждать следом ещё 9 с кнопку сабмита
  // бессмысленно: она часть той же формы. Лог оператора 2026-09-20 (TRUU/MEXC):
  // `form=19903` — это ровно два таймаута подряд, после которых прогрев всё равно
  // отрапортовал «Форма прогрета», хотя греть было нечего. Молчаливого успеха на
  // пустом месте не бывает: 20 с профиль был занят впустую, а следующая заявка
  // ждала их в очереди (прогрев и ордер сериализованы в одном профиле).
  if (inputs.length < 2) {
    log(`Прогрев не удался: форма лимит-ордера ${pair} не догрузилась (полей ${inputs.length}) за ${Date.now() - tW1} мс`);
    log(`[прогрев-тайминг] page(поиск+вкладка)=${tW1 - tW0} form=${Date.now() - tW1} ИТОГО=${Date.now() - tW0}мс${cold ? ' [холодная]' : ''} [форма не догрузилась]`);
    return { ok: false, cold, error: `MEXC: форма лимит-ордера ${pair} не догрузилась (полей ${inputs.length}).` };
  }
  await page.waitForSelector(SELECTORS.submit, { state: 'visible', timeout: 9000 }).catch(() => {});
  // НЕ ждём enabled-состояния кнопки на ПУСТОЙ форме прогрева: если кнопка сабмита
  // без значений disabled, цикл ожидания крутил бы ~5с (25×200мс) ВПУСТУЮ, и
  // реальный ордер, пришедший следом, эти 5с ждал бы в очереди (warmup и ордер
  // сериализованы в одном профиле). Форма уже готова; enabled проверит executeIntent
  // ПОСЛЕ заполнения. Короткая догидрация React.
  await page.waitForTimeout(Number(process.env.ARBI_MEXC_WARMUP_SETTLE_MS || 250));
  await dismissOverlays(page);
  const tW2 = Date.now();
  {
    const lw = await loginWall(page);
    if (lw.wall) { log(`Нет входа в аккаунт MEXC в этом профиле (на форме: «${lw.text}») — прогрев невозможен`); return { ok: false, cold, loginRequired: true, error: loginRequiredError('MEXC') }; }
  }
  log(`Форма прогрета (${pair})${cold ? ' [была холодная]' : ''} — ордер НЕ ставился`);
  log(`[прогрев-тайминг] page(поиск+вкладка)=${tW1 - tW0} form=${tW2 - tW1} ИТОГО=${tW2 - tW0}мс${cold ? ' [холодная]' : ''}`);
  return { ok: true, cold };
}

/**
 * Исполняет ОДНО намерение в живой странице MEXC.
 *
 * @param {import('playwright').BrowserContext} context  контекст профиля аккаунта
 * @param {object} intent  { id, accountId, symbol, side, type, price, quantity, dryRun }
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{ok:boolean, orderId?:string, error?:string}>}
 */
async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  const pair = toMexcPair(intent.symbol);

  // v1: только limit (как и терминал-реплей). Market — отдельная вёрстка формы.
  if (intent.type !== 'limit' || intent.price == null) {
    return { ok: false, error: 'Стадия 3 v1: поддержан только limit-ордер с ценой' };
  }
  // IM-1: развернуть экспоненту (1.2e-7 → 0.00000012) и отсечь мусорные значения
  // ДО любого ввода в форму. Экспоненциальная строка в поле → биржа парсит неверно.
  const priceStr = formatDecimal(intent.price);
  const qtyStr = formatDecimal(intent.quantity);
  if (!isPlainPositive(priceStr) || !isPlainPositive(qtyStr)) {
    return { ok: false, error: `Некорректные цена/количество: price=${intent.price} qty=${intent.quantity}. Ордер НЕ отправлен.` };
  }
  intent = { ...intent, price: priceStr, quantity: qtyStr };

  const t0 = Date.now();
  let { page, cold } = await getMexcPage(context, pair, log);
  await ensureTabInFront(page, log); // скрытая вкладка = клики ждут кадров (см. pair-tabs)
  // Оператор 15.09: две заявки подряд сорвались в вкладке WOJAK, восстановленной при
  // старте в окне профиля (фокус на <body>, клавиши «набраны» за 35 мс = выброшены
  // скрытым виджетом), и прошли в свежей вкладке в своём окне. visibilityState тут
  // врал — проверяем ФАКТ (кадры): нет → вперёд → всё равно нет → эту вкладку под
  // ордера больше не берём и открываем паре свежую в своём окне.
  const tProbe = Date.now();
  if (!(await pageRenders(page))) {
    log(`Вкладка пары не рисует кадры (${Date.now() - tProbe} мс без rAF) — вывожу вперёд`);
    await page.bringToFront().catch(() => {});
    if (!(await pageRenders(page))) {
      page.__arbiNoInput = true;
      log(`Вкладка пары не рисует кадры даже после вывода вперёд — ввод в неё глотается; открываю паре свежую вкладку`);
      ({ page, cold } = await getMexcPage(context, pair, log));
    }
  }
  const tPage = Date.now();

  // Akamai «Access Denied» (блок профиля/IP) — ставим глобальный бэкофф и выходим,
  // чтобы не долбить биржу (это продлевает бан и мешает восстановлению).
  if (await isMexcAccessDenied(page)) {
    noteMexcAccessDenied(log);
    return { ok: false, error: `MEXC заблокировал доступ (Access Denied, Akamai) — профиль/IP под баном биржи. Смените IP прокси или подождите; навигация к MEXC приостановлена.` };
  }
  // Пара 404-ит по прямой ссылке (напр. PIN — торгуется только через поиск/делистнута):
  // форма не появится, дальше долбить бессмысленно. Внятная ошибка вместо срыва.
  if (await isMexcNotFound(page)) {
    return { ok: false, error: `MEXC: страница пары ${pair} недоступна (404 по прямой ссылке — токен делистнут или торгуется только через поиск на бирже). Ордер НЕ отправлен.` };
  }

  // Закрыть блокирующую модалку-ошибку от ПРОШЛОГО ордера (нехватка баланса/риск),
  // иначе ant-modal-v2 перехватит клики и завалит эту заявку.
  await dismissBlockingModal(page);
  // Закрыть промо-оверлеи (Market Movers и т.п.), которые перекрывают форму/кнопку.
  await dismissOverlays(page);

  const TAB_TIMEOUT = Number(process.env.ARBI_MEXC_TAB_TIMEOUT_MS || 400);

  // Быстрая проверка: лимит-форма уже готова? Если ≥2 инпутов есть — вкладку Limit
  // НЕ трогаем (в устойчивом состоянии это убирает главный тормоз — ожидание
  // отсутствующей/ненужной вкладки). Клик по Limit нужен только если формы ещё нет.
  let inputs = await page.$$(SELECTORS.input);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: TAB_TIMEOUT }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.input, { timeout: 8000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.input);
  }
  // M6: закрыть висящую модалку подтверждения ПРОШЛОГО ордера ДО заполнения/клика —
  // иначе confirmOrderModal в цикле клика подтвердила бы её (чужой ордер, ложный orderId).
  await dismissOrderModal(page, log);
  // Сторона (Buy/Sell): клик дорогой (~120-430мс). Пропускаем, если на ЭТОЙ вкладке
  // мы уже выставили нужную сторону и вкладку не переоткрывали (cold). Скрытый
  // браузер пользователь не трогает → активная сторона извне не меняется, поэтому
  // на тёплой форме при совпадении стороны повторный клик — чистая потеря времени.
  // На cold (новая/сменили пару) кликаем всегда: форма свежая, сторона неизвестна.
  // Сторона (Buy/Sell): НАДЁЖНОЕ переключение с проверкой по кнопке сабмита (ensureSide).
  // На cold или несовпадении — переключаем; если не удалось встать на нужную сторону,
  // НЕ отправляем ордер (иначе sell ушёл бы как buy) и дампим кандидаты-вкладки, чтобы
  // при необходимости пиновать ARBI_MEXC_SEL_BUY/SELL под вёрстку биржи.
  // Условие дешёвое (в памяти): cold или сторона в памяти не та. Лишний DOM-read стороны
  // на КАЖДЫЙ ордер убран — __arbiSide сбрасывается при смене пары/прогреве, а если он
  // всё же разойдётся с формой, ошибочную сторону поймает M5-страж перед самым кликом.
  if (cold || page.__arbiSide !== intent.side) {
    const ok = await ensureSide(page, intent.side, log);
    if (!ok) {
      const btnText = await readVisibleSubmitText(page);
      // Подробный снимок РАСКЛАДКИ: кнопки сабмита (текст/видимость/координаты), видимые
      // числовые поля (индекс/координаты/значение) и вкладки Buy/Sell. По координатам видно,
      // табовая раскладка (одна кнопка, переключатель) или split (Buy-панель + Sell-панель).
      const layout = await page.evaluate((sel) => {
        const rc = (el) => { const r = el.getBoundingClientRect(); return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) }; };
        const vis = (el) => el && el.offsetParent !== null && el.getBoundingClientRect().width > 2;
        const submits = Array.from(document.querySelectorAll(sel)).slice(0, 8).map((b) => ({ t: (b.textContent || '').trim().slice(0, 16), v: vis(b), ...rc(b) }));
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 8).map((i, idx) => ({ i: idx, val: String(i.value || '').slice(0, 8), ...rc(i) }));
        const tabs = Array.from(document.querySelectorAll('[class*="actions_buyBtn__"],[class*="actions_sellBtn__"]')).slice(0, 6).map((b) => ({ t: (b.textContent || '').trim().slice(0, 10), v: vis(b), ...rc(b) }));
        return { submits, inputs, tabs };
      }, SELECTORS.submit).catch(() => ({}));
      console.log('[mexc-exec] [diag layout] ' + JSON.stringify(layout).slice(0, 1400));
      return { ok: false, error: `MEXC: не удалось переключить форму на «${intent.side}» (осталась «${btnText}») — ордер НЕ отправлен.` };
    }
  }
  const tTabs = Date.now();
  const forceClickOn = (process.env.ARBI_MEXC_INPUT_FORCE_CLICK || '1') !== '0';
  // Разбор фазы fill по шагам (#66: тюнить только по замеру). Счётчики локальны для
  // executeIntent; typeNumber принимает их отдельным необязательным параметром.
  const fm = { read: 0, readN: 0, vis: 0, visN: 0, click: 0, point: 0, clear: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0, btn: 0 };
  // Разбор фазы submit+resp (#66): зачистки / модалка подтверждения / клик / ожидание / медленная ветка.
  const ms = { clean: 0, confirm: 0, click: 0, wait: 0, slow: 0, retry: 0 };

  if (inputs.length < 2) {
    return { ok: false, error: `Форма ордера MEXC не распознана (найдено инпутов: ${inputs.length}). Проверьте ARBI_MEXC_SEL_INPUT.` };
  }
  {
    const lw = await loginWall(page);
    if (lw.wall) { log(`Нет входа в аккаунт MEXC в этом профиле (на форме: «${lw.text}») — заявка НЕ отправлена`); return { ok: false, loginRequired: true, error: loginRequiredError('MEXC') }; }
  }
  log(`Заполняю форму: price=${intent.price} amount=${intent.quantity} (${intent.side})${cold ? ' [холодная]' : ''}`);
  // СТРОГАЯ проверка ФАКТИЧЕСКИХ значений полей (как на XT/BingX). Нельзя опираться
  // только на isSubmitReady: MEXC держит кнопку сабмита активной даже при устаревшем/
  // неполном КОЛИЧЕСТВЕ (быстрый ввод не всегда прижимает это поле) → ордер мог уйти с
  // ЧУЖИМ количеством от прошлой заявки. Поэтому сверяем сами значения полей, добиваем
  // клавиатурой то, что не прижалось, а ПЕРЕД кликом строго проверяем близость к нужным
  // (иначе ордер НЕ отправляется).
  const wantPrice = String(intent.price);
  let wantQty = String(intent.quantity);
  const knownDec = MEXC_QTY_DEC.get(pair);
  const shortQty = truncateQty(wantQty, knownDec);
  if (shortQty !== wantQty) {
    wantQty = shortQty;
    log(`Количество усечено до ${knownDec} зн. по прошлому ответу MEXC: ${wantQty}`);
  }
  const wantP = parseFloat(wantPrice);
  const wantQ = parseFloat(wantQty);
  // ТОЛЬКО ВИДИМЫЕ поля: MEXC держит в DOM несколько mx-motion-input-inner (разные
  // панели/стороны); скрытые сбивали индексацию и приводили к клику по НЕВИДИМОМУ полю
  // (30с зависание на WOJAK). Видимые = поля активной формы: [0]=цена,[1]=кол-во,[2]=всего.
  const readVals = async () => {
    const _s = Date.now();
    try { return await page.$$eval(SELECTORS.input, (els) => els.filter((e) => e.offsetParent !== null).map((e) => e.value)); }
    finally { fm.read += Date.now() - _s; fm.readN++; }
  };
  const visibleInputs = async () => {
    const _s = Date.now();
    const all = await page.$$(SELECTORS.input);
    // isVisible по всем хэндлам ОДНИМ заходом, а не россыпью (#35): последовательный
    // цикл — это N круговых CDP-рейсов подряд (MEXC держит в DOM несколько
    // mx-motion-input-inner), и вызывается он дважды за попытку заполнения. Promise.all
    // кладёт их в один тик: порядок и результат те же, меняется только число ожиданий.
    const flags = await Promise.all(all.map((h) => h.isVisible().catch(() => false)));
    const vis = all.filter((_, i) => flags[i]);
    fm.vis += Date.now() - _s; fm.visN++;
    return vis;
  };
  // Хэндлы видимых полей на ОДНУ попытку заполнения: форма между цена→количество
  // не пересобирается, а каждый лишний visibleInputs — это полный обход
  // mx-motion-input-inner с проверкой видимости по каждому (в замере 2026-09-21
  // «видимость=164x2»). Кэш сбрасывается на следующей попытке: если ввод не
  // прижался, форму мог перерисовать React, и хэндлы надо перечитать. Устаревший
  // хэндл не опасен — click по нему бросает, и typeNumber уходит в свою ветку
  // с повтором, а перед сабмитом всё равно стоит строгая сверка значений.
  let visCache = null;
  const setField = async (idx, val) => {
    if (!visCache) visCache = await visibleInputs();
    if (visCache[idx]) await typeNumber(page, visCache[idx], val, { st: fm });
  };
  const settleMs = Number(process.env.ARBI_MEXC_FILL_SETTLE_MS || 40);
  const logFill = () => log(`[timing fill] клик-в-поле=${fm.click}(наведение=${fm.point} очистка=${fm.clear}${fm.fallback ? ` срыв-клика=${fm.fallback}` : ''}${forceClickOn ? ' force' : ''}) набор=${fm.keys}(${fm.keysN}зн/${fm.typeN}пол) чтение=${fm.read}x${fm.readN} видимость=${fm.vis}x${fm.visN} кнопка=${fm.btn}`);
  // Строгая: поле уже содержит НУЖНОЕ значение в пределах шага последнего разряда
  // (MEXC усекает по шагу токена) — но НЕ принимает близкое-но-ЧУЖОЕ значение прошлого
  // ордера. Именно это отличает её от closeEnough (широкая, ±%, для усадки по балансу).
  // fieldFresh — единая строгая проверка из order-utils (M3: допуск от want, см. там).
  const closeEnough = (v, want) => {
    const f = parseFloat(String(v).replace(/[,\s]/g, ''));
    return isFinite(f) && want > 0 && f <= want * 1.03 && f >= want * 0.85;
  };
  const bothFresh = (v) => fieldFresh(v[0], wantP) && fieldFresh(v[1], wantQ);
  if (cold) {
    // ХОЛОДНАЯ форма (только открыли/сменили пару): setReactInput на «сырой» React
    // не регистрируется. Надёжный посимвольный ввод. Ждём готовность кнопки перед вводом.
    await page.waitForSelector(SELECTORS.submit, { state: 'visible', timeout: 10000 }).catch(() => {});
    // P1-2: залипший промо/риск-оверлей перехватывает клики по полям холодной формы.
    await dismissOverlays(page);
    // Заполняем ВИДИМЫЕ поля активной формы (не скрытые из других панелей).
    const vi = await visibleInputs();
    await typeNumber(page, vi[0] || inputs[0], intent.price, { st: fm });
    await typeNumber(page, vi[1] || inputs[1], intent.quantity, { st: fm });
    // Дождаться, пока форма РЕАЛЬНО готова (кнопка активна): на только что загруженной
    // странице React ещё «сырой», клик слишком рано не порождает order/place. Шаг 100мс
    // (было 200) — выходим по готовности раньше, потолок ~2.5с вместо 5с.
    // P2: пороги вынесены в env (без пересборки, если готовность формы окажется дольше).
    const coldReadyTries = Number(process.env.ARBI_MEXC_COLD_READY_TRIES || 25);
    const coldReadyStepMs = Number(process.env.ARBI_MEXC_COLD_READY_STEP_MS || 100);
    for (let i = 0; i < coldReadyTries; i++) {
      if (await isSubmitReady(page)) break;
      await new Promise((r) => setTimeout(r, coldReadyStepMs));
    }
  }
  let finalVals = [];
  // Быстрый ввод (fastSetInputs) для MEXC по умолчанию ОТКЛЮЧЁН. Причина: MEXC
  // завязан на ПОВЕДЕНЧЕСКИЙ анти-бот (SDK trochilus/watchman) — кнопка сабмита
  // «вооружается» только ДОВЕРЕННЫМ вводом (реальные события клавиатуры/мыши через
  // CDP, isTrusted=true). fastSetInputs — нативный сеттер + dispatchEvent (isTrusted=
  // false) → поля визуально заполнены и строгая fieldFresh проходит, но клик по кнопке
  // НЕ порождает order/place (ловили: «Поля заполнены … order/place не ушёл»).
  // Поэтому MEXC заполняем ТОЛЬКО доверенным typeNumber (цикл ниже). Включить залп
  // осознанно: ARBI_MEXC_FAST_FILL=1.
  if ((process.env.ARBI_MEXC_FAST_FILL || '0') === '1' && !cold) {
    await fastSetInputs(page, intent.price, intent.quantity).catch(() => {});
    await page.waitForTimeout(settleMs);
  }
  finalVals = await readVals().catch(() => []);
  // Добиваем клавиатурой ЛЮБОЕ поле, которое ещё не содержит НУЖНОГО значения (строгая
  // проверка — чтобы не оставить количество прошлого ордера). На cold после typeNumber
  // значения уже должны быть свежими → цикл не сработает.
  for (let attempt = 0; attempt < 3 && !bothFresh(finalVals); attempt++) {
    if (!fieldFresh(finalVals[0], wantP)) {
      await setField(0, wantPrice);
      // diag: значение поля цены СРАЗУ после ввода (до settle). Если тут наш ${wantPrice},
      // а в «Поля заполнены» другое — биржа СНАПит цену (price cage/тик). Если тут сразу
      // чужое — проблема ввода. По этому чиним прицельно (цена ушла не туда — деньги).
      // По умолчанию ВЫКЛЮЧЕН: вопрос закрыт замерами 19-21.09 (поле всегда принимало
      // нашу цену «сразу»), а лишнее чтение стоит места в каждой заявке. Включается
      // ARBI_MEXC_DIAG_PRICE=1, когда цена снова окажется под подозрением.
      if (attempt === 0 && process.env.ARBI_MEXC_DIAG_PRICE === '1') {
        const jt = (await readVals().catch(() => []))[0];
        console.log(`[mexc-exec] [diag цена] ввёл «${wantPrice}» → поле сразу «${jt}» (хотели ${wantP})`);
      }
    }
    if (!fieldFresh(finalVals[1], wantQ)) await setField(1, wantQty);
    await page.waitForTimeout(settleMs);
    finalVals = await readVals().catch(() => []);
    // Поля не приняли ввод с первого захода — самое частое объяснение в проде —
    // промо/риск-оверлей поверх формы: клик уходит в него, поле не получает фокус,
    // набор летит в никуда, и в поле остаётся ПОДСТАВЛЕННАЯ БИРЖЕЙ рыночная цена.
    // Перед повтором убираем перехватчиков теми же зачистками, что и на холодной
    // форме. На успешном пути (bothFresh с первого раза) сюда не заходим.
    if (!bothFresh(finalVals)) { await dismissOverlays(page); await dismissBlockingModal(page); visCache = null; }
  }
  // Урок точности: чему биржа нас научила этим заполнением. Учимся ТОЛЬКО когда
  // совпала ЦЕЛАЯ часть — тогда MEXC отрезал именно точность. Разошлась целая
  // часть = усадка по доступному балансу, и урок «столько-то знаков» был бы
  // выдумкой (#54: догадка не имеет права стать фактом). Хвостовая точка
  // («14003111802.») — то же усечение до нуля знаков, поэтому её снимаем.
  {
    const lesson = learnQtyDecimals(finalVals[1], wantQty);
    if (lesson != null) MEXC_QTY_DEC.set(pair, lesson);
  }
  // Предохранитель ПЕРЕД кликом. CR-3: ЦЕНА — строгая (fieldFresh, ±1 шаг разряда),
  // НЕ closeEnough: широкий ±15% на цене пропускал бы sell на 15% ниже рынка
  // (значение прошлого ордера, если добивание сорвалось). Широкий допуск оставлен
  // ТОЛЬКО количеству (усадка по доступному балансу — легитимна).
  if (!fieldFresh(finalVals[0], wantP) || !closeEnough(finalVals[1], wantQ)) {
    console.log('[mexc-exec] [diag заполнение] ' + JSON.stringify({ finalVals, wantPrice, wantQty }));
    logFill();
    // Количество усеклось до 0 при корректной цене — почти всегда означает, что
    // ДОСТУПНЫЙ баланс = 0: монета уже продана или ЗАБЛОКИРОВАНА в открытой заявке
    // (ловили на ALVA: заявка выставилась, а повторные sell-интенты MEXC усекал в 0).
    // Понятная причина вместо загадочного «поля не совпали».
    // ТОЛЬКО на продаже и только когда цена принята СТРОГО (fieldFresh): на покупке
    // количество не ограничено монетой, а «цена близко, количество пусто» на любой
    // стороне — это перехваченный ввод (лог 15.09 22:01: системное окно логина прокси,
    // поля ["0.00000004899","",""] → ложное «баланс для продажи = 0» на BUY).
    const qtyZero = parseFloat(String(finalVals[1] || '0').replace(/[,\s]/g, '')) === 0;
    if (intent.side === 'sell' && qtyZero && fieldFresh(finalVals[0], wantP)) {
      return { ok: false, error: `MEXC: доступный баланс для продажи = 0 (монета уже продана или заблокирована в открытой заявке — проверьте открытые ордера). Заявка НЕ отправлена.` };
    }
    // ЦЕНА не приняла наш ввод — разделяем два РАЗНЫХ отказа, которые до сих пор
    // выглядели одинаково. Если после клика фокус не на поле ввода, значит клик и
    // клавиши вообще не доходят до страницы: поверх окна профиля висит СИСТЕМНОЕ
    // окно Chromium (запрос логина/пароля прокси, скачивание, разрешение) — оно
    // живёт в браузере, а не в DOM, поэтому ни dismissOverlays, ни Playwright его
    // не видят и закрыть не могут. Пять сорванных заявок 2026-09-07 21:51–21:52
    // были именно этим (в поле оставалась подставленная биржей рыночная цена).
    if (!fieldFresh(finalVals[0], wantP)) {
      // Факты вместо догадки (#54/#58, оператор 15.09: «мекс не ставит ордера» при
      // фокусе на <body>): текст видимой кнопки формы (у разлогиненного MEXC там
      // «Log In»), disabled/readOnly поля цены, видимые модалки и идут ли кадры
      // (rAF за 200 мс — окно свёрнуто/скрыто не рисует, ввод глотается).
      const d = await page.evaluate((sel) => new Promise((resolve) => {
        const vis = (e) => e && e.offsetParent !== null && e.getBoundingClientRect().width > 2;
        const inp = Array.from(document.querySelectorAll(sel.input)).filter(vis)[0];
        const btn = Array.from(document.querySelectorAll(sel.submit)).filter(vis)[0];
        const out = {
          focus: (document.activeElement && document.activeElement.tagName) || '',
          btn: btn ? (btn.textContent || '').trim().slice(0, 30) : '(нет)',
          disabled: !!(inp && (inp.disabled || inp.readOnly)),
          modals: Array.from(document.querySelectorAll('[role="dialog"],[class*="ant-modal"],[class*="odal-v2"]')).filter(vis).length,
          frames: false,
        };
        requestAnimationFrame(() => { out.frames = true; resolve(out); });
        setTimeout(() => resolve(out), 200);
      }), { input: SELECTORS.input, submit: SELECTORS.submit }).catch(() => null);
      if (d && /log ?in|sign ?in|войти|вход|登录/i.test(d.btn)) {
        return { ok: false, error: `MEXC: в этом профиле вы НЕ вошли в аккаунт биржи — на форме кнопка «${d.btn}» вместо Buy/Sell. Откройте окно профиля, войдите на MEXC и повторите. Заявка НЕ отправлена.` };
      }
      if (!d || d.focus !== 'INPUT') {
        const facts = d ? ` [факты: кнопка=«${d.btn}» поле_заблокировано=${d.disabled} модалок=${d.modals} кадры=${d.frames ? 'идут' : 'НЕТ'}]` : '';
        return { ok: false, error: `MEXC: клик и ввод не доходят до страницы (после клика фокус на <${((d && d.focus) || '?').toLowerCase()}>, в поле цены осталось «${finalVals[0]}»).${facts} Если кадры НЕТ — окно профиля свёрнуто/скрыто, разверните его; если модалка — закройте её; иначе поверх окна системное окно Chromium (логин прокси) — закройте его («Отмена»). Заявка НЕ отправлена.` };
      }
    }
    return { ok: false, error: `Поля не совпали с ордером: хотели цена=${wantPrice} кол-во=${wantQty}, в форме ${JSON.stringify(finalVals)}. Ордер НЕ отправлен.` };
  }
  // M5: ВЕРИФИКАЦИЯ СТОРОНЫ из DOM перед кликом. Клик по вкладке Buy/Sell (выше) мог
  // молча не сработать (таймаут → catch), и ордер ушёл бы с ЧУЖОЙ стороной (sell как
  // buy). Кнопка сабмита MEXC несёт сторону в тексте («Buy WOJAK»/«Comprar WOJAK»…).
  // Блокируем ТОЛЬКО явно ПРОТИВОПОЛОЖНУЮ сторону (ровно тот дефект, что ловим).
  // Нераспознанный текст (язык вне словаря) — предупреждение, НЕ блок: иначе любой
  // новый язык интерфейса останавливал бы все MEXC-ордера (регрессия класса M7).
  const _sBtn = Date.now();
  const btnText = await readVisibleSubmitText(page);
  fm.btn = Date.now() - _sBtn;
  const domSide = sideFromText(btnText);
  if (domSide && domSide !== intent.side) {
    return { ok: false, error: `MEXC: сторона на форме (${domSide}) ≠ запрошенной (${intent.side}) — ордер НЕ отправлен. Кнопка: «${btnText}».` };
  }
  if (!domSide) log(`M5: сторона по кнопке «${btnText}» не распознана (язык вне словаря?) — продолжаю без DOM-сверки стороны`);
  log(`Поля заполнены: ${JSON.stringify(finalVals)} (хотели ${wantPrice}/${wantQty})${domSide ? `, сторона ${domSide} подтверждена` : ''}`);
  const tFill = Date.now();
  logFill();

  // CR-1 (learn-on-confirm): строгая сверка токена на странице с базой интента.
  // Токены с displayName≠coinName (GENSYN на бирже = «AI») легитимны — оператор
  // подтверждает их разово в терминале, тогда сюда приходит hints.coinAlias и блока
  // нет. Без алиаса (клон ART/ARTX ИЛИ ещё не подтверждённый) — блок со структурным
  // pairMismatch: терминал покажет «это верный токен?», сохранит алиас и повторит.
  // Проверка ДО подписки листенеров ниже → cleanup не нужен.
  const base = String(pair).split('_')[0];
  const pageBase = await page.evaluate(() => {
    for (const h of document.querySelectorAll('h1')) {
      const m = (h.textContent || '').trim().match(/([A-Za-z0-9一-鿿]+)\s*[/\-]\s*[A-Za-z]{2,}/);
      if (m) return m[1];
    }
    return null;
  }).catch(() => null);
  const gate = pairGate(pageBase, base, intent.hints && intent.hints.coinAlias);
  if (gate.block) {
    // Кэш пары вкладки НЕДЕЙСТВИТЕЛЕН: страница показала не тот/нечитаемый токен — иначе
    // cachedPairWarm вечно отдавал бы её «тёплой», и следующий интент того же токена
    // повторял бы блок без ре-навигации (застревание на mismatch/unreadable).
    page.__arbiPair = null;
  }
  if (gate.block && gate.reason === 'unreadable') {
    return { ok: false, error: `Не удалось прочитать пару на странице MEXC (ожидался ${base}) — ордер НЕ отправлен. Обновите страницу пары и повторите.` };
  }
  if (gate.block) {
    return { ok: false, pairMismatch: true, pageBase, wanted: base,
      error: `Биржа показывает пару ${pageBase}/…, а ордер для ${base}. Подтвердите, что это верный токен.` };
  }
  if (gate.reason === 'alias') log(`M8: MEXC — ордер по ${base} пропущен по подтверждённому алиасу «${pageBase}» (доверенный реестр терминала для этой пары)`);

  // Защита от ЗАДВОЕНИЯ (зеркало XT/BingX): следим, УШЁЛ ли реальный POST order/place,
  // и постоянно захватываем его ОТВЕТ. Раньше MEXC повторял клик вслепую — при
  // медленном ответе прокси повтор мог задвоить ордер; а повторный waitForResponse
  // пропускает ответ, пришедший до новой подписки (ложная «не ушёл»).
  let orderReqFired = false;
  // CR-2: множество POST-запросов ордера, реально ушедших В ЭТОЙ попытке. Ответ
  // захватываем ТОЛЬКО на запрос из этого множества — иначе на тёплой вкладке
  // capturedOrderResp мог поймать ПОЗДНИЙ ответ ПРОШЛОГО ордера (чужой orderId,
  // ложный успех). Листенеры подписаны после t0, так что запрос прошлого ордера,
  // ушедший до подписки, сюда не попадёт.
  const firedReqs = new Set();
  const onReq = (req) => { try { if (req.method() === 'POST' && ORDER_PLACE_RE.test(req.url())) { orderReqFired = true; firedReqs.add(req); } } catch { /* игнор */ } };
  page.on('request', onReq);
  let capturedOrderResp = null;
  const onRespCap = (r) => { try { if (!capturedOrderResp && firedReqs.has(r.request())) capturedOrderResp = r; } catch { /* игнор */ } };
  page.on('response', onRespCap);
  const offListeners = () => { page.off('request', onReq); page.off('response', onRespCap); };

  // Один клик + ожидание ответа. Если ответа нет за attemptMs — возвращаем null
  // (order/place НЕ ушёл — значит клик не отправил ордер, повтор безопасен).
  const clickAndWait = async (attemptMs) => {
    // v0.4.119 (скорость, замер оператора 2026-09-07:
    // submit+resp=9506мс из 18332): ожидание ответа ВООРУЖАЛОСЬ ЗДЕСЬ — до
    // dismissOverlays / dismissBlockingModal / confirmOrderModal. Все они
    // ходят в страницу через прокси, поэтому к моменту РЕАЛЬНОГО клика от
    // бюджета attemptMs оставались крохи: `waitForResponse` истекал не
    // потому, что биржа молчит, а потому, что бюджет съели зачистки. Дальше
    // внешний код видел «ответа нет», решал, что клик не отправил ордер, и
    // гонял весь блок повторно — те самые ~7 секунд второго прохода.
    //
    // Теперь ожидание вооружается ПРЯМО перед кликом (ниже), и attemptMs —
    // честный бюджет ответа биржи. Ничего не теряется: запрос и ответ ордера
    // ловят page-листенеры onReq/onRespCap (выставлены до этой функции) в
    // orderReqFired/capturedOrderResp, и ветка «POST уже ушёл» читает именно
    // их. Константы не трогаю — правится причина, а не таймаут (#66).
    let respOrNull = null;
    let _t = Date.now();
    // ПРЯМО перед кликом закрываем промо-оверлеи («Market Movers» и т.п.) и окно
    // риска/ошибки: они всплывают УЖЕ ПОСЛЕ заполнения формы и перехватывали trusted-
    // клик — order/place не уходил (ловили на ALVA: 3 срыва подряд с «Market Movers»
    // в диагностике). Один вызов в начале ордера не спасает — попап поздний.
    await dismissOverlays(page);
    await dismissBlockingModal(page);
    ms.clean += Date.now() - _t; _t = Date.now();
    // Если от прошлой попытки осталась модалка подтверждения — сперва подтвердить её,
    // иначе ant-modal-v2 перехватит клик по сабмиту (page.click висит 5с → падает).
    // ГОНКА CDP: клик по Confirm сам отправляет order/place, но событие 'request'
    // долетает в Node асинхронно — orderReqFired в момент проверки ниже мог ещё не
    // выставиться → повторный клик сабмита ЗАДВОИЛ бы ордер (модалка после галки
    // «No more reminders» больше не появляется — второй POST ушёл бы напрямую).
    // Поэтому после РЕАЛЬНОГО клика по Confirm даём событию долететь.
    if (await confirmOrderModal(page, log)) {
      for (let i = 0; i < 6 && !orderReqFired; i++) await page.waitForTimeout(100);
    }
    ms.confirm += Date.now() - _t; _t = Date.now();
    // CR-2: если POST ордера УЖЕ ушёл (мог уйти, пока закрывали модалки/подтверждали) —
    // повторный клик ЗАДВОИТ ордер. Не кликаем: ждём захваченный ответ и возвращаем его.
    if (orderReqFired) {
      let cap = capturedOrderResp;
      for (let i = 0; !cap && i < Math.ceil(attemptMs / 100); i++) { await page.waitForTimeout(100); cap = capturedOrderResp; }
      return cap;
    }
    // Доверенный клик по ВИДИМОЙ кнопке сабмита (активной стороны — неактивная скрыта в
    // DOM). Короткий таймаут + catch: модалка не должна подвесить весь ордер на 5с.
    // Ожидание ответа вооружаем ПЕРЕД самым кликом (см. комментарий выше):
    // раньше бюджет утекал в зачистку оверлеев до клика.
    respOrNull = page
      .waitForResponse((r) => firedReqs.has(r.request()), { timeout: attemptMs })
      .then((r) => r, () => null);
    // force (по умолчанию, ARBI_MEXC_INPUT_FORCE_CLICK=0 выключает): на этой странице
    // проверка актуальности Playwright стабильно не сходится (поля — срыв на каждом
    // ордере до 0.4.129), кнопка сабмита — тот же DOM и тот же анти-бот. Локатор уже
    // берёт только :visible; промах ловится ответом биржи/медленной веткой ниже.
    await visibleSubmit(page).click({ timeout: 3000, noWaitAfter: true, force: forceClickOn }).catch(() => {});
    ms.click += Date.now() - _t; _t = Date.now();
    // Ответ за ~1.2с? Иначе — подтверждаем модалку ордера (широкий селектор) и ждём.
    let r = await Promise.race([
      respOrNull,
      new Promise((res) => setTimeout(() => res('__slow__'), 1200)),
    ]);
    ms.wait += Date.now() - _t; _t = Date.now();
    if (r === '__slow__') {
      ms.retry++;
      // Поздний промо/риск-попап мог перехватить клик — закрываем и подтверждаем
      // модалку ордера (dismissOverlays модалку ордера НЕ трогает — отфильтрована).
      await dismissOverlays(page);
      await dismissBlockingModal(page);
      // Та же гонка CDP, что выше: после клика по Confirm ждём долёта 'request',
      // прежде чем решать про повторный клик сабмита (иначе дубль).
      if (await confirmOrderModal(page, log)) {
        for (let i = 0; i < 6 && !orderReqFired; i++) await page.waitForTimeout(100);
      }
      // P1-1: ордер ВСЁ ЕЩЁ не ушёл (оверлей перехватил первый клик по сабмиту) —
      // повторный клик по видимой кнопке нужной стороны. Guard orderReqFired: если POST
      // уже ушёл (мог уйти пока закрывали модалки), повтор ЗАДВОИТ ордер — не кликаем.
      if (!orderReqFired) {
        await visibleSubmit(page).click({ timeout: 1500, noWaitAfter: true, force: forceClickOn }).catch(() => {});
      }
      r = await respOrNull;
      ms.slow += Date.now() - _t;
    }
    return r;
  };

  // Доверенный клик по кнопке сабмита + ОДИН повтор, если ордер не ушёл
  // (клик иногда «не регистрируется» / промах → order/place не летит).
  log('Нажимаю кнопку ордера (trusted-клик)...');
  let resp = await clickAndWait(Number(process.env.ARBI_MEXC_RESP_TIMEOUT_MS || 2500));
  if (!resp) {
    if (orderReqFired) {
      // POST УЖЕ ушёл — повтор клика ЗАДВОИТ ордер. Ждём ответ через захват листенера.
      log('Запрос ордера УЖЕ ушёл — ответ медленный, жду без повтора (не дублируем)');
      resp = capturedOrderResp;
      for (let i = 0; !resp && i < 80; i++) { // до 8с, шаг 100мс
        await page.waitForTimeout(100);
        resp = capturedOrderResp;
      }
    } else {
      log('Ответа нет — повтор клика (первый ордер не отправил)');
      resp = await clickAndWait(6000);
    }
  }
  if (!resp && capturedOrderResp) resp = capturedOrderResp; // последний шанс — захваченный ответ
  offListeners();
  // POST ордера ушёл, но ответ не получен — заявка, вероятно, стоит на бирже.
  if (!resp && orderReqFired) {
    return {
      ok: false,
      // CR-6: НЕ «точно не выставлено», а НЕОПРЕДЕЛЁННОСТЬ — структурный флаг, чтобы
      // терминал НЕ авторетраил (риск дубля), а показал «проверьте открытые ордера».
      ambiguous: true,
      error: 'Запрос ордера отправлен на MEXC, но ответ не получен (медленный прокси). Заявка, вероятно, ВЫСТАВЛЕНА — проверьте «Открытые ордера» перед повтором. Повторная отправка не выполнялась (защита от дублирования).',
    };
  }

  if (!resp) {
    // Диагностика: что на странице держит ордер (модалка? её кнопки? текст?).
    const diag = await page.evaluate(() => {
      const vis = (el) => el && el.offsetParent !== null;
      const dialogs = Array.from(document.querySelectorAll('[role="dialog"],[class*="odal"],[class*="ialog"],[class*="opup"]'))
        .filter(vis).map((el) => ({
          text: (el.innerText || '').replace(/\s+/g, ' ').slice(0, 160),
          buttons: Array.from(el.querySelectorAll('button')).map((b) => (b.innerText || '').trim()).filter(Boolean).slice(0, 6),
        })).slice(0, 3);
      return { dialogs };
    }).catch(() => ({ dialogs: [] }));
    console.log('[mexc-exec] [diag таймаут] ' + JSON.stringify(diag));
    // Закрыть блокирующую модалку-ошибку (иначе заблокирует следующий ордер) и
    // вернуть понятную причину; кнопки модалки в diag выше — если подтверждение не
    // сработало, по ним подберём точный ARBI_MEXC_SEL_CONFIRM.
    const modalText = (diag.dialogs || []).map((d) => d.text).join(' | ');
    const closed = await dismissBlockingModal(page);
    if (/insufficient|not enough|недостаточн/i.test(modalText + ' ' + (closed.text || ''))) {
      return { ok: false, error: `MEXC отклонил: недостаточно баланса для ордера.` };
    }
    return {
      ok: false,
      error: `order/place не ушёл. Модалки/кнопки: ${JSON.stringify(diag.dialogs).slice(0, 280)}`,
    };
  }

  const tResp = Date.now();
  log(`[timing submit] зачистки=${ms.clean} подтв-модалка=${ms.confirm} клик=${ms.click} ожидание=${ms.wait}${ms.retry ? ` медленная-ветка=${ms.slow}` : ''}`);
  // Тайминг по фазам — чтобы видеть, где уходит время (цель ≤500мс на тёплой странице).
  log(`[timing] page=${tPage - t0} tabs=${tTabs - tPage} fill=${tFill - tTabs} submit+resp=${tResp - tFill} ИТОГО=${tResp - t0}мс`);

  const status = resp.status();
  let json = null;
  try { json = await resp.json(); } catch { /* не JSON */ }
  // Конверт MEXC: { code:200, msg:"success", data:"<orderId>" }.
  const okCode = json && (json.code === 200 || json.code === 0);
  if (status >= 200 && status < 300 && okCode) {
    const orderId = typeof json.data === 'string' ? json.data
      : (json.data && json.data.orderId) ? String(json.data.orderId)
      : (json.orderId ? String(json.orderId) : null);
    if (!orderId) return { ok: false, error: `success, но нет orderId: ${JSON.stringify(json).slice(0, 160)}` };
    log(`Ордер выставлен: ${orderId}`);
    return { ok: true, orderId };
  }
  const msg = json ? String(json.msg || json.message || json.code) : `HTTP ${status}`;
  return { ok: false, error: `MEXC отклонил ордер: ${String(msg).slice(0, 200)}` };
}

/**
 * Отмена ВСЕХ открытых ордеров через нативную кнопку биржи «Cancel all» — для
 * web-only токенов, которые нельзя отменить по API. Навигируем на пару и жмём кнопку
 * (текст EN/RU + класс, env-переопределяемо), затем подтверждаем модалку, если есть.
 */
async function cancelAllOrders(context, pair, log) {
  const { page } = await getMexcPage(context, pair, log);
  await dismissOverlays(page);
  await dismissBlockingModal(page);
  const sel = process.env.ARBI_MEXC_SEL_CANCEL_ALL;
  // MEXC: кнопка — <span>Cancel All</span> (НЕ button) → getByText ловит и span, и button.
  const btn = sel ? page.locator(sel).first()
    : page.getByText(/^\s*(cancel all|отменить\s+вс[её]|отмена всех)\s*$/i).first();
  try { await btn.waitFor({ state: 'visible', timeout: 8000 }); }
  catch { return { ok: false, error: 'Кнопка «Отменить все» не найдена (задайте ARBI_MEXC_SEL_CANCEL_ALL).' }; }
  // Клик ОБЯЗАН пройти: проглоченный сбой + ok:true = терминал считает ордера
  // отменёнными, хотя они висят (web-only нельзя отменить по API — это единственный путь).
  try { await btn.click({ timeout: 4000 }); }
  catch (e) { return { ok: false, error: `Клик по «Отменить все» не прошёл: ${String(e.message).slice(0, 80)} — ордера НЕ отменены.` }; }
  // Подтверждение отмены (MEXC «Confirm», XT «OK»): якорный матч — НЕ трогаем «Отмена».
  // Жмём СРАЗУ по появлению кнопки (force → без ожидания анимации/стабильности модалки),
  // чтобы отмена всех ордеров проходила быстрее. Ждём только visible (короткий таймаут).
  const confirmBtn = page.locator('[role="dialog"] button,[class*="modal" i] button')
    .filter({ hasText: /^\s*(confirm|подтверд\w*|ok|да|yes)\s*$/i }).first();
  try {
    await confirmBtn.waitFor({ state: 'visible', timeout: Number(process.env.ARBI_MEXC_CANCEL_CONFIRM_MS || 2500) });
    await confirmBtn.click({ timeout: 1200, force: true, noWaitAfter: true });
  } catch { /* модалки подтверждения не было — MEXC отменил без неё */ }
  log(`Отмена всех ордеров (${pair}): кнопка нажата`);
  return { ok: true, cancelledAll: true };
}

// ── Чтение истории ордеров MEXC со страницы (web-only токены, API не отдаёт) ──
// Зеркало bingx-order-page.readOrders. MEXC-биржа держит «Историю ордеров» в нижней
// панели (вкладка «Order History»/«История ордеров»/«历史委托»); строки — div-таблица.
// Все селекторы/тексты env-переопределяемы.
const ORD_TAB_RE = new RegExp(process.env.ARBI_MEXC_ORDHIST_TAB_RE || '^\\s*(Order History|История ордеров|历史委托|订单历史)\\s*$', 'i');
const ORD_HDR = {
  pair: process.env.ARBI_MEXC_ORDHIST_PAIR_RE || '^(trading pair|pair|торговая пара|пара|交易对)',
  time: process.env.ARBI_MEXC_ORDHIST_TIME_RE || '(time|время|时间)',
  side: process.env.ARBI_MEXC_ORDHIST_SIDE_RE || '(side|сторона|направление|方向)',
  avg: process.env.ARBI_MEXC_ORDHIST_AVG_RE || '(average|avg|средн|均价|成交均价)',
  // Заголовки с якорем «^»: в шапке MEXC есть и «Average Filled Price», и «Executed» —
  // без якоря `filled` ловил колонку средней цены (снимок 15.09).
  executed: process.env.ARBI_MEXC_ORDHIST_EXEC_RE || '^(executed|filled|исполнено|成交)',
  qty: process.env.ARBI_MEXC_ORDHIST_QTY_RE || '^(quantity|amount|количество|кол-во|数量)',
  status: process.env.ARBI_MEXC_ORDHIST_STATUS_RE || '^(all|status|state|статус|状态)$',
};

/**
 * Чистый разбор строк истории: на вход массивы текстов ячеек (первая подходящая —
 * шапка с «Time» и «Side»), на выход строки ордеров. Вынесен из evaluate, чтобы
 * проверяться тестом на снимке страницы (test/page-contract.test.js).
 */
function parseOrderRows(cellsList, hdr = ORD_HDR, limit = 60) {
  const rex = Object.fromEntries(Object.entries(hdr).map(([k, v]) => [k, new RegExp(v, 'i')]));
  let map = null;
  const out = [];
  for (const cells of cellsList) {
    if (cells.length < 4) continue;
    if (!map) {
      const joined = cells.join(' | ');
      if (rex.time.test(joined) && rex.side.test(joined)) {
        map = {};
        cells.forEach((c, i) => {
          for (const k of Object.keys(rex)) { if (map[k] == null && rex[k].test(c)) map[k] = i; }
        });
      }
      continue;
    }
    const pick = (k) => (map[k] != null && map[k] < cells.length ? cells[map[k]] : '');
    const side = pick('side') || cells.find((c) => /^(buy|sell|купить|продать|покупка|продажа)$/i.test(c)) || '';
    if (!side) continue;
    out.push({
      pair: pick('pair'),
      time: pick('time'),
      side,
      avgPrice: pick('avg'),
      executed: pick('executed'),
      quantity: pick('qty'),
      status: pick('status'),
      raw: cells.join(' | ').slice(0, 300),
    });
    if (out.length >= limit) break;
  }
  return out;
}

/**
 * Найти УЖЕ ОТКРЫТУЮ вкладку, стоящую на нужной паре — БЕЗ КАКОЙ-ЛИБО НАВИГАЦИИ.
 * Инцидент 2026-07-20: свежая фоновая вкладка + голый goto = Akamai «Access Denied»
 * (редирект на логин, бан-риск профиля). Тёплая вкладка пары прошла Akamai «как
 * человек» (SPA-поиск/клики), читать с неё безопасно. Нет такой вкладки → null:
 * вызывающий ПРОПУСКАЕТ чтение (никогда не навигирует ради read-only интента).
 * Матч: кэш пары / точный URL / полная пара base/quote в h1 (клоны отсечены границей).
 */
async function findWarmPairPage(context, pair) {
  const [base, quote = 'USDT'] = String(pair).split('_');
  for (const p of context.pages()) {
    let u = '';
    try { if (p.isClosed()) continue; u = p.url(); } catch { continue; }
    if (!u.startsWith(MEXC_ORIGIN)) continue;
    // Своя фоновая страница истории «тёплой вкладкой пары» НЕ считается: иначе
    // она сама себя оправдывала бы и чтение продолжалось после того, как
    // оператор закрыл пару (гейт «пара открыта» перестал бы работать).
    try { if (p.__arbiOrdersBg === true) continue; } catch { /* игнор */ }
    if (cachedPairWarm(p, u, pair)) return p;
    if (urlHasPair(u, pair)) return p;
    if (!/\/exchange\//i.test(u)) continue;
    const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + escRe(base) + '\\s*/\\s*' + escRe(quote) + '(?![A-Za-z0-9])', 'i') })
      .first().isVisible().catch(() => false);
    if (h1Match) return p;
  }
  return null;
}

/**
 * Снимает историю ордеров пары со страницы MEXC: кликает вкладку «История ордеров»,
 * маппит колонки по заголовкам и возвращает видимые строки. Read-only (без ордеров).
 * @returns {Promise<{ok:boolean, pair:string, rows:Array, error?:string}>}
 */
async function readOrders(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const page = opts.page || (await getMexcPage(context, pair, log)).page;
    await dismissOverlays(page).catch(() => {});
    await dismissBlockingModal(page).catch(() => {});
    // Вкладка «История ордеров» нижней панели (лист-элемент с точным текстом).
    const clicked = await page.evaluate((reSrc) => {
      const rx = new RegExp(reSrc, 'i');
      const tab = Array.from(document.querySelectorAll('span,div,li,a,button'))
        .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null);
      if (!tab) return false;
      try { tab.click(); return true; } catch (_) { return false; }
    }, ORD_TAB_RE.source).catch(() => false);
    if (!clicked) log('История ордеров MEXC: вкладка не найдена (ARBI_MEXC_ORDHIST_TAB_RE)');
    // Снимок 15.09: строки — div.orders_tableRow, ячейки orders_cell вложены в две
    // группы (fixed/extend), у строки 2 прямых потомка → прежний разбор по children
    // отбрасывал ВСЕ строки («снято строк 0» при 100 строках на странице). Ячейки
    // берём листовыми [class*="cell"], если прямых потомков меньше четырёх.
    const snapshot = () => page.evaluate(() => {
      const vis = (el) => el && el.offsetParent !== null;
      const txt = (c) => (c.innerText || '').replace(/\s+/g, ' ').trim();
      const cellTexts = (row) => {
        let cs = Array.from(row.children);
        if (cs.length < 4) cs = Array.from(row.querySelectorAll('[class*="cell" i]')).filter((c) => !c.querySelector('[class*="cell" i]'));
        return cs.map(txt);
      };
      const rows = new Set([
        ...Array.from(document.querySelectorAll('tr')).filter(vis),
        ...Array.from(document.querySelectorAll('[class*="tableRow" i],[class*="table" i] [class*="row" i]')).filter(vis),
      ]);
      const empty = Array.from(document.querySelectorAll('div,span,p')).some((e) => e.children.length === 0 && vis(e) && /^(no data|нет данных|暂无数据)$/i.test(txt(e)));
      return { cells: Array.from(rows).map(cellTexts).filter((c) => c.length >= 4), empty };
    }).catch(() => ({ cells: [], empty: false }));
    // Ждём ПО ФАКТУ, а не фиксированную секунду: на свежей фоновой странице биржа
    // догружает строки дольше (лог 15.09: первое чтение после открытия — 0 строк,
    // следующее — 60), а на тёплой они есть сразу — тогда и ждать нечего.
    // Выход: строки есть / биржа показала «No data» (не раньше 600 мс — плашка
    // мелькает и во время загрузки) / потолок ARBI_MEXC_ORDHIST_WAIT_MS.
    const t0 = Date.now();
    const deadline = t0 + Number(process.env.ARBI_MEXC_ORDHIST_WAIT_MS || 3000);
    let rows = [];
    for (;;) {
      await page.waitForTimeout(Number(process.env.ARBI_MEXC_ORDHIST_STEP_MS || 200));
      const snap = await snapshot();
      rows = parseOrderRows(snap.cells);
      if (rows.length || Date.now() >= deadline || (snap.empty && Date.now() - t0 >= 600)) break;
    }

    // Панель показывает ВСЕ пары (снимок 15.09: WOJAK и ANYONE в одном списке), а
    // сервер пишет строки под ЗАПРОШЕННЫЙ символ — фильтруем по колонке пары.
    // Колонки нет и страница не на паре → строк не отдаём (чужой журнал хуже пустого).
    const all = rows;
    const want = String(pair).toUpperCase().replace(/[^A-Z0-9]/g, '');
    const hasPairCol = all.some((r) => r.pair);
    if (hasPairCol) rows = all.filter((r) => !r.pair || r.pair.toUpperCase().replace(/[^A-Z0-9]/g, '') === want);
    else if (!urlHasPair(page.url(), pair)) { rows = []; log(`История ордеров MEXC ${pair}: колонки пары нет, а страница на другой паре — строки не беру`); }
    log(`История ордеров MEXC ${pair}: снято строк ${rows.length}${all.length !== rows.length ? ` (из ${all.length} на странице, остальные — другие пары)` : ''} (ожидание ${Date.now() - t0} мс)`);
    return { ok: rows.length > 0, pair, rows };
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/**
 * Как readOrders, но ТОЛЬКО с уже открытой тёплой вкладки пары — БЕЗ навигации
 * (безопасно для Akamai). Нет тёплой вкладки → мягкий пропуск (ok:false, skipped):
 * терминал покажет историю из своего журнала, а чтение случится, когда пара
 * реально открыта (прогрев/ордер её открывает — тогда вкладка уже тёплая).
 */
async function readOrdersWarm(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const warm = await findWarmPairPage(context, pair);
    if (!warm) {
      log(`История ордеров ${pair}: нет открытой вкладки пары — чтение пропущено (без навигации)`);
      return { ok: false, skipped: true, pair, rows: [], error: 'нет открытой вкладки пары — историю не читаем (защита от Akamai: без навигации)' };
    }
    // Тёплая вкладка пары есть — значит профиль на MEXC живой и пара открыта
    // оператором. Читаем НЕ в ней (иначе раз в минуту в рабочей вкладке
    // переключается нижняя панель и фильтр типа — жалоба оператора 11.09), а в
    // СВОЕЙ фоновой странице, как это давно сделано у BingX (#27 — симметрия).
    // Инвариант «ради чтения к бирже не ходим» сохранён: навигация бывает только
    // при СМЕНЕ пары фоновой страницы, а не на каждом чтении, и только когда
    // пара и так открыта. Рубильник ARBI_MEXC_ORDHIST_BG=0 — читать по-старому.
    let page = warm;
    if ((process.env.ARBI_MEXC_ORDHIST_BG || '1') !== '0') {
      page = await getOrdersBgPage(context, pair, log).catch((e) => {
        log(`История ордеров ${pair}: фоновая страница недоступна (${e.message}) — читаю в тёплой вкладке`);
        return warm;
      });
    }
    return await readOrders(context, pair, { ...opts, page });
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/**
 * Фоновая страница ИСТОРИИ MEXC (`__arbiOrdersBg`) — одна на профиль, живёт
 * между чтениями; сборщик памяти усыпляет её после простоя (ARBI_BG_IDLE_MIN),
 * следующее чтение поднимает её обычной навигацией. Если страница не доехала до
 * нужной пары — бросаем: читать историю ЧУЖОЙ пары нельзя (строки уйдут в чужой
 * журнал), вызывающий отступит на тёплую вкладку.
 */
async function getOrdersBgPage(context, pair, log) {
  let page = context.pages().find((p) => { try { return p.__arbiOrdersBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context));
    page.__arbiOrdersBg = true;
    log('Открыл фоновую страницу истории MEXC (активная вкладка оператора не трогается)');
  }
  // ОДНА страница на биржу, без навигации по парам (оператор 15.09): панель истории
  // показывает все пары, readOrders фильтрует по колонке пары. Навигация — только
  // если страница не на торговой странице MEXC (свежая / разбужена из сна).
  const u = String(page.url());
  if (!(u.startsWith(MEXC_ORIGIN) && /\/exchange\//i.test(u))) {
    await page.goto(`${MEXC_ORIGIN}/exchange/${pair}`, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (!String(page.url()).startsWith(MEXC_ORIGIN)) throw new Error(`фоновая страница истории не открылась (URL ${String(page.url()).slice(0, 60)})`);
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

module.exports = { executeIntent, getMexcPage, warmupForm, cancelAllOrders, readOrders, readOrdersWarm, parseOrderRows, mexcBlocked, mexcBlockedMsLeft, toMexcPair, SELECTORS };

'use strict';

/**
 * light-pages.js — «лёгкий режим» СЛУЖЕБНЫХ страниц ArbiBrowser (вкладки пула пар,
 * фоновые страницы истории/баланса, временные проверки входа). Оператор 2026-10-11:
 * «грузить только окно заявки, стакан и историю». Выборочно грузить части одного
 * SPA-бандла биржи нельзя, но можно не качать то, что заявке не нужно.
 *
 * Механика — CDP `Network.setBlockedURLs` на КАЖДОЙ нашей странице. Не page.route:
 * перехват Playwright идёт через Fetch и ВЫКЛЮЧАЕТ HTTP-кэш — 10 МБ скриптов MEXC
 * качались бы заново на каждом холодном открытии, то есть медленнее, а не быстрее.
 * Ручные вкладки оператора (вход в аккаунт, капча, QR) не трогаются: там картинки нужны.
 *
 * Уровни (ARBI_LIGHT_PAGES):
 *   0     — выключено;
 *   1     — по умолчанию: шрифты, видео/аудио, сторонняя реклама и аналитика;
 *   chart — то же + скрипты графиков (tradingview/kline). ЭКСПЕРИМЕНТ: включать на
 *           одном профиле и смотреть, что форма заявки по-прежнему появляется
 *           (строка [прогрев-тайминг] … лёгкий=N). Антифрод-скрипты бирж (akamai,
 *           turingfraud и т.п.) НЕ блокируются никогда — без них заявки режет риск-контроль.
 * Замер 11.10 (страница MEXC BKN_USDT): 47 скриптов / 10,2 МБ, шрифты 3 / 500 КБ.
 */
const FONTS = ['*.woff', '*.woff2', '*.ttf', '*.otf', '*.eot'].flatMap((p) => [p, `${p}?*`]);
const MEDIA = ['*.mp4', '*.webm', '*.mp3', '*.m3u8', '*.ogg'].flatMap((p) => [p, `${p}?*`]);
const ADS = ['*moloco.com*', '*doubleclick.net*', '*googletagmanager.com*', '*google-analytics.com*',
  '*googlesyndication.com*', '*facebook.net*', '*connect.facebook.com*', '*hotjar.com*', '*clarity.ms*',
  '*appsflyer*', '*adjust.com*', '*go-mpulse.net*'];
const CHART = ['*tradingview*', '*charting_library*', '*klinechart*', '*kline-chart*'];

function lightLevel() {
  const v = String(process.env.ARBI_LIGHT_PAGES || '1').trim().toLowerCase();
  return v === '0' || v === 'off' ? '0' : v === 'chart' ? 'chart' : '1';
}

/** Шаблоны блокировки для уровня. */
function patternsFor(level = lightLevel()) {
  if (level === '0') return [];
  const base = [...FONTS, ...MEDIA, ...ADS];
  return level === 'chart' ? [...base, ...CHART] : base;
}

const said = new WeakSet();
/**
 * Включить лёгкий режим на странице. Сессия CDP остаётся открытой: при её закрытии
 * Chromium снимает список. Возвращает null, если режим выключен или CDP недоступен.
 * Счётчик заблокированных читается через lightBlocked(page).
 */
async function applyLightMode(page, context, log = console.log) {
  const level = lightLevel();
  const urls = patternsFor(level);
  if (!urls.length || !context || typeof context.newCDPSession !== 'function') return null;
  try {
    const s = await context.newCDPSession(page);
    await s.send('Network.enable');
    await s.send('Network.setBlockedURLs', { urls });
    let n = 0;
    s.on('Network.loadingFailed', (e) => { if (e && e.blockedReason === 'inspector') n++; });
    page.__arbiLightBlocked = () => n;
    if (!said.has(context)) {
      said.add(context);
      log(`[лёгкий режим] служебные страницы не качают ${level === 'chart' ? 'шрифты, медиа, рекламу/аналитику и скрипты графиков (эксперимент)' : 'шрифты, медиа, рекламу/аналитику'} (ARBI_LIGHT_PAGES=${level}; 0 — выключить, chart — ещё и графики)`);
    }
    return s;
  } catch (e) {
    log(`[лёгкий режим] не включился на странице: ${e && e.message}`);
    return null;
  }
}

/** Сколько запросов отрезано на странице (для строк тайминга), 0 если режим выключен. */
function lightBlocked(page) {
  try { return typeof page.__arbiLightBlocked === 'function' ? page.__arbiLightBlocked() : 0; } catch { return 0; }
}

module.exports = { applyLightMode, patternsFor, lightLevel, lightBlocked };

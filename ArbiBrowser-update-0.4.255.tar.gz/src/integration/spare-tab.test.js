'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { makeSpare } = require('./spare-tab');

const cfg = { name: 'T', envKey: 'ARBI_TEST_SPARE_PAIR', defaultPair: 'USDC_USDT', origin: 'https://x.test', pairUrl: (p) => `https://x.test/t/${p}`, inputSel: 'input', submitSel: 'button' };

test('take: отдаёт только ГОТОВУЮ запасную на своей бирже и снимает метки', () => {
  const s = makeSpare(cfg);
  const loading = { __arbiSpare: true, url: () => 'https://x.test/t/USDC_USDT', isClosed: () => false };
  assert.equal(s.take({ pages: () => [loading] }), null, 'полузагруженная не берётся');
  const ready = { __arbiSpare: true, __arbiSpareReady: true, url: () => 'https://x.test/t/USDC_USDT', isClosed: () => false };
  assert.equal(s.take({ pages: () => [ready] }), ready);
  assert.equal(ready.__arbiSpare, false);
  assert.equal(s.take({ pages: () => [ready] }), null, 'второй раз не отдаётся');
});

test('pairOf: env выключает (0/пусто) и переопределяет пару', () => {
  const s = makeSpare(cfg);
  delete process.env.ARBI_TEST_SPARE_PAIR; assert.equal(s.pairOf(), 'USDC_USDT');
  process.env.ARBI_TEST_SPARE_PAIR = '0'; assert.equal(s.pairOf(), '');
  process.env.ARBI_TEST_SPARE_PAIR = 'btc_usdt'; assert.equal(s.pairOf(), 'btc_usdt');
  delete process.env.ARBI_TEST_SPARE_PAIR;
  assert.equal(makeSpare({ ...cfg, defaultPair: '' }).pairOf(), '');
});

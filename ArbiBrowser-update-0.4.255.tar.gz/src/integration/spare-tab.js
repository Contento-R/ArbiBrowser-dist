'use strict';

/**
 * spare-tab.js — ЗАПАСНАЯ ТЁПЛАЯ ВКЛАДКА биржи (оператор 2026-10-11: «держим вкладку по
 * стоячему токену, чтобы быстро перезаполнить»; «проверяем запасные вкладки для BingX и XT»).
 *
 * В затишье денежной дорожки (laneIdleMs ≥ quietMs, нет заявок и прогревов) в дорожке 'bg'
 * поднимается ОДНА загруженная вкладка биржи на тихой паре (USDC_USDT). Когда нужна новая
 * пара, а тёплой вкладки у неё нет, драйвер берёт запасную и меняет в ней пару SPA-поиском
 * вместо холодного открытия; следующая запасная поднимается снова в затишье. Вкладка
 * помечена __arbiSpare: места в пуле не занимает, уборка и усыпление её не трогают
 * (pair-tabs.tradeTabs, launcher). Готовность — __arbiSpareReady: полузагруженную не берут.
 *
 * Замер MEXC 11.10 (v0.4.244): SPA-смена 2148 мс + форма 758 = 2912 мс против холодного
 * открытия 2057–2482 мс в лёгком режиме → на MEXC выключена (ARBI_MEXC_SPARE_PAIR пуст).
 * BingX/XT — включены для замера: строка «[запасная вкладка] отдана паре … N мс».
 */
const { isContextBusy, laneIdleMs, withContextLock } = require('./context-lock');
const { markPairTab, markOwned, newBackgroundPage } = require('./pair-tabs');

/**
 * @param {{name:string, envKey:string, defaultPair:string, pairUrl:(pair:string)=>string,
 *   origin:string, inputSel:string, submitSel:string, blocked?:()=>boolean}} cfg
 */
function makeSpare(cfg) {
  const timers = new WeakMap();
  const pairOf = () => {
    const v = String(process.env[cfg.envKey] ?? cfg.defaultPair ?? '').trim();
    return v && v !== '0' ? v : '';
  };
  const find = (context) => context.pages().find((p) => { try { return p.__arbiSpare === true && !p.isClosed(); } catch { return false; } }) || null;

  async function open(context, log) {
    const pair = pairOf();
    const t0 = Date.now();
    const p = markPairTab(markOwned(await newBackgroundPage(context)));
    p.__arbiSpare = true;
    await p.goto(cfg.pairUrl(pair), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (!String(p.url()).startsWith(cfg.origin)) { await p.close().catch(() => {}); throw new Error(`страница ${pair} не открылась`); }
    await p.waitForSelector(cfg.inputSel, { timeout: 15000 }).catch(() => {});
    await p.waitForSelector(`${cfg.submitSel}:visible`, { timeout: 3000 }).catch(() => {});
    p.__arbiSpareReady = true;
    log(`[запасная вкладка] ${cfg.name}: открыта на ${pair} за ${Date.now() - t0} мс в затишье — следующая новая пара получит её SPA-сменой вместо холодного открытия`);
  }

  /** Раз в 5 с: запасной нет, торговля затихла → поднять. Идемпотентно на контекст. */
  function schedule(context, log = () => {}) {
    if (!context || !pairOf() || timers.has(context)) return;
    const quietMs = Number(process.env.ARBI_SPARE_QUIET_MS || 20000);
    const tick = async () => {
      timers.delete(context);
      let pages = [];
      try { pages = context.pages(); } catch { return; } // контекст закрыт — больше не планируем
      if (!pages.length || find(context)) return;
      if ((cfg.blocked && cfg.blocked()) || isContextBusy(context, 'order') || laneIdleMs(context, 'order') < quietMs) { schedule(context, log); return; }
      try {
        // Дорожка 'bg': заявку не задерживает (она нас не ждёт), затишье делает столкновение редким.
        await withContextLock(context, () => open(context, log), { lane: 'bg' });
      } catch (e) { log(`[запасная вкладка] ${cfg.name}: не поднялась (${e && e.message}) — попробую позже`); schedule(context, log); }
    };
    const t = setTimeout(tick, 5000);
    if (typeof t.unref === 'function') t.unref();
    timers.set(context, t);
  }

  /** Готовая запасная вкладка или null; возвращённая перестаёт быть запасной. */
  function take(context) {
    const p = find(context);
    if (!p || p.__arbiSpareReady !== true) return null;
    let u = '';
    try { u = p.url(); } catch { return null; }
    if (!u.startsWith(cfg.origin) || (typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl)) return null;
    p.__arbiSpare = false; p.__arbiSpareReady = false; // с этого момента — обычная вкладка пары
    return p;
  }

  return { schedule, take, pairOf };
}

module.exports = { makeSpare };

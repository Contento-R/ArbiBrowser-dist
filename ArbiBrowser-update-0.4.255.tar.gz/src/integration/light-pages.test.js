'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { applyLightMode, patternsFor, lightBlocked } = require('./light-pages');

test('patternsFor: 0 — пусто; 1 — шрифты/медиа/реклама без графиков и антифрода; chart — плюс графики', () => {
  assert.deepEqual(patternsFor('0'), []);
  const p1 = patternsFor('1');
  assert.ok(p1.includes('*.woff2') && p1.includes('*.mp4') && p1.includes('*moloco.com*'));
  assert.ok(!p1.some((p) => /tradingview|kline/.test(p)), 'графики — только на уровне chart');
  assert.ok(!p1.some((p) => /akam|turingfraud|mexc|bingx|xt\.com/i.test(p)), 'антифрод и сами биржи не блокируются');
  assert.ok(patternsFor('chart').includes('*tradingview*'));
});

test('applyLightMode: ставит Network.setBlockedURLs через CDP и считает отрезанные запросы', async () => {
  const sent = []; const handlers = {};
  const session = { send: async (m, p) => { sent.push([m, p]); }, on: (ev, fn) => { handlers[ev] = fn; } };
  const context = { newCDPSession: async () => session };
  const page = {};
  process.env.ARBI_LIGHT_PAGES = '1';
  const s = await applyLightMode(page, context, () => {});
  assert.equal(s, session);
  assert.equal(sent[0][0], 'Network.enable');
  assert.equal(sent[1][0], 'Network.setBlockedURLs');
  assert.ok(sent[1][1].urls.includes('*.woff2'));
  handlers['Network.loadingFailed']({ blockedReason: 'inspector' });
  handlers['Network.loadingFailed']({ errorText: 'net::ERR_FAILED' }); // не наша блокировка — не считаем
  assert.equal(lightBlocked(page), 1);
  process.env.ARBI_LIGHT_PAGES = '0';
  assert.equal(await applyLightMode({}, context, () => {}), null);
  delete process.env.ARBI_LIGHT_PAGES;
});

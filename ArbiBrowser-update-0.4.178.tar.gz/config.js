'use strict';

/**
 * config.js — глобальная конфигурация ArbiBrowser.
 *
 * Здесь только пути и общие параметры среды выполнения. Конфигурация
 * КОНКРЕТНОГО браузера (navigator, UA, прокси, WebGL и т.д.) НЕ живёт здесь —
 * единственный источник правды для этого — JSON-профиль в /profiles.
 *
 * Переменные окружения (все опциональны):
 *   ARBI_PROFILES_DIR   — каталог с JSON-профилями        (по умолчанию ./profiles)
 *   ARBI_DATA_DIR       — корень изолированных user-data   (по умолчанию ./data)
 *   ARBI_CHROMIUM_PATH  — путь к бинарю Chromium           (по умолчанию из Playwright)
 *   ARBI_GEOIP_MMDB     — путь к оффлайн-базе MaxMind .mmdb (опционально)
 *   ARBI_GEOIP_API      — базовый URL HTTP GeoIP-API        (по умолчанию ip-api.com)
 */

const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');

const ROOT = __dirname;

// Стабильный per-user каталог данных ВНЕ каталога приложения. Раньше профили и
// браузерные сессии лежали ВНУТРИ каталога запуска ({ROOT}/profiles, /data) — при
// установке exe поверх dev-запуска (другой каталог) или переустановке они «терялись»
// (на самом деле оставались в старом каталоге, а новый стартовал пустым). Теперь
// данные всегда в одном месте, одинаковом для dev и exe, и переживают переустановку.
function dataHome() {
  if (process.env.LOCALAPPDATA) return path.join(process.env.LOCALAPPDATA, 'ArbiBrowser');
  if (process.env.APPDATA) return path.join(process.env.APPDATA, 'ArbiBrowser');
  return path.join(os.homedir(), '.arbibrowser');
}
const DATA_HOME = dataHome();

/**
 * Одноразовая миграция из legacy-каталога ({ROOT}/profiles, /data) в стабильный
 * DATA_HOME — КОПИРОВАНИЕМ (оригинал не трогаем). Идемпотентно: если в новом месте
 * уже есть профили, ничего не делает. Вызывается на старте приложения (bin/browser.js),
 * НЕ на require config (чтобы тесты/CI не трогали ФС). Никогда не рушит старт.
 * @returns {{migrated:boolean, from?:string, to?:string, error?:string}}
 */
function migrateLegacyDataIfNeeded() {
  try {
    if (process.env.ARBI_PROFILES_DIR || process.env.ARBI_DATA_DIR) return { migrated: false };
    const newProfiles = path.join(DATA_HOME, 'profiles');
    const hasNew = fs.existsSync(newProfiles) && fs.readdirSync(newProfiles).some((f) => f.endsWith('.json'));
    if (hasNew) return { migrated: false }; // уже есть данные в новом месте
    const oldProfiles = path.join(ROOT, 'profiles');
    const hasOld = fs.existsSync(oldProfiles) && fs.readdirSync(oldProfiles).some((f) => f.endsWith('.json'));
    if (!hasOld) return { migrated: false }; // нечего мигрировать
    fs.mkdirSync(DATA_HOME, { recursive: true });
    fs.cpSync(oldProfiles, newProfiles, { recursive: true });
    const oldData = path.join(ROOT, 'data');
    const newData = path.join(DATA_HOME, 'data');
    if (fs.existsSync(oldData) && !fs.existsSync(newData)) fs.cpSync(oldData, newData, { recursive: true });
    return { migrated: true, from: ROOT, to: DATA_HOME };
  } catch (e) {
    return { migrated: false, error: (e && e.message) || String(e) };
  }
}

// Мини-загрузчик .env (без зависимостей): читает .env в process.env.
// Уже заданные в системе переменные окружения имеют приоритет и не перетираются.
function parseDotEnv(envPath) {
  try {
    if (!fs.existsSync(envPath)) return;
    for (const line of fs.readFileSync(envPath, 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (!m || line.trim().startsWith('#')) continue;
      let v = m[2];
      if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
        // Значение в кавычках — берём как есть (внутри '#' легитимен).
        v = v.slice(1, -1);
      } else {
        // БЕЗ кавычек: обрезаем inline-комментарий (пробел(ы)+# … до конца строки).
        // Иначе `ARBI_BINGX_EXEC=1   # вкл` даёт значение "1   # вкл" ≠ "1" → флаг
        // не срабатывает (ловили: bingx-exec не стартовал у юзеров, скопировавших
        // строки с комментарием из гайда). Хэш вплотную (abc#def) — часть значения.
        const c = v.search(/\s#/);
        if (c !== -1) v = v.slice(0, c);
        v = v.trim();
      }
      if (process.env[m[1]] === undefined) process.env[m[1]] = v;
    }
  } catch { /* .env необязателен */ }
}
// ДВА источника .env, в порядке приоритета (первый выигрывает — см. `undefined`):
//   1) ROOT/.env — каталог запуска (удобно для dev; перетирает при коллизии).
//   2) DATA_HOME/.env — СТАБИЛЬНЫЙ per-user каталог (%LOCALAPPDATA%\ArbiBrowser).
// Каталог установки exe меняется при переустановке/обновлении → ROOT/.env там
// теряется (как раньше терялись профили). DATA_HOME переживает переустановки,
// поэтому токен/URL/флаги, положенные туда ОДИН раз, работают всегда.
parseDotEnv(path.join(ROOT, '.env'));
parseDotEnv(path.join(DATA_HOME, '.env'));

const config = {
  root: ROOT,

  // Каталог с профилями пользователя (JSON — единственный источник конфигурации).
  profilesDir: process.env.ARBI_PROFILES_DIR
    ? path.resolve(process.env.ARBI_PROFILES_DIR)
    : path.join(DATA_HOME, 'profiles'),

  // Корень данных. Внутри — по одному изолированному каталогу на профиль.
  dataDir: process.env.ARBI_DATA_DIR
    ? path.resolve(process.env.ARBI_DATA_DIR)
    : path.join(DATA_HOME, 'data'),

  // Каталог с user-data-dir'ами Chromium (по одному на профиль).
  get userDataRoot() {
    return path.join(this.dataDir, 'user-data');
  },

  // Каталог для отчётов модуля validation.
  get reportsDir() {
    return path.join(this.dataDir, 'reports');
  },

  // Каталог загрузок (по одному на профиль). Без него Playwright складывает
  // скачанные файлы во ВРЕМЕННУЮ папку под GUID-именем без расширения и УДАЛЯЕТ
  // их при закрытии профиля (Windows не знает, чем открыть; «Показать в папке»
  // из шелфа Chrome не работает) — экспорт истории с биржи просто пропадал.
  get downloadsRoot() {
    return path.join(this.dataDir, 'downloads');
  },

  // Путь к бинарю Chromium. Пусто → Playwright возьмёт свой встроенный.
  chromiumPath: process.env.ARBI_CHROMIUM_PATH || null,

  // Стартовая страница профиля. По умолчанию пустая вкладка (about:blank) —
  // никакой внешний сайт не грузится при старте. Свою стартовую страницу можно
  // задать через ARBI_START_URL (напр. https://www.myip.com/ для проверки IP/гео).
  startUrl: process.env.ARBI_START_URL || 'about:blank',

  // Интеграция с цекс-терминалом (импорт аккаунтов/прокси/фингерпринтов).
  terminal: {
    // SEC-3: не-loopback терминал ОБЯЗАН быть https — иначе X-Arbi-Token и intents
    // идут по сети открыто, MITM читает токен и подменяет ордер реальными деньгами.
    // Escape hatch для доверенной изолированной локалки: ARBI_ALLOW_INSECURE_TERMINAL=1.
    url: (() => {
      const u = process.env.ARBI_TERMINAL_URL || 'http://127.0.0.1:3001';
      try {
        const p = new URL(u);
        const hn = p.hostname.replace(/^\[|\]$/g, '');
        const loopback = hn === '127.0.0.1' || hn === 'localhost' || hn === '::1';
        // SEC-3: не-loopback http небезопасен (токен/ордера идут открыто, MITM).
        // НО не роняем старт (это боевой инструмент — падение = простой торговли):
        // громко предупреждаем и продолжаем. Заглушить: ARBI_ALLOW_INSECURE_TERMINAL=1.
        if (!loopback && p.protocol !== 'https:' && process.env.ARBI_ALLOW_INSECURE_TERMINAL !== '1') {
          console.warn(`[config] ВНИМАНИЕ: ARBI_TERMINAL_URL=${u} — не-loopback по http. `
            + `Токен и ордера идут ОТКРЫТО (риск перехвата). Настоятельно перейдите на https:// `
            + `(или ARBI_ALLOW_INSECURE_TERMINAL=1, чтобы убрать это предупреждение).`);
        }
      } catch { /* невалидный URL — упадёт при первом запросе, старт не рушим */ }
      return u;
    })(),
    token: process.env.ARBI_TERMINAL_TOKEN || '',
  },

  // MEXC web-исполнитель (Стадия 3). Два независимых рубильника:
  //   mexcExec  — авто-запускать цикл опроса намерений вместе с GUI-панелью.
  //               Без него панель работает как раньше (исполнителя нет).
  //   mexcExecLive — РАЗРЕШИТЬ реальное исполнение ордера в странице MEXC.
  //               Пока OFF: даже намерения dryRun=false НЕ исполняются реально
  //               (kill-switch — на случай, пока не пройден живой прогон против
  //               анти-бота MEXC). Включать только после проверки (см. session-note).
  mexcExec: (process.env.ARBI_MEXC_EXEC || '') === '1' || (process.env.ARBI_MEXC_EXEC || '').toLowerCase() === 'true',
  mexcExecLive: (process.env.ARBI_MEXC_EXEC_LIVE || '') === '1' || (process.env.ARBI_MEXC_EXEC_LIVE || '').toLowerCase() === 'true',
  //   mexcOrdersRead — читать историю ордеров пары С УЖЕ ОТКРЫТОЙ тёплой вкладки
  //   (БЕЗ навигации: свежая фоновая вкладка + голый goto триггерили Akamai «Access
  //   Denied» — инцидент 2026-07-20; readOrdersWarm не навигирует вовсе, поэтому
  //   безопасно и ВКЛ по умолчанию). Выключить: ARBI_MEXC_ORDERS_READ=0.
  mexcOrdersRead: (process.env.ARBI_MEXC_ORDERS_READ || '1') !== '0',

  // XT web-исполнитель (Стадия 3). Те же два независимых рубильника, что у MEXC:
  //   xtExec  — авто-запускать цикл опроса намерений вместе с GUI-панелью.
  //   xtExecLive — РАЗРЕШИТЬ реальное исполнение ордера в странице XT.
  //               Пока OFF: даже намерения dryRun=false НЕ исполняются реально
  //               (kill-switch — на случай, пока не пройден живой прогон против
  //               анти-бота XT). Включать только после проверки (см. session-note).
  xtExec: (process.env.ARBI_XT_EXEC || '') === '1' || (process.env.ARBI_XT_EXEC || '').toLowerCase() === 'true',
  xtExecLive: (process.env.ARBI_XT_EXEC_LIVE || '') === '1' || (process.env.ARBI_XT_EXEC_LIVE || '').toLowerCase() === 'true',

  // BingX web-исполнитель (Стадия 3). Те же два независимых рубильника, что у XT/MEXC:
  //   bingxExec  — авто-запускать цикл опроса намерений вместе с GUI-панелью.
  //   bingxExecLive — РАЗРЕШИТЬ реальное исполнение ордера в странице BingX.
  //               Пока OFF: даже намерения dryRun=false НЕ исполняются реально
  //               (kill-switch — держим OFF, пока оператор не пришлёт реальные
  //               DOM-селекторы/endpoint BingX и не пройдёт живой прогон).
  bingxExec: (process.env.ARBI_BINGX_EXEC || '') === '1' || (process.env.ARBI_BINGX_EXEC || '').toLowerCase() === 'true',
  bingxExecLive: (process.env.ARBI_BINGX_EXEC_LIVE || '') === '1' || (process.env.ARBI_BINGX_EXEC_LIVE || '').toLowerCase() === 'true',

  // Облачная синхронизация профилей (src/sync): выгружать JSON-профиль+cookie в
  // терминал и на старте панели скачивать более свежие ДО открытия (барьер), чтобы
  // пересаживаться между устройствами с тем же отпечатком/прокси. Выключено →
  // модуль синка бездействует, поведение как раньше. Канал — тот же токен терминала.
  profileSync: (process.env.ARBI_PROFILE_SYNC || '') === '1' || (process.env.ARBI_PROFILE_SYNC || '').toLowerCase() === 'true',

  // Каталог с распакованными расширениями (грузятся во все профили в headful).
  get extensionsDir() {
    return path.join(this.root, 'extensions');
  },

  // GeoIP.
  geoip: {
    // Оффлайн-база MaxMind (.mmdb). Если файла нет — используется HTTP-API.
    mmdbPath: process.env.ARBI_GEOIP_MMDB
      ? path.resolve(process.env.ARBI_GEOIP_MMDB)
      : path.join(ROOT, 'data', 'geoip', 'GeoLite2-City.mmdb'),
    // HTTP-API как основной путь: запрос идёт ЧЕРЕЗ прокси, поэтому отдаёт
    // гео именно выходного IP прокси (а не хоста, где запущен браузер).
    apiBase: process.env.ARBI_GEOIP_API || 'http://ip-api.com/json',
    // Таймаут сетевых запросов GeoIP, мс.
    timeoutMs: 15000,
  },

  // Возвращает абсолютный путь user-data-dir для конкретного профиля.
  userDataDirFor(profileName) {
    return path.join(this.userDataRoot, profileName);
  },

  // Возвращает абсолютный путь каталога загрузок для конкретного профиля.
  downloadsDirFor(profileName) {
    return path.join(this.downloadsRoot, profileName);
  },

  // Возвращает путь к файлу профиля по имени (без .json).
  profilePathFor(profileName) {
    const name = profileName.endsWith('.json') ? profileName : `${profileName}.json`;
    return path.join(this.profilesDir, name);
  },
  // Одноразовая миграция legacy-данных в стабильный каталог (вызывать на старте).
  migrateLegacyDataIfNeeded,
};

module.exports = config;

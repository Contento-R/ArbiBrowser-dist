' ArbiBrowser.vbs - launch the ArbiBrowser control panel with no console window (Windows).
' Double-click starts node in the background; the ArbiBrowser panel window opens.
Dim sh, fso, here
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = here
' 0 = hidden window (no console), False = do not wait
sh.Run "node bin\browser.js gui", 0, False

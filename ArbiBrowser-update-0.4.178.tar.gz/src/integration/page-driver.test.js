'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { driverFor, PROFILES } = require('./page-driver');

const SEL = { numberInput: 'input.n', input: 'input.n', submit: 'button.s', submitBuy: 'button.b', submitSell: 'button.sl' };

// Дубль страницы/поля Playwright: пишем в журнал, что было вызвано и с чем.
function fakePage({ evaluate, $eval } = {}) {
  const calls = [];
  return {
    calls,
    keyboard: {
      press: async (k) => calls.push(['press', k]),
      insertText: async (s) => calls.push(['insert', s]),
      type: async (s) => calls.push(['type', s]),
    },
    evaluate: evaluate || (async () => ({ closed: 0, text: '' })),
    $eval: $eval || (async () => { throw new Error('нет'); }),
  };
}
function fakeHandle(calls, { failFirst = false, stuck = true } = {}) {
  let n = 0;
  return {
    click: async (o) => { calls.push(['click', o]); if (failFirst && n++ === 0) throw new Error('перекрыто'); },
    evaluate: async () => stuck,
  };
}

test('профили: три биржи, регэкспы собираются, неизвестная биржа — ошибка', () => {
  assert.deepEqual(Object.keys(PROFILES).sort(), ['bingx', 'mexc', 'xt']);
  for (const p of Object.values(PROFILES)) {
    new RegExp(p.modal.block, 'i'); new RegExp(p.modal.ok, 'i');
    if (p.modal.risk) new RegExp(p.modal.risk, 'i');
    if (p.overlays.hide) new RegExp(p.overlays.hide, 'i');
  }
  assert.throws(() => driverFor('okx', SEL), /неизвестная/);
  assert.throws(() => driverFor('bingx', { submit: 'x' }), /SELECTORS\.numberInput/);
});

test('typeNumber BingX/XT: вставка одним событием, поле приняло → без посимвольного ввода', async () => {
  const page = fakePage();
  const h = fakeHandle(page.calls);
  await driverFor('bingx', SEL).typeNumber(page, h, '0.0123');
  const kinds = page.calls.map((c) => c[0]);
  assert.deepEqual(kinds, ['click', 'press', 'insert']);
  assert.equal(page.calls[0][1].timeout, 4000);
  assert.equal(page.calls[0][1].force, false);
});

test('typeNumber XT direct: поле количества — сразу посимвольно, без вставки', async () => {
  const page = fakePage();
  await driverFor('xt', SEL).typeNumber(page, fakeHandle(page.calls), '12345', { direct: true });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
});

test('typeNumber MEXC: по умолчанию force-клик 1200мс и только посимвольный ввод; счётчики st', async () => {
  const page = fakePage();
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls), '777', { st });
  assert.deepEqual(page.calls.map((c) => c[0]), ['click', 'press', 'type']);
  assert.equal(page.calls[0][1].force, true);
  assert.equal(page.calls[0][1].timeout, 1200);
  assert.equal(st.typeN, 1);
  assert.equal(st.keysN, 3);
  assert.equal(st.fallback, 0);
});

test('typeNumber: сорванный клик → закрыть модалку → повтор с force; st.fallback растёт', async () => {
  let modalCalls = 0;
  const page = fakePage({ evaluate: async () => { modalCalls++; return { closed: 0, text: '' }; } });
  const st = { point: 0, clear: 0, click: 0, keys: 0, keysN: 0, typeN: 0, fallback: 0 };
  await driverFor('mexc', SEL).typeNumber(page, fakeHandle(page.calls, { failFirst: true }), '5', { st });
  const clicks = page.calls.filter((c) => c[0] === 'click');
  assert.equal(clicks.length, 2);
  assert.equal(clicks[1][1].force, true);
  assert.equal(modalCalls, 1);
  assert.equal(st.fallback, 1);
});

test('dismissBlockingModal: risk-модалка ставит __arbiSawRisk (BingX/XT), MEXC — нет', async () => {
  const risky = async () => ({ closed: 1, text: 'Предупреждение о риске: инновационная зона' });
  for (const [ex, want] of [['bingx', true], ['xt', true], ['mexc', undefined]]) {
    const page = fakePage({ evaluate: risky });
    const r = await driverFor(ex, SEL).dismissBlockingModal(page);
    assert.equal(r.closed, 1);
    assert.equal(page.__arbiSawRisk, want, ex);
  }
  // Баланс — не риск.
  const page = fakePage({ evaluate: async () => ({ closed: 1, text: 'Insufficient balance' }) });
  await driverFor('bingx', SEL).dismissBlockingModal(page);
  assert.equal(page.__arbiSawRisk, undefined);
});

test('dismissOverlays: опрос без крестика → Escape (только BingX); возвращает число', async () => {
  const page = fakePage({ evaluate: async () => ({ closed: 2, surveyLeft: true }) });
  assert.equal(await driverFor('bingx', SEL).dismissOverlays(page), 2);
  assert.deepEqual(page.calls, [['press', 'Escape']]);
  const bad = fakePage({ evaluate: async () => { throw new Error('страница закрыта'); } });
  assert.equal(await driverFor('mexc', SEL).dismissOverlays(bad), 0);
});

test('isSubmitReady: side-режим пробует сторону → общий → true; MEXC — одна evaluate', async () => {
  const asked = [];
  const page = fakePage({ $eval: async (s) => { asked.push(s); throw new Error('нет'); } });
  assert.equal(await driverFor('xt', SEL).isSubmitReady(page, 'sell'), true);
  assert.deepEqual(asked, ['button.sl', 'button.s']);
  const ok = fakePage({ $eval: async (s) => s === 'button.b' });
  assert.equal(await driverFor('bingx', SEL).isSubmitReady(ok, 'buy'), true);
  let sel = null;
  const mexc = fakePage({ evaluate: async (fn, s) => { sel = s; return false; } });
  assert.equal(await driverFor('mexc', SEL).isSubmitReady(mexc, 'sell'), false);
  assert.equal(sel, 'button.s');
});

test('loginWall: «Log In» на месте кнопки ордера или в шапке → wall; Buy → нет', async () => {
  const d = driverFor('mexc', SEL);
  const mk = (ret) => ({ evaluate: async (fn, sel) => ret });
  assert.equal((await d.loginWall(mk({ wall: true, text: 'Log In / Sign Up' }))).wall, true);
  assert.equal((await d.loginWall(mk({ wall: false, text: 'Buy WOJAK' }))).wall, false);
  assert.equal((await d.loginWall({ evaluate: async () => { throw new Error('closed'); } })).wall, false);
  const { loginRequiredError } = require('./page-driver');
  assert.match(loginRequiredError('MEXC'), /нет входа в аккаунт MEXC/);
});

'use strict';

/**
 * mexc-executor.js — локальный исполнитель web-ордеров MEXC.
 *
 * Тонкая обёртка над общим транспортом executor-core.js (keep-alive + long-poll,
 * зеркально для XT и будущего BingX). Опрашивает очередь намерений MEXC у
 * цекс-терминала (per-user X-Arbi-Token), исполняет их в живой странице MEXC
 * запущенного профиля и постит результат.
 */

const { makeExecutor, requestJson } = require('./executor-core');

const impl = makeExecutor({
  pendingPath: '/api/integrations/arbibrowser/mexc/pending',
  resultPath: '/api/integrations/arbibrowser/mexc/result',
  waitEnv: 'ARBI_MEXC_WAIT_MS',   // long-poll hold, мс (0 = откл. long-poll)
  pollEnv: 'ARBI_MEXC_POLL_MS',   // фолбэк-интервал для сервера без long-poll
});

module.exports = { pollOnce: impl.pollOnce, startLoop: impl.startLoop, requestJson };

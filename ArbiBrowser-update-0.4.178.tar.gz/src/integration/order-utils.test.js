'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { formatDecimal, isPlainPositive, baseNamedIn, parseVolumeLimit, parseRejectLimit, VOLUME_LIMIT_HINT_RE, pairMismatch, pairGate, fieldFresh, sideFromText } = require('./order-utils');

test('formatDecimal: разворачивает экспоненту мелких цен Alpha-токенов', () => {
  assert.equal(formatDecimal(1.2e-7), '0.00000012');
  assert.equal(formatDecimal('1.2e-7'), '0.00000012');
  assert.equal(formatDecimal(1.5e3), '1500');
  assert.equal(formatDecimal(1.23e2), '123');
  assert.equal(formatDecimal(1.2345e2), '123.45');
  assert.equal(formatDecimal('1.20e-7'), '0.00000012'); // хвостовой ноль убран
  assert.equal(formatDecimal(5e-8), '0.00000005');
  assert.equal(formatDecimal(3e21), '3000000000000000000000');
});

test('formatDecimal: плоскую запись не трогает', () => {
  assert.equal(formatDecimal('0.00000012'), '0.00000012');
  assert.equal(formatDecimal('123.45'), '123.45');
  assert.equal(formatDecimal('0'), '0');
  assert.equal(formatDecimal('1000'), '1000');
});

test('isPlainPositive: отсекает мусор до отправки', () => {
  assert.equal(isPlainPositive('0.00000012'), true);
  assert.equal(isPlainPositive('123'), true);
  assert.equal(isPlainPositive('1.2e-7'), false); // экспонента запрещена
  assert.equal(isPlainPositive('0'), false);
  assert.equal(isPlainPositive('-5'), false);
  assert.equal(isPlainPositive(''), false);
  assert.equal(isPlainPositive('abc'), false);
  assert.equal(isPlainPositive('NaN'), false);
});

test('baseNamedIn: клоны-тикеры НЕ матчатся (CR-1)', () => {
  // Наш токен назван — да.
  assert.equal(baseNamedIn('Sell ART', 'ART'), true);
  assert.equal(baseNamedIn('ART/USDT', 'ART'), true);
  assert.equal(baseNamedIn('Buy ART USDT', 'ART'), true);
  // Клон — НЕТ (главный кейс потери денег).
  assert.equal(baseNamedIn('Sell ARTX', 'ART'), false);
  assert.equal(baseNamedIn('ARTX/USDT', 'ART'), false);
  assert.equal(baseNamedIn('Buy TIG', 'STIG'), false);
  assert.equal(baseNamedIn('STIG/USDT', 'TIG'), false);
  assert.equal(baseNamedIn('TIGER/USDT', 'TIG'), false);
  // CJK-имя с границей по «/».
  assert.equal(baseNamedIn('币安底裤/USDT', '币安底裤'), true);
});

test('pairMismatch: строгий блок с escape по alias (CR-1 learn-on-confirm)', () => {
  // Наш токен на странице — не блок.
  assert.equal(pairMismatch('GENSYN', 'GENSYN', null), false);
  assert.equal(pairMismatch('gensyn', 'GENSYN', null), false); // регистр
  // displayName≠coinName без алиаса — БЛОК (оператор подтвердит).
  assert.equal(pairMismatch('AI', 'GENSYN', null), true);
  // тот же с зарегистрированным алиасом — пропуск.
  assert.equal(pairMismatch('AI', 'GENSYN', 'AI'), false);
  assert.equal(pairMismatch('ai', 'GENSYN', 'AI'), false);
  // клон-тикер без алиаса — БЛОК.
  assert.equal(pairMismatch('ARTX', 'ART', null), true);
  // алиас не тот — всё равно блок.
  assert.equal(pairMismatch('XYZ', 'GENSYN', 'AI'), true);
  // страницу не прочитали — fail-open (не блокируем).
  assert.equal(pairMismatch(null, 'GENSYN', null), false);
  assert.equal(pairMismatch('', 'GENSYN', 'AI'), false);
});

test('pairGate: пустой pageBase → БЛОК unreadable (M1 fail-closed)', () => {
  // Дыра CR-1: раньше пустая пара молча пропускала ордер. Теперь — блок без диалога.
  assert.deepEqual(pairGate('', 'GENSYN', 'AI'), { block: true, reason: 'unreadable' });
  assert.deepEqual(pairGate(null, 'GENSYN', null), { block: true, reason: 'unreadable' });
  // Чужой токен без алиаса → блок с диалогом подтверждения.
  assert.deepEqual(pairGate('AI', 'GENSYN', null), { block: true, reason: 'mismatch' });
  // Наш токен → own; подтверждённый алиас → alias (M8: для аудит-лога применения).
  assert.deepEqual(pairGate('GENSYN', 'GENSYN', null), { block: false, reason: 'own' });
  assert.deepEqual(pairGate('AI', 'GENSYN', 'AI'), { block: false, reason: 'alias' });
});

test('fieldFresh M3: допуск от want, схлопнутое поле НЕ проходит', () => {
  // Дыра: поле схлопнулось до «5» при желаемом 5.9 → раньше unit=1 (из поля) пропускал
  // ~15% ошибку. Теперь unit=0.1 (из want=5.9) → блок.
  assert.equal(fieldFresh('5', 5.9), false);
  // Точное значение — свежо.
  assert.equal(fieldFresh('5.9', 5.9), true);
  // 5.8 vs 5.9 = 1.7% — это ДРУГАЯ цена (не округление тика), должна блокироваться.
  assert.equal(fieldFresh('5.8', 5.9), false);
  assert.equal(fieldFresh('5.7', 5.9), false);
  // Мелкая цена в экспоненте: unit из formatDecimal, не из «e».
  assert.equal(fieldFresh('0.00000000032', 3.2e-10), true);
  assert.equal(fieldFresh('0.00000000045', 3.2e-10), false);
  // Мусор/ноль — не свежо.
  assert.equal(fieldFresh('', 5.9), false);
  assert.equal(fieldFresh('5', 0), false);
});

test('fieldFresh M3-регрессия: биржевое усечение по шагу лота проходит, чужое значение — нет', () => {
  // Боевой кейс XT: want=8.97129187, биржа усекла поле до «8.97» (шаг лота 0.01).
  // Это легитимно (0.014% от want) — люфт 0.5% пропускает, ордер НЕ блокируется.
  assert.equal(fieldFresh('8.97', 8.97129187), true);
  assert.equal(fieldFresh('313.8', 313.80753138), true); // BingX-кейс из боевого лога
  // Чужое значение прошлого ордера (CR-3: 92.37 vs 95.23 = 3%) — по-прежнему БЛОК.
  assert.equal(fieldFresh('92.37', 95.23), false);
  // Схлопывание (15%) — по-прежнему БЛОК.
  assert.equal(fieldFresh('5', 5.9), false);
  // Боевой баг: цену 0.000000077 стакан-снапнул до 0.00000007657 (0.56%) — БЛОК (раньше
  // 0.5%-допуск пропускал → ордер уходил по не той цене и сидел в стакане).
  assert.equal(fieldFresh('0.00000007657', 0.000000077), false);
  // Легитимное округление тика (0.00000007655 → 0.00000007658, 0.04%) — проходит.
  assert.equal(fieldFresh('0.00000007658', 0.00000007655), true);
});

test('sideFromText M5: сторона из текста кнопки сабмита (языки локалей профилей)', () => {
  assert.equal(sideFromText('Buy WOJAK'), 'buy');
  assert.equal(sideFromText('Sell WOJAK'), 'sell');
  assert.equal(sideFromText('Купить'), 'buy');
  assert.equal(sideFromText('Продать'), 'sell');
  assert.equal(sideFromText('买入'), 'buy');
  assert.equal(sideFromText('卖出'), 'sell');
  // M5-регрессия: язык биржи следует за локалью профиля (боевые: es-ES, de-DE).
  assert.equal(sideFromText('Comprar WOJAK'), 'buy');   // испанский
  assert.equal(sideFromText('Vender WOJAK'), 'sell');
  assert.equal(sideFromText('Kaufen'), 'buy');          // немецкий
  assert.equal(sideFromText('Verkaufen'), 'sell');
  assert.equal(sideFromText('Acheter'), 'buy');         // французский
  assert.equal(sideFromText('Vendre'), 'sell');
  // Не распознать → '' → вызывающий НЕ блокирует (лог-предупреждение), блок только
  // на ЯВНО противоположной стороне — иначе новый язык остановил бы все ордера.
  assert.equal(sideFromText(''), '');
  assert.equal(sideFromText('Confirm'), '');
});

test('parseVolumeLimit: локали и суффиксы (CR-4)', () => {
  assert.equal(parseVolumeLimit('доступно только 5000 USDT'), 5000);
  assert.equal(parseVolumeLimit('только 5 000 USDT'), 5000);      // RU пробел-тысячи
  assert.equal(parseVolumeLimit('5,5 USDT'), 5.5);                 // десятичная запятая
  assert.equal(parseVolumeLimit('1,234.56 USDT'), 1234.56);        // EN тысячи+десятичн.
  assert.equal(parseVolumeLimit('1.234,56 USDT'), 1234.56);        // EU тысячи+десятичн.
  assert.equal(parseVolumeLimit('available 5K USDT'), 5000);
  assert.equal(parseVolumeLimit('2.5M USDT'), 2.5e6);
  assert.equal(parseVolumeLimit('no limit here'), null);
  assert.equal(parseVolumeLimit(''), null);
});

test('VOLUME_LIMIT_HINT_RE: формулировки лимита объёма (инцидент 2026-07-19)', () => {
  // RU-кап BingX на стоимость заявки — раньше НЕ проходил фильтр → split молча не запускался
  assert.ok(VOLUME_LIMIT_HINT_RE.test('Стоимость не может быть больше 500 USDT'));
  assert.ok(VOLUME_LIMIT_HINT_RE.test('доступно только 5000 USDT'));
  assert.ok(VOLUME_LIMIT_HINT_RE.test('The order value cannot exceed 500 USDT'));
  assert.ok(VOLUME_LIMIT_HINT_RE.test('Total should not be more than 500 USDT'));
  // Нейтральные тексты полей формы фильтр проходить не должны
  assert.ok(!VOLUME_LIMIT_HINT_RE.test('Всего USDT'));
  assert.ok(!VOLUME_LIMIT_HINT_RE.test('Цена USDT'));
  // parseVolumeLimit на прошедшем фильтр тексте достаёт число
  assert.equal(parseVolumeLimit('Стоимость не может быть больше 500 USDT'), 500);
});

test('fieldFresh: залипшая цена прошлой операции НЕ считается свежей (WOJAK/MEXC 01.09)', () => {
  // Форма биржи хранит цену прошлого ордера. Оператор ввёл 0.00000005645, в поле
  // сидела 0.00000005661 (правка предыдущей заявки) — 0.283%: под старым допуском
  // 0.3% цена не перезаписывалась и ордер уходил по ЧУЖОЙ цене.
  assert.equal(fieldFresh('0.00000005661', 0.00000005645), false);
  assert.equal(fieldFresh('0.00000005645', 0.00000005645), true, 'своя цена — свежа');
  // Легитимные кейсы из боевых логов сохраняются (запас к новому порогу ≥2×).
  assert.equal(fieldFresh('8.97', 8.97129187), true);      // усечение по шагу лота, 0.014%
  assert.equal(fieldFresh('313.8', 313.80753138), true);   // BingX, 0.002%
  assert.equal(fieldFresh('0.00000007658', 0.00000007655), true); // округление тика, 0.039%
});

test('VOLUME_MIN_HINT_RE: подсказка о минимуме — не лимит объёма (кейс 15.09, лимит=1 USDT)', () => {
  const { VOLUME_MIN_HINT_RE, VOLUME_LIMIT_HINT_RE } = require('./order-utils');
  for (const t of ['Мин. стоимость - 1 USDT', 'Minimum order value 5 USDT', 'Не менее 1 USDT']) assert.ok(VOLUME_MIN_HINT_RE.test(t), t);
  for (const t of ['Стоимость не может быть больше 500 USDT', 'Максимальная стоимость для ордера - 500.0000', 'Доступно только 500 USDT']) {
    assert.ok(!VOLUME_MIN_HINT_RE.test(t), t);
    assert.ok(VOLUME_LIMIT_HINT_RE.test(t), t);
  }
});

test('parseRejectLimit: лимит из ОТКАЗА биржи (валюты рядом с числом нет)', () => {
  // Реальный отказ BingX из лога напарника 2026-09-08.
  assert.equal(parseRejectLimit('Максимальная стоимость для ордера - 500.0000'), 500);
  assert.equal(parseRejectLimit('Maximum order value is 1,000.50'), 1000.5);
  assert.equal(parseRejectLimit('Стоимость не может быть больше 500 USDT'), 500); // обычный путь
  // Не про лимит стоимости — числа не выдумываем (#54).
  assert.equal(parseRejectLimit('Недостаточно средств, доступно 12.3'), null);
  assert.equal(parseRejectLimit('Order 2097383682258927616 rejected'), null);
  assert.equal(parseRejectLimit(''), null);
  assert.equal(parseRejectLimit(null), null);
});

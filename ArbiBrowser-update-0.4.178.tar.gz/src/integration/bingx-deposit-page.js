'use strict';

/**
 * bingx-deposit-page.js — «Счёт получения» депозита BingX: проверка и перевод
 * на «Спот счёт» в живой странице профиля (оператор 2026-09-17).
 *
 * Зачем. Депозит BingX по умолчанию падает на Счёт фонда, и терминал тратит
 * секунды и запросы (опрос истории депозитов, чтение Фонда, перевод, ожидание
 * Спота) на то, чтобы монета стала продаваемой. На странице депозита у монеты
 * есть «Счёт получения» (Счёт фонда ⇄ Спот счёт): если у торгуемых монет
 * поставить «Спот счёт», шаг Фонд→Спот исчезает целиком.
 *
 * Что делает интент `depositProbe` ({coins:[…], set:'SPOT'|null}):
 *   • для каждой монеты открывает страницу депозита в ФОНОВОЙ вкладке профиля,
 *     читает показанную монету, сеть и текущий «Счёт получения»;
 *   • при set:'SPOT' и значении «Счёт фонда» — нажимает ⇄ → «Спот счёт» → OK
 *     и перечитывает значение;
 *   • записывает сетевые вызовы страницы к API биржи за это время (метод, URL,
 *     тело запроса, тело ответа) — чтобы найти прямой вызов смены счёта и
 *     дальше не кликать, а звать его.
 *
 * БЕЗОПАСНОСТЬ ВЫВОДА. Заголовки запросов НЕ записываются вовсе (там cookie и
 * токены сессии). В телах запроса/ответа и в query-параметрах вымарываются
 * ключи, похожие на секреты/идентификаторы (token, sign, cookie, auth, uid,
 * phone, email, device…), и ЛЮБЫЕ длинные (≥32 симв.) буквенно-цифровые
 * строки. Наружу уходит только это — в терминал, тем же путём, что и
 * результат любого интента.
 */

const { newBackgroundPage, markOwned } = require('./pair-tabs');

const BINGX_ORIGIN = process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com';
// Страница депозита с монетой в query. Если у BingX другой параметр — env.
const DEPOSIT_URL_TMPL = process.env.ARBI_BINGX_DEPOSIT_URL || `${BINGX_ORIGIN}/ru/assets/recharge?coin={coin}`;
// Хосты API страницы (подтверждённый: api-app.we-api.com — см. bingx-order-page.js).
const API_RE = new RegExp(process.env.ARBI_BINGX_DEPOSIT_API_RE || 'we-api\\.com|bingx\\.com/api', 'i');
// Вызовы, относящиеся к депозиту/счёту — их отдаём подробно; остальные считаем.
const RELEVANT_RE = /recharge|deposit|account|asset|setting|config|wallet|transfer|coin/i;
const SECRET_KEY_RE = /token|secret|sign|cookie|auth|session|passw|apikey|api[_-]?key|private|uid|user[_-]?id|phone|email|device|fingerprint|trace|nonce|captcha/i;
const MAX_REQ_PER_COIN = 25;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Вымарать секреты/идентификаторы из любого JSON-значения. */
function scrub(v, depth = 0) {
  if (depth > 6) return '[глубже не смотрим]';
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => scrub(x, depth + 1));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, val] of Object.entries(v).slice(0, 60)) o[k] = SECRET_KEY_RE.test(k) ? '[скрыто]' : scrub(val, depth + 1);
    return o;
  }
  if (typeof v === 'string') {
    // URL — это адрес вызова, ради него проба и нужна; query уже вымаран scrubUrl.
    if (/^https?:\/\//i.test(v)) return scrubUrl(v);
    if (v.length >= 32 && /^[A-Za-z0-9+/=_\-.:]+$/.test(v)) return `[скрыто, ${v.length} симв.]`;
    return v.length > 200 ? v.slice(0, 200) + '…' : v;
  }
  return v;
}
function scrubUrl(u) {
  try {
    const url = new URL(u);
    for (const k of [...url.searchParams.keys()]) {
      const val = url.searchParams.get(k) || '';
      if (SECRET_KEY_RE.test(k) || val.length >= 32) url.searchParams.set(k, 'HIDDEN');
    }
    return url.origin + url.pathname + url.search;
  } catch { return String(u).slice(0, 200); }
}
function scrubBody(text) {
  if (!text) return null;
  try { return scrub(JSON.parse(text)); } catch { return `[не JSON, ${text.length} симв.]`; }
}

/** Запись вызовов страницы к API биржи. Заголовки не читаем никогда. */
function attachRecorder(page) {
  const rows = [];
  const onResponse = async (resp) => {
    try {
      const req = resp.request();
      const url = req.url();
      if (!API_RE.test(url)) return;
      const rt = req.resourceType();
      if (rt !== 'xhr' && rt !== 'fetch') return;
      let body = null;
      try { body = await resp.text(); } catch { /* тело недоступно — не критично */ }
      rows.push({
        t: Date.now(), method: req.method(), url: scrubUrl(url), status: resp.status(),
        request: scrubBody(req.postData()), response: body ? scrubBody(body.slice(0, 6000)) : null,
      });
      if (rows.length > 400) rows.shift();
    } catch { /* запись — диагностика, страницу не трогает */ }
  };
  page.on('response', onResponse);
  return { rows, detach: () => { try { page.off('response', onResponse); } catch { /* игнор */ } } };
}

async function getDepositPage(context, log) {
  let page = context.pages().find((p) => { try { return p.__arbiDepositBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context, { tab: true }));
    page.__arbiDepositBg = true;
    log('Открыл фоновую вкладку депозита (активная вкладка оператора не трогается)');
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

/** Текст n-го шага формы (0 — монета, 1 — сеть): вторая непустая строка = выбранное значение. */
async function readStepValue(page, n) {
  const txt = await page.locator('.bx-step-content').nth(n).innerText({ timeout: 5000 }).catch(() => '');
  const lines = txt.split('\n').map((s) => s.trim()).filter(Boolean);
  return (lines[1] || lines[0] || '').slice(0, 60);
}

async function readReceiveAccount(page) {
  const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
  if (!(await item.count())) return null;
  const txt = await item.locator('.right-text').first().innerText({ timeout: 5000 }).catch(() => '');
  return txt.replace(/\s+/g, ' ').trim() || null;
}

/** Выбрать монету через выпадающий список, если query-параметр не сработал. */
async function selectCoin(page, coin, log) {
  const box = page.locator('.bx-step-content').nth(0);
  await box.locator('[class*="select"], [class*="picker"], [class*="dropdown"]').first().click({ timeout: 5000 });
  await sleep(500);
  await page.keyboard.type(coin, { delay: 40 });
  await sleep(1200);
  const option = page.getByText(new RegExp(`^\\s*${coin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`, 'i')).filter({ visible: true }).last();
  await option.click({ timeout: 5000 });
  await sleep(1500);
  log(`Монета ${coin} выбрана через список`);
}

/** Сеть не выбрана («Выберите»): открыть список сетей и взять первую. У монет с
 *  одной сетью страница выбирает её сама, у USDT/USDC — ждёт пользователя, и без
 *  сети блок «Информация про депозит» (а с ним и «Счёт получения») не рисуется. */
async function selectFirstNetwork(page, log) {
  // Разметка подтверждена отчётом 17.09: триггер — .recharge-chain .bx-select-popover,
  // список — .recharge-network-select-popper, пункты — .dp-item.network-option
  // (заголовок сети в .network-option__title). Меню шапки сюда не попадает.
  const trigger = page.locator('.recharge-chain .bx-select-popover').first();
  await trigger.click({ timeout: 5000 });
  const opts = page.locator('.recharge-network-select-popper .dp-item.network-option').filter({ visible: true });
  await opts.first().waitFor({ state: 'visible', timeout: 6000 });
  const opt = opts.first();
  const name = (await opt.locator('.network-option__title').first().innerText({ timeout: 3000 }).catch(() => '')).trim().slice(0, 40);
  await opt.click({ timeout: 5000 });
  await sleep(1500);
  log(`Сеть выбрана из списка: «${name || '?'}»`);
}

/** Выбранная сеть — текст триггера списка (не подсказка внутри выпадашки). */
async function readNetwork(page) {
  const t = await page.locator('.recharge-chain .bx-select-popover').first().innerText({ timeout: 4000 }).catch(() => '');
  const line = t.split('\n').map((x) => x.trim()).filter((x) => x && !/^не уверены/i.test(x))[0] || '';
  return line.slice(0, 60);
}

/** Разметка видимых модалок — в отчёт, если переключение не прошло (секретов там нет). */
async function visibleDialogsHtml(page) {
  return page.evaluate(() => {
    const vis = [...document.querySelectorAll('[class*="modal"],[class*="dialog"],[role="dialog"],[class*="popup"]')]
      .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    return vis.slice(0, 3).map((e) => e.outerHTML.slice(0, 2000)).join('\n---\n');
  }).catch(() => '');
}

/** ⇄ → «Спот счёт» → OK. Модалка «Выберите аккаунт» ищется по тексту: её
 *  разметка не подтверждена (пункты .asset-account-item из отчёта 17.09 оказались
 *  меню «Активы» в шапке, а не модалкой). */
async function setSpot(page, log) {
  const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
  // Триггер — значок ⇄ (ics-assets-huazhuan); текст рядом кликабелен не всегда.
  const icon = item.locator('.ics-assets-huazhuan, [class*="huazhuan"]').first();
  if (await icon.count()) await icon.click({ timeout: 5000 }); else await item.locator('.right-text').first().click({ timeout: 5000 });
  const title = page.getByText(/Выберите аккаунт|Select account|Choose account/i).filter({ visible: true }).first();
  await title.waitFor({ state: 'visible', timeout: 8000 });
  log('Модалка «Выберите аккаунт» открыта');
  const spot = page.getByText(/^\s*(Спот счет|Спот счёт|Spot account)\s*$/i).filter({ visible: true }).last();
  await spot.click({ timeout: 5000 });
  await sleep(300);
  const ok = page.getByText(/^\s*(OK|ОК|Подтвердить|Confirm)\s*$/i).filter({ visible: true }).last();
  await ok.click({ timeout: 8000 });
  await sleep(2000);
  log('Нажал ⇄ → «Спот счёт» → OK');
}

/**
 * @param {import('playwright').BrowserContext} context
 * @param {{coins?: string[], set?: 'SPOT'|null, log?: (m:string)=>void}} opts
 */
async function probeDepositAccount(context, opts = {}) {
  const log = opts.log || (() => {});
  const coins = (Array.isArray(opts.coins) && opts.coins.length ? opts.coins : ['USDT']).slice(0, 40).map((c) => String(c).toUpperCase());
  const set = opts.set === 'SPOT' ? 'SPOT' : null;
  const page = await getDepositPage(context, log);
  const rec = attachRecorder(page);
  const results = [];
  try {
    for (const coin of coins) {
      const r = { coin, url: null, coinShown: null, network: null, before: null, after: null, changed: false, error: null, setAt: null, requests: [], otherRequests: 0, notes: [], debug: null };
      const t0 = Date.now();
      const idx0 = rec.rows.length;
      const note = (m) => { r.notes.push(String(m).slice(0, 200)); log(m); };
      try {
        // Сначала about:blank: повторный goto на тот же адрес не перезагружал SPA,
        // и вызовы страницы (в т.ч. чтение «Счёта получения») в отчёт не попадали.
        await page.goto('about:blank').catch(() => {});
        await page.goto(DEPOSIT_URL_TMPL.replace('{coin}', encodeURIComponent(coin)), { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 });
        await sleep(2000);
        r.url = scrubUrl(page.url());
        r.coinShown = await readStepValue(page, 0);
        if (!r.coinShown.toUpperCase().includes(coin)) {
          await selectCoin(page, coin, log).catch((e) => log(`Список монет: ${e.message}`));
          r.coinShown = await readStepValue(page, 0);
        }
        r.network = await readNetwork(page);
        if (/выберите|select/i.test(r.network) || !(await readReceiveAccount(page))) {
          // Разметка шага «сеть» — до и после клика: селекторы списка сетей не
          // подтверждены, и пока «Счёт получения» не читается, отчёт несёт HTML,
          // по которому их можно уточнить (адресов/секретов в этом блоке нет).
          const stepHtml = await page.locator('.bx-step-content').nth(1).evaluate((el) => el.outerHTML).catch(() => '');
          await selectFirstNetwork(page, note).catch((e) => note(`Список сетей: ${e.message}`));
          r.network = await readNetwork(page);
          if (!(await readReceiveAccount(page))) {
            const openHtml = await page.evaluate(() => {
              const vis = [...document.querySelectorAll('[class*="dropdown"],[class*="popper"],[role="listbox"],[class*="select-menu"],[class*="options"]')]
                .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
              return vis.slice(0, 4).map((e) => e.outerHTML.slice(0, 1200)).join('\n---\n');
            }).catch(() => '');
            r.debug = { stepHtml: stepHtml.slice(0, 3000), openHtml: openHtml.slice(0, 4000) };
          }
        }
        r.before = await readReceiveAccount(page);
        note(`${coin}: показано «${r.coinShown}» / сеть «${r.network}» / счёт получения «${r.before || '?'}»`);
        if (set === 'SPOT' && r.before && !/Спот|Spot/i.test(r.before) && r.coinShown.toUpperCase().includes(coin)) {
          r.setAt = Date.now();
          try {
            await setSpot(page, note);
          } catch (e) {
            note(`переключение: ${String(e.message).split('\n')[0].slice(0, 160)}`);
            r.debug = { ...(r.debug || {}), dialogsHtml: (await visibleDialogsHtml(page)).slice(0, 6000) };
            await page.keyboard.press('Escape').catch(() => {});
          }
          r.after = await readReceiveAccount(page);
          r.changed = r.after !== r.before;
          note(`${coin}: счёт получения теперь «${r.after || '?'}»`);
        }
      } catch (e) {
        r.error = e.message;
        note(`${coin}: ${e.message}`);
      }
      const mine = rec.rows.slice(idx0).filter((x) => x.t >= t0);
      const relevant = mine.filter((x) => RELEVANT_RE.test(x.url)).map((x) => ({ ...x, phase: r.setAt && x.t >= r.setAt ? 'set' : 'load' }));
      // Вызовы ПОСЛЕ нажатия OK — главное: среди них смена счёта. Их отдаём первыми.
      relevant.sort((a, b) => (a.phase === b.phase ? a.t - b.t : a.phase === 'set' ? -1 : 1));
      r.requests = relevant.slice(0, MAX_REQ_PER_COIN);
      r.otherRequests = mine.length - r.requests.length;
      results.push(r);
      await sleep(1200); // темп: страница биржи, не API — но без залпа
    }
  } finally {
    rec.detach();
  }
  return { ok: true, set, results };
}

module.exports = { probeDepositAccount, scrub, scrubUrl };

'use strict';

/**
 * Тесты точечной привязки профиля к аккаунтам терминала.
 *
 * Класс, который они закрывают (оператор 2026-09-16, кейс «spot Aylan»): аккаунт
 * завели на прокси ПОСЛЕ последней синхронизации, в заметке профиля остался ключ
 * заготовки `draft-<proxyId>`, и исполнитель отвечал «Профиль для accountId не
 * найден» при открытом профиле. Кнопка «Привязка» переписывает ТОЛЬКО сегмент
 * accountIds — здесь проверяется, что она не задевает остального текста заметки
 * и что её строка совпадает с той, что пишет полная синхронизация.
 */

const test = require('node:test');
const assert = require('node:assert');

const { noteWithAccountIds, proxyKey } = require('./terminal-sync');

// Ровно тот префикс, что пишет боевой код (IMPORT_NOTE_PREFIX) — иначе тест
// проверял бы не ту строку, которую видит оператор.
const PREFIX = 'Импорт из терминала';

test('заготовка заменяется реальным accountId, остальной текст заметки цел', () => {
  const before = `${PREFIX}: прокси decodo 3 / биржи: BINGX / accountIds: draft-cmtyw9wjs04n8vtxesoas4rmb`;
  const after = noteWithAccountIds(before, ['cmtyzj9p20kg5vt1jw6mmh6yn'], ['BINGX']);
  assert.equal(after, `${PREFIX}: прокси decodo 3 / биржи: BINGX / accountIds: cmtyzj9p20kg5vt1jw6mmh6yn`);
  assert.ok(!after.includes('draft-'), 'ключ заготовки не должен остаться');
});

test('профиль на несколько аккаунтов: список переписывается целиком', () => {
  const before = `${PREFIX}: прокси decodo 1 / биржи: BINGX,MEXC / accountIds: a1,a2`;
  const after = noteWithAccountIds(before, ['a1', 'a2', 'a3'], ['BINGX', 'MEXC', 'XT']);
  assert.ok(after.endsWith('accountIds: a1,a2,a3'));
  assert.ok(after.includes('биржи: BINGX,MEXC,XT'), 'список бирж тоже обновляется');
});

test('дописанный оператором текст перед accountIds не теряется', () => {
  const before = `${PREFIX}: прокси decodo 2 / мой комментарий: не закрывать / accountIds: old`;
  const after = noteWithAccountIds(before, ['new'], []);
  assert.ok(after.includes('мой комментарий: не закрывать'));
  assert.ok(after.endsWith('accountIds: new'));
});

test('в заметке без accountIds сегмент дописывается, а не затирает её', () => {
  const after = noteWithAccountIds('ручной профиль', ['x1'], []);
  assert.equal(after, 'ручной профиль / accountIds: x1');
});

test('пустая заметка даёт только сегмент accountIds', () => {
  assert.equal(noteWithAccountIds('', ['x1'], []), 'accountIds: x1');
  assert.equal(noteWithAccountIds(undefined, ['x1'], []), 'accountIds: x1');
});

test('строка привязки совпадает с ключом группировки полной синхронизации', () => {
  // Кнопка ищет аккаунты тем же ключом, что и sync, — иначе они расходились бы.
  const acc = { accountId: 'a1', proxy: { type: 'HTTP', host: 'isp.decodo.com', port: 10003 } };
  assert.equal(proxyKey(acc), 'http://isp.decodo.com:10003');
  // Ключ профиля строится так же, из его собственного поля proxy.
  const px = { type: 'http', host: 'isp.decodo.com', port: 10003 };
  assert.equal(`${String(px.type).toLowerCase()}://${px.host}:${px.port}`, proxyKey(acc));
});

test('текст ПОСЛЕ списка id не теряется: сегмент кончается на «/»', () => {
  const before = `${PREFIX}: прокси decodo 1 / accountIds: a1,a2 / не закрывать вручную`;
  const after = noteWithAccountIds(before, ['b1'], []);
  assert.ok(after.includes('не закрывать вручную'), 'хвост заметки обязан выжить');
  assert.ok(after.includes('accountIds: b1'));
  assert.ok(!after.includes('a1'), 'старые id не остаются');
});

test('перевод строки не съедается — приписка оператора остаётся отдельной строкой', () => {
  const after = noteWithAccountIds('accountIds: a1,a2\nНЕ ЗАКРЫВАТЬ', ['b1'], []);
  assert.equal(after, 'accountIds: b1\nНЕ ЗАКРЫВАТЬ');
});

test('замена списка бирж не съедает остаток строки', () => {
  const before = `${PREFIX}: биржи: BINGX / accountIds: a1 / прочее`;
  const after = noteWithAccountIds(before, ['b1'], ['BINGX', 'MEXC']);
  assert.ok(after.includes('биржи: BINGX,MEXC'));
  assert.ok(after.includes('прочее'), 'текст после сегмента бирж обязан выжить');
});

test('спецсимволы замены в идентификаторе не раскрываются', () => {
  // Данные приходят извне (терминал) — `$&` в строке замены подставил бы совпадение.
  const after = noteWithAccountIds('accountIds: old', ['a$&b'], []);
  assert.equal(after, 'accountIds: a$&b');
});

test('строка кнопки совпадает с тем, что пишет полная синхронизация, и идемпотентна', () => {
  const sync = `${PREFIX}: прокси decodo 3 / биржи: BINGX / accountIds: cmtyzj9p20kg5vt1jw6mmh6yn`;
  const stale = `${PREFIX}: прокси decodo 3 / биржи: BINGX / accountIds: draft-cmtyw9wjs04n8vtxesoas4rmb`;
  const fixed = noteWithAccountIds(stale, ['cmtyzj9p20kg5vt1jw6mmh6yn'], ['BINGX']);
  assert.equal(fixed, sync, 'кнопка и синхронизация обязаны давать одну строку');
  assert.equal(noteWithAccountIds(fixed, ['cmtyzj9p20kg5vt1jw6mmh6yn'], ['BINGX']), fixed, 'повтор ничего не меняет');
});

test('аккаунт без прокси в группу по прокси не попадает', () => {
  const acc = { accountId: 'solo', proxy: null };
  assert.equal(proxyKey(acc), 'noproxy:solo');
  assert.notEqual(proxyKey(acc), 'http://isp.decodo.com:10003');
});

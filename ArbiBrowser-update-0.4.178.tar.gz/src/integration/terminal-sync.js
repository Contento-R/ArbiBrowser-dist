'use strict';

/**
 * terminal-sync.js — импорт аккаунтов из цекс-терминала в профили ArbiBrowser.
 *
 * Заменяет ADS Power: для каждого активного аккаунта терминала создаётся профиль
 * браузера, который СОВПАДАЕТ с тем, что терминал использует для этого аккаунта:
 *   • тот же прокси (host/port/тип/логин/пароль);
 *   • тот же фингерпринт (User-Agent / platform / версия Chrome из getAccountProfile).
 * Значит вход/2FA/ручная работа в браузере и API-запросы терминала выглядят для
 * биржи как ОДНО устройство — нет рассинхрона identity.
 *
 * Данные берутся из терминального эндпоинта
 *   GET /api/integrations/arbibrowser/accounts   (заголовок X-Arbi-Token)
 * Настройка: config.terminal.url + config.terminal.token
 * (env ARBI_TERMINAL_URL / ARBI_TERMINAL_TOKEN).
 */

const http = require('node:http');
const https = require('node:https');
const config = require('../../config');
const fs = require('node:fs');
const path = require('node:path');
const profileStore = require('../profile');
const generator = require('../fingerprint/generator');

// Метка в note импортированных профилей — по ней prune находит их и НЕ трогает
// профили, созданные пользователем вручную.
const IMPORT_NOTE_PREFIX = 'Импорт из терминала';

/** GET JSON с заголовком токена. */
function getJson(url, token) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https:') ? https : http;
    const req = lib.get(url, { headers: { 'X-Arbi-Token': token, Accept: 'application/json' }, timeout: 15000 }, (res) => {
      let data = '';
      res.on('data', (c) => (data += c));
      res.on('end', () => {
        let body;
        try { body = JSON.parse(data); } catch { body = null; }
        if (res.statusCode < 200 || res.statusCode >= 300) {
          const msg = (body && body.error) || `HTTP ${res.statusCode}`;
          return reject(new Error(msg));
        }
        resolve(body);
      });
    });
    req.on('timeout', () => req.destroy(new Error('таймаут запроса к терминалу')));
    req.on('error', reject);
  });
}

/** Приводит имя к допустимому виду профиля ([a-zA-Z0-9._-]). */
function sanitizeName(s) {
  return String(s).trim().replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 64) || 'account';
}

/** ProxyType терминала (HTTP|HTTPS|SOCKS5) → тип профиля (http|https|socks5). */
function mapProxy(p) {
  if (!p) return undefined;
  const proxy = { type: String(p.type).toLowerCase(), host: p.host, port: p.port };
  if (p.username) proxy.username = p.username;
  if (p.password) proxy.password = p.password;
  return proxy;
}

/** platform терминала (Windows|macOS|Linux) → os генератора. */
function mapOs(platform) {
  if (platform === 'macOS') return 'macOS';
  if (platform === 'Linux') return 'Linux';
  return 'Windows';
}

/**
 * Ключ группировки: аккаунты на ОДНОМ прокси (одном IP) → один профиль браузера.
 * Так антибот биржи видит один «девайс» на прокси, а не по одному на аккаунт.
 * Аккаунт без прокси получает собственный профиль (ключ по accountId).
 */
function proxyKey(acc) {
  const p = acc.proxy;
  if (!p || !p.host) return `noproxy:${acc.accountId}`;
  return `${String(p.type).toLowerCase()}://${p.host}:${p.port}`;
}

/**
 * Собирает ОДИН профиль ArbiBrowser из ГРУППЫ аккаунтов на одном прокси
 * (= прокси-профиль терминала). В профиль логинятся все биржи этого прокси;
 * seed = ключ прокси (стабильный отпечаток на IP, а не на аккаунт). В note —
 * список всех accountId, чтобы исполнитель нашёл профиль по любому из них.
 */
function profileFromProxyGroup(key, accs) {
  const first = accs[0];
  const fp = first.fingerprint || {};
  const p = first.proxy;
  const accountIds = accs.map((a) => a.accountId);
  const exchanges = [...new Set(accs.map((a) => a.exchange).filter(Boolean))];
  // Имя — по label прокси-профиля терминала; фолбэк host-port; иначе биржа-метка.
  const baseName = (p && p.label) ? `proxy-${p.label}`
    : (p ? `proxy-${p.host}-${p.port}` : `${first.exchange}-${first.label}`);
  const profile = generator.generate({
    name: sanitizeName(baseName),
    seed: key, // стабильный отпечаток на ПРОКСИ (не на аккаунт)
    os: mapOs(fp.platform),
    userAgent: fp.userAgent || undefined,
    chromeMajor: fp.chromeVersion || undefined,
    proxy: mapProxy(p),
    note: `${IMPORT_NOTE_PREFIX}: прокси ${p ? (p.label || `${p.host}:${p.port}`) : 'нет'}`
      + ` / биржи: ${exchanges.join(',')} / accountIds: ${accountIds.join(',')}`,
  });
  profile.group = 'by-proxy';
  return profile;
}

/**
 * Заметка профиля с ОБНОВЛЁННЫМ списком accountIds (и биржами, если они там были).
 * Меняются только эти сегменты: дописанный оператором текст остаётся на месте.
 * Формат тот же, что пишет `profileFromProxyGroup`, — значит точечная привязка
 * одного профиля и полная синхронизация дают одинаковую строку, и они не спорят.
 */
function noteWithAccountIds(note, ids, exchanges) {
  const src = typeof note === 'string' ? note : '';
  // Сегмент кончается на разделителе «/» или переводе строки — иначе класс
  // символов со \s съедал ЛЮБОЙ латинский хвост за списком id и текст оператора
  // пропадал без следа (ревью 2026-09-16). Замена — ФУНКЦИЯ: в строке замены
  // `$&`/`$1` из внешних данных раскрылись бы как ссылки на совпадение.
  // Заглядывание вперёд оставляет пробел перед разделителем на месте — заметка
  // после правки выглядит ровно как была, меняется только список id.
  const tail = () => `accountIds: ${ids.join(',')}`;
  let out = /accountIds:/i.test(src)
    ? src.replace(/accountIds:[^/\n]*?(?=\s*(?:\/|\n|$))/i, tail)
    : (src ? `${src} / ${tail()}` : tail());
  if (exchanges && exchanges.length && /биржи:/i.test(out)) {
    out = out.replace(/биржи:[^/\n]*?(?=\s*(?:\/|\n|$))/i, () => `биржи: ${exchanges.join(',')}`);
  }
  return out.trim();
}

/** Запрашивает аккаунты у терминала. */
async function fetchAccounts() {
  if (!config.terminal.token) {
    throw new Error('Не задан токен: установите ARBI_TERMINAL_TOKEN (совпадающий с ARBI_TOKEN терминала).');
  }
  const url = config.terminal.url.replace(/\/+$/, '') + '/api/integrations/arbibrowser/accounts';
  const body = await getJson(url, config.terminal.token);
  return (body && body.accounts) || [];
}

/**
 * Полная синхронизация: тянет аккаунты и создаёт/обновляет профили.
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{created:string[], updated:string[], skipped:{name:string,reason:string}[], total:number}>}
 */
async function sync(opts = {}) {
  const log = opts.log || (() => {});
  log(`Запрос аккаунтов у терминала: ${config.terminal.url}`);
  const accounts = await fetchAccounts();
  log(`Получено аккаунтов: ${accounts.length}`);

  // Группируем аккаунты по прокси: один профиль = один прокси (все биржи на нём).
  const groups = new Map();
  for (const acc of accounts) {
    const key = proxyKey(acc);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(acc);
  }
  log(`Прокси-профилей (групп): ${groups.size}`);

  const created = [];
  const updated = [];
  const skipped = [];

  const syncedNames = new Set();
  for (const [key, accs] of groups.entries()) {
    try {
      const profile = profileFromProxyGroup(key, accs);
      const existed = profileStore.exists(profile.name);
      if (!existed) {
        // Новый профиль на чужом каталоге браузера (одноимённый когда-то удалили, каталог
        // остался) = cookies/история старого аккаунта в «чистом устройстве». Откладываем
        // каталог; не смогли — группа пропускается (catch ниже), профиль не создаётся.
        const q = profileStore.quarantineStaleUserData(profile.name);
        if (q) log(`⚠ ${profile.name}: на диске уже был каталог браузера прежнего профиля с этим именем — отложен как ${path.basename(q)}, новый профиль стартует чистым`);
      }
      profileStore.save(profile);
      syncedNames.add(profile.name);
      (existed ? updated : created).push(profile.name);
      const exs = [...new Set(accs.map((a) => a.exchange).filter(Boolean))].join(',');
      log(`${existed ? 'обновлён' : 'создан'}: ${profile.name} — биржи [${exs}], аккаунтов ${accs.length}`
        + `${profile.proxy ? ` (прокси ${profile.proxy.type}://${profile.proxy.host}:${profile.proxy.port})` : ' (без прокси)'}`);
    } catch (e) {
      const f = accs[0] || {};
      skipped.push({ name: `${f.exchange}-${f.label}`, reason: e.message });
      log(`пропущена группа ${key}: ${e.message}`);
    }
  }

  // Опционально удаляем ранее импортированные профили, которых больше нет в
  // ответе (напр. чужие аккаунты после перехода на per-user токен). Трогаем
  // ТОЛЬКО импортированные (по метке в note), пользовательские профили не удаляем.
  const pruned = [];
  if (opts.prune) {
    for (const name of profileStore.list()) {
      if (syncedNames.has(name)) continue;
      const r = profileStore.loadResult(name);
      const note = r.profile && r.profile.note;
      if (note && note.startsWith(IMPORT_NOTE_PREFIX)) {
        profileStore.remove(name);
        try { fs.rmSync(path.join(config.userDataRoot, name), { recursive: true, force: true }); } catch { /* нет каталога */ }
        pruned.push(name);
        log(`удалён импортированный (нет в ответе): ${name}`);
      }
    }
  }

  return { created, updated, skipped, pruned, total: accounts.length };
}

module.exports = { sync, fetchAccounts, profileFromProxyGroup, proxyKey, sanitizeName, mapProxy, mapOs, noteWithAccountIds };

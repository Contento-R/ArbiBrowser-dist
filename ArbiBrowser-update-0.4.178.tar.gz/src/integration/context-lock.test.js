'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { withContextLock } = require('./context-lock');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('withContextLock: сериализует задачи на одном ключе (нет перекрытия)', async () => {
  const ctx = {};
  const events = [];
  const task = (id, ms) => withContextLock(ctx, async () => {
    events.push(`start-${id}`);
    await sleep(ms);
    events.push(`end-${id}`);
  });
  await Promise.all([task('A', 30), task('B', 5), task('C', 5)]);
  // Каждая задача полностью завершается до старта следующей: start/end чередуются парами.
  assert.deepEqual(events, ['start-A', 'end-A', 'start-B', 'end-B', 'start-C', 'end-C']);
});

test('withContextLock: разные ключи идут параллельно', async () => {
  const a = {}, b = {};
  const events = [];
  const ta = withContextLock(a, async () => { events.push('a-start'); await sleep(20); events.push('a-end'); });
  const tb = withContextLock(b, async () => { events.push('b-start'); await sleep(5); events.push('b-end'); });
  await Promise.all([ta, tb]);
  // b успевает завершиться, пока a ещё работает → перекрытие есть.
  assert.equal(events.indexOf('b-end') < events.indexOf('a-end'), true);
});

test('withContextLock: упавшая задача не блокирует очередь', async () => {
  const ctx = {};
  const results = [];
  const p1 = withContextLock(ctx, async () => { throw new Error('boom'); }).catch((e) => results.push('err:' + e.message));
  const p2 = withContextLock(ctx, async () => { results.push('ok'); });
  await Promise.all([p1, p2]);
  assert.deepEqual(results, ['err:boom', 'ok']);
});

test('withContextLock: фоновая дорожка НЕ задерживает заявку (оператор 01.09)', async () => {
  const ctx = {};
  const events = [];
  // Долгое фоновое чтение стартует первым и держит свою дорожку.
  const bg = withContextLock(ctx, async () => {
    events.push('bg-start'); await sleep(40); events.push('bg-end');
  }, { lane: 'bg' });
  await sleep(5);
  // Заявка приходит, пока чтение ещё идёт, — и НЕ ждёт его.
  const order = withContextLock(ctx, async () => { events.push('order'); });
  await Promise.all([bg, order]);
  assert.ok(events.indexOf('order') < events.indexOf('bg-end'), 'заявка прошла до конца чтения: ' + events.join(','));
});

test('withContextLock: внутри дорожки сериализация сохраняется', async () => {
  const ctx = {};
  const events = [];
  const bg = (id, ms) => withContextLock(ctx, async () => {
    events.push(`s-${id}`); await sleep(ms); events.push(`e-${id}`);
  }, { lane: 'bg' });
  await Promise.all([bg('A', 20), bg('B', 5)]);
  assert.deepEqual(events, ['s-A', 'e-A', 's-B', 'e-B']);
});

test('isContextBusy: занятость денежного пути не путается с фоном', async () => {
  const { isContextBusy } = require('./context-lock');
  const ctx = {};
  const bg = withContextLock(ctx, () => sleep(20), { lane: 'bg' });
  assert.equal(isContextBusy(ctx), false, 'фоновое чтение НЕ считается занятым ордером');
  assert.equal(isContextBusy(ctx, 'bg'), true);
  const order = withContextLock(ctx, () => sleep(10));
  assert.equal(isContextBusy(ctx), true, 'заявка занимает денежный путь');
  await Promise.all([bg, order]);
  assert.equal(isContextBusy(ctx), false);
});

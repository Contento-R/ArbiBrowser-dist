'use strict';

// Тест журнала идемпотентности (CR-5). Задаём временный ARBI_DATA_DIR ДО require,
// чтобы журнал писался в tmp, а не в реальный data-каталог.
const os = require('node:os');
const fs = require('node:fs');
const path = require('node:path');

const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'arbi-journal-'));
process.env.ARBI_DATA_DIR = TMP;

const test = require('node:test');
const assert = require('node:assert/strict');
const { _journal } = require('./executor-core');

test('journal: round-trip по intent.id', () => {
  _journal.journalSet('id-1', { result: { ok: true, orderId: 'X1' } });
  const got = _journal.journalGet('id-1');
  assert.equal(got.result.orderId, 'X1');
  assert.ok(got.ts > 0);
  // Персистится на диск.
  assert.ok(fs.existsSync(_journal.JOURNAL_PATH));
});

test('journal: неизвестный id → undefined', () => {
  assert.equal(_journal.journalGet('нет-такого'), undefined);
});

test('journal M2: inflight-маркер round-trip + атомарная запись (нет .tmp, валидный JSON)', () => {
  _journal.journalSet('id-inflight', { inflight: true });
  const got = _journal.journalGet('id-inflight');
  assert.equal(got.inflight, true);
  assert.equal(got.result, undefined); // результата ещё нет → на рестарте отдадим unknown
  // Атомарность: временный файл не остаётся, основной — валидный JSON.
  assert.ok(!fs.existsSync(_journal.JOURNAL_PATH + '.tmp'), '.tmp не должен оставаться');
  const parsed = JSON.parse(fs.readFileSync(_journal.JOURNAL_PATH, 'utf8'));
  assert.equal(parsed['id-inflight'].inflight, true);
});

test('journal: TTL-прунинг при свежей загрузке (в дочернем процессе)', () => {
  // Прунинг живёт в loadJournal и срабатывает при ПЕРВОМ чтении. Модульный кэш в
  // этом процессе уже населён, поэтому проверяем в чистом дочернем процессе: пишем
  // файл с протухшей и свежей записью → грузим → протухшая должна исчезнуть.
  const { execFileSync } = require('node:child_process');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'arbi-journal-ttl-'));
  const jpath = path.join(dir, 'intent-journal.json');
  const TTL = _journal.JOURNAL_TTL_MS;
  fs.writeFileSync(jpath, JSON.stringify({
    old: { result: { ok: true }, ts: Date.now() - TTL - 1000 },
    fresh: { result: { ok: true }, ts: Date.now() },
  }), 'utf8');
  const script = `process.env.ARBI_DATA_DIR=${JSON.stringify(dir)};`
    + `const { _journal } = require(${JSON.stringify(path.resolve(__dirname, 'executor-core.js'))});`
    + `_journal.loadJournal();`
    + `const j = JSON.parse(require('fs').readFileSync(${JSON.stringify(jpath)},'utf8'));`
    + `process.stdout.write(JSON.stringify({ hasOld: 'old' in j, hasFresh: 'fresh' in j }));`;
  const out = execFileSync(process.execPath, ['-e', script], { encoding: 'utf8' });
  const res = JSON.parse(out);
  assert.equal(res.hasOld, false, 'протухшая запись должна быть удалена');
  assert.equal(res.hasFresh, true, 'свежая запись должна остаться');
  fs.rmSync(dir, { recursive: true, force: true });
});

test.after(() => { try { fs.rmSync(TMP, { recursive: true, force: true }); } catch { /* ignore */ } });

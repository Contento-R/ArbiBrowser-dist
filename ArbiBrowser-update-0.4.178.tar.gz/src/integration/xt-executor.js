'use strict';

/**
 * xt-executor.js — локальный исполнитель web-ордеров XT.
 *
 * Тонкая обёртка над общим транспортом executor-core.js (keep-alive + long-poll,
 * зеркально для MEXC и будущего BingX). Опрашивает очередь намерений XT у
 * цекс-терминала (per-user X-Arbi-Token), исполняет их в живой странице XT
 * запущенного профиля и постит результат.
 */

const { makeExecutor, requestJson } = require('./executor-core');

const impl = makeExecutor({
  pendingPath: '/api/integrations/arbibrowser/xt/pending',
  resultPath: '/api/integrations/arbibrowser/xt/result',
  waitEnv: 'ARBI_XT_WAIT_MS',   // long-poll hold, мс (0 = откл. long-poll)
  pollEnv: 'ARBI_XT_POLL_MS',   // фолбэк-интервал для сервера без long-poll
});

module.exports = { pollOnce: impl.pollOnce, startLoop: impl.startLoop, requestJson };

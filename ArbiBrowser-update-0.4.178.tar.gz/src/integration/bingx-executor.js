'use strict';

/**
 * bingx-executor.js — локальный исполнитель web-ордеров BingX.
 *
 * Тонкая обёртка над общим транспортом executor-core.js (keep-alive + long-poll,
 * зеркально XT/MEXC). Опрашивает очередь намерений BingX у цекс-терминала
 * (per-user X-Arbi-Token), исполняет их в живой странице BingX запущенного
 * профиля и постит результат. У BingX нет серверного replay — браузер
 * единственный путь для API-disabled токенов.
 */

const { makeExecutor, requestJson } = require('./executor-core');

const impl = makeExecutor({
  pendingPath: '/api/integrations/arbibrowser/bingx/pending',
  resultPath: '/api/integrations/arbibrowser/bingx/result',
  waitEnv: 'ARBI_BINGX_WAIT_MS',   // long-poll hold, мс (0 = откл. long-poll)
  pollEnv: 'ARBI_BINGX_POLL_MS',   // фолбэк-интервал для сервера без long-poll
});

module.exports = { pollOnce: impl.pollOnce, startLoop: impl.startLoop, requestJson };

'use strict';

/**
 * generator.js — генератор УНИКАЛЬНОГО СОГЛАСОВАННОГО отпечатка.
 *
 * Цель: по имени профиля (seed) детерминированно собрать внутренне согласованный
 * набор параметров (navigator ↔ User-Agent ↔ Client Hints ↔ WebGL ↔ screen).
 *
 * Почему детерминированно от seed: отпечаток профиля должен быть СТАБИЛЕН между
 * запусками (как в ADS Power). Иначе один и тот же аккаунт каждый раз выглядит
 * новым устройством — это само по себе аномалия. Один seed → один и тот же отпечаток.
 *
 * Генерируются только ВЗАИМНО СОГЛАСОВАННЫЕ комбинации: мы не миксуем случайно
 * поля, а выбираем целостный пресет ОС и варьируем внутри его допустимых границ
 * (версия Chrome, число ядер, память, разрешение экрана, GPU из списка под эту ОС).
 */

const crypto = require('node:crypto');

// ─── Детерминированный PRNG (mulberry32), засеянный из строки ───

function seedFromString(str) {
  const h = crypto.createHash('sha256').update(String(str)).digest();
  // Берём первые 4 байта как uint32.
  return (h[0] << 24) | (h[1] << 16) | (h[2] << 8) | h[3];
}

function mulberry32(a) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeRng(seed) {
  const rng = mulberry32(seedFromString(seed) >>> 0);
  return {
    next: rng,
    pick: (arr) => arr[Math.floor(rng() * arr.length)],
    int: (min, max) => min + Math.floor(rng() * (max - min + 1)),
  };
}

// ─── Пулы согласованных значений по ОС ───
// Версии Chrome держим в узком актуальном коридоре.
const CHROME_VERSIONS = [
  { major: 139, full: '139.0.7258.128' },
  { major: 140, full: '140.0.7339.128' },
  { major: 141, full: '141.0.7390.65' },
];

// Реалистичные десктопные разрешения.
const RESOLUTIONS = [
  { width: 1920, height: 1080 },
  { width: 2560, height: 1440 },
  { width: 1536, height: 864 },
  { width: 1440, height: 900 },
  { width: 1366, height: 768 },
  { width: 1680, height: 1050 },
];

const HW_CONCURRENCY = [4, 6, 8, 12, 16];
const DEVICE_MEMORY = [4, 8];

// GPU-пулы, согласованные с ОС (UNMASKED_VENDOR / UNMASKED_RENDERER).
const GPU = {
  Windows: [
    {
      vendor: 'Google Inc. (NVIDIA)',
      renderer:
        'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002503) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    },
    {
      vendor: 'Google Inc. (NVIDIA)',
      renderer:
        'ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 (0x00002184) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    },
    {
      vendor: 'Google Inc. (Intel)',
      renderer:
        'ANGLE (Intel, Intel(R) UHD Graphics 630 (0x00003E9B) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    },
    {
      vendor: 'Google Inc. (AMD)',
      renderer:
        'ANGLE (AMD, AMD Radeon RX 6600 (0x000073FF) Direct3D11 vs_5_0 ps_5_0, D3D11)',
    },
  ],
  macOS: [
    { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)' },
    { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M2, Unspecified Version)' },
    { vendor: 'Google Inc. (Apple)', renderer: 'ANGLE (Apple, ANGLE Metal Renderer: Apple M3, Unspecified Version)' },
  ],
  Linux: [
    { vendor: 'Google Inc. (Intel)', renderer: 'ANGLE (Intel, Mesa Intel(R) UHD Graphics 620 (KBL GT2), OpenGL 4.6)' },
    { vendor: 'Google Inc. (AMD)', renderer: 'ANGLE (AMD, AMD Radeon Graphics (radeonsi), OpenGL 4.6)' },
  ],
};

// Версии платформы для Client Hints.
const PLATFORM_VERSIONS = {
  Windows: ['10.0.0', '15.0.0', '13.0.0'], // "15.0.0" = Windows 11 в терминах CH
  macOS: ['14.5.0', '13.6.0', '15.1.0'],
  Linux: ['6.5.0', '6.8.0'],
};

// Соответствие ОС → navigator.platform / CH platform / фрагмент UA.
const OS_MAP = {
  Windows: {
    navPlatform: 'Win32',
    chPlatform: 'Windows',
    uaOs: 'Windows NT 10.0; Win64; x64',
    arch: 'x86',
  },
  macOS: {
    navPlatform: 'MacIntel',
    chPlatform: 'macOS',
    uaOs: 'Macintosh; Intel Mac OS X 10_15_7',
    arch: 'x86', // Chrome на Apple Silicon всё равно рапортует x86 в CH-Arch по историческим причинам
  },
  Linux: {
    navPlatform: 'Linux x86_64',
    chPlatform: 'Linux',
    uaOs: 'X11; Linux x86_64',
    arch: 'x86',
  },
};

// Соответствие locale → timezone (грубое, если гео ещё неизвестно; при запуске
// перекрывается реальным GeoIP прокси).
const LOCALE_DEFAULTS = {
  'en-US': { timezone: 'America/New_York', languages: ['en-US', 'en'] },
  'en-GB': { timezone: 'Europe/London', languages: ['en-GB', 'en'] },
  'de-DE': { timezone: 'Europe/Berlin', languages: ['de-DE', 'de', 'en'] },
  'fr-FR': { timezone: 'Europe/Paris', languages: ['fr-FR', 'fr', 'en'] },
  'ru-RU': { timezone: 'Europe/Moscow', languages: ['ru-RU', 'ru', 'en'] },
};

// ─── Генерация ───

/**
 * Собирает согласованный отпечаток.
 * @param {object} opts
 * @param {string} opts.name        имя профиля (обязателен) — идёт в seed и в profile.name
 * @param {string} [opts.seed]      явный seed (по умолчанию = name)
 * @param {'Windows'|'macOS'|'Linux'} [opts.os]  фиксировать ОС (иначе выбирается по seed)
 * @param {string} [opts.locale]    базовая локаль (по умолчанию en-US; при запуске уточняется по GeoIP)
 * @param {object} [opts.proxy]     блок proxy для вставки в профиль
 * @param {string} [opts.note]
 * @returns {object} профиль, соответствующий schema.json
 */
function generate(opts = {}) {
  if (!opts.name) throw new Error('generate(): требуется opts.name');
  const rng = makeRng(opts.seed || opts.name);

  const osName = opts.os || rng.pick(['Windows', 'macOS', 'Linux', 'Windows', 'Windows']); // Windows чаще
  const osm = OS_MAP[osName];

  // Версия Chrome: можно зафиксировать (opts.chromeMajor) — нужно для точного
  // совпадения с фингерпринтом цекс-терминала (getAccountProfile).
  const chrome = opts.chromeMajor
    ? { major: Number(opts.chromeMajor), full: `${Number(opts.chromeMajor)}.0.0.0` }
    : rng.pick(CHROME_VERSIONS);
  const res = rng.pick(RESOLUTIONS);
  const gpu = rng.pick(GPU[osName]);
  const platformVersion = rng.pick(PLATFORM_VERSIONS[osName]);
  const hw = rng.pick(HW_CONCURRENCY);
  const mem = rng.pick(DEVICE_MEMORY);

  // Локаль: если задана явно — фиксируем (autoGeo=false). Если «авто» — ставим
  // временную en-US как fallback, а при запуске с прокси её перетрёт гео IP (autoGeo=true).
  const localeExplicit = !!opts.locale;
  const locale = opts.locale || 'en-US';
  const loc = LOCALE_DEFAULTS[locale] || LOCALE_DEFAULTS['en-US'];

  // User-Agent: можно передать готовый (opts.userAgent) для 1:1 совпадения с
  // терминалом; иначе собираем из ОС и версии Chrome.
  const userAgent =
    opts.userAgent ||
    `Mozilla/5.0 (${osm.uaOs}) AppleWebKit/537.36 (KHTML, like Gecko) ` +
      `Chrome/${chrome.major}.0.0.0 Safari/537.36`;

  // Таскбар/док: доступная высота чуть меньше физической.
  const availHeightDelta = osName === 'macOS' ? 25 : 40;

  const profile = {
    name: opts.name,
    note: opts.note || `Автосгенерирован (${osName}, Chrome ${chrome.major})`,
    autoGeo: !localeExplicit, // авто-локаль → гео из прокси; явная локаль → фиксирована
    navigator: {
      platform: osm.navPlatform,
      hardwareConcurrency: hw,
      deviceMemory: mem,
      maxTouchPoints: 0,
      doNotTrack: null,
    },
    userAgent,
    clientHints: {
      brands: [
        { brand: 'Chromium', version: String(chrome.major) },
        { brand: 'Google Chrome', version: String(chrome.major) },
        { brand: 'Not?A_Brand', version: '99' },
      ],
      fullVersionList: [
        { brand: 'Chromium', version: chrome.full },
        { brand: 'Google Chrome', version: chrome.full },
        { brand: 'Not?A_Brand', version: '99.0.0.0' },
      ],
      platform: osm.chPlatform,
      platformVersion,
      architecture: osm.arch,
      bitness: '64',
      model: '',
      mobile: false,
      wow64: false,
    },
    screen: {
      width: res.width,
      height: res.height,
      availWidth: res.width,
      availHeight: res.height - availHeightDelta,
      colorDepth: 24,
      pixelDepth: 24,
      devicePixelRatio: osName === 'macOS' ? 2 : 1,
      viewport: {
        width: res.width,
        height: res.height - availHeightDelta - 74, // минус хром браузера
      },
    },
    webgl: {
      vendor: gpu.vendor,
      renderer: gpu.renderer,
    },
    locale,
    languages: loc.languages,
    timezone: loc.timezone,
    geolocation: undefined, // заполнится из GeoIP прокси при запуске
  };

  if (opts.proxy) profile.proxy = opts.proxy;

  // Убираем undefined-поля (JSON их не сериализует, но подстрахуемся).
  Object.keys(profile).forEach((k) => profile[k] === undefined && delete profile[k]);

  return profile;
}

module.exports = { generate, makeRng, seedFromString };

'use strict';

/**
 * src/fingerprint — применение параметров профиля к Chromium.
 *
 * Три уровня применения (каждый закрывает то, что не покрывают другие):
 *
 *  1) Playwright Context options — штатные поля (userAgent, locale, timezoneId,
 *     geolocation, viewport, deviceScaleFactor, screen, extraHTTPHeaders).
 *  2) CDP (Emulation.*) — то, чего нет в API Playwright: User-Agent Client Hints
 *     (userAgentMetadata), жёсткая фиксация timezone/locale на уровне движка.
 *  3) addInitScript — то, что правится только в JS-контексте страницы до её кода:
 *     navigator.hardwareConcurrency/deviceMemory/platform, WebGL vendor/renderer,
 *     параметры screen, navigator.languages.
 *
 * ВСЕ значения берутся ТОЛЬКО из JSON-профиля. Никаких «случайных» значений здесь.
 *
 * Ограничения (важно):
 *  • Playwright не выставляет Sec-CH-UA автоматически из userAgent — их задаём
 *    через CDP Emulation.setUserAgentOverride.userAgentMetadata (см. applyCdp).
 *  • Реальные screen.width/height у Chromium привязаны к окну ОС; в headless и в
 *    окне мы переопределяем их из JS (addInitScript). Это косметика на уровне DOM,
 *    физический размер окна задаём через viewport/--window-size в launcher.
 *  • navigator.deviceMemory квантуется браузером (0.25..8) — используем те же ступени.
 */

const net = require('../network');

// ─── Уровень 1: опции Playwright Context ───

/**
 * Строит опции для launchPersistentContext из профиля (после applyGeo).
 * @param {object} profile
 * @param {string} acceptLanguage
 * @returns {object}
 */
function contextOptions(profile, acceptLanguage) {
  const opts = {
    userAgent: profile.userAgent,
    locale: profile.locale,
    timezoneId: profile.timezone,
    // extraHTTPHeaders гарантирует Accept-Language, согласованный с locale.
    extraHTTPHeaders: acceptLanguage ? { 'Accept-Language': acceptLanguage } : undefined,
  };

  if (profile.geolocation) {
    opts.geolocation = {
      latitude: profile.geolocation.latitude,
      longitude: profile.geolocation.longitude,
      accuracy: profile.geolocation.accuracy || 100,
    };
    opts.permissions = ['geolocation'];
  }

  // viewport:null — контент следует за РЕАЛЬНЫМ окном ОС: окно разворачивается
  // без принудительной полосы прокрутки, а размер страницы зависит от того, как
  // окно развёрнуто (как в обычном браузере). НЕ форсируем фикс-viewport и не
  // отдаём screen-подсказку меньшего размера — иначе при maximize innerWidth стал
  // бы больше screen.width (детектируемый рассинхрон). screen репортим реальный.
  //
  // ВАЖНО: Playwright запрещает deviceScaleFactor при viewport:null — поэтому его
  // здесь НЕ задаём; нужный devicePixelRatio ставится в initScript (window.devicePixelRatio).
  opts.viewport = null;

  return opts;
}

// ─── Уровень 2: CDP ───

/**
 * Применяет через CDP то, чего нет в API Playwright: Client Hints + фиксация TZ/locale.
 * @param {import('playwright').Page} page
 * @param {object} profile
 * @param {string} acceptLanguage
 */
async function applyCdp(page, profile, acceptLanguage) {
  const client = await page.context().newCDPSession(page);

  // User-Agent + Client Hints (userAgentMetadata). Именно так задаются Sec-CH-UA.
  const ch = profile.clientHints;
  const metadata = ch
    ? {
        brands: ch.brands,
        fullVersionList: ch.fullVersionList || ch.brands,
        platform: ch.platform,
        platformVersion: ch.platformVersion,
        architecture: ch.architecture,
        bitness: ch.bitness || '64',
        model: ch.model || '',
        mobile: !!ch.mobile,
        wow64: !!ch.wow64,
      }
    : undefined;

  // ВАЖНО про acceptLanguage: CDP ждёт СПИСОК языковых ТЕГОВ и САМ навешивает
  // q-веса при сборке заголовка Accept-Language. Если передать сюда уже
  // q-размеченную строку ("es-ES,es;q=0.9,en;q=0.8"), Chromium трактует
  // "es;q=0.9" как тег и добавит q ПОВТОРНО → битый "es;q=0.9;q=0.9". Поэтому
  // отдаём в CDP только теги без q; веса Chromium проставит сам (чисто).
  const langTags = (Array.isArray(profile.languages) && profile.languages.length
    ? profile.languages
    : [profile.locale || 'en-US'])
    .map((l) => String(l).split(';')[0].trim())
    .filter(Boolean)
    .join(',');

  await client.send('Emulation.setUserAgentOverride', {
    userAgent: profile.userAgent,
    acceptLanguage: langTags || undefined,
    platform: platformStringFor(profile),
    userAgentMetadata: metadata,
  });

  // Жёстко фиксируем timezone на уровне движка (дублирует context.timezoneId,
  // но CDP-override надёжнее для воркеров/iframe).
  if (profile.timezone) {
    try {
      await client.send('Emulation.setTimezoneOverride', { timezoneId: profile.timezone });
    } catch (e) {
      // Некоторые сборки бросают, если TZ уже равен системному — не критично.
    }
  }

  if (profile.locale) {
    try {
      await client.send('Emulation.setLocaleOverride', { locale: profile.locale });
    } catch (e) {
      /* аналогично */
    }
  }
}

/** navigator.platform-совместимая строка «platform» для CDP UA-override. */
function platformStringFor(profile) {
  const p = profile.navigator && profile.navigator.platform;
  if (p === 'Win32') return 'Windows';
  if (p === 'MacIntel') return 'macOS';
  return 'Linux';
}

// ─── Уровень 3: addInitScript ───

/**
 * Возвращает функцию инициализации страницы. Выполняется ДО кода страницы в
 * каждом фрейме. Правит только DOM/JS-видимые поля из профиля.
 */
function initScriptFn() {
  // Внутри — чистый браузерный контекст. Профиль приходит аргументом.
  return (p) => {
    const define = (obj, prop, value) => {
      try {
        Object.defineProperty(obj, prop, { get: () => value, configurable: true });
      } catch (e) {
        /* поле может быть не переопределяемо в этой сборке */
      }
    };

    // navigator.*
    if (p.navigator) {
      const n = p.navigator;
      if (n.platform != null) define(navigator, 'platform', n.platform);
      if (n.hardwareConcurrency != null) define(navigator, 'hardwareConcurrency', n.hardwareConcurrency);
      if (n.deviceMemory != null) define(navigator, 'deviceMemory', n.deviceMemory);
      if (n.maxTouchPoints != null) define(navigator, 'maxTouchPoints', n.maxTouchPoints);
    }
    if (p.languages) {
      // Санитайз: срезаем любые ";q=..."-хвосты у тегов (могли попасть из старого
      // сохранения) — navigator.languages должен быть чистым ["es-ES","es","en"].
      const langs = p.languages.map((l) => String(l).split(';')[0].trim()).filter(Boolean);
      define(navigator, 'languages', Object.freeze(langs));
    }

    // navigator.webdriver НЕ патчим здесь: он убран НАТИВНО флагом запуска
    // --disable-blink-features=AutomationControlled (см. launcher). JS-override
    // создавал бы own-property со стрелочным геттером — а именно это (hasOwnProperty
    // + getter.toString() ≠ "[native code]") палит Google/reCAPTCHA. Нативный
    // webdriver=false на Navigator.prototype неотличим от обычного браузера.

    // screen.*
    if (p.screen) {
      const s = p.screen;
      // width/height/availWidth/availHeight НЕ спуфим: окно запускается с
      // viewport:null и следует за реальным дисплеем. Спуф меньшего screen дал бы
      // при разворачивании innerWidth > screen.width (рассинхрон, детектируемо).
      // Реальный screen — низкоэнтропийный и всегда согласован с окном. Оставляем
      // только глубину цвета и DPR (не зависят от размера окна).
      if (s.colorDepth != null) define(screen, 'colorDepth', s.colorDepth);
      if (s.pixelDepth != null) define(screen, 'pixelDepth', s.pixelDepth);
      if (s.devicePixelRatio != null) define(window, 'devicePixelRatio', s.devicePixelRatio);
    }

    // WebGL vendor/renderer (UNMASKED_*). Патчим getParameter у обоих контекстов.
    if (p.webgl && (p.webgl.vendor || p.webgl.renderer)) {
      const UNMASKED_VENDOR = 0x9245; // 37445
      const UNMASKED_RENDERER = 0x9246; // 37446
      const patch = (proto) => {
        if (!proto) return;
        const orig = proto.getParameter;
        proto.getParameter = function (param) {
          if (param === UNMASKED_VENDOR && p.webgl.vendor) return p.webgl.vendor;
          if (param === UNMASKED_RENDERER && p.webgl.renderer) return p.webgl.renderer;
          return orig.call(this, param);
        };
      };
      if (typeof WebGLRenderingContext !== 'undefined') patch(WebGLRenderingContext.prototype);
      if (typeof WebGL2RenderingContext !== 'undefined') patch(WebGL2RenderingContext.prototype);
    }

    // ── speechSynthesis: голоса согласуем с ОС+локалью профиля ──────────────
    // Реальные ОС-голоса (напр. «Microsoft Irina» на русском Windows) выдают
    // настоящую машину и противоречат локали профиля. Отдаём правдоподобный
    // Chrome-набор (эти голоса есть в любом Chrome) + ОС-голоса под платформу.
    try {
      if (typeof speechSynthesis !== 'undefined' && typeof speechSynthesis.getVoices === 'function') {
        const os = (p.clientHints && p.clientHints.platform) || 'Windows';
        const V = (name, l, local) => ({ voiceURI: name, name, lang: l, localService: !!local, default: false });
        const google = [V('Google US English', 'en-US', false), V('Google UK English Female', 'en-GB', false),
          V('Google UK English Male', 'en-GB', false), V('Google Deutsch', 'de-DE', false),
          V('Google español', 'es-ES', false), V('Google français', 'fr-FR', false)];
        const osVoices = os === 'macOS'
          ? [V('Alex', 'en-US', true), V('Samantha', 'en-US', true), V('Daniel', 'en-GB', true)]
          : os === 'Linux' ? []
            : [V('Microsoft David - English (United States)', 'en-US', true),
              V('Microsoft Zira - English (United States)', 'en-US', true)];
        const voices = google.concat(osVoices);
        if (voices.length) voices[0].default = true;
        speechSynthesis.getVoices = () => voices.map((v) => Object.assign({}, v));
      }
    } catch (e) { /* voices best-effort */ }

    // ── Web Workers: тот же отпечаток и ВНУТРИ воркеров ─────────────────────
    // addInitScript в воркеры НЕ попадает → там протекала реальная машина (её
    // UA/ядра/GPU — из-за этого отпечаток «разъезжался» между главным потоком и
    // воркером, что и палит бота/светит настоящий ПК). Оборачиваем ТОЛЬКО
    // same-origin classic-воркеры: их источник грузим через importScripts после
    // нашего bootstrap. Любая помеха (module/blob/cross-origin/CSP) → прозрачный
    // фолбэк на оригинал, страницу НЕ ломаем.
    function workerBootstrap(pp) {
      try {
        var def = function (o, k, v) {
          try { Object.defineProperty(o, k, { get: function () { return v; }, configurable: true }); } catch (e) { /* */ }
        };
        if (pp.userAgent) def(navigator, 'userAgent', pp.userAgent);
        if (pp.navigator) {
          if (pp.navigator.platform != null) def(navigator, 'platform', pp.navigator.platform);
          if (pp.navigator.hardwareConcurrency != null) def(navigator, 'hardwareConcurrency', pp.navigator.hardwareConcurrency);
          if (pp.navigator.deviceMemory != null) def(navigator, 'deviceMemory', pp.navigator.deviceMemory);
        }
        if (pp.languages && pp.languages.length) {
          var L = pp.languages.map(function (l) { return String(l).split(';')[0].trim(); }).filter(Boolean);
          def(navigator, 'languages', Object.freeze(L));
          def(navigator, 'language', L[0]);
        }
        if (pp.webgl && (pp.webgl.vendor || pp.webgl.renderer)) {
          var UV = 0x9245, UR = 0x9246;
          var patch = function (proto) {
            if (!proto) return;
            var orig = proto.getParameter;
            proto.getParameter = function (x) {
              if (x === UV && pp.webgl.vendor) return pp.webgl.vendor;
              if (x === UR && pp.webgl.renderer) return pp.webgl.renderer;
              return orig.call(this, x);
            };
          };
          if (typeof WebGLRenderingContext !== 'undefined') patch(WebGLRenderingContext.prototype);
          if (typeof WebGL2RenderingContext !== 'undefined') patch(WebGL2RenderingContext.prototype);
        }
      } catch (e) { /* */ }
    }
    try {
      // На биржевых доменах воркеры НЕ оборачиваем: там приоритет — НЕ сломать
      // исполнение ордеров (воркер биржи может парсить self.location/относительные
      // пути, а запуск из blob сменил бы base). Биржа и так видит согласованный
      // отпечаток главного потока; worker-leak там — маргинальный риск, поломка — нет.
      const host = (self.location && self.location.hostname) || '';
      const EXCH = /(^|\.)(mexc|xt|bingx)\.com$/i;
      const boot = '(' + workerBootstrap.toString() + ')(' + JSON.stringify(p) + ');';
      const wrap = (Ctor) => {
        const Wrapped = function (url, options) {
          try {
            if (options && options.type === 'module') return new Ctor(url, options);
            const u = new URL(url, self.location.href);
            if (u.origin !== self.location.origin) return new Ctor(url, options);
            const glue = boot + '\ntry{importScripts(' + JSON.stringify(u.href) + ');}catch(e){}';
            const burl = URL.createObjectURL(new Blob([glue], { type: 'text/javascript' }));
            return new Ctor(burl, options);
          } catch (e) {
            return new Ctor(url, options); // фолбэк — страницу не ломаем
          }
        };
        try { Wrapped.prototype = Ctor.prototype; } catch (e) { /* */ }
        try { Object.defineProperty(Wrapped, 'name', { value: Ctor.name || 'Worker' }); } catch (e) { /* */ }
        return Wrapped;
      };
      if (!EXCH.test(host)) {
        if (typeof Worker !== 'undefined') self.Worker = wrap(Worker);
        if (typeof SharedWorker !== 'undefined') self.SharedWorker = wrap(SharedWorker);
      }
    } catch (e) { /* worker-обёртка best-effort */ }
  };
}

/**
 * Регистрирует init-скрипт на контексте (действует на все страницы/фреймы).
 * @param {import('playwright').BrowserContext} context
 * @param {object} profile
 */
async function addInit(context, profile) {
  await context.addInitScript(initScriptFn(), profile);
}

// ─── Общая точка входа ───

/**
 * Применяет весь профиль к уже созданному persistent-контексту.
 * @param {import('playwright').BrowserContext} context
 * @param {object} profile   профиль ПОСЛЕ applyGeo
 * @param {string} acceptLanguage
 */
async function applyAll(context, profile, acceptLanguage) {
  await addInit(context, profile);
  // Применяем CDP к уже открытым и будущим страницам.
  const applyToPage = (page) => applyCdp(page, profile, acceptLanguage).catch(() => {});
  context.on('page', applyToPage);
  for (const page of context.pages()) await applyToPage(page);
}

module.exports = {
  contextOptions,
  applyCdp,
  addInit,
  applyAll,
  initScriptFn,
};

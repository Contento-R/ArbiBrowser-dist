'use strict';

/**
 * settings.js — пользовательские настройки ArbiBrowser (data/settings.json).
 *
 *   • chromiumPath       — явный путь к бинарю Chrome/Chromium (высший приоритет
 *                          после env ARBI_CHROMIUM_PATH);
 *   • preferSystemChrome — по умолчанию true: если найден обычный системный Chrome,
 *                          запускаем ЕГО (не «Chrome for Testing» из Playwright);
 *   • autoUpdateCheck    — проверять ли новую версию ArbiBrowser при старте панели.
 */

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const config = require('../config');

const FILE = path.join(config.dataDir, 'settings.json');

const DEFAULTS = {
  chromiumPath: '',
  // По умолчанию — встроенный Chromium (обычная open-source сборка Playwright,
  // НЕ «Chrome for Testing»), как и окно панели. Причина: системный Google
  // Chrome, когда он уже открыт у пользователя, перехватывает запуск (single-
  // instance) → показывает profile-picker, ломает изоляцию user-data-dir и не
  // грузит --load-extension. Встроенный Chromium — отдельный бинарь без этих
  // проблем. Отпечаток НЕ страдает: UA и navigator.userAgentData.brands уже
  // подменяются под «Google Chrome» через CDP (см. fingerprint/generator.js),
  // поэтому underlying-бинарь на веб-детекции не виден. Вернуть системный можно
  // явно: settings.chromiumPath, env ARBI_CHROMIUM_PATH или preferSystemChrome:true.
  preferSystemChrome: false,
  autoUpdateCheck: true,
  // Свёрнутые папки профилей в панели (оператор 2026-09-02: «каждый раз папки
  // открываются развёрнутыми, теряюсь в количестве профилей»). Раньше это
  // состояние жило в localStorage окна панели — а её профиль Chromium создаётся
  // с pid в имени и удаляется при закрытии, так что переживать перезапуск оно
  // не могло в принципе. Место такой настройки — здесь, рядом с остальными.
  collapsedFolders: [],
  // ── Экономия ресурсов (оператор 2026-08-03: «отжирает очень много, даже
  // мощная машина тормозит») ────────────────────────────────────────────────
  // Chromium по умолчанию держит ОТДЕЛЬНЫЙ процесс-рендерер почти на каждую
  // вкладку: 8 восстановленных вкладок бирж на профиль × несколько профилей =
  // десятки процессов и гигабайты (замер оператора: 19 процессов, 10.8 ГБ).
  //
  //  • saveMemory      — вкладки ОДНОГО сайта делят один процесс
  //                      (--process-per-site) + потолок числа рендереров.
  //                      Изоляция между ПРОФИЛЯМИ не затрагивается: это разные
  //                      user-data-dir и разные браузеры.
  //  • sleepingTabs    — восстановленные вкладки не грузятся все сразу: активная
  //                      грузится, остальные «спят» (лёгкая заглушка) и
  //                      загружаются сами при первом переключении на них.
  //  • maxRestoredTabs — сколько вкладок вообще восстанавливать.
  //  • rendererLimit   — потолок процессов-рендереров на профиль (0 = без
  //                      потолка). Работает только при saveMemory.
  saveMemory: true,
  sleepingTabs: true,
  maxRestoredTabs: 8,
  rendererLimit: 6,
  //  • idleSleepMinutes — через сколько минут «в фоне» вкладка засыпает сама.
  //                      Порог намеренно большой: усыплять вкладку, в которой
  //                      прямо сейчас работают, нельзя (в ней форма ордера), а
  //                      исполнение занимает секунды, не десятки минут.
  //  • maxLoadedTabs    — сколько вкладок максимум держим ЗАГРУЖЕННЫМИ; сверх
  //                      потолка усыпляются те, что скрыты дольше всех.
  idleSleepMinutes: 20,
  maxLoadedTabs: 4,
};

function read() {
  try {
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) };
  } catch {
    return { ...DEFAULTS };
  }
}

function write(patch) {
  const next = { ...read(), ...patch };
  fs.mkdirSync(config.dataDir, { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify(next, null, 2) + '\n', 'utf8');
  return next;
}

/** Ищет установленный обычный Chrome/Chromium/Edge по типичным путям ОС. */
function detectSystemChrome() {
  const home = os.homedir();
  const candidates = process.platform === 'win32'
    ? [
        'C:/Program Files/Google/Chrome/Application/chrome.exe',
        'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe',
        path.join(home, 'AppData/Local/Google/Chrome/Application/chrome.exe'),
        'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',
        'C:/Program Files/Microsoft/Edge/Application/msedge.exe',
      ]
    : process.platform === 'darwin'
    ? [
        '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
        '/Applications/Chromium.app/Contents/MacOS/Chromium',
        '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      ]
    : [
        '/usr/bin/google-chrome',
        '/usr/bin/google-chrome-stable',
        '/usr/bin/chromium',
        '/usr/bin/chromium-browser',
        '/snap/bin/chromium',
      ];
  return candidates.find((p) => { try { return fs.existsSync(p); } catch { return false; } }) || null;
}

/**
 * Эффективный путь к Chromium:
 *   1) env ARBI_CHROMIUM_PATH
 *   2) settings.chromiumPath (явно задан пользователем)
 *   3) системный обычный Chrome (если preferSystemChrome и он найден)
 *   4) null → встроенный Playwright-Chromium (Chrome for Testing)
 */
function effectiveChromiumPath() {
  if (process.env.ARBI_CHROMIUM_PATH) return process.env.ARBI_CHROMIUM_PATH;
  const s = read();
  if (s.chromiumPath && fs.existsSync(s.chromiumPath)) return s.chromiumPath;
  if (s.preferSystemChrome !== false) {
    const sys = detectSystemChrome();
    if (sys) return sys;
  }
  return null;
}

module.exports = { read, write, effectiveChromiumPath, detectSystemChrome, FILE, DEFAULTS };

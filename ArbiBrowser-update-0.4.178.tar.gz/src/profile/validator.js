'use strict';

/**
 * validator.js — валидация профиля.
 *
 * Две ступени:
 *   1) Структурная валидация по JSON Schema (ajv) — типы, обязательные поля, форматы.
 *   2) Проверка ВНУТРЕННЕЙ СОГЛАСОВАННОСТИ — межполевые инварианты, которые схемой
 *      не выразить: platform ↔ User-Agent ↔ Client Hints ↔ WebGL, экран, локаль, TZ.
 *
 * Несогласованный профиль — главный источник «противоречивого» отпечатка:
 * например platform=Win32, но User-Agent содержит Macintosh. Такие расхождения
 * ловим здесь с понятными сообщениями.
 */

const fs = require('node:fs');
const path = require('node:path');

const schema = require('./schema.json');

// ajv — предпочтительный валидатор схемы. Если пакет недоступен (напр. offline-
// среда без доступа к npm-реестру), используем встроенный минимальный fallback:
// он проверяет обязательные поля и базовые типы верхнего уровня. Проверки
// согласованности (checkConsistency) работают в любом случае — они на чистом JS.
let validateSchema;
try {
  const Ajv = require('ajv');
  const addFormats = require('ajv-formats');
  const ajv = new Ajv({ allErrors: true, strict: false });
  addFormats(ajv);
  validateSchema = ajv.compile(schema);
} catch (e) {
  validateSchema = makeFallbackValidator(schema);
}

/** Минимальный валидатор без ajv: обязательные поля + типы верхнего уровня. */
function makeFallbackValidator(sch) {
  const fn = (data) => {
    const errs = [];
    if (typeof data !== 'object' || data === null) {
      errs.push({ instancePath: '', message: 'должен быть объектом' });
      fn.errors = errs;
      return false;
    }
    for (const req of sch.required || []) {
      if (data[req] === undefined) errs.push({ instancePath: '', message: `отсутствует обязательное поле "${req}"` });
    }
    for (const [key, def] of Object.entries(sch.properties || {})) {
      if (data[key] === undefined || !def.type) continue;
      const t = def.type;
      const v = data[key];
      const okType =
        t === 'string' ? typeof v === 'string'
        : t === 'integer' ? Number.isInteger(v)
        : t === 'number' ? typeof v === 'number'
        : t === 'boolean' ? typeof v === 'boolean'
        : t === 'array' ? Array.isArray(v)
        : t === 'object' ? typeof v === 'object' && v !== null && !Array.isArray(v)
        : true;
      if (!okType) errs.push({ instancePath: `/${key}`, message: `должен быть типа ${t}` });
    }
    fn.errors = errs;
    return errs.length === 0;
  };
  return fn;
}

// ─── Вспомогательное ───

/** Определяет ОС по User-Agent. Возвращает 'Windows'|'macOS'|'Linux'|null. */
function osFromUserAgent(ua) {
  if (/Windows NT/i.test(ua)) return 'Windows';
  if (/Mac OS X|Macintosh/i.test(ua)) return 'macOS';
  if (/Linux|X11/i.test(ua)) return 'Linux';
  return null;
}

/** Определяет ОС по navigator.platform. */
function osFromPlatform(platform) {
  if (platform === 'Win32') return 'Windows';
  if (platform === 'MacIntel') return 'macOS';
  if (/^Linux/.test(platform)) return 'Linux';
  return null;
}

/** Извлекает мажорную версию Chrome из User-Agent (число) либо null. */
function chromeMajorFromUA(ua) {
  const m = ua.match(/Chrome\/(\d+)/);
  return m ? Number(m[1]) : null;
}

/** Проверяет, что строка — валидная IANA timezone (через Intl). */
function isValidTimezone(tz) {
  try {
    Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

// ─── Проверка согласованности ───

/**
 * Проверяет межполевые инварианты профиля.
 * @returns {{errors: string[], warnings: string[]}}
 */
function checkConsistency(p) {
  const errors = [];
  const warnings = [];

  const platOs = osFromPlatform(p.navigator.platform);
  const uaOs = osFromUserAgent(p.userAgent);

  // 1. platform ↔ User-Agent
  if (platOs && uaOs && platOs !== uaOs) {
    errors.push(
      `Несогласованность ОС: navigator.platform="${p.navigator.platform}" (${platOs}), ` +
      `но User-Agent указывает на ${uaOs}. Они должны описывать одну ОС.`
    );
  }

  // 2. platform ↔ Client Hints platform
  if (p.clientHints) {
    if (platOs && p.clientHints.platform && platOs !== p.clientHints.platform) {
      errors.push(
        `Несогласованность ОС: navigator.platform="${p.navigator.platform}" (${platOs}), ` +
        `но clientHints.platform="${p.clientHints.platform}". Приведите к одной ОС.`
      );
    }

    // 3. User-Agent Chrome major ↔ Client Hints brand version
    const uaMajor = chromeMajorFromUA(p.userAgent);
    if (uaMajor && Array.isArray(p.clientHints.brands)) {
      const chromeBrand = p.clientHints.brands.find((b) =>
        /Chrome|Chromium/i.test(b.brand)
      );
      if (chromeBrand) {
        const chMajor = Number(String(chromeBrand.version).split('.')[0]);
        if (chMajor && chMajor !== uaMajor) {
          errors.push(
            `Несогласованность версии Chrome: User-Agent → Chrome/${uaMajor}, ` +
            `но clientHints "${chromeBrand.brand}" → ${chMajor}. Версии должны совпадать.`
          );
        }
      } else {
        warnings.push(
          'В clientHints.brands нет бренда Chrome/Chromium — на реальном Chrome он присутствует.'
        );
      }
    }

    // 4. mobile ↔ platform / touch
    if (p.clientHints.mobile === true) {
      if (['Windows', 'macOS', 'Linux'].includes(p.clientHints.platform)) {
        errors.push(
          `clientHints.mobile=true несовместимо с десктопной платформой "${p.clientHints.platform}".`
        );
      }
    } else {
      if ((p.navigator.maxTouchPoints || 0) > 0 && platOs !== null) {
        warnings.push(
          `clientHints.mobile=false, но navigator.maxTouchPoints=${p.navigator.maxTouchPoints}. ` +
          'Для десктопа обычно 0.'
        );
      }
    }

    // 5. architecture ↔ platform (грубая проверка)
    if (p.clientHints.architecture === 'arm' && p.navigator.platform === 'Win32') {
      warnings.push('clientHints.architecture="arm" при platform="Win32" — редкое сочетание, проверьте.');
    }
  } else {
    warnings.push('Блок clientHints отсутствует. Современный Chrome всегда отправляет Sec-CH-UA-*.');
  }

  // 6. WebGL ↔ platform (эвристика по ключевым словам)
  if (p.webgl && p.webgl.renderer) {
    const r = p.webgl.renderer;
    if (platOs === 'macOS' && /NVIDIA|Direct3D|ANGLE \(NVIDIA/i.test(r) && !/Apple|Metal/i.test(r)) {
      warnings.push(
        `WebGL renderer="${r}" выглядит как Windows/NVIDIA, но платформа macOS. ` +
        'На Mac ожидается Apple GPU / Metal.'
      );
    }
    if (platOs === 'Windows' && /Apple|Metal/i.test(r)) {
      warnings.push(`WebGL renderer="${r}" выглядит как macOS/Apple, но платформа Windows.`);
    }
    if (platOs !== 'macOS' && /Direct3D|ANGLE/i.test(r) === false && /Apple/i.test(r) === false) {
      // ничего — Linux/Mesa допустим
    }
  }

  // 7. locale ↔ languages
  if (p.languages && p.languages.length > 0 && p.locale) {
    if (!p.languages[0].startsWith(p.locale.split('-')[0])) {
      warnings.push(
        `Первый элемент navigator.languages="${p.languages[0]}" не согласован с locale="${p.locale}".`
      );
    }
  }

  // 8. Экран: доступная область не больше физической
  const s = p.screen;
  if (s.availWidth && s.availWidth > s.width) {
    errors.push(`screen.availWidth (${s.availWidth}) больше screen.width (${s.width}).`);
  }
  if (s.availHeight && s.availHeight > s.height) {
    errors.push(`screen.availHeight (${s.availHeight}) больше screen.height (${s.height}).`);
  }
  if (s.viewport) {
    if (s.viewport.width > s.width) {
      errors.push(`viewport.width (${s.viewport.width}) больше screen.width (${s.width}).`);
    }
    if (s.viewport.height > s.height) {
      errors.push(`viewport.height (${s.viewport.height}) больше screen.height (${s.height}).`);
    }
  }

  // 9. Timezone валидна как IANA
  if (p.timezone && !isValidTimezone(p.timezone)) {
    errors.push(`timezone="${p.timezone}" не является валидной IANA-зоной (напр. "Europe/Berlin").`);
  }

  // 10. Геолокация. Если есть прокси — подтянется из GeoIP выходного IP при
  // запуске (штатное авто-поведение, не предупреждаем). Предупреждаем только
  // когда прокси нет И координаты не заданы — тогда Geolocation API будет пуст.
  if (!p.geolocation && !p.proxy) {
    warnings.push('Ни прокси, ни geolocation не заданы — Geolocation API останется пустым. Задайте прокси (гео подтянется само) или координаты.');
  }

  return { errors, warnings };
}

// ─── Публичное API ───

/**
 * Полная валидация объекта профиля.
 * @param {object} profile
 * @returns {{ok: boolean, errors: string[], warnings: string[]}}
 */
function validate(profile) {
  const errors = [];
  const warnings = [];

  const structOk = validateSchema(profile);
  if (!structOk) {
    for (const e of validateSchema.errors) {
      const where = e.instancePath || '(корень)';
      errors.push(`Схема: ${where} ${e.message}` + (e.params && e.params.allowedValues
        ? ` (допустимо: ${JSON.stringify(e.params.allowedValues)})`
        : ''));
    }
    // При структурных ошибках межполевые проверки могут падать — выходим.
    return { ok: false, errors, warnings };
  }

  const cons = checkConsistency(profile);
  errors.push(...cons.errors);
  warnings.push(...cons.warnings);

  return { ok: errors.length === 0, errors, warnings };
}

/**
 * Загружает профиль из файла и валидирует.
 * @param {string} filePath
 * @returns {{ok: boolean, profile: object|null, errors: string[], warnings: string[]}}
 */
function validateFile(filePath) {
  let raw;
  try {
    raw = fs.readFileSync(filePath, 'utf8');
  } catch (e) {
    return { ok: false, profile: null, errors: [`Не удалось прочитать файл: ${filePath} (${e.message})`], warnings: [] };
  }

  let profile;
  try {
    profile = JSON.parse(raw);
  } catch (e) {
    return { ok: false, profile: null, errors: [`Некорректный JSON в ${path.basename(filePath)}: ${e.message}`], warnings: [] };
  }

  const res = validate(profile);
  return { ...res, profile };
}

module.exports = {
  validate,
  validateFile,
  checkConsistency,
  osFromUserAgent,
  osFromPlatform,
  chromeMajorFromUA,
  isValidTimezone,
};

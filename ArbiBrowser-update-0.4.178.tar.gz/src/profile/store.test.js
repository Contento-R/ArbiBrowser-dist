'use strict';

// Тесты файловой логики хранилища профилей (0.4.144): каталог браузера нового
// профиля не наследуется, «Очистить данные» и «Удалить навсегда» не трогают
// чужое. Без Playwright: только временный каталог данных.

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'arbi-store-'));
process.env.ARBI_DATA_DIR = path.join(tmp, 'data');
process.env.ARBI_PROFILES_DIR = path.join(tmp, 'profiles');

const config = require('../../config');
const store = require('./index');

const ud = (n) => config.userDataDirFor(n);
const syncCookie = (n, kind) => path.join(config.dataDir, 'sync', `${encodeURIComponent(n)}.cookies.${kind}.json`);
function mkUserData(n, file = 'History') {
  fs.mkdirSync(ud(n), { recursive: true });
  fs.writeFileSync(path.join(ud(n), file), 'old');
}
function mkSyncCookies(n) {
  fs.mkdirSync(path.join(config.dataDir, 'sync'), { recursive: true });
  fs.writeFileSync(syncCookie(n, 'pending'), '[]');
  fs.writeFileSync(syncCookie(n, 'local'), '[]');
}
function mkLiveProfile(n) {
  store.ensureProfilesDir();
  fs.writeFileSync(config.profilePathFor(n), '{}');
}
function mkTrashed(n) {
  fs.mkdirSync(path.join(config.profilesDir, '.trash'), { recursive: true });
  fs.writeFileSync(path.join(config.profilesDir, '.trash', `${n}.json`), '{}');
}

test.after(() => { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* ok */ } });

test('quarantineStaleUserData: чужой каталог откладывается рядом, cookie-файлы синка стираются', () => {
  mkUserData('proxy-a');
  mkSyncCookies('proxy-a');
  const q = store.quarantineStaleUserData('proxy-a');
  assert.ok(q && path.basename(q).startsWith('proxy-a.old-'));
  assert.equal(fs.existsSync(ud('proxy-a')), false);
  assert.equal(fs.existsSync(path.join(q, 'History')), true, 'данные не потеряны, а отложены');
  assert.equal(fs.existsSync(syncCookie('proxy-a', 'pending')), false);
  assert.equal(fs.existsSync(syncCookie('proxy-a', 'local')), false);
  assert.equal(store.quarantineStaleUserData('proxy-a'), null, 'нечего откладывать — null');
});

test('wipeUserData: каталог и cookie-файлы синка стёрты, JSON профиля цел', () => {
  mkLiveProfile('proxy-b');
  mkUserData('proxy-b', 'Cookies');
  mkSyncCookies('proxy-b');
  assert.equal(store.wipeUserData('proxy-b'), true);
  assert.equal(fs.existsSync(ud('proxy-b')), false);
  assert.equal(fs.existsSync(syncCookie('proxy-b', 'pending')), false);
  assert.equal(store.exists('proxy-b'), true, 'настройки профиля остаются');
  assert.equal(store.wipeUserData('proxy-b'), false, 'повторно — нечего стирать');
});

test('purge: при живом одноимённом профиле его каталог не трогается, отложенные .old-* подметаются', () => {
  mkLiveProfile('proxy-c');
  mkUserData('proxy-c');
  fs.mkdirSync(`${ud('proxy-c')}.old-2026-01-01T00-00-00-000Z`, { recursive: true });
  mkTrashed('proxy-c');
  store.purge('proxy-c');
  assert.equal(fs.existsSync(ud('proxy-c')), true, 'каталог живого профиля цел');
  assert.equal(fs.existsSync(`${ud('proxy-c')}.old-2026-01-01T00-00-00-000Z`), false);
  assert.equal(store.listTrash().includes('proxy-c'), false);
});

test('purge: без живого профиля стирает каталог и cookie-файлы синка', () => {
  mkUserData('proxy-d');
  mkSyncCookies('proxy-d');
  mkTrashed('proxy-d');
  store.purge('proxy-d');
  assert.equal(fs.existsSync(ud('proxy-d')), false);
  assert.equal(fs.existsSync(syncCookie('proxy-d', 'local')), false);
});

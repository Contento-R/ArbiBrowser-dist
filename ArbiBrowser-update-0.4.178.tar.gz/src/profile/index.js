'use strict';

/**
 * src/profile — работа с профилями как с файлами.
 *
 * Профиль — JSON-файл в config.profilesDir. Единственный источник конфигурации
 * браузера. Здесь: загрузка, список, сохранение, удаление + реэкспорт валидатора.
 */

const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const validator = require('./validator');

/** Гарантирует существование каталога профилей. */
function ensureProfilesDir() {
  fs.mkdirSync(config.profilesDir, { recursive: true });
}

/** Возвращает список имён профилей (без .json). */
function list() {
  ensureProfilesDir();
  return fs
    .readdirSync(config.profilesDir)
    .filter((f) => f.endsWith('.json'))
    .map((f) => f.replace(/\.json$/, ''))
    .sort();
}

/** Загружает и валидирует профиль по имени. Бросает при ошибке валидации. */
function load(name) {
  const file = config.profilePathFor(name);
  const res = validator.validateFile(file);
  if (!res.ok) {
    const msg = res.errors.join('\n  - ');
    throw new Error(`Профиль "${name}" невалиден:\n  - ${msg}`);
  }
  return res.profile;
}

/** Загружает профиль БЕЗ падения — возвращает полный результат валидации. */
function loadResult(name) {
  return validator.validateFile(config.profilePathFor(name));
}

/** Существует ли профиль. */
function exists(name) {
  return fs.existsSync(config.profilePathFor(name));
}

/** Сохраняет объект профиля в файл (перезаписывает). Валидирует перед записью. */
function save(profile) {
  ensureProfilesDir();
  const res = validator.validate(profile);
  if (!res.ok) {
    throw new Error(`Отказ сохранить невалидный профиль:\n  - ${res.errors.join('\n  - ')}`);
  }
  const file = config.profilePathFor(profile.name);
  // SEC-5: профиль содержит proxy.password — файл не должен быть читаем другими
  // пользователями машины (дефолтный umask даёт 0644). mode при создании + chmod
  // на случай уже существующего файла. На Windows mode игнорируется (ACL профиля ОС).
  fs.writeFileSync(file, JSON.stringify(profile, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(file, 0o600); } catch { /* best-effort */ }
  return { file, warnings: res.warnings };
}

/** Удаляет файл профиля (user-data-dir не трогает). */
function remove(name) {
  const file = config.profilePathFor(name);
  if (fs.existsSync(file)) fs.unlinkSync(file);
}

// ── Корзина ──────────────────────────────────────────────────────────────────
// «Удалить» не стирает профиль сразу, а переносит его JSON в подкаталог .trash/
// внутри каталога профилей. list() его не видит (это каталог, не *.json), поэтому
// корзина не засоряет список. Оттуда профиль можно ВОССТАНОВИТЬ или удалить НАВСЕГДА.
function trashDir() { return path.join(config.profilesDir, '.trash'); }
function trashPathFor(name) {
  const n = name.endsWith('.json') ? name : `${name}.json`;
  return path.join(trashDir(), n);
}

/** Переносит профиль в корзину. Возвращает true, если было что переносить. */
function trash(name) {
  const file = config.profilePathFor(name);
  if (!fs.existsSync(file)) return false;
  fs.mkdirSync(trashDir(), { recursive: true });
  fs.renameSync(file, trashPathFor(name)); // атомарно в пределах одной ФС
  return true;
}

/** Список имён профилей в корзине. */
function listTrash() {
  const d = trashDir();
  if (!fs.existsSync(d)) return [];
  return fs.readdirSync(d)
    .filter((f) => f.endsWith('.json'))
    .map((f) => f.replace(/\.json$/, ''))
    .sort();
}

/** Восстанавливает профиль из корзины обратно в список. false, если имя занято/нет в корзине. */
function restore(name) {
  const src = trashPathFor(name);
  if (!fs.existsSync(src)) return false;
  const dest = config.profilePathFor(name);
  if (fs.existsSync(dest)) return false; // не перетираем существующий одноимённый
  fs.renameSync(src, dest);
  return true;
}

/** Удаляет профиль из корзины НАВСЕГДА (JSON) вместе с данными браузера: каталог
 *  профиля (если имя не занято ЖИВЫМ профилем — тогда каталог принадлежит ему),
 *  отложенные каталоги `<имя>.old-*` и cookie-файлы облачной синхронизации. */
function purge(name) {
  const src = trashPathFor(name);
  if (fs.existsSync(src)) fs.unlinkSync(src);
  if (!exists(name)) {
    rmDirAtomic(config.userDataDirFor(name));
    dropSyncCookies(name);
  }
  for (const d of staleUserDataDirs(name)) rmDirAtomic(d);
}

// ── Каталог браузера профиля (cookies, история, хранилища сайтов, вкладки) ────────
// JSON профиля (прокси, отпечаток) и каталог браузера живут раздельно. «Удалить»
// стирало только JSON, каталог оставался — и профиль, созданный позже с тем же
// именем, молча наследовал cookies/историю чужого аккаунта (факт 2026-09-12:
// «новый» proxy-decodo-3 с историей xt.com от июля). Для «чистого устройства»
// это недопустимо, отсюда правила ниже.

function stamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }

/** Удаляет каталог АТОМАРНО по исходу: сперва rename рядом, потом rm. Занятый
 *  каталог (открытый Chromium, в т.ч. чужой) на Windows не переименуется и бросит,
 *  НЕ стерев ни файла; прямой rmSync стирал бы Cookies/History и падал на глубине. */
function rmDirAtomic(dir) {
  if (!fs.existsSync(dir)) return false;
  const tmp = `${dir}.rm-${stamp()}`;
  fs.renameSync(dir, tmp);
  fs.rmSync(tmp, { recursive: true, force: true });
  return true;
}

/** Отложенные каталоги `<имя>.old-<дата>` этого профиля (см. quarantineStaleUserData). */
function staleUserDataDirs(name) {
  const root = config.userDataRoot;
  if (!fs.existsSync(root)) return [];
  const prefix = `${name}.old-`;
  return fs.readdirSync(root).filter((d) => d.startsWith(prefix)).map((d) => path.join(root, d));
}

/** Cookie-файлы облачной синхронизации профиля лежат ВНЕ каталога браузера
 *  (data/sync/<имя>.cookies.{pending,local}.json) и вливаются в контекст при
 *  запуске — без их удаления «чистый» профиль получил бы cookies обратно. */
function dropSyncCookies(name) {
  const base = path.join(config.dataDir, 'sync', encodeURIComponent(name));
  for (const f of [`${base}.cookies.pending.json`, `${base}.cookies.local.json`]) {
    try { fs.rmSync(f, { force: true }); } catch { /* нет файла или занят — не критично для JSON-файла */ }
  }
}

/** Стирает данные браузера профиля (каталог + cookie-файлы синхронизации). JSON не
 *  трогает; профиль должен быть закрыт (проверяет вызывающий). true — было что стирать. */
function wipeUserData(name) {
  const had = rmDirAtomic(config.userDataDirFor(name));
  dropSyncCookies(name);
  return had;
}

/** Копия JSON профиля ПЕРЕД правкой — в `.backups/` внутри каталога профилей.
 *  Оператор 2026-09-16: «не хочу сам файлы копировать». list() берёт только
 *  `*.json` в КОРНЕ каталога, поэтому подкаталог профилем не станет и в панели
 *  не появится. Данные браузера не трогаются — копируется только конфиг.
 *  Возвращает путь копии или null, если профиля на диске нет. */
function backupProfileFile(name) {
  const src = config.profilePathFor(name);
  if (!fs.existsSync(src)) return null;
  const dir = path.join(config.profilesDir, '.backups');
  fs.mkdirSync(dir, { recursive: true });
  const dest = path.join(dir, `${name}-${stamp()}.json`);
  fs.copyFileSync(src, dest);
  // В профиле лежит пароль прокси (SEC-5) — копия так же недоступна другим.
  try { fs.chmodSync(dest, 0o600); } catch { /* best-effort, на Windows — ACL */ }
  return dest;
}

/** НОВЫЙ профиль не наследует чужие данные: существующий каталог с этим именем
 *  откладывается рядом как `<имя>.old-<дата>` (не удаляется — вернуть можно руками;
 *  «Удалить навсегда» из корзины подметает), cookie-файлы синхронизации стираются.
 *  Возвращает путь отложенного каталога или null. Не смог отложить — бросает:
 *  профиль на чужих cookies создавать нельзя (fail-closed). */
function quarantineStaleUserData(name) {
  const dir = config.userDataDirFor(name);
  let dest = null;
  if (fs.existsSync(dir)) {
    dest = `${dir}.old-${stamp()}`;
    fs.renameSync(dir, dest);
  }
  dropSyncCookies(name);
  return dest;
}

module.exports = {
  list,
  load,
  loadResult,
  exists,
  save,
  remove,
  trash,
  listTrash,
  restore,
  purge,
  wipeUserData,
  backupProfileFile,
  quarantineStaleUserData,
  ensureProfilesDir,
  // реэкспорт валидатора для удобства
  validate: validator.validate,
  validateFile: validator.validateFile,
  checkConsistency: validator.checkConsistency,
};

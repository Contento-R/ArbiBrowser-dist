'use strict';

/**
 * src/index.js — публичная точка входа ArbiBrowser (программный API).
 *
 * Реэкспортирует модули, чтобы их можно было использовать как библиотеку:
 *
 *   const arbi = require('arbibrowser');
 *   const profile = arbi.generator.generate({ name: 'acc1', os: 'Windows' });
 *   arbi.profile.save(profile);
 *   const { context } = await arbi.launcher.open('acc1', { headless: false });
 */

const config = require('../config');

module.exports = {
  config,
  profile: require('./profile'),
  generator: require('./fingerprint/generator'),
  fingerprint: require('./fingerprint'),
  network: require('./network'),
  geoip: require('./network/geoip'),
  launcher: require('./launcher'),
  validation: require('./validation'),
  gui: require('./gui/server'),
};

// Прямой запуск `node src/index.js` — краткая справка.
if (require.main === module) {
  const list = require('./profile').list();
  console.log('ArbiBrowser — приватный браузер на Chromium.');
  console.log(`Профилей: ${list.length}${list.length ? ' (' + list.join(', ') + ')' : ''}`);
  console.log('CLI:  node bin/browser.js --help');
  console.log('GUI:  node bin/browser.js gui');
}

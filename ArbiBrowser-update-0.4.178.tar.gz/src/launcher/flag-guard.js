'use strict';

/**
 * flag-guard.js — SEC-6: фильтр опасных Chromium-флагов, подмешиваемых из профиля.
 *
 * Опасные флаги:
 *   • remote-debugging(-port/-pipe) — открыл бы CDP наружу (полный контроль браузера/сессий);
 *   • proxy(-server/-bypass-list)   — увёл бы трафик МИМО антидетект-прокси (утечка реального IP);
 *   • host-resolver(-rules)         — подменил бы DNS → тот же обход прокси/увод хостов;
 *   • load-extension                — подгрузил бы произвольное расширение;
 *   • disable-web-security          — снял бы SOP.
 *
 * Chromium принимает флаг и с ОДНИМ, и с ДВУМЯ дефисами (`-remote-debugging-port`
 * эквивалентен `--remote-debugging-port`) — раньше фильтр `^--` ловил только двойной,
 * одиночный дефис его обходил. Теперь `-{1,2}` + совпадение по ПРЕФИКСУ имени (ловит
 * `-port`/`-server`/`-rules` и т.п.).
 */
const BLOCKED_FLAG = /^-{1,2}(remote-debugging|proxy|host-resolver|load-extension|disable-web-security)/i;

function isBlockedFlag(f) {
  return typeof f === 'string' && BLOCKED_FLAG.test(f.trim());
}

module.exports = { isBlockedFlag, BLOCKED_FLAG };

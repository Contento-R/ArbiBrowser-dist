'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { isBlockedFlag } = require('./flag-guard');

test('flag-guard SEC-6: блокирует опасные флаги (и одиночный дефис)', () => {
  // Двойной дефис — блок (как раньше).
  assert.equal(isBlockedFlag('--remote-debugging-port=9222'), true);
  assert.equal(isBlockedFlag('--proxy-server=http://evil:8080'), true);
  assert.equal(isBlockedFlag('--load-extension=/evil'), true);
  assert.equal(isBlockedFlag('--disable-web-security'), true);
  // ОДИНОЧНЫЙ дефис — Chromium его принимает, раньше обходил фильтр (SEC-6 дыра).
  assert.equal(isBlockedFlag('-remote-debugging-port=9222'), true);
  assert.equal(isBlockedFlag('-proxy-server=http://evil'), true);
  // host-resolver-rules — новый блок (увод DNS мимо прокси).
  assert.equal(isBlockedFlag('--host-resolver-rules=MAP * evil'), true);
  assert.equal(isBlockedFlag('-host-resolver-rules=MAP * evil'), true);
  // Пробелы вокруг — тоже ловим (trim).
  assert.equal(isBlockedFlag('  --remote-debugging-pipe '), true);
});

test('flag-guard SEC-6: легитимные флаги проходят', () => {
  assert.equal(isBlockedFlag('--window-size=800,600'), false);
  assert.equal(isBlockedFlag('--lang=de-DE'), false);
  assert.equal(isBlockedFlag('--force-webrtc-ip-handling-policy=disable_non_proxied_udp'), false);
  assert.equal(isBlockedFlag(''), false);
  assert.equal(isBlockedFlag(undefined), false);
  // Не путаем префикс с чужим флагом (proxy vs proxxy — начинается с proxy, но это
  // теоретический край; реальных легит-флагов с этими префиксами у Chromium нет).
});

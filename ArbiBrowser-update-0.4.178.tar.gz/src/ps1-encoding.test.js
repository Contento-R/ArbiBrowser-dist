'use strict';

/**
 * Защита от «скрипт не запускается у пользователя».
 *
 * Windows PowerShell 5.1 (встроенный `powershell.exe`, а не pwsh 7) читает .ps1
 * БЕЗ BOM в системной ANSI-кодировке, а не в UTF-8. На любой не-русской локали
 * (у оператора была испанская, cp1252) кириллица в комментариях и строках
 * превращается в мусор, обрывается кавычка — и скрипт падает пачкой
 * ParserError ещё до первой команды. Проявляется ТОЛЬКО на машине пользователя,
 * поэтому ловим здесь: любой .ps1 с не-ASCII обязан начинаться с UTF-8 BOM.
 *
 * Чинится добавлением 3 байт EF BB BF в начало файла (pwsh 7 их тоже понимает).
 */

const test = require('node:test');
const assert = require('node:assert');
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const ROOT = path.join(__dirname, '..');
const BOM = Buffer.from([0xef, 0xbb, 0xbf]);

function ps1Files() {
  const out = execFileSync('git', ['-C', ROOT, 'ls-files', '*.ps1'], { encoding: 'utf8' });
  return out.split('\n').map((s) => s.trim()).filter(Boolean);
}

test('.ps1 с не-ASCII содержимым имеют UTF-8 BOM (иначе PowerShell 5.1 их не разберёт)', () => {
  const bad = [];
  for (const rel of ps1Files()) {
    const raw = fs.readFileSync(path.join(ROOT, rel));
    const hasNonAscii = raw.some((b) => b > 127);
    const hasBom = raw.subarray(0, 3).equals(BOM);
    // Чисто ASCII-скрипту BOM не нужен — ANSI и UTF-8 для него совпадают.
    if (hasNonAscii && !hasBom) bad.push(rel);
  }
  assert.deepStrictEqual(bad, [], `нет UTF-8 BOM (сломаются в powershell.exe): ${bad.join(', ')}`);
});

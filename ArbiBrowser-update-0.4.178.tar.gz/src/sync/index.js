'use strict';

/**
 * src/sync — облачная синхронизация JSON-профилей (отпечаток + прокси) и cookie
 * сессий между устройствами ЧЕРЕЗ CEX-терминал. Профиль шифруется НА СЕРВЕРЕ при
 * хранении (терминал уже держит ключи бирж/прокси — тот же периметр доверия); в
 * канал наружу идёт по HTTPS под тем же per-user токеном X-Arbi-Token, что и очередь
 * интентов (ключ доступа переносится на любое устройство).
 *
 * БАРЬЕР (runBarrier) выполняется на СТАРТЕ панели ДО открытия любого профиля и ДО
 * старта исполнителей: качает и проверяет более свежие слепки, чтобы на новом
 * устройстве был ТОТ ЖЕ отпечаток/прокси. Fail-closed: если облачный профиль новее,
 * но скачать/проверить не удалось — барьер бросает, и открытие профилей блокируется
 * (иначе биржа увидит «не тот отпечаток» — ровно то, чего избегаем).
 *
 * Включается флагом ARBI_PROFILE_SYNC=1 (+ заданный токен терминала). Выключен →
 * весь модуль бездействует, поведение панели как раньше.
 *
 * Только stdlib Node + существующий HTTP-клиент терминала (executor-core.requestJson).
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const config = require('../../config');
const profileStore = require('../profile');
const { requestJson } = require('../integration/executor-core');

const BASE = '/api/integrations/arbibrowser/profiles';
const SYNC_DIR = () => path.join(config.dataDir, 'sync');

/** Синк включён? Нужен флаг И токен терминала (канал синка = тот же токен). */
function enabled() {
  return !!(config.profileSync && config.terminal && config.terminal.token);
}

/** Стабильный per-устройство id — создаётся один раз, живёт в каталоге данных. */
function deviceId() {
  const f = path.join(config.dataDir, 'device-id');
  try { const v = fs.readFileSync(f, 'utf8').trim(); if (v) return v; } catch { /* создадим ниже */ }
  const id = crypto.randomBytes(16).toString('hex');
  try { fs.mkdirSync(config.dataDir, { recursive: true }); fs.writeFileSync(f, id, { mode: 0o600 }); } catch { /* best-effort */ }
  return id;
}

// Локальное состояние синка по профилю: { version, hash, maxVersion }.
function statePath(name) { return path.join(SYNC_DIR(), `${encodeURIComponent(name)}.json`); }
function readState(name) {
  try { return JSON.parse(fs.readFileSync(statePath(name), 'utf8')); }
  catch { return { version: 0, hash: '', maxVersion: 0 }; }
}
function writeState(name, st) {
  try { fs.mkdirSync(SYNC_DIR(), { recursive: true }); fs.writeFileSync(statePath(name), JSON.stringify(st), { mode: 0o600 }); }
  catch { /* best-effort */ }
}

// cookie: pending — скачанные, ждут вливания при открытии; local — захваченные из
// живого контекста, ждут выгрузки.
function cookiesPendingPath(name) { return path.join(SYNC_DIR(), `${encodeURIComponent(name)}.cookies.pending.json`); }
function cookiesLocalPath(name) { return path.join(SYNC_DIR(), `${encodeURIComponent(name)}.cookies.local.json`); }

function serialize(profile) { return JSON.stringify(profile); }
function sha256(s) { return crypto.createHash('sha256').update(s, 'utf8').digest('hex'); }

async function api(method, p, body) { return requestJson(method, p, body, 25000); }

/**
 * Проверка скачанного слепка: hash сходится (целостность) + профиль ВАЛИДЕН по
 * схеме (значит есть отпечаток, прокси и всё нужное — иначе «не тот отпечаток»).
 */
function verify(profileStr, expectHash, name) {
  if (sha256(profileStr) !== expectHash) return { ok: false, reason: 'hash не сошёлся' };
  let p; try { p = JSON.parse(profileStr); } catch { return { ok: false, reason: 'битый JSON' }; }
  if (!p || typeof p !== 'object') return { ok: false, reason: 'не объект' };
  p.name = name; // имя авторитетно от облака (ключ записи)
  const res = profileStore.validate(p);
  if (!res.ok) return { ok: false, reason: 'профиль невалиден по схеме: ' + res.errors.join('; ') };
  return { ok: true, profile: p };
}

/**
 * БАРЬЕР. Скачивает и применяет более свежие облачные профили ДО открытия.
 * Бросает (fail-closed), если хоть один облачный профиль новее локального, но
 * скачать/проверить его не удалось. Возвращает { summary } при успехе.
 */
async function runBarrier() {
  const list = await api('GET', BASE); // { profiles: [{name,version,deviceId,hash,hasCookies,updatedAt}] }
  const profiles = (list && list.profiles) || [];
  // Профили в корзине НЕ тянем из облака — иначе удалённый локально профиль «воскреснет».
  const trashed = new Set(profileStore.listTrash());
  let pulled = 0; let upToDate = 0; const problems = [];
  for (const meta of profiles) {
    const name = String(meta.name || '');
    if (!name || trashed.has(name)) continue;
    const st = readState(name);
    const localVer = st.version || 0;
    const maxSeen = Math.max(st.maxVersion || 0, localVer);
    const cloudVer = Number(meta.version) || 0;
    const needPull = cloudVer > localVer || !profileStore.exists(name);
    if (!needPull) { upToDate++; continue; }
    // Защита от отката версии (облако/канал подсунули версию МЕНЬШЕ виденной).
    if (cloudVer < maxSeen) { problems.push(`${name}: откат версии (${cloudVer}<${maxSeen})`); continue; }
    try {
      const blob = await api('GET', `${BASE}/${encodeURIComponent(name)}`);
      const v = verify(String(blob.profile || ''), String(blob.hash || meta.hash || ''), name);
      if (!v.ok) { problems.push(`${name}: ${v.reason}`); continue; }
      profileStore.save(v.profile); // валидирует повторно + пишет mode 0600
      if (blob.cookies) {
        try { fs.mkdirSync(SYNC_DIR(), { recursive: true }); fs.writeFileSync(cookiesPendingPath(name), String(blob.cookies), { mode: 0o600 }); }
        catch { /* cookie best-effort */ }
      }
      writeState(name, { version: cloudVer, hash: String(blob.hash || meta.hash || ''), maxVersion: Math.max(maxSeen, cloudVer) });
      pulled++;
    } catch (e) {
      problems.push(`${name}: ${e.message}`);
    }
  }
  if (problems.length) {
    const err = new Error('не удалось синхронизировать профили — ' + problems.join(' | '));
    err.problems = problems;
    throw err; // fail-closed: панель заблокирует открытие профилей
  }
  return { summary: `скачано ${pulled}, актуально ${upToDate}, всего ${profiles.length}`, pulled, upToDate };
}

/**
 * Выгрузка профиля в облако (при сохранении/закрытии/heartbeat). Best-effort —
 * НЕ бросает наружу (сбой выгрузки не должен ронять торговлю). CAS по version:
 * 409 = кто-то записал с другого устройства → барьер подтянет на следующем старте.
 * cookiesStr (если передан) выгружается вместе с профилем.
 */
async function pushProfile(name, opts = {}) {
  if (!enabled()) return { ok: false, skipped: true };
  let profile;
  try { profile = profileStore.load(name); } catch (e) { return { ok: false, error: e.message }; }
  profile.name = name;
  const str = serialize(profile);
  const hash = sha256(str);
  const st = readState(name);
  let cookies = opts.cookiesStr || null;
  if (!cookies) { try { if (fs.existsSync(cookiesLocalPath(name))) cookies = fs.readFileSync(cookiesLocalPath(name), 'utf8'); } catch { /* нет cookie */ } }
  if (hash === st.hash && !opts.force && !cookies) return { ok: true, unchanged: true };
  try {
    const resp = await api('PUT', `${BASE}/${encodeURIComponent(name)}`, {
      baseVersion: st.version || 0, deviceId: deviceId(), hash, profile: str, cookies,
    });
    writeState(name, { version: resp.version, hash, maxVersion: Math.max(st.maxVersion || 0, resp.version) });
    return { ok: true, version: resp.version };
  } catch (e) {
    return { ok: false, error: e.message }; // в т.ч. 409 VERSION_CONFLICT
  }
}

/** Разово выгрузить ВСЕ локальные профили (напр. при первом включении синка). */
async function pushAll() {
  const out = [];
  for (const name of profileStore.list()) { out.push({ name, ...(await pushProfile(name).catch((e) => ({ ok: false, error: e.message }))) }); }
  return out;
}

/** Вливание скачанных cookie в свежеоткрытый контекст (best-effort, один раз). */
async function injectPendingCookies(name, context) {
  const f = cookiesPendingPath(name);
  let raw; try { raw = fs.readFileSync(f, 'utf8'); } catch { return false; }
  try {
    const parsed = JSON.parse(raw);
    const cookies = Array.isArray(parsed) ? parsed : (parsed.cookies || []);
    if (cookies.length) await context.addCookies(cookies);
    try { fs.unlinkSync(f); } catch { /* уже удалён */ }
    return true;
  } catch (e) { console.warn('[sync] вливание cookie ' + name + ': ' + e.message); return false; }
}

/** Захват cookie из ЖИВОГО контекста (для последующей выгрузки). Возвращает строку JSON или null. */
async function captureCookies(name, context) {
  if (!enabled()) return null;
  try {
    const state = await context.storageState(); // { cookies, origins }
    const str = JSON.stringify({ cookies: state.cookies || [] });
    fs.mkdirSync(SYNC_DIR(), { recursive: true });
    fs.writeFileSync(cookiesLocalPath(name), str, { mode: 0o600 });
    return str;
  } catch { return null; } // cookie best-effort (контекст закрыт/недоступен)
}

module.exports = { enabled, deviceId, runBarrier, pushProfile, pushAll, injectPendingCookies, captureCookies };

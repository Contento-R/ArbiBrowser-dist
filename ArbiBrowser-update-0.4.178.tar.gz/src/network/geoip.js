'use strict';

/**
 * geoip.js — определение географии по ВЫХОДНОМУ IP прокси.
 *
 * Ключевая идея: запрос делается ЧЕРЕЗ прокси, поэтому мы получаем гео именно
 * того IP, который увидит целевой сайт, а не гео машины, где запущен браузер.
 * Это то, что нужно для согласованности: locale/timezone/geolocation браузера
 * должны соответствовать стране выходного IP.
 *
 * Основной путь — HTTP GeoIP-API (без ключа). Резерв — оффлайн-база MaxMind
 * (.mmdb), если она положена в data/geoip/. В оффлайн-режиме сначала узнаём
 * выходной IP (echo-сервис через прокси), затем локально резолвим по базе.
 */

const http = require('node:http');
const https = require('node:https');
const fs = require('node:fs');
const config = require('../../config');

// maxmind подгружаем лениво — он нужен только для оффлайн-режима.
let maxmindLib = null;
function tryLoadMaxmind() {
  if (maxmindLib === false) return null;
  if (maxmindLib) return maxmindLib;
  try {
    maxmindLib = require('maxmind');
    return maxmindLib;
  } catch {
    maxmindLib = false;
    return null;
  }
}

/**
 * GET JSON через опциональный http/https-агент (для похода через прокси).
 * @param {string} url
 * @param {import('http').Agent} [agent]
 * @returns {Promise<object>}
 */
function getJson(url, agent) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https:') ? https : http;
    const req = lib.get(
      url,
      { agent, timeout: config.geoip.timeoutMs, headers: { 'User-Agent': 'ArbiBrowser/0.1' } },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            return reject(new Error(`GeoIP HTTP ${res.statusCode} для ${url}`));
          }
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            reject(new Error(`GeoIP: не JSON от ${url}: ${e.message}`));
          }
        });
      }
    );
    req.on('timeout', () => req.destroy(new Error(`GeoIP таймаут (${config.geoip.timeoutMs}мс) для ${url}`)));
    req.on('error', reject);
  });
}

/** Нормализует ответ ip-api.com в общий формат гео. */
function normalizeIpApi(j) {
  if (j.status && j.status !== 'success') {
    throw new Error(`GeoIP API: ${j.message || 'неуспех'}`);
  }
  return {
    ip: j.query,
    countryCode: j.countryCode, // ISO-3166 alpha-2
    country: j.country,
    region: j.regionName,
    city: j.city,
    latitude: j.lat,
    longitude: j.lon,
    timezone: j.timezone, // IANA
    isp: j.isp,
    source: 'api',
  };
}

/**
 * Определяет гео через HTTP-API (по умолчанию ip-api.com), опционально через прокси.
 * @param {import('http').Agent} [agent]  агент прокси; если нет — гео хоста
 */
async function lookupViaApi(agent) {
  // ip-api.com/json возвращает и IP, и все гео-поля разом.
  const url = `${config.geoip.apiBase}?fields=status,message,query,country,countryCode,regionName,city,lat,lon,timezone,isp`;
  const j = await getJson(url, agent);
  return normalizeIpApi(j);
}

/** Узнаёт выходной IP через echo-сервис (для оффлайн-mmdb-пути). */
async function lookupExitIp(agent) {
  const j = await getJson('https://api.ipify.org?format=json', agent);
  return j.ip;
}

/** Оффлайн-резолв гео по IP через базу MaxMind. */
async function lookupViaMmdb(ip) {
  const lib = tryLoadMaxmind();
  if (!lib) throw new Error('maxmind не установлен');
  if (!fs.existsSync(config.geoip.mmdbPath)) {
    throw new Error(`Оффлайн-база не найдена: ${config.geoip.mmdbPath}`);
  }
  const reader = await lib.open(config.geoip.mmdbPath);
  const r = reader.get(ip);
  if (!r) throw new Error(`MaxMind: нет данных для IP ${ip}`);
  return {
    ip,
    countryCode: r.country && r.country.iso_code,
    country: r.country && r.country.names && r.country.names.en,
    region: r.subdivisions && r.subdivisions[0] && r.subdivisions[0].names.en,
    city: r.city && r.city.names && r.city.names.en,
    latitude: r.location && r.location.latitude,
    longitude: r.location && r.location.longitude,
    timezone: r.location && r.location.time_zone,
    source: 'mmdb',
  };
}

/**
 * Главная точка входа: гео выходного IP.
 * @param {import('http').Agent} [agent]  прокси-агент (см. network/index.js)
 * @returns {Promise<object>} нормализованное гео
 */
async function resolveGeo(agent) {
  // 1. Пробуем API (сразу отдаёт IP + гео).
  try {
    return await lookupViaApi(agent);
  } catch (apiErr) {
    // 2. Резерв: оффлайн-база MaxMind (если есть). Нужен выходной IP.
    if (tryLoadMaxmind() && fs.existsSync(config.geoip.mmdbPath)) {
      try {
        const ip = await lookupExitIp(agent);
        return await lookupViaMmdb(ip);
      } catch (mmErr) {
        throw new Error(
          `GeoIP не удался. API: ${apiErr.message}; MaxMind: ${mmErr.message}`
        );
      }
    }
    throw new Error(`GeoIP не удался (API): ${apiErr.message}. Оффлайн-база MaxMind не подключена.`);
  }
}

module.exports = { resolveGeo, lookupViaApi, lookupViaMmdb, lookupExitIp };

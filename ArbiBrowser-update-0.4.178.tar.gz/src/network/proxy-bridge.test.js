'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const net = require('node:net');
const { startBridge } = require('./proxy-bridge');

// upstream socks5 намеренно недоступен (порт закрыт): нам важно ТОЛЬКО поведение
// auth-гейта. Без кред → 407 ДО попытки соединения; с кредами → гейт пройден
// (дальше 502, т.к. upstream не отвечает — но это уже не 407).
const DUMMY_PROXY = { type: 'socks5', host: '127.0.0.1', port: 1, username: 'u', password: 'p' };

function proxyReq(bridgePort, authHeader) {
  return new Promise((resolve, reject) => {
    const headers = {};
    if (authHeader) headers['Proxy-Authorization'] = authHeader;
    const req = http.request(
      { host: '127.0.0.1', port: bridgePort, method: 'GET', path: 'http://example.com/', headers },
      (res) => { res.resume(); resolve(res.statusCode); },
    );
    req.on('error', reject);
    req.end();
  });
}

test('bridge: без Proxy-Authorization → 407 (SEC-2)', async () => {
  const b = await startBridge(DUMMY_PROXY);
  const port = Number(new URL(b.server).port);
  try {
    const code = await proxyReq(port, null);
    assert.equal(code, 407, 'без кред мост обязан вернуть 407');
  } finally { await b.close(); }
});

test('bridge: c верными кредами → гейт пройден (не 407)', async () => {
  const b = await startBridge(DUMMY_PROXY);
  const port = Number(new URL(b.server).port);
  const auth = 'Basic ' + Buffer.from(`${b.username}:${b.password}`).toString('base64');
  try {
    const code = await proxyReq(port, auth);
    assert.notEqual(code, 407, 'с верными кредами 407 быть не должно (гейт пройден)');
  } finally { await b.close(); }
});

test('bridge: неверный пароль → 407', async () => {
  const b = await startBridge(DUMMY_PROXY);
  const port = Number(new URL(b.server).port);
  const auth = 'Basic ' + Buffer.from(`${b.username}:wrong`).toString('base64');
  try {
    const code = await proxyReq(port, auth);
    assert.equal(code, 407, 'неверный пароль → 407');
  } finally { await b.close(); }
});

// ─── upstream = обычный HTTP-прокси с авторизацией (класс инцидента 2026-09-07) ───

// Поддельный вышестоящий HTTP-прокси: требует Proxy-Authorization и обслуживает
// CONNECT. Нужен, чтобы проверить сквозной путь Chromium → мост → upstream и —
// главное — что отказ upstream'а НЕ превращается в 407 для браузера (иначе
// Chromium снова покажет системное окно ввода логина/пароля).
function startFakeHttpProxy(user, pass) {
  return new Promise((resolve) => {
    const expected = 'Basic ' + Buffer.from(`${user}:${pass}`).toString('base64');
    const live = new Set();
    const srv = http.createServer((req, res) => {
      if ((req.headers['proxy-authorization'] || '') !== expected) {
        res.writeHead(407, { 'Proxy-Authenticate': 'Basic realm="up"' });
        return res.end('nope');
      }
      res.writeHead(200, { 'content-type': 'text/plain' });
      res.end('plain-ok:' + req.url);
    });
    srv.on('connect', (req, socket) => {
      live.add(socket);
      socket.on('close', () => live.delete(socket));
      if ((req.headers['proxy-authorization'] || '') !== expected) {
        socket.write('HTTP/1.1 407 Proxy Authentication Required\r\nProxy-Authenticate: Basic realm="up"\r\n\r\n');
        return socket.destroy();
      }
      socket.write('HTTP/1.1 200 Connection Established\r\n\r\n');
      socket.on('data', (d) => socket.write(Buffer.concat([Buffer.from('echo:'), d])));
      socket.on('error', () => {});
    });
    // Закрытие с грацией: Node не завершает close() для сокетов, ушедших в CONNECT
    // (та же причина, что и в самом мосте) — рвём их сами и не ждём колбэк вечно.
    const close = () => new Promise((r) => {
      for (const sock of live) { try { sock.destroy(); } catch (_) {} }
      live.clear();
      try { srv.closeAllConnections(); } catch (_) {}
      srv.close(() => r());
      setTimeout(() => r(), 300).unref();
    });
    srv.listen(0, '127.0.0.1', () => resolve({ port: srv.address().port, close }));
  });
}

// Говорим с мостом СЫРЫМ сокетом — ровно как Chromium: CONNECT, разбор статуса,
// дальше двоичный туннель. HTTP-клиент Node для CONNECT ведёт себя иначе, чем
// браузер, и проверял бы не тот путь.
function bridgeConnect(bridgePort, auth, target) {
  return new Promise((resolve, reject) => {
    const socket = net.connect(bridgePort, '127.0.0.1');
    let buf = Buffer.alloc(0);
    socket.on('error', reject);
    socket.on('connect', () => {
      const head = [`CONNECT ${target} HTTP/1.1`, `Host: ${target}`];
      if (auth) head.push(`Proxy-Authorization: ${auth}`);
      socket.write(head.join('\r\n') + '\r\n\r\n');
    });
    const onData = (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      const end = buf.indexOf('\r\n\r\n');
      if (end === -1) return;
      socket.removeListener('data', onData);
      const status = Number(buf.slice(0, end).toString().split(' ')[1]);
      const rest = buf.slice(end + 4);
      if (rest.length) socket.unshift(rest);
      resolve({ status, socket });
    };
    socket.on('data', onData);
  });
}

test('мост через upstream HTTP-прокси: CONNECT доходит и туннель работает', async () => {
  const up = await startFakeHttpProxy('u', 'p');
  const b = await startBridge({ type: 'http', host: '127.0.0.1', port: up.port, username: 'u', password: 'p' });
  const bp = Number(new URL(b.server).port);
  const auth = 'Basic ' + Buffer.from(`${b.username}:${b.password}`).toString('base64');
  try {
    const { status, socket } = await bridgeConnect(bp, auth, 'example.com:443');
    assert.equal(status, 200, 'мост обязан установить туннель через upstream');
    const echoed = await new Promise((r) => { socket.once('data', (d) => r(d.toString())); socket.write('hi'); });
    assert.equal(echoed, 'echo:hi', 'данные должны ходить сквозь мост');
    socket.destroy();
  } finally { await b.close(); await up.close(); }
});

test('отказ upstream по кредам → 502 браузеру, НЕ 407 (иначе всплывёт окно Chromium)', async () => {
  const up = await startFakeHttpProxy('u', 'p');
  const b = await startBridge({ type: 'http', host: '127.0.0.1', port: up.port, username: 'u', password: 'ЧУЖОЙ' });
  const bp = Number(new URL(b.server).port);
  const auth = 'Basic ' + Buffer.from(`${b.username}:${b.password}`).toString('base64');
  try {
    const { status } = await bridgeConnect(bp, auth, 'example.com:443');
    assert.equal(status, 502, 'ошибка вышестоящего прокси обязана дойти как 502');
    assert.notEqual(status, 407, '407 от моста = системное окно ввода пароля в Chromium');
  } finally { await b.close(); await up.close(); }
});

test('мост через upstream HTTP-прокси: обычный http идёт absolute-URI с его авторизацией', async () => {
  const up = await startFakeHttpProxy('u', 'p');
  const b = await startBridge({ type: 'http', host: '127.0.0.1', port: up.port, username: 'u', password: 'p' });
  const bp = Number(new URL(b.server).port);
  const auth = 'Basic ' + Buffer.from(`${b.username}:${b.password}`).toString('base64');
  try {
    const body = await new Promise((resolve, reject) => {
      const req = http.request({ host: '127.0.0.1', port: bp, method: 'GET', path: 'http://example.com/x',
        headers: { 'Proxy-Authorization': auth } }, (res) => {
        let d = ''; res.on('data', (c) => { d += c; }); res.on('end', () => resolve(`${res.statusCode}:${d}`));
      });
      req.on('error', reject); req.end();
    });
    assert.equal(body, '200:plain-ok:http://example.com/x');
  } finally { await b.close(); await up.close(); }
});

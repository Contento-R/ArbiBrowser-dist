'use strict';

/**
 * src/network — сеть профиля: прокси, удалённый DNS, GeoIP, автозаполнение.
 *
 * Какие сетевые параметры контролируем и почему они должны быть согласованы:
 *
 *  • proxy         — весь трафик браузера идёт через ОДИН прокси профиля. Никакого
 *                    трафика в обход (иначе утечёт реальный IP).
 *  • remote DNS    — для SOCKS5 используем схему socks5h://, чтобы DNS-резолв шёл
 *                    на стороне прокси. Иначе DNS-запрос уходит с реального IP —
 *                    классическая утечка, рассинхрон с выходным IP.
 *  • locale        — язык интерфейса/форматов. Должен соответствовать стране
 *                    выходного IP прокси (нем. IP + en-US локаль = противоречие).
 *  • timezone      — часовой пояс JS (Date/Intl). Должен совпадать со страной IP.
 *  • geolocation   — координаты Geolocation API. Должны попадать в страну IP.
 *  • Accept-Language— HTTP-заголовок. Должен соответствовать locale/languages.
 *
 * Все эти поля профиля выводятся из ОДНОГО источника — гео выходного IP прокси,
 * чтобы среда была непротиворечивой.
 */

const geoip = require('./geoip');

// Прокси-агенты нужны ТОЛЬКО для GeoIP-запроса через прокси. Если пакеты
// недоступны (offline-среда), agentFor вернёт null — GeoIP пойдёт напрямую,
// а трафик самого браузера всё равно идёт через прокси средствами Playwright.
let SocksProxyAgent = null;
let HttpsProxyAgent = null;
try { ({ SocksProxyAgent } = require('socks-proxy-agent')); } catch (e) { /* optional */ }
try { ({ HttpsProxyAgent } = require('https-proxy-agent')); } catch (e) { /* optional */ }

// ─── URL и агенты прокси ───

/**
 * Собирает URL прокси из блока профиля.
 * Для socks5 → socks5h, чтобы DNS резолвился удалённо (без утечки DNS).
 */
function proxyUrl(proxy) {
  if (!proxy) return null;
  const auth =
    proxy.username != null
      ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password || '')}@`
      : '';
  // socks5h — удалённый DNS.
  const scheme = proxy.type === 'socks5' ? 'socks5h' : proxy.type;
  return `${scheme}://${auth}${proxy.host}:${proxy.port}`;
}

/**
 * Создаёт http(s)-агент для похода ЧЕРЕЗ прокси (используется GeoIP-запросами).
 * @returns {import('http').Agent|null}
 */
function agentFor(proxy) {
  if (!proxy) return null;
  const url = proxyUrl(proxy);
  if (proxy.type === 'socks5') {
    if (!SocksProxyAgent) return null; // пакет недоступен — GeoIP пойдёт напрямую
    return new SocksProxyAgent(url);
  }
  if (!HttpsProxyAgent) return null;
  return new HttpsProxyAgent(url);
}

/**
 * Форматирует прокси для Playwright launch/launchPersistentContext.
 * Playwright сам направляет через него весь трафик Chromium.
 * @returns {{server:string, username?:string, password?:string}|undefined}
 */
function playwrightProxy(proxy) {
  if (!proxy) return undefined;
  // Playwright ожидает scheme://host:port без креденшелов в URL.
  const scheme = proxy.type === 'socks5' ? 'socks5' : proxy.type;
  const out = { server: `${scheme}://${proxy.host}:${proxy.port}` };
  if (proxy.username != null) {
    out.username = proxy.username;
    out.password = proxy.password || '';
  }
  return out;
}

// ─── GeoIP ───

/**
 * Определяет гео выходного IP прокси профиля (или хоста, если прокси нет).
 * @param {object} profile
 * @returns {Promise<object>} нормализованное гео (см. geoip.js)
 */
// Кэш гео по выходному IP прокси. Гео стабильно на прокси (тот же exit-IP →
// та же страна/город/tz), а resolveGeo — сетевой запрос через прокси до ~15с. В
// холодном пути (авто-запуск профиля под ордер) он платился на КАЖДЫЙ запуск ДО
// старта Chromium. Кэшируем по идентичности прокси; TTL покрывает ротацию IP.
const geoCache = new Map();
const GEO_TTL_MS = Number(process.env.ARBI_GEO_CACHE_TTL_MS || 3600000);
function proxyKey(p) {
  return p ? `${p.type}:${p.host}:${p.port}:${p.username || ''}` : 'noproxy';
}

async function resolveGeo(profile) {
  const key = proxyKey(profile.proxy);
  const cached = geoCache.get(key);
  if (cached && Date.now() - cached.ts < GEO_TTL_MS) return cached.geo;
  const agent = agentFor(profile.proxy);
  // SEC-4 fail-closed: у профиля ЗАДАН прокси, но агент не построился (пакет
  // socks/https-proxy-agent недоступен ИЛИ битый URL) → agentFor вернул null.
  // Раньше запрос уходил НАПРЯМУЮ с реального IP хоста на ip-api.com/ipify —
  // деанонимизация биржевого аккаунта. Теперь блокируем прямой путь.
  if (profile.proxy && !agent) {
    throw new Error('GeoIP заблокирован: у профиля задан прокси, но прокси-агент не создан — прямой запрос утёк бы реальный IP. Проверьте прокси/установку socks-proxy-agent.');
  }
  const geo = await geoip.resolveGeo(agent);
  geoCache.set(key, { geo, ts: Date.now() });
  return geo;
}

// ─── Автозаполнение полей профиля из гео ───

// Страна → предпочтительная локаль/языки (упрощённая таблица; при явно заданной
// в профиле locale она сохраняется, здесь только дефолты «по стране IP»).
const COUNTRY_LOCALE = {
  US: 'en-US', GB: 'en-GB', DE: 'de-DE', FR: 'fr-FR', ES: 'es-ES', IT: 'it-IT',
  NL: 'nl-NL', RU: 'ru-RU', UA: 'uk-UA', PL: 'pl-PL', TR: 'tr-TR', BR: 'pt-BR',
  JP: 'ja-JP', CN: 'zh-CN', HK: 'zh-HK', SG: 'en-SG', IN: 'en-IN', CA: 'en-CA',
  AU: 'en-AU', AE: 'ar-AE', KR: 'ko-KR', SE: 'sv-SE', CH: 'de-CH',
};

/** Строит navigator.languages из локали. */
function languagesFromLocale(locale) {
  const base = locale.split('-')[0];
  return base === 'en' ? [locale, 'en'] : [locale, base, 'en'];
}

/** Строит заголовок Accept-Language с q-факторами из списка языков. */
function acceptLanguage(languages) {
  // Идемпотентно: срезаем любой уже присутствующий ";q=..." и пробелы у каждого
  // тега и дедуплицируем, сохраняя порядок. Иначе, если на вход придёт уже
  // q-размеченный список (напр. profile.languages из старого сохранения или при
  // autoGeo=false), получим битый заголовок "de;q=0.9;q=0.9" — детектируемый признак.
  const seen = new Set();
  const tags = languages
    .map((l) => String(l).split(';')[0].trim())
    .filter((t) => t && !seen.has(t) && seen.add(t));
  return tags
    .map((lang, i) => (i === 0 ? lang : `${lang};q=${(1 - i * 0.1).toFixed(1)}`))
    .join(',');
}

/**
 * Заполняет locale/timezone/geolocation/languages профиля из гео.
 * Уже заданные в профиле поля НЕ перетираются (профиль — источник правды),
 * заполняются только пустые. Возвращает копию профиля + вычисленный acceptLanguage.
 *
 * @param {object} profile
 * @param {object} geo   результат resolveGeo
 * @returns {{profile: object, acceptLanguage: string}}
 */
function applyGeo(profile, geo) {
  const p = JSON.parse(JSON.stringify(profile));
  const hasProxy = !!p.proxy;
  // autoGeo (по умолчанию true): гео прокси управляет locale. Если пользователь
  // явно зафиксировал локаль (autoGeo=false), она не перетирается.
  const autoLocale = p.autoGeo !== false;

  if (hasProxy) {
    // С прокси среда должна соответствовать стране выходного IP. timezone и
    // geolocation ПЕРЕТИРАЕМ всегда (они обязаны совпадать с IP), locale — при autoGeo.
    if (autoLocale && geo.countryCode) {
      p.locale = COUNTRY_LOCALE[geo.countryCode] || p.locale || 'en-US';
      p.languages = languagesFromLocale(p.locale);
    } else if (!p.languages && p.locale) {
      p.languages = languagesFromLocale(p.locale);
    }
    if (geo.timezone) p.timezone = geo.timezone;
    if (geo.latitude != null && geo.longitude != null) {
      p.geolocation = { latitude: geo.latitude, longitude: geo.longitude, accuracy: 100 };
    }
  } else {
    // Без прокси — не навязываем гео хоста, только дозаполняем пустые поля.
    if (!p.locale && geo.countryCode) p.locale = COUNTRY_LOCALE[geo.countryCode] || 'en-US';
    if (!p.languages && p.locale) p.languages = languagesFromLocale(p.locale);
    if (!p.timezone && geo.timezone) p.timezone = geo.timezone;
    if (!p.geolocation && geo.latitude != null && geo.longitude != null) {
      p.geolocation = { latitude: geo.latitude, longitude: geo.longitude, accuracy: 100 };
    }
  }

  const accept = acceptLanguage(p.languages || languagesFromLocale(p.locale || 'en-US'));
  return { profile: p, acceptLanguage: accept };
}

// ─── Проверка конфигурации сети ───

/**
 * Проверяет, что сеть профиля согласована: прокси доступен, а гео его выходного
 * IP не противоречит locale/timezone профиля.
 * @param {object} profile
 * @returns {Promise<{ok:boolean, geo:object|null, errors:string[], warnings:string[], info:object}>}
 */
async function checkNetworkConfig(profile) {
  const errors = [];
  const warnings = [];
  const info = {};

  if (!profile.proxy) {
    warnings.push('Прокси не задан — браузер пойдёт с реального IP хоста. Для приватности задайте proxy.');
  } else {
    info.proxy = `${profile.proxy.type}://${profile.proxy.host}:${profile.proxy.port}`;
    if (profile.proxy.type === 'socks5') {
      info.remoteDns = 'socks5h (удалённый DNS — включён)';
    }
  }

  let geo = null;
  try {
    geo = await resolveGeo(profile);
    info.exitIp = geo.ip;
    info.geo = `${geo.city || '?'}, ${geo.country || '?'} (${geo.countryCode || '?'})`;
    info.geoTimezone = geo.timezone;
  } catch (e) {
    errors.push(`Не удалось определить гео выходного IP: ${e.message}`);
    return { ok: false, geo: null, errors, warnings, info };
  }

  // ЭФФЕКТИВНОЕ состояние при запуске: applyGeo перетирает locale/timezone под
  // страну прокси (autoGeo=true). netcheck обязан проверять именно его, иначе
  // ложно ругается на дефолт-заглушку en-US/America_New_York, которую реальный
  // запуск профиля уже заменяет на гео прокси (подтверждено вживую).
  const effective = applyGeo(profile, geo).profile;
  info.effectiveLocale = effective.locale;
  info.effectiveTimezone = effective.timezone;

  // Согласованность locale ↔ страна IP (по эффективной локали).
  if (effective.locale && geo.countryCode) {
    const expected = COUNTRY_LOCALE[geo.countryCode];
    const profCountry = effective.locale.split('-')[1];
    if (expected && profCountry && expected.split('-')[1] !== profCountry) {
      warnings.push(
        `эффективная locale="${effective.locale}", но выходной IP в стране ${geo.countryCode} ` +
        `(ожидалось ~${expected}). Возможен рассинхрон язык/страна.`
      );
    }
  }

  // Согласованность timezone ↔ гео IP (по эффективному часовому поясу).
  if (effective.timezone && geo.timezone && effective.timezone !== geo.timezone) {
    warnings.push(
      `эффективный timezone="${effective.timezone}" ≠ timezone выходного IP="${geo.timezone}". ` +
      'Часовой пояс должен совпадать со страной IP.'
    );
  }

  return { ok: errors.length === 0, geo, errors, warnings, info };
}

module.exports = {
  proxyUrl,
  agentFor,
  playwrightProxy,
  resolveGeo,
  applyGeo,
  acceptLanguage,
  languagesFromLocale,
  checkNetworkConfig,
  COUNTRY_LOCALE,
};

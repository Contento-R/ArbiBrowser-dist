'use strict';

/**
 * app-info.js — сведения о версии ArbiBrowser и о движке Chromium.
 *
 *  • Обновление ArbiBrowser (движок — отдельно!): сравниваем локальный git с
 *    origin и говорим, отстаём ли (нужно ли обновить приложение).
 *  • Chromium: какой бинарь запускается (системный обычный Chrome или встроенный
 *    Playwright «Chrome for Testing»), и его версия, если удаётся определить.
 */

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const https = require('node:https');
const { execFile, execFileSync } = require('node:child_process');
const settings = require('./settings');

const ROOT = path.join(__dirname, '..');
const pkg = require('../package.json');

// Публичный dist-репозиторий с релизами инсталлятора (owner/repo). Именно сюда
// GitHub Action публикует ArbiBrowser-Setup.exe / ArbiBrowser-linux-x64.tar.gz под
// тегом vX.Y.Z (см. .github/workflows/build-installer.yml → «Publish...»).
// Публичный → доступен БЕЗ токена, поэтому проверка обновления работает и в .exe.
const UPDATE_REPO = process.env.ARBI_UPDATE_REPO || 'Contento-R/ArbiBrowser-dist';

// Имя ассета релиза зависит от ОС: под Linux — самодостаточный .tar.gz, под
// Windows (и по умолчанию) — установщик .exe. Один и тот же релиз содержит оба.
const INSTALLER_ASSET = process.platform === 'linux'
  ? 'ArbiBrowser-linux-x64.tar.gz'
  : 'ArbiBrowser-Setup.exe';
// Прямая ссылка на последний установщик под текущую ОС (постоянный URL Releases).
const INSTALLER_URL = process.env.ARBI_INSTALLER_URL
  || `https://github.com/${UPDATE_REPO}/releases/latest/download/${INSTALLER_ASSET}`;

/** Установлено из git (терминал) или как .exe (нет .git)? */
function isGitInstall() {
  return fs.existsSync(path.join(ROOT, '.git'));
}

/** "v1.2.3"/"1.2.3" → [1,2,3]. Нечисловые хвосты (rc/beta) отбрасываются. */
function parseVersion(v) {
  return String(v || '').replace(/^v/i, '').split('.')
    .map((n) => parseInt(n, 10) || 0);
}

/** semver-сравнение: >0 если a новее b, <0 если старее, 0 если равны. */
function cmpVersion(a, b) {
  const pa = parseVersion(a); const pb = parseVersion(b);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** GET api.github.com/... → распарсенный JSON (или reject). Таймаут, User-Agent. */
function githubApiGet(apiPath) {
  return new Promise((resolve, reject) => {
    const req = https.get({
      hostname: 'api.github.com',
      path: apiPath,
      headers: {
        'User-Agent': 'ArbiBrowser-update-check',
        Accept: 'application/vnd.github+json',
      },
      timeout: 8000,
    }, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          return reject(new Error(`HTTP ${res.statusCode}`));
        }
        try { resolve(JSON.parse(data)); } catch (e) { reject(e); }
      });
    });
    req.on('timeout', () => { req.destroy(new Error('timeout')); });
    req.on('error', reject);
  });
}

/**
 * Проверка обновления через ПОСЛЕДНИЙ GitHub-релиз публичного dist-репо. Работает
 * для ЛЮБОЙ установки (в т.ч. .exe, где .git нет) — единый источник правды о
 * «свежести» = опубликованный релиз. Сравниваем tag_name (vX.Y.Z) с pkg.version.
 */
function checkReleaseUpdate() {
  return githubApiGet(`/repos/${UPDATE_REPO}/releases/latest`).then((rel) => {
    const latest = String(rel && rel.tag_name || '').replace(/^v/i, '');
    const updateAvailable = !!latest && cmpVersion(latest, pkg.version) > 0;
    return {
      current: pkg.version, latest, updateAvailable, method: 'release',
      behind: 0, downloadUrl: INSTALLER_URL, error: null,
    };
  }).catch((e) => ({
    current: pkg.version, latest: null, updateAvailable: false, method: 'release',
    behind: 0, downloadUrl: INSTALLER_URL, error: String(e && e.message || e),
  }));
}

/** Путь к бинарю, который реально будет запущен. */
function activeChromiumPath() {
  const custom = settings.effectiveChromiumPath();
  if (custom) return custom;
  try { return require('playwright').chromium.executablePath(); } catch { return null; }
}

/** Версия и тип сборки Chromium. На Windows GUI-Chrome может не печатать --version. */
function chromiumInfo() {
  const exe = activeChromiumPath();
  const usingSystem = !!settings.effectiveChromiumPath();
  const info = {
    path: exe,
    version: null,
    isForTesting: false,
    source: usingSystem ? 'system' : 'playwright', // system = обычный Chrome
  };
  if (!exe || !fs.existsSync(exe)) return info;
  try {
    const out = execFileSync(exe, ['--version'], { timeout: 5000 }).toString().trim();
    if (out) {
      info.version = out;
      info.isForTesting = /for testing/i.test(out);
    }
  } catch { /* нет вывода (частый случай на Windows) — не считаем ошибкой */ }
  return info;
}

/** Проверка обновления через git (отстаём ли от upstream). Только для git-установки. */
function checkGitUpdate() {
  return new Promise((resolve) => {
    const result = { current: pkg.version, updateAvailable: false, behind: 0, method: 'git', error: null };
    execFile('git', ['-C', ROOT, 'fetch', '--quiet'], { timeout: 15000 }, () => {
      execFile('git', ['-C', ROOT, 'rev-list', '--count', 'HEAD..@{u}'], { timeout: 8000 }, (err, stdout) => {
        if (err) { result.error = 'нет upstream/сети'; return resolve(result); }
        const behind = parseInt(String(stdout).trim(), 10) || 0;
        result.behind = behind;
        result.updateAvailable = behind > 0;
        resolve(result);
      });
    });
  });
}

/**
 * Проверка обновления САМОГО ArbiBrowser. Единый вход для ОБЕИХ установок:
 *   • .exe (нет .git) — по последнему публичному релизу (checkReleaseUpdate);
 *   • терминал (git)  — сначала по релизу (единый источник правды о версии), плюс
 *     git-отставание в коммитах; updateAvailable, если сработало ЛЮБОЕ из двух.
 * Так уведомление о новом релизе всплывает и там, и там (требование оператора).
 */
async function checkAppUpdate() {
  const installType = isGitInstall() ? 'git' : 'exe';
  const rel = await checkReleaseUpdate();
  if (installType !== 'git') {
    // .exe: обновляемся самообновлением по манифесту latest.json. Раньше баннер и
    // «Проверить обновления» смотрели ТОЛЬКО на GitHub-релизы: когда пакет
    // опубликован руками (17.09: сборки Actions не стартуют, latest.json указывает
    // на 0.4.171, а последний релиз в списке — 0.4.168), обновление уже скачано и
    // ждёт, а панель писала «у вас последняя версия» и прятала кнопку.
    let self = null;
    try { self = await require('./updater').checkRemote(); } catch { /* канал молчит — ниже релизы */ }
    if (self && self.updateAvailable) {
      const latest = String(self.latest || '').replace(/^v/i, '');
      return { ...rel, latest, updateAvailable: true, method: 'self', error: null, installType, canGitPull: false };
    }
    return { ...rel, installType, canGitPull: false };
  }
  // git-установка: релиз + git-отставание. Метод показа выбираем по тому, что
  // сработало (релиз информативнее — показывает конкретную версию).
  const git = await checkGitUpdate().catch(() => null);
  const behind = git ? git.behind : 0;
  const updateAvailable = rel.updateAvailable || behind > 0;
  return {
    current: pkg.version,
    latest: rel.latest,
    updateAvailable,
    behind,
    method: rel.updateAvailable ? 'release' : 'git',
    downloadUrl: rel.downloadUrl,
    installType,
    canGitPull: true,
    error: rel.error && !git ? rel.error : null,
  };
}

/**
 * Применить обновление ArbiBrowser. Для git-установки — git pull (перезапуск
 * вручную). Для .exe git pull невозможен — возвращаем ссылку на установщик, чтобы
 * панель предложила скачать новую сборку.
 */
/**
 * @param {{openProfiles?:number}} [opts] сколько профилей открыто — нужно
 *   самообновлению: под живой сессией биржи код не подменяем (см. updater.js).
 */
function applyAppUpdate(opts = {}) {
  return new Promise((resolve) => {
    if (!isGitInstall()) {
      // САМООБНОВЛЕНИЕ: качаем ~1.5 МБ кода и распаковываем поверх, вместо
      // 262-мегабайтного установщика и мастера установки. Переустановка
      // остаётся запасным путём — если канал раздачи недоступен или обновление
      // почему-то не встало, ниже вернётся прежний ответ со ссылкой на .exe.
      return selfUpdate(opts).then(async (r) => {
        if (r) return resolve(r);
        // Манифест самообновления не новее нас, но релиз в списке уже есть?
        // Значит пакет ещё публикуется (оператор 15.09: кликнул «обновить» в
        // ту минуту, когда releases/latest уже показывал 0.4.150, а latest.json
        // ещё указывал на 0.4.149 — и панель послала за 262-мегабайтным
        // установщиком с чужой причиной «это .exe-сборка»). Говорим правду и
        // просим повторить через минуту; установщик — только когда релиза нет.
        try {
          const rel = await checkReleaseUpdate();
          if (rel && rel.updateAvailable) {
            return resolve({
              ok: false, installType: 'self', latest: rel.latest, pending: true,
              output: `Релиз ${rel.latest} уже опубликован, пакет самообновления ещё собирается — нажмите «Обновить» через минуту.`,
            });
          }
        } catch { /* нет сети — ниже прежний путь */ }
        resolve({
          ok: false, installType: 'exe', downloadUrl: INSTALLER_URL,
          output: 'Это .exe-сборка — обновление ставится новым установщиком.',
        });
      });
    }
    execFile('git', ['-C', ROOT, 'pull', '--ff-only'], { timeout: 60000 }, (err, stdout, stderr) => {
      resolve({ ok: !err, installType: 'git', output: String(stdout || '') + String(stderr || '') });
    });
  });
}

/**
 * Попытка самообновления .exe-сборки: манифест → архив кода (sha256) →
 * распаковка поверх. Возвращает `null`, если сделать этого нельзя (канал
 * недоступен, обновления нет) — тогда вызывающий откатывается на прежний путь
 * «скачайте установщик». Ошибки самого обновления возвращаются как результат,
 * а не глушатся: пользователь должен знать, почему не встало.
 */
function selfUpdate({ openProfiles = 0 } = {}) {
  const updater = require('./updater');
  return updater.checkRemote().then(async (r) => {
    if (r.error) {
      // Канал самообновления не ответил — падаем на установщик, но ПРИЧИНУ отдаём
      // наверх и в лог: до 2026-09-12 отказ был безымянным («самообновление
      // недоступно»), и то, что у оператора не открывается raw.githubusercontent.com,
      // выяснилось только по коду.
      console.warn(`[update] самообновление недоступно: ${r.error}`);
      return { ok: false, installType: 'exe', downloadUrl: INSTALLER_URL, output: `самообновление недоступно: ${r.error}` };
    }
    if (!r.updateAvailable || !r.manifest) return null; // нечего ставить
    const gate = updater.canInstall(openProfiles);
    if (!gate.ok) {
      return { ok: false, installType: 'self', latest: r.latest, output: gate.reason };
    }
    try {
      await updater.download(r.manifest);
      const res = await updater.install(r.manifest, { openProfiles });
      if (!res.ok) return { ok: false, installType: 'self', latest: r.latest, output: res.error };
      return {
        ok: true, installType: 'self', latest: res.version, restartRequired: true,
        output: `Обновление до ${res.version} установлено. Перезапустите ArbiBrowser, чтобы оно вступило в силу.`,
      };
    } catch (e) {
      return { ok: false, installType: 'self', latest: r.latest, output: String(e && e.message || e) };
    }
  }).catch(() => null);
}

/**
 * Открыть цель во ВНЕШНЕЙ системной программе: URL → системный браузер (по умолчанию),
 * путь к папке → проводник. Кроссплатформенно. Нужно, потому что панель открыта ВНУТРИ
 * антидетект-Chromium ArbiBrowser: window.open('...exe') там качает файл с «мусорным»
 * именем и не показывает его. Открытие в СИСТЕМНОМ браузере/проводнике этого избегает.
 */
function openExternal(target) {
  return new Promise((resolve) => {
    let cmd; let args;
    if (process.platform === 'win32') { cmd = 'cmd'; args = ['/c', 'start', '', target]; }
    else if (process.platform === 'darwin') { cmd = 'open'; args = [target]; }
    else { cmd = 'xdg-open'; args = [target]; }
    execFile(cmd, args, { timeout: 8000, windowsHide: true }, (err) => resolve({ ok: !err, error: err ? err.message : null }));
  });
}

/** Открыть страницу/файл установщика в СИСТЕМНОМ браузере (кнопка «Скачать в браузере»). */
function openDownloadInBrowser() {
  return openExternal(INSTALLER_URL);
}

/**
 * СЕРВЕРНОЕ скачивание установщика (Node, а НЕ Chromium панели) — гарантирует верное
 * имя файла (INSTALLER_ASSET под текущую ОС). Идём по редиректам GitHub (releases → objects.
 * githubusercontent.com). Кладём в папку «Загрузки» пользователя. По завершении
 * вызывающий откроет папку в проводнике. Возвращает {ok, path|error}.
 */
function downloadInstaller(destDir) {
  const preferred = destDir || path.join(os.homedir(), 'Downloads');
  const dir = fs.existsSync(preferred) ? preferred : os.tmpdir();
  const dest = path.join(dir, INSTALLER_ASSET);
  return new Promise((resolve) => {
    const get = (url, redirects) => {
      if (redirects > 6) return resolve({ ok: false, error: 'слишком много редиректов' });
      const req = https.get(url, { headers: { 'User-Agent': 'ArbiBrowser-update' }, timeout: 120000 }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume(); // освободить сокет и идти по редиректу
          return get(res.headers.location, redirects + 1);
        }
        if (res.statusCode !== 200) { res.resume(); return resolve({ ok: false, error: `HTTP ${res.statusCode}` }); }
        const tmp = dest + '.part';
        const file = fs.createWriteStream(tmp);
        res.pipe(file);
        file.on('finish', () => file.close(() => {
          try { fs.renameSync(tmp, dest); resolve({ ok: true, path: dest }); }
          catch (e) { resolve({ ok: false, error: e.message }); }
        }));
        file.on('error', (e) => { try { fs.unlinkSync(tmp); } catch { /* игнор */ } resolve({ ok: false, error: e.message }); });
      });
      req.on('timeout', () => req.destroy(new Error('timeout')));
      req.on('error', (e) => resolve({ ok: false, error: e.message }));
    };
    get(INSTALLER_URL, 0);
  });
}

/** Сводка для панели. `force` — ручная кнопка «Проверить обновления»: смотрим
 *  канал даже при выключенной автопроверке (в этом и смысл ручной проверки). */
async function appInfo({ force = false } = {}) {
  const chrome = chromiumInfo();
  const sysChrome = settings.detectSystemChrome();
  let appUpdate = {
    current: pkg.version, latest: null, updateAvailable: false, behind: 0,
    method: 'release', installType: isGitInstall() ? 'git' : 'exe',
    canGitPull: isGitInstall(), downloadUrl: INSTALLER_URL, error: null,
  };
  try { if (force || settings.read().autoUpdateCheck !== false) appUpdate = await checkAppUpdate(); } catch { /* без сети */ }

  // Заметка про движок: показываем ТОЛЬКО если реально используется тестовая
  // сборка и есть обычный Chrome, на который стоит переключиться.
  let engineNote = null;
  if (chrome.isForTesting && sysChrome && chrome.path !== sysChrome) {
    engineNote = 'Сейчас движок — «Chrome for Testing». Найден обычный Chrome — можно переключиться.';
  } else if (!settings.effectiveChromiumPath() && sysChrome) {
    // редко: preferSystemChrome выключен, но Chrome есть
    engineNote = 'Найден обычный Chrome — можно использовать его вместо встроенного.';
  }

  return {
    appVersion: pkg.version,
    chromium: chrome,
    detectedSystemChrome: sysChrome,
    settings: settings.read(),
    appUpdate,
    engineNote,
  };
}

module.exports = { appInfo, chromiumInfo, checkAppUpdate, checkReleaseUpdate, applyAppUpdate, downloadInstaller, openDownloadInBrowser, openExternal, INSTALLER_URL, detectSystemChrome: settings.detectSystemChrome, activeChromiumPath };

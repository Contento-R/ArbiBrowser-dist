'use strict';

/**
 * local-guard.js — SEC-1: проверка, что HTTP-запрос к локальному GUI пришёл
 * действительно с loopback, а не через DNS-rebinding/cross-site из обычного
 * браузера. Вынесено из server.js отдельным модулем БЕЗ тяжёлых зависимостей
 * (playwright и пр.), чтобы покрыть юнит-тестами.
 */

const LOCAL_HOSTNAMES = new Set(['127.0.0.1', 'localhost', '::1']);

function hostnameOf(hostHeader) {
  if (!hostHeader) return null;
  try {
    const v = String(hostHeader).includes('://') ? String(hostHeader) : 'http://' + hostHeader;
    return new URL(v).hostname.replace(/^\[|\]$/g, '');
  } catch { return null; }
}

function isLocalHostname(hn, boundHost) {
  return !!hn && (LOCAL_HOSTNAMES.has(hn) || hn === boundHost);
}

/**
 * Пропускаем запрос ТОЛЬКО если Host — loopback (или фактический адрес привязки)
 * И Origin проходит проверку. Иначе — DNS-rebinding или cross-site: блок.
 *
 * SEC-1: `Origin: null` (sandboxed-iframe/`data:`/некоторые расширения) РАНЬШЕ
 * пропускался безусловно → cross-site страница могла слать МУТИРУЮЩИЕ запросы
 * (запуск/удаление/создание профиля) с Origin:null и обойти guard (CSRF). Теперь
 * Origin:null допускается только для БЕЗОПАСНЫХ методов (GET/HEAD/OPTIONS); на
 * POST/DELETE/PATCH/PUT — блок. Легитимный GUI грузится с http://127.0.0.1 и шлёт
 * НОРМАЛЬНЫЙ loopback-Origin, поэтому не задет.
 */
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);
function isLocalRequest(req, boundHost) {
  if (!isLocalHostname(hostnameOf(req.headers.host), boundHost)) return false;
  const origin = req.headers.origin;
  if (origin === 'null') {
    return SAFE_METHODS.has(String(req.method || 'GET').toUpperCase());
  }
  if (origin && !isLocalHostname(hostnameOf(origin), boundHost)) return false;
  return true;
}

module.exports = { hostnameOf, isLocalHostname, isLocalRequest };

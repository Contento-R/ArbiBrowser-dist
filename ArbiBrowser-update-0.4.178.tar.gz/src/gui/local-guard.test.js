'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { isLocalRequest } = require('./local-guard');

const mk = (host, origin, method) => ({ method, headers: { host, ...(origin !== undefined ? { origin } : {}) } });
const HOST = '127.0.0.1';

test('isLocalRequest: loopback Host без Origin — ок', () => {
  assert.equal(isLocalRequest(mk('127.0.0.1:8777'), HOST), true);
  assert.equal(isLocalRequest(mk('localhost:8777'), HOST), true);
});

test('isLocalRequest: DNS-rebinding (чужой Host) — блок (SEC-1)', () => {
  assert.equal(isLocalRequest(mk('evil.com'), HOST), false);
  assert.equal(isLocalRequest(mk('attacker.example:8777'), HOST), false);
});

test('isLocalRequest: cross-site Origin при loopback Host — блок', () => {
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'http://evil.com'), HOST), false);
});

test('isLocalRequest: loopback Host + loopback Origin — ок', () => {
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'http://127.0.0.1:8777'), HOST), true);
});

test('isLocalRequest: Origin=null — ок на GET, БЛОК на мутациях (SEC-1 CSRF)', () => {
  // Читающие безопасны.
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'null', 'GET'), HOST), true);
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'null', undefined), HOST), true); // без метода = GET
  // Мутирующие с Origin:null (sandboxed-iframe CSRF) — блок.
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'null', 'POST'), HOST), false);
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'null', 'DELETE'), HOST), false);
  assert.equal(isLocalRequest(mk('127.0.0.1:8777', 'null', 'PATCH'), HOST), false);
});

test('isLocalRequest: без Host — блок', () => {
  assert.equal(isLocalRequest(mk(undefined), HOST), false);
});

// ── Свёрнутые папки профилей переживают перезапуск (оператор 02.09) ──────────
// Состояние жило в localStorage окна панели, а её профиль Chromium создаётся с
// pid в имени и удаляется при закрытии — пережить перезапуск оно не могло.
// Теперь источник правды — settings.json.
test('settings: свёрнутые папки сохраняются и чистятся при записи', () => {
  const fs = require('node:fs');
  const os = require('node:os');
  const path = require('node:path');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'arbi-settings-'));
  const prev = process.env.ARBI_DATA_DIR;
  process.env.ARBI_DATA_DIR = dir;
  delete require.cache[require.resolve('../../config')];
  delete require.cache[require.resolve('../settings')];
  const settings = require('../settings');
  try {
    assert.deepEqual(settings.read().collapsedFolders, [], 'по умолчанию все папки развёрнуты');
    const next = settings.write({ collapsedFolders: ['by-proxy', 'GATEIO', ''] });
    assert.deepEqual(next.collapsedFolders, ['by-proxy', 'GATEIO', ''], '«» — это «Без папки», тоже валидное имя');
    // Перечитывание с диска — то, ради чего всё затевалось.
    delete require.cache[require.resolve('../settings')];
    const reread = require('../settings').read();
    assert.deepEqual(reread.collapsedFolders, ['by-proxy', 'GATEIO', ''], 'состояние пережило перезапуск');
  } finally {
    if (prev === undefined) delete process.env.ARBI_DATA_DIR; else process.env.ARBI_DATA_DIR = prev;
    delete require.cache[require.resolve('../../config')];
    delete require.cache[require.resolve('../settings')];
    fs.rmSync(dir, { recursive: true, force: true });
  }
});

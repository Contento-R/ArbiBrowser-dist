'use strict';

/**
 * collect.js — браузерный сборщик фактических параметров.
 *
 * Функция collectFn() возвращает функцию, которую launcher выполняет ВНУТРИ
 * страницы через page.evaluate(). Она читает то, что реально видит сайт:
 * User-Agent, Client Hints, WebGL, Canvas-хэш, WebRTC-кандидаты, Intl locale/TZ,
 * geolocation. Никаких значений отсюда не «подкручивается» — это чистое снятие
 * наблюдаемого состояния для последующего сравнения с профилем.
 */

/** @returns {Function} функция для page.evaluate() */
function collectFn() {
  return async () => {
    const out = {};

    // ── User-Agent ──
    out.userAgent = navigator.userAgent;
    out.platform = navigator.platform;
    out.hardwareConcurrency = navigator.hardwareConcurrency;
    out.deviceMemory = navigator.deviceMemory;
    out.maxTouchPoints = navigator.maxTouchPoints;
    out.webdriver = navigator.webdriver;
    out.languages = navigator.languages;
    out.language = navigator.language;

    // ── Client Hints (высокоэнтропийные) ──
    try {
      if (navigator.userAgentData && navigator.userAgentData.getHighEntropyValues) {
        out.clientHints = await navigator.userAgentData.getHighEntropyValues([
          'platform', 'platformVersion', 'architecture', 'bitness', 'model',
          'uaFullVersion', 'fullVersionList', 'wow64',
        ]);
        out.clientHints.brands = navigator.userAgentData.brands;
        out.clientHints.mobile = navigator.userAgentData.mobile;
      } else {
        out.clientHints = null;
      }
    } catch (e) {
      out.clientHints = { error: String(e) };
    }

    // ── Screen ──
    out.screen = {
      width: screen.width,
      height: screen.height,
      availWidth: screen.availWidth,
      availHeight: screen.availHeight,
      colorDepth: screen.colorDepth,
      pixelDepth: screen.pixelDepth,
      devicePixelRatio: window.devicePixelRatio,
      innerWidth: window.innerWidth,
      innerHeight: window.innerHeight,
    };

    // ── WebGL ──
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (gl) {
        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
        out.webgl = {
          vendor: dbg ? gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL) : null,
          renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : null,
          glVendor: gl.getParameter(gl.VENDOR),
          glRenderer: gl.getParameter(gl.RENDERER),
        };
      } else {
        out.webgl = { error: 'WebGL недоступен' };
      }
    } catch (e) {
      out.webgl = { error: String(e) };
    }

    // ── Canvas (хэш отрисовки — стабильность отпечатка) ──
    try {
      const c = document.createElement('canvas');
      c.width = 240; c.height = 60;
      const ctx = c.getContext('2d');
      ctx.textBaseline = 'top';
      ctx.font = "16px 'Arial'";
      ctx.fillStyle = '#f60';
      ctx.fillRect(10, 10, 100, 30);
      ctx.fillStyle = '#069';
      ctx.fillText('ArbiBrowser 🅐 fingerprint', 12, 15);
      const data = c.toDataURL();
      // Простой хэш строки (не крипто — только для сравнения стабильности).
      let h = 0;
      for (let i = 0; i < data.length; i++) {
        h = (Math.imul(31, h) + data.charCodeAt(i)) | 0;
      }
      out.canvas = { hash: (h >>> 0).toString(16), length: data.length };
    } catch (e) {
      out.canvas = { error: String(e) };
    }

    // ── Intl locale / timezone ──
    try {
      const ro = Intl.DateTimeFormat().resolvedOptions();
      out.intl = { locale: ro.locale, timeZone: ro.timeZone };
      out.timezoneOffsetMin = new Date().getTimezoneOffset();
    } catch (e) {
      out.intl = { error: String(e) };
    }

    // ── WebRTC (утечка реального IP) ──
    // Правильный разбор ICE-кандидата: SDP-строка вида
    //   candidate:<foundation> <comp> <transport> <priority> <АДРЕС> <port> typ <type> ...
    // Адрес — 5-е поле. Современный Chrome прячет локальные IP через mDNS
    // (имя *.local), это НЕ утечка. Утечка — реальный публичный IP (обычно srflx).
    out.webrtc = await new Promise((resolve) => {
      const addrs = new Set();
      let mdnsCount = 0;
      let done = false;
      const finish = (extra) => {
        if (done) return; done = true;
        try { pc.close(); } catch (_) {}
        resolve(Object.assign({ candidateIps: Array.from(addrs), mdnsCount }, extra || {}));
      };
      let pc;
      try {
        pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
        pc.createDataChannel('x');
        pc.onicecandidate = (e) => {
          if (!e.candidate) return finish();
          const parts = String(e.candidate.candidate).split(' ');
          const addr = parts[4];
          const type = parts[7]; // host | srflx | prflx | relay
          if (!addr) return;
          if (/\.local$/i.test(addr)) { mdnsCount++; return; } // mDNS — обфусцировано, не утечка
          const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(addr) || addr.indexOf(':') >= 0;
          if (isIp) addrs.add(type ? `${addr} (${type})` : addr);
        };
        pc.createOffer().then((o) => pc.setLocalDescription(o)).catch(() => finish({ error: 'offer failed' }));
        setTimeout(() => finish({ timedOut: true }), 4000);
      } catch (e) {
        resolve({ error: String(e) });
      }
    });

    // ── Geolocation (не запрашиваем разрешение силой; отражаем наличие API) ──
    out.geolocationApi = typeof navigator.geolocation !== 'undefined';

    return out;
  };
}

module.exports = { collectFn };

'use strict';

/**
 * src/validation — проверка согласованности реального браузера с профилем.
 *
 * Запускает профиль (по умолчанию headless), снимает фактические параметры
 * (collect.js) прямо в странице, сверяет их с ожидаемыми (профиль + гео) и
 * формирует понятный отчёт по секциям с рекомендациями по устранению расхождений.
 */

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const config = require('../../config');
const launcher = require('../launcher');
const { collectFn } = require('./collect');

/**
 * Поднимает временную локальную страницу на 127.0.0.1. Это ВАЖНО: часть API
 * (navigator.userAgentData / Client Hints, а также SubtleCrypto и др.) доступна
 * только в «secure context». about:blank и data: — НЕ secure context, поэтому
 * userAgentData там отсутствует. localhost/127.0.0.1 считается доверенным origin,
 * что даёт корректную проверку Client Hints без выхода в интернет.
 */
function startLocalPage() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('<!doctype html><title>ArbiBrowser check</title><body>config check</body>');
    });
    server.listen(0, '127.0.0.1', () => {
      const url = `http://127.0.0.1:${server.address().port}/`;
      resolve({ url, close: () => new Promise((r) => server.close(r)) });
    });
  });
}

// ── Помощники сравнения ──

function mark(ok) {
  return ok === true ? 'OK' : ok === false ? 'FAIL' : 'WARN';
}

/** Одна проверка секции. */
function check(name, status, expected, actual, hint) {
  return { name, status, expected, actual, hint: status === true ? null : hint || null };
}

/**
 * Анализирует собранные данные против профиля.
 * @returns {{sections: object, summary: {ok:number, warn:number, fail:number}}}
 */
function analyze(profile, geo, data) {
  const sections = {};

  // ── User-Agent ──
  {
    const c = [];
    c.push(check('User-Agent', data.userAgent === profile.userAgent, profile.userAgent, data.userAgent,
      'UA страницы не совпал с профилем — проверьте применение Emulation.setUserAgentOverride.'));
    c.push(check('navigator.platform',
      data.platform === (profile.navigator && profile.navigator.platform),
      profile.navigator.platform, data.platform,
      'platform не применился — проверьте addInitScript.'));
    c.push(check('hardwareConcurrency',
      data.hardwareConcurrency === profile.navigator.hardwareConcurrency,
      profile.navigator.hardwareConcurrency, data.hardwareConcurrency));
    c.push(check('deviceMemory',
      data.deviceMemory === profile.navigator.deviceMemory,
      profile.navigator.deviceMemory, data.deviceMemory));
    c.push(check('webdriver', data.webdriver === false, false, data.webdriver,
      'navigator.webdriver=true выдаёт автоматизацию и противоречит остальному отпечатку.'));
    sections['User-Agent'] = c;
  }

  // ── Client Hints ──
  {
    const c = [];
    const ch = data.clientHints;
    const pch = profile.clientHints;
    if (!ch || ch.error) {
      c.push(check('Client Hints', false, 'присутствуют', ch && ch.error ? ch.error : 'отсутствуют',
        'userAgentData недоступен — Client Hints не применились.'));
    } else if (pch) {
      c.push(check('CH.platform', ch.platform === pch.platform, pch.platform, ch.platform,
        'Sec-CH-UA-Platform не совпал — проверьте userAgentMetadata в CDP.'));
      c.push(check('CH.platformVersion', ch.platformVersion === pch.platformVersion, pch.platformVersion, ch.platformVersion));
      c.push(check('CH.architecture', ch.architecture === pch.architecture, pch.architecture, ch.architecture));
      c.push(check('CH.mobile', ch.mobile === pch.mobile, pch.mobile, ch.mobile));
      // Сверка бренда Chrome с UA.
      const uaMajor = (profile.userAgent.match(/Chrome\/(\d+)/) || [])[1];
      const chBrand = (ch.brands || []).find((b) => /Chrome|Chromium/i.test(b.brand));
      c.push(check('CH.brand ↔ UA', !!chBrand && String(chBrand.version) === String(uaMajor),
        `Chrome ${uaMajor}`, chBrand ? `${chBrand.brand} ${chBrand.version}` : 'нет',
        'Версия бренда в Client Hints должна совпадать с версией Chrome в User-Agent.'));
    }
    sections['Client Hints'] = c;
  }

  // ── WebGL ──
  {
    const c = [];
    const w = data.webgl || {};
    const pw = profile.webgl || {};
    if (w.error) {
      c.push(check('WebGL', 'warn', pw.renderer || '(любой)', w.error, 'WebGL недоступен в этой среде (headless без GPU) — проверьте в headful.'));
    } else {
      c.push(check('WebGL vendor', pw.vendor ? w.vendor === pw.vendor : 'warn', pw.vendor || '(не задан)', w.vendor,
        'UNMASKED_VENDOR не совпал — проверьте патч getParameter в addInitScript.'));
      c.push(check('WebGL renderer', pw.renderer ? w.renderer === pw.renderer : 'warn', pw.renderer || '(не задан)', w.renderer,
        'UNMASKED_RENDERER не совпал — проверьте патч getParameter.'));
    }
    sections['WebGL'] = c;
  }

  // ── Canvas ──
  {
    const c = [];
    const cv = data.canvas || {};
    c.push(check('Canvas hash', cv.hash ? 'warn' : false, 'стабильный между запусками', cv.hash || cv.error,
      'Canvas-хэш стабилен для профиля (мы его не рандомизируем). Он должен совпадать при повторных запусках того же профиля.'));
    sections['Canvas'] = c;
  }

  // ── WebRTC ──
  {
    const c = [];
    const rtc = data.webrtc || {};
    const ips = rtc.candidateIps || []; // элементы вида "1.2.3.4 (srflx)"
    const ipOf = (s) => String(s).split(' ')[0];
    // Приватные адреса утечкой не считаем; mDNS (*.local) сюда вообще не попадают.
    const publicIps = ips.filter((s) => !/^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|127\.|169\.254\.|::1|fe80:|fc|fd)/i.test(ipOf(s)));
    const hasProxy = !!profile.proxy;
    const exitIp = geo && geo.ip;
    let status = true, hint = null;
    if (hasProxy) {
      const leaked = publicIps.filter((s) => ipOf(s) !== exitIp);
      if (leaked.length) {
        status = false;
        hint = 'WebRTC раскрывает публичный IP, отличный от выходного IP прокси — утечка реального адреса. Запускайте с прокси (мы добавляем --force-webrtc-ip-handling-policy=disable_non_proxied_udp), либо отключите WebRTC.';
      }
    }
    const actual = ips.length ? ips.join(', ') : (rtc.mdnsCount ? `нет утечки (mDNS-обфускация, ${rtc.mdnsCount} лок. кандидатов скрыто)` : 'нет кандидатов');
    c.push(check('WebRTC IPs', status, hasProxy ? `только ${exitIp || 'выходной IP'}` : 'нет утечки', actual, hint));
    sections['WebRTC'] = c;
  }

  // ── Locale ──
  {
    const c = [];
    c.push(check('navigator.language', data.language && profile.locale && data.language.toLowerCase() === profile.locale.toLowerCase(),
      profile.locale, data.language, 'Язык страницы не совпал с locale профиля.'));
    c.push(check('Intl.locale', data.intl && data.intl.locale && profile.locale && data.intl.locale.toLowerCase().startsWith(profile.locale.split('-')[0]),
      profile.locale, data.intl && data.intl.locale, 'Intl locale не согласован.'));
    if (geo && geo.countryCode && profile.locale) {
      const cc = profile.locale.split('-')[1];
      const matches = !cc || cc === geo.countryCode;
      c.push(check('locale ↔ страна IP', matches ? true : 'warn',
        `${geo.countryCode}`, profile.locale,
        `locale указывает на страну ${cc}, а выходной IP — в ${geo.countryCode}. Для совпадения задайте locale страны IP (или включите autoGeo).`));
    }
    sections['Locale'] = c;
  }

  // ── Timezone ──
  {
    const c = [];
    c.push(check('Intl.timeZone', data.intl && data.intl.timeZone === profile.timezone,
      profile.timezone, data.intl && data.intl.timeZone, 'timeZone страницы не совпал с профилем.'));
    if (geo && geo.timezone) {
      c.push(check('timezone ↔ IP', profile.timezone === geo.timezone,
        geo.timezone, profile.timezone,
        'Часовой пояс профиля не совпадает с TZ выходного IP — рассинхрон гео.'));
    }
    sections['Timezone'] = c;
  }

  // ── Географические параметры ──
  {
    const c = [];
    if (profile.geolocation && geo) {
      const dLat = Math.abs(profile.geolocation.latitude - geo.latitude);
      const dLon = Math.abs(profile.geolocation.longitude - geo.longitude);
      const near = dLat < 2 && dLon < 2;
      c.push(check('geolocation ↔ IP', near, `~${geo.latitude?.toFixed(2)},${geo.longitude?.toFixed(2)}`,
        `${profile.geolocation.latitude},${profile.geolocation.longitude}`,
        'Координаты geolocation далеки от гео выходного IP — Geolocation API выдаст другую страну, чем IP.'));
    } else {
      c.push(check('geolocation', 'warn', 'из гео IP', profile.geolocation ? 'задана' : 'не задана',
        'Геолокация не сопоставлена с IP (нет данных гео или не задана в профиле).'));
    }
    sections['Гео'] = c;
  }

  // Свод.
  let ok = 0, warn = 0, fail = 0;
  for (const arr of Object.values(sections)) {
    for (const it of arr) {
      if (it.status === true) ok++;
      else if (it.status === false) fail++;
      else warn++;
    }
  }
  return { sections, summary: { ok, warn, fail } };
}

/** Форматирует отчёт в текст. */
function formatReport(profileName, geo, report) {
  const lines = [];
  lines.push('═'.repeat(64));
  lines.push(`  ОТЧЁТ О ПРОВЕРКЕ КОНФИГУРАЦИИ — профиль "${profileName}"`);
  lines.push('═'.repeat(64));
  if (geo) lines.push(`  Выходной IP: ${geo.ip || '?'}  •  ${geo.city || '?'}, ${geo.country || '?'} (${geo.countryCode || '?'})  •  TZ ${geo.timezone || '?'}`);
  const s = report.summary;
  lines.push(`  Итог: OK=${s.ok}  WARN=${s.warn}  FAIL=${s.fail}`);
  lines.push('');

  for (const [section, items] of Object.entries(report.sections)) {
    lines.push(`── ${section} ${'─'.repeat(Math.max(0, 58 - section.length))}`);
    for (const it of items) {
      lines.push(`  [${mark(it.status).padEnd(4)}] ${it.name}`);
      if (it.status !== true) {
        lines.push(`         ожидалось: ${fmt(it.expected)}`);
        lines.push(`         получено : ${fmt(it.actual)}`);
        if (it.hint) lines.push(`         → ${it.hint}`);
      }
    }
    lines.push('');
  }

  // Рекомендации: собираем все hint'ы из FAIL.
  const recs = [];
  for (const items of Object.values(report.sections)) {
    for (const it of items) if (it.status === false && it.hint) recs.push(`• ${it.name}: ${it.hint}`);
  }
  if (recs.length) {
    lines.push('── РЕКОМЕНДАЦИИ ' + '─'.repeat(48));
    lines.push(...recs.map((r) => '  ' + r));
  } else {
    lines.push('  Явных несоответствий (FAIL) не найдено.');
  }
  lines.push('═'.repeat(64));
  return lines.join('\n');
}

function fmt(v) {
  if (v == null) return String(v);
  if (typeof v === 'object') return JSON.stringify(v);
  return String(v);
}

/**
 * Полный прогон проверки: запуск профиля, сбор, анализ, отчёт.
 * @param {string} profileName
 * @param {{headless?:boolean, save?:boolean, log?:(m:string)=>void}} [options]
 * @returns {Promise<{report:object, text:string, geo:object|null, savedTo:string|null}>}
 */
async function run(profileName, options = {}) {
  const log = options.log || (() => {});
  const headless = options.headless !== false; // по умолчанию headless
  const { context, profile, geo } = await launcher.launch(profileName, { headless, log });
  const local = await startLocalPage();
  try {
    const page = context.pages()[0] || (await context.newPage());
    // Собираем на secure-context странице (127.0.0.1), иначе navigator.userAgentData
    // (Client Hints) недоступен. Внешний интернет не требуется.
    await page.goto(local.url, { waitUntil: 'domcontentloaded', timeout: 15000 }).catch(() => {});
    log('Сбор фактических параметров...');
    const data = await page.evaluate(collectFn());
    const report = analyze(profile, geo, data);
    const text = formatReport(profileName, geo, report);

    let savedTo = null;
    if (options.save) {
      fs.mkdirSync(config.reportsDir, { recursive: true });
      savedTo = path.join(config.reportsDir, `${profileName}.report.txt`);
      fs.writeFileSync(savedTo, text, 'utf8');
      fs.writeFileSync(savedTo.replace(/\.txt$/, '.json'),
        JSON.stringify({ profileName, geo, ...report, raw: data }, null, 2), 'utf8');
    }
    return { report, text, geo, savedTo, raw: data };
  } finally {
    await context.close();
    await local.close();
  }
}

module.exports = { run, analyze, formatReport };

#!/usr/bin/env node
'use strict';

/**
 * fingerprint-viewer.js — визуальная проверка отпечатка профиля.
 *
 * Поднимает локальную secure-context страницу (127.0.0.1), запускает профиль,
 * открывает на нём эту страницу и делает скриншот того, что браузер сообщает о
 * себе сайту. Полезно, чтобы «глазами» убедиться в согласованности отпечатка.
 *
 * Использование:
 *   node scripts/fingerprint-viewer.js <profile> [--out путь.png] [--headful]
 *
 * По умолчанию headless + скриншот в data/reports/<profile>.fingerprint.png.
 * На локальной машине с дисплеем добавь --headful, чтобы увидеть живое окно.
 */

const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const config = require('../config');
const launcher = require('../src/launcher');

const VIEWER_HTML = `<!doctype html><html><head><meta charset=utf-8><title>Fingerprint Viewer</title>
<style>
  body{margin:0;background:#0b0d10;color:#c9d1d9;font:14px ui-monospace,Menlo,Consolas,monospace;padding:24px}
  h1{font-size:18px;color:#4f8cff;margin:0 0 4px}
  .sub{color:#6b7280;margin-bottom:20px}
  table{border-collapse:collapse;width:100%;max-width:900px}
  td{padding:7px 12px;border-bottom:1px solid #1c2128;vertical-align:top}
  td.k{color:#8b949e;width:230px} td.v{color:#3fb950;word-break:break-all}
</style></head><body>
<h1>ArbiBrowser — что видит сайт</h1><div class=sub id=host></div><table id=t></table>
<script>
function row(k,v){const tr=document.createElement('tr');tr.innerHTML='<td class=k></td><td class=v></td>';tr.children[0].textContent=k;tr.children[1].textContent=v;document.getElementById('t').appendChild(tr);}
(async()=>{
  document.getElementById('host').textContent='URL: '+location.href;
  row('User-Agent',navigator.userAgent);
  row('navigator.platform',navigator.platform);
  row('hardwareConcurrency',navigator.hardwareConcurrency);
  row('deviceMemory',navigator.deviceMemory+' GB');
  row('navigator.webdriver',String(navigator.webdriver));
  row('languages',navigator.languages.join(', '));
  row('screen',screen.width+'x'+screen.height+' avail '+screen.availWidth+'x'+screen.availHeight+' dpr '+window.devicePixelRatio);
  row('timezone',Intl.DateTimeFormat().resolvedOptions().timeZone);
  row('locale',Intl.DateTimeFormat().resolvedOptions().locale);
  try{const c=document.createElement('canvas');const gl=c.getContext('webgl');const d=gl.getExtension('WEBGL_debug_renderer_info');
    row('WebGL vendor',gl.getParameter(d.UNMASKED_VENDOR_WEBGL));row('WebGL renderer',gl.getParameter(d.UNMASKED_RENDERER_WEBGL));}catch(e){row('WebGL','n/a: '+e.message);}
  if(navigator.userAgentData){const h=await navigator.userAgentData.getHighEntropyValues(['platform','platformVersion','architecture','fullVersionList']);
    row('CH platform',h.platform+' '+h.platformVersion+' ('+h.architecture+')');
    row('CH brands',h.fullVersionList.map(b=>b.brand+' '+b.version).join(' | '));row('CH mobile',String(navigator.userAgentData.mobile));}
  else row('Client Hints','недоступны (не secure context)');
  document.title='READY';
})();
</script></body></html>`;

function startViewer() {
  return new Promise((resolve) => {
    const server = http.createServer((q, r) => {
      r.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      r.end(VIEWER_HTML);
    });
    server.listen(0, '127.0.0.1', () => {
      resolve({ url: `http://127.0.0.1:${server.address().port}/`, close: () => new Promise((x) => server.close(x)) });
    });
  });
}

async function main() {
  const argv = process.argv.slice(2);
  const name = argv.find((a) => !a.startsWith('--'));
  if (!name) {
    console.error('Использование: node scripts/fingerprint-viewer.js <profile> [--out путь.png] [--headful]');
    process.exit(1);
  }
  const headful = argv.includes('--headful');
  const outIdx = argv.indexOf('--out');
  const out = outIdx >= 0 ? argv[outIdx + 1] : path.join(config.reportsDir, `${name}.fingerprint.png`);

  const viewer = await startViewer();
  const { context } = await launcher.launch(name, { headless: !headful, log: (m) => console.log('· ' + m) });
  try {
    const page = context.pages()[0] || (await context.newPage());
    await page.goto(viewer.url, { waitUntil: 'networkidle', timeout: 15000 });
    await page.waitForFunction(() => document.title === 'READY', { timeout: 8000 }).catch(() => {});
    fs.mkdirSync(path.dirname(out), { recursive: true });
    await page.screenshot({ path: out, fullPage: true });
    console.log('Скриншот отпечатка: ' + out);
    if (headful) {
      console.log('Окно открыто. Закрой браузер, чтобы завершить.');
      await new Promise((r) => context.on('close', r));
    }
  } finally {
    if (!headful) await context.close();
    await viewer.close();
  }
}

main().catch((e) => { console.error('Ошибка:', e.message); process.exit(1); });

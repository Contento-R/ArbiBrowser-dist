﻿# update-now.ps1 — поставить обновление ArbiBrowser БЕЗ установщика.
#
# Зачем. Установщик .exe — это новый исполняемый файл, подписанный сертификатом,
# которому Windows не доверяет. Smart App Control блокирует его запуск, Kaspersky
# требует отключения. Обновлению всё это не нужно: меняется только код (~270 КБ),
# а Node и Chromium уже стоят. Скрипт качает архив кода, сверяет контрольную
# сумму и распаковывает поверх установленной программы. Ни одного .exe не
# запускается, поэтому ни Smart App Control, ни антивирус в этом не участвуют.
#
# Запуск (из обычного PowerShell, права администратора НЕ нужны):
#   powershell -ExecutionPolicy Bypass -File scripts\update-now.ps1
# Если ArbiBrowser стоит в нестандартном месте:
#   ... -File scripts\update-now.ps1 -AppDir "D:\ArbiBrowser"
#
# ⚠️ Перед запуском ЗАКРОЙТЕ ArbiBrowser и все его профили: под открытым профилем
# идёт сессия биржи, и подмена кода на ходу может оборвать исполнение заявки.

param(
  [string]$AppDir = "$env:LOCALAPPDATA\Programs\ArbiBrowser",
  [string]$ManifestUrl = 'https://raw.githubusercontent.com/Contento-R/ArbiBrowser-dist/main/latest.json'
)

$ErrorActionPreference = 'Stop'

if (-not (Test-Path (Join-Path $AppDir 'package.json'))) {
  throw "В '$AppDir' не найден package.json — это не папка ArbiBrowser. Укажите путь через -AppDir."
}

$installed = (Get-Content (Join-Path $AppDir 'package.json') -Raw | ConvertFrom-Json).version
Write-Host "Установлено: $installed"

$m = Invoke-RestMethod -Uri $ManifestUrl -TimeoutSec 30
$latest = ($m.version -replace '^v', '')
Write-Host "Доступно:   $latest"

if ([version]$latest -le [version]$installed) {
  Write-Host 'Обновление не требуется — у вас последняя версия.' -ForegroundColor Green
  exit 0
}

# Идёт ли ArbiBrowser прямо сейчас. Распаковка под работающей программой оставит
# половину старого кода в памяти и половину нового на диске.
if (Get-Process -Name node -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and $_.Path.StartsWith($AppDir, 'OrdinalIgnoreCase') }) {
  throw 'ArbiBrowser сейчас запущен. Закройте программу и профили, затем повторите.'
}

$tmp = Join-Path $env:TEMP $m.name
Write-Host "Качаю $($m.name) ..."
Invoke-WebRequest -Uri $m.url -OutFile $tmp -TimeoutSec 300

# Контрольная сумма — защита от повреждённой закачки и от подмены архива.
$got = (Get-FileHash $tmp -Algorithm SHA256).Hash.ToLower()
if ($got -ne $m.sha256.ToLower()) {
  Remove-Item $tmp -Force -ErrorAction SilentlyContinue
  throw "Контрольная сумма не совпала (ожидали $($m.sha256), получили $got) — файл повреждён или подменён."
}

# tar есть в Windows 10 1803+ штатно. Распаковка своим кодом, а не проводником:
# так распакованные файлы не получают метку «скачано из интернета».
Write-Host "Распаковываю в $AppDir ..."
& tar.exe -xzf $tmp -C $AppDir
if ($LASTEXITCODE -ne 0) { throw "Распаковка не удалась (tar вернул $LASTEXITCODE)." }

Remove-Item $tmp -Force -ErrorAction SilentlyContinue
Write-Host "Готово: $installed → $latest. Запускайте ArbiBrowser." -ForegroundColor Green

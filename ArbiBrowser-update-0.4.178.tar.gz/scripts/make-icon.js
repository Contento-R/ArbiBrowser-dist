#!/usr/bin/env node
'use strict';

/**
 * make-icon.js — собирает брендовую иконку ArbiBrowser: наша панда (assets/panda.png)
 * с маленьким значком Google Chrome в правом нижнем углу.
 *
 * Только встроенные модули Node (zlib) — без внешних зависимостей и без
 * ImageMagick. Декодирует базовый PNG (RGBA/8-бит), рисует бейдж Chrome с
 * суперсэмплингом, кодирует результат обратно в PNG и заворачивает несколько
 * уменьшенных копий в многоразмерный .ico.
 *
 * Выход:
 *   assets/arbibrowser.png   256×256 — фавикон панели
 *   assets/arbibrowser.ico   256/128/64/32/16 — ярлыки установщика
 *
 * Запуск: node scripts/make-icon.js
 */

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'assets', 'panda.png');
const OUT_PNG = path.join(ROOT, 'assets', 'arbibrowser.png');
const OUT_ICO = path.join(ROOT, 'assets', 'arbibrowser.ico');

// ── CRC32 (для чанков PNG) ──
const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

// ── Декодер PNG: только 8-бит RGBA (color type 6), без интерлейса ──
function decodePng(buf) {
  const sig = [137, 80, 78, 71, 13, 10, 26, 10];
  for (let i = 0; i < 8; i++) if (buf[i] !== sig[i]) throw new Error('не PNG');
  let off = 8;
  let width, height, colorType, bitDepth;
  const idat = [];
  while (off < buf.length) {
    const len = buf.readUInt32BE(off);
    const type = buf.toString('latin1', off + 4, off + 8);
    const data = buf.slice(off + 8, off + 8 + len);
    if (type === 'IHDR') {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      bitDepth = data[8];
      colorType = data[9];
    } else if (type === 'IDAT') {
      idat.push(data);
    } else if (type === 'IEND') {
      break;
    }
    off += 12 + len;
  }
  if (bitDepth !== 8 || colorType !== 6) {
    throw new Error(`ожидался 8-бит RGBA PNG, получено bitDepth=${bitDepth} colorType=${colorType}`);
  }
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const stride = width * 4;
  const out = Buffer.alloc(width * height * 4);
  let prev = Buffer.alloc(stride);
  let p = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[p++];
    const line = raw.slice(p, p + stride);
    p += stride;
    const cur = Buffer.alloc(stride);
    for (let x = 0; x < stride; x++) {
      const a = x >= 4 ? cur[x - 4] : 0;      // left
      const b = prev[x];                        // up
      const c = x >= 4 ? prev[x - 4] : 0;       // up-left
      let v = line[x];
      if (filter === 1) v += a;
      else if (filter === 2) v += b;
      else if (filter === 3) v += (a + b) >> 1;
      else if (filter === 4) {
        const pp = a + b - c;
        const pa = Math.abs(pp - a), pb = Math.abs(pp - b), pc = Math.abs(pp - c);
        v += pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
      }
      cur[x] = v & 0xff;
    }
    cur.copy(out, y * stride);
    prev = cur;
  }
  return { width, height, data: out };
}

// ── Кодер PNG (8-бит RGBA, фильтр 0) ──
function encodePng(width, height, data) {
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter none
    data.copy(raw, y * (stride + 1) + 1, y * stride, y * stride + stride);
  }
  const idat = zlib.deflateSync(raw, { level: 9 });

  function chunk(type, body) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(body.length, 0);
    const typeBuf = Buffer.from(type, 'latin1');
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, body])), 0);
    return Buffer.concat([len, typeBuf, body, crcBuf]);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;   // bit depth
  ihdr[9] = 6;   // color type RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', idat),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

// ── Рисуем бейдж Chrome поверх панды ──
function drawChromeBadge(img) {
  const { width: W, height: H, data } = img;
  // Центр бейджа — правый нижний угол.
  const cx = W * 0.71, cy = H * 0.71;
  const rOuter = W * 0.265;     // внешний радиус цветного кольца
  const rWhite = rOuter + W * 0.018; // белая окантовка для отрыва от фона
  const rBlue = W * 0.115;      // синий центр
  const rBlueRing = rBlue + W * 0.022; // белое кольцо вокруг синего

  const RED = [234, 67, 53], GREEN = [52, 168, 83], YELLOW = [251, 188, 5],
        BLUE = [66, 133, 244], WHITE = [255, 255, 255];

  const SS = 3; // суперсэмплинг 3×3
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let r = 0, g = 0, b = 0, cov = 0; // накопитель цвета бейджа + покрытие
      for (let sy = 0; sy < SS; sy++) {
        for (let sx = 0; sx < SS; sx++) {
          const px = x + (sx + 0.5) / SS - 0.5;
          const py = y + (sy + 0.5) / SS - 0.5;
          const dx = px - cx, dy = py - cy;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist > rWhite) continue;
          let col;
          if (dist > rOuter) col = WHITE;                 // внешняя окантовка
          else if (dist <= rBlue) col = BLUE;             // синий центр
          else if (dist <= rBlueRing) col = WHITE;        // кольцо вокруг синего
          else {
            // Цветное кольцо, три сектора по 120°.
            let ang = Math.atan2(dy, dx) * 180 / Math.PI; // -180..180, y вниз
            if (ang < 0) ang += 360;
            if (ang >= 210 && ang < 330) col = RED;        // верх
            else if (ang >= 90 && ang < 210) col = GREEN;  // низ-лево
            else col = YELLOW;                             // низ-право
          }
          r += col[0]; g += col[1]; b += col[2]; cov++;
        }
      }
      const total = SS * SS;
      const alpha = cov / total;
      if (alpha <= 0) continue;
      r /= cov; g /= cov; b /= cov;
      const idx = (y * W + x) * 4;
      // Композит «бейдж (непрозрачный) over панда» с покрытием alpha.
      data[idx]     = Math.round(r * alpha + data[idx] * (1 - alpha));
      data[idx + 1] = Math.round(g * alpha + data[idx + 1] * (1 - alpha));
      data[idx + 2] = Math.round(b * alpha + data[idx + 2] * (1 - alpha));
      data[idx + 3] = Math.max(data[idx + 3], Math.round(255 * alpha));
    }
  }
  return img;
}

// ── Уменьшение box-фильтром (с учётом альфы) ──
function downscale(img, n) {
  const { width: W, data } = img;
  const ratio = W / n;
  if (!Number.isInteger(ratio)) throw new Error(`неверный размер ${n}`);
  const out = Buffer.alloc(n * n * 4);
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      let rs = 0, gs = 0, bs = 0, as = 0;
      for (let yy = 0; yy < ratio; yy++) {
        for (let xx = 0; xx < ratio; xx++) {
          const idx = ((y * ratio + yy) * W + (x * ratio + xx)) * 4;
          const a = data[idx + 3];
          rs += data[idx] * a; gs += data[idx + 1] * a; bs += data[idx + 2] * a;
          as += a;
        }
      }
      const oidx = (y * n + x) * 4;
      if (as > 0) {
        out[oidx] = Math.round(rs / as);
        out[oidx + 1] = Math.round(gs / as);
        out[oidx + 2] = Math.round(bs / as);
      }
      out[oidx + 3] = Math.round(as / (ratio * ratio));
    }
  }
  return { width: n, height: n, data: out };
}

// ── Сборка .ico из набора PNG-кадров ──
function buildIco(pngs) {
  const count = pngs.length;
  const header = Buffer.alloc(6);
  header.writeUInt16LE(0, 0);     // reserved
  header.writeUInt16LE(1, 2);     // type = icon
  header.writeUInt16LE(count, 4);
  const dir = Buffer.alloc(16 * count);
  let offset = 6 + 16 * count;
  pngs.forEach((e, i) => {
    const o = i * 16;
    dir[o] = e.size >= 256 ? 0 : e.size;     // width (0 = 256)
    dir[o + 1] = e.size >= 256 ? 0 : e.size; // height
    dir[o + 2] = 0;  // palette
    dir[o + 3] = 0;  // reserved
    dir.writeUInt16LE(1, o + 4);   // planes
    dir.writeUInt16LE(32, o + 6);  // bpp
    dir.writeUInt32LE(e.png.length, o + 8);
    dir.writeUInt32LE(offset, o + 12);
    offset += e.png.length;
  });
  return Buffer.concat([header, dir, ...pngs.map((e) => e.png)]);
}

function main() {
  const base = decodePng(fs.readFileSync(SRC));
  if (base.width !== 256 || base.height !== 256) {
    console.warn(`база ${base.width}×${base.height}, ожидалось 256×256 — продолжаю`);
  }
  drawChromeBadge(base);

  const png256 = encodePng(base.width, base.height, base.data);
  fs.writeFileSync(OUT_PNG, png256);
  console.log(`PNG: ${OUT_PNG} (${png256.length} байт)`);

  const sizes = [256, 128, 64, 32, 16];
  const frames = sizes.map((s) => {
    const im = s === base.width ? base : downscale(base, s);
    return { size: s, png: encodePng(im.width, im.height, im.data) };
  });
  const ico = buildIco(frames);
  fs.writeFileSync(OUT_ICO, ico);
  console.log(`ICO: ${OUT_ICO} (${ico.length} байт, размеры ${sizes.join('/')})`);
}

if (require.main === module) main();

module.exports = { decodePng, encodePng, buildIco };

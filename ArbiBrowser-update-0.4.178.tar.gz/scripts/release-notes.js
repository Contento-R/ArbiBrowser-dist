'use strict';

/**
 * release-notes.js — печатает описание релиза ПОНЯТНЫМ языком (markdown) из
 * единого списка изменений src/changelog.js. Используется GitHub Action при
 * публикации релиза: тело релиза = записи для версии из package.json.
 *
 * Запуск:
 *   node scripts/release-notes.js            → записи для версии из package.json
 *   node scripts/release-notes.js 0.4.20     → записи для указанной версии
 *
 * Если для версии записей нет — печатает короткую заглушку (релиз всё равно
 * опубликуется, просто без подробного описания).
 */

const { CHANGELOG } = require('../src/changelog');
const pkg = require('../package.json');

const KIND = {
  speed: '⚡ Быстрее',
  visual: '✨ Новое',
  security: '🔒 Надёжность',
  fix: '🔧 Исправление',
};

/** "1.2.3" → [1,2,3]; сравнение semver. */
function cmp(a, b) {
  const pa = String(a).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).replace(/^v/i, '').split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

function build(version) {
  const v = String(version || pkg.version).replace(/^v/i, '');
  // ТОЛЬКО записи ЭТОЙ версии — тело релиза не должно превращаться в простыню всей
  // истории. Раньше брали «всё с прошлого тега», но на CI-раннере git-тегов нет
  // (checkout тянет один тег) → prevReleased=null → в тело попадал весь changelog.
  const entries = CHANGELOG.filter((e) => cmp(e.version, v) === 0);
  const lines = [`## ArbiBrowser v${v}`, ''];
  if (!entries.length) {
    lines.push('Обновление ArbiBrowser. Подробности — в списке изменений внутри программы (кнопка «✨ Что нового?»).');
  } else {
    lines.push('Что изменилось в этой версии:', '');
    for (const e of entries) {
      lines.push(`### ${KIND[e.kind] || '✨ Новое'} — ${e.title}`);
      lines.push('', e.body, '');
    }
  }
  lines.push('---', 'Установщик для Windows — файл `ArbiBrowser-Setup.exe` ниже. Уже установленная программа предложит обновиться сама.');
  return lines.join('\n');
}

if (require.main === module) {
  process.stdout.write(build(process.argv[2]));
}

module.exports = { build };

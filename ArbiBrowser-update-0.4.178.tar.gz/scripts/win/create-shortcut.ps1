﻿# create-shortcut.ps1 - creates a Desktop shortcut "ArbiBrowser" with the panda icon.
#
# Run once, from the project folder:
#   powershell -ExecutionPolicy Bypass -File scripts\win\create-shortcut.ps1
#
# The shortcut launches ArbiBrowser.vbs (control panel, no console window)
# and uses the icon assets\panda.ico. ASCII-only on purpose (avoids PS 5.1
# ANSI/codepage parsing issues with non-Latin characters).

$ErrorActionPreference = 'Stop'

# Repo root = two levels above this script (scripts\win\..\..)
$repo = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

$vbs = Join-Path $repo 'ArbiBrowser.vbs'
$ico = Join-Path $repo 'assets\panda.ico'
if (-not (Test-Path $vbs)) { throw "Not found: $vbs" }
if (-not (Test-Path $ico)) { throw "Icon not found: $ico" }

$ws = New-Object -ComObject WScript.Shell

function New-ArbiShortcut($lnkPath) {
  $lnk = $ws.CreateShortcut($lnkPath)
  $lnk.TargetPath = $vbs
  $lnk.WorkingDirectory = $repo
  $lnk.IconLocation = "$ico,0"
  $lnk.Description = 'ArbiBrowser - private antidetect browser'
  $lnk.WindowStyle = 1
  $lnk.Save()
}

# 1) Ярлык на рабочем столе.
$desktop = [Environment]::GetFolderPath('Desktop')
$desktopLnk = Join-Path $desktop 'ArbiBrowser.lnk'
New-ArbiShortcut $desktopLnk

# 2) Ярлык в меню Пуск — ЗАКРЕПЛЯЙТЕ НА ПАНЕЛИ ИМЕННО ЕГО (identity ярлыка,
#    а не запущенного окна Chrome for Testing).
$startDir = Join-Path ([Environment]::GetFolderPath('Programs')) 'ArbiBrowser'
if (-not (Test-Path $startDir)) { New-Item -ItemType Directory -Path $startDir | Out-Null }
$startLnk = Join-Path $startDir 'ArbiBrowser.lnk'
New-ArbiShortcut $startLnk

Write-Host "Done."
Write-Host "  Desktop:    $desktopLnk"
Write-Host "  Start Menu: $startLnk"
Write-Host "  Icon:       $ico"
Write-Host ""
Write-Host "HOW TO PIN (important):"
Write-Host "  Open Start, find 'ArbiBrowser', right-click -> Pin to taskbar."
Write-Host "  Pin the SHORTCUT, NOT the running window."
Write-Host "  If a 'Chrome for Testing' button appears while the panel is open,"
Write-Host "  that is the panel window itself - do NOT pin that one."

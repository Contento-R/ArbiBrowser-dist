#!/usr/bin/env node
'use strict';

/**
 * fetch-extensions.js — скачивает и распаковывает расширения из Chrome Web Store
 * в каталог extensions/<name>/, откуда launcher грузит их во все профили (headful).
 *
 * Только встроенные модули Node (https, zlib, fs) — без внешних зависимостей.
 * Скачивает .crx, снимает CRX2/CRX3-заголовок, распаковывает ZIP (по центральному
 * каталогу) через zlib.inflateRawSync.
 *
 * Запуск (на машине с доступом в интернет):
 *   node scripts/fetch-extensions.js
 *
 * Список расширений задан ниже в EXTENSIONS. По умолчанию:
 *   • uBlock Origin        (cjpalhdlnbpafiamejdnhcphjbkeiagm)
 *   • Proxy Switcher/Omega (onnfghpihccifgojkpnnncpagjcdbjod)
 */

const https = require('node:https');
const http = require('node:http');
const zlib = require('node:zlib');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../config');

// uBlock Origin (MV2) больше НЕ грузится в свежем Chromium (manifest v2 удалён) —
// используем uBlock Origin Lite (MV3). Proxy Switcher уже MV3.
// uBlock Origin Lite грузится (виден в браузере, пользователь может включить фильтрацию),
// но по умолчанию ПЕРЕКЛЮЧЕН в режим «No filtering» — patchUbolDefaultNone ниже. Иначе он
// режет сенсор-скрипт Akamai на MEXC → залогиненная сессия «Access Denied» (2026-07-14).
const EXTENSIONS = [
  { name: 'ublock-origin-lite', id: 'ddkjiahejlhfcafbddmgiahcphecmpfh', ubolDefaultNone: true },
  // proxy-switcher (onnfghpihccifgojkpnnncpagjcdbjod) больше не ставим: его настройка
  // перекрывала прокси профиля (2026-09-12, ERR_MANDATORY_PROXY_CONFIGURATION_FAILED).
];

// Старые каталоги, которые надо удалить перед установкой (напр. несовместимый MV2-uBlock).
const OBSOLETE = ['ublock-origin', 'proxy-switcher'];

// Версия Chrome для запроса CRX. Слишком СТАРАЯ версия → Google отдаёт HTTP 204
// (нет совместимого билда, напр. uBlock Lite требует свежий Chrome). Берём
// реальную версию установленного Chromium; если не вышло — высокий дефолт.
function detectProdVersion() {
  if (process.env.ARBI_CHROME_VERSION) return process.env.ARBI_CHROME_VERSION;
  try {
    const { chromium } = require('playwright');
    let exe;
    try { exe = require('../src/settings').effectiveChromiumPath(); } catch { exe = null; }
    exe = exe || chromium.executablePath();
    const out = require('node:child_process').execFileSync(exe, ['--version'], { timeout: 5000 }).toString();
    const m = out.match(/(\d+)\.\d+\.\d+/);
    if (m) return `${m[1]}.0`;
  } catch { /* Windows-Chrome может не печатать --version — используем дефолт */ }
  return '141.0';
}
const PRODVERSION = detectProdVersion();

function crxUrl(id) {
  return (
    'https://clients2.google.com/service/update2/crx?response=redirect' +
    `&acceptformat=crx2,crx3&prodversion=${PRODVERSION}` +
    `&x=id%3D${id}%26installsource%3Dondemand%26uc`
  );
}

/** GET с автоследованием редиректам, возвращает Buffer. */
function getBuffer(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 8) return reject(new Error('слишком много редиректов'));
    const lib = url.startsWith('https:') ? https : http;
    lib.get(url, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        const next = new URL(res.headers.location, url).toString();
        return resolve(getBuffer(next, redirects + 1));
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode} для ${url}`));
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve(Buffer.concat(chunks)));
    }).on('error', reject);
  });
}

/** Снимает CRX2/CRX3-заголовок, возвращает ZIP-буфер. */
function crxToZip(buf) {
  if (buf.slice(0, 4).toString('latin1') !== 'Cr24') {
    // Уже zip? (некоторые зеркала отдают zip напрямую)
    if (buf.slice(0, 2).toString('latin1') === 'PK') return buf;
    throw new Error('не CRX и не ZIP');
  }
  const version = buf.readUInt32LE(4);
  if (version === 3) {
    const headerLen = buf.readUInt32LE(8);
    return buf.slice(12 + headerLen);
  }
  if (version === 2) {
    const pubKeyLen = buf.readUInt32LE(8);
    const sigLen = buf.readUInt32LE(12);
    return buf.slice(16 + pubKeyLen + sigLen);
  }
  throw new Error(`неизвестная версия CRX: ${version}`);
}

/** Распаковка ZIP по центральному каталогу (надёжно к data descriptor). */
function unzip(zip, destDir) {
  // Найти End Of Central Directory (сигнатура PK\x05\x06), сканируя с конца.
  const EOCD = 0x06054b50;
  let eocd = -1;
  for (let i = zip.length - 22; i >= 0 && i >= zip.length - 22 - 65536; i--) {
    if (zip.readUInt32LE(i) === EOCD) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('ZIP: не найден EOCD');
  const count = zip.readUInt16LE(eocd + 10);
  let off = zip.readUInt32LE(eocd + 16); // смещение центрального каталога

  let written = 0;
  for (let n = 0; n < count; n++) {
    if (zip.readUInt32LE(off) !== 0x02014b50) throw new Error('ZIP: битый central header');
    const method = zip.readUInt16LE(off + 10);
    const compSize = zip.readUInt32LE(off + 20);
    const nameLen = zip.readUInt16LE(off + 28);
    const extraLen = zip.readUInt16LE(off + 30);
    const commentLen = zip.readUInt16LE(off + 32);
    const localOff = zip.readUInt32LE(off + 42);
    const name = zip.slice(off + 46, off + 46 + nameLen).toString('utf8');
    off += 46 + nameLen + extraLen + commentLen;

    // Локальный заголовок: 30 байт + имя + extra.
    const lNameLen = zip.readUInt16LE(localOff + 26);
    const lExtraLen = zip.readUInt16LE(localOff + 28);
    const dataStart = localOff + 30 + lNameLen + lExtraLen;
    const comp = zip.slice(dataStart, dataStart + compSize);

    const outPath = path.join(destDir, name);
    if (name.endsWith('/')) { fs.mkdirSync(outPath, { recursive: true }); continue; }
    fs.mkdirSync(path.dirname(outPath), { recursive: true });
    const data = method === 0 ? comp : zlib.inflateRawSync(comp);
    fs.writeFileSync(outPath, data);
    written++;
  }
  return written;
}

/**
 * Переключить ДЕФОЛТНЫЙ режим uBlock Origin Lite на «No filtering» (MODE_NONE=0), чтобы он
 * НИЧЕГО не блокировал по умолчанию (иначе режет сенсор Akamai на MEXC → «Access Denied»).
 * uBO при этом загружен и виден — пользователь может включить фильтрацию через попап uBO.
 * Патчим два места в исходниках uBOL:
 *   • js/mode-manager.js: defaultFilteringModes optimal:['all-urls'] → none:['all-urls'];
 *   • js/background.js: первый запуск без широких прав ставил MODE_BASIC → ставим 0 (none).
 * Возвращает true, если КЛЮЧЕВОЙ патч (mode-manager) применён. false → вызывающий НЕ
 * поставит uBO в блокирующем состоянии (безопаснее, чем сломать MEXC).
 */
function patchUbolDefaultNone(dest) {
  const mm = path.join(dest, 'js', 'mode-manager.js');
  let coreOk = false;
  try {
    let s = fs.readFileSync(mm, 'utf8');
    const re = /export const defaultFilteringModes = \{[\s\S]*?\};/;
    if (re.test(s)) {
      s = s.replace(re, "export const defaultFilteringModes = {\n    none: [ 'all-urls' ],\n    basic: [],\n    optimal: [],\n    complete: [],\n};");
      fs.writeFileSync(mm, s);
      coreOk = true;
      console.log('  [uBO] дефолтный режим фильтрации → No filtering (mode-manager)');
    } else {
      console.warn('  [uBO] defaultFilteringModes не найден — вёрстка uBOL изменилась');
    }
  } catch (e) { console.warn(`  [uBO] mode-manager: ${e.message}`); }
  // Дополнительно (best-effort): первый запуск без широких прав тоже не ставит BASIC.
  const bg = path.join(dest, 'js', 'background.js');
  try {
    let s = fs.readFileSync(bg, 'utf8');
    if (s.includes('setDefaultFilteringMode(MODE_BASIC)')) {
      s = s.split('setDefaultFilteringMode(MODE_BASIC)').join('setDefaultFilteringMode(0)')
        .split('afterLevel === MODE_BASIC').join('afterLevel === 0');
      fs.writeFileSync(bg, s);
      console.log('  [uBO] первый запуск → No filtering (background)');
    }
  } catch (e) { console.warn(`  [uBO] background: ${e.message}`); }
  return coreOk;
}

async function fetchOne(ext) {
  const dest = path.join(config.extensionsDir, ext.name);
  console.log(`\n[${ext.name}] загрузка ${ext.id}...`);
  const crx = await getBuffer(crxUrl(ext.id));
  console.log(`[${ext.name}] получено ${crx.length} байт, распаковка...`);
  const zip = crxToZip(crx);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.mkdirSync(dest, { recursive: true });
  const n = unzip(zip, dest);
  if (!fs.existsSync(path.join(dest, 'manifest.json'))) {
    throw new Error('после распаковки нет manifest.json');
  }
  // uBO: пропатчить дефолт на No filtering. Если ключевой патч не лёг (uBOL сменил
  // вёрстку) — НЕ ставим uBO, чтобы он не сломал MEXC в блокирующем режиме.
  if (ext.ubolDefaultNone && !patchUbolDefaultNone(dest)) {
    fs.rmSync(dest, { recursive: true, force: true });
    throw new Error('не удалось перевести uBO в No filtering — расширение не установлено (защита от блокировки MEXC)');
  }
  console.log(`[${ext.name}] готово: ${n} файлов → ${dest}`);
}

async function main() {
  fs.mkdirSync(config.extensionsDir, { recursive: true });
  // Удаляем устаревшие расширения (напр. несовместимый MV2-uBlock), иначе
  // Chromium покажет блокирующее окно ошибки при запуске профиля.
  for (const name of OBSOLETE) {
    const dir = path.join(config.extensionsDir, name);
    if (fs.existsSync(dir)) { fs.rmSync(dir, { recursive: true, force: true }); console.log(`Удалён устаревший: ${name}`); }
  }
  let ok = 0;
  for (const ext of EXTENSIONS) {
    try { await fetchOne(ext); ok++; }
    catch (e) { console.error(`[${ext.name}] ОШИБКА: ${e.message}`); }
  }
  console.log(`\nГотово: ${ok}/${EXTENSIONS.length} расширений. Запусти профиль в headful — они загрузятся автоматически.`);
}

if (require.main === module) main().catch((e) => { console.error(e); process.exit(1); });

module.exports = { crxToZip, unzip, crxUrl };

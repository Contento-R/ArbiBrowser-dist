#!/usr/bin/env bash
set -euo pipefail
#
# 00-setup-depot-tools.sh — установка depot_tools (Модуль 7, этап 1).
#
# ЧЕРНОВИК: не запускать вслепую. Скрипт готовит инструментарий Google для
# сборки Chromium (gclient, gn, autoninja). Требует ~несколько ГБ и доступа в сеть.
#
# После установки depot_tools должен быть в PATH во ВСЕХ последующих скриптах.

# ─── Параметры ───
CHROMIUM_ROOT="${CHROMIUM_ROOT:-$HOME/chromium}"        # корень воркспейса Chromium
DEPOT_TOOLS_DIR="${DEPOT_TOOLS_DIR:-$CHROMIUM_ROOT/depot_tools}"

# ─── Проверка зависимостей ───
for bin in git python3 curl; do
  command -v "$bin" >/dev/null 2>&1 || { echo "Нет обязательной зависимости: $bin"; exit 1; }
done

echo "==> Корень Chromium: $CHROMIUM_ROOT"
mkdir -p "$CHROMIUM_ROOT"

# ─── Клонирование depot_tools ───
if [ -d "$DEPOT_TOOLS_DIR/.git" ]; then
  echo "==> depot_tools уже есть, обновляю..."
  git -C "$DEPOT_TOOLS_DIR" pull --ff-only
else
  echo "==> Клонирую depot_tools..."
  git clone https://chromium.googlesource.com/chromium/tools/depot_tools.git "$DEPOT_TOOLS_DIR"
fi

# ─── PATH ───
export PATH="$DEPOT_TOOLS_DIR:$PATH"
echo "==> depot_tools в PATH: $DEPOT_TOOLS_DIR"
echo ""
echo "Добавь в свой профиль (bashrc/zshrc):"
echo "    export PATH=\"$DEPOT_TOOLS_DIR:\$PATH\""
echo ""
echo "Проверка: $(command -v gclient || echo 'gclient пока не в PATH текущей сессии')"
echo "Готово. Далее: 01-fetch-chromium.sh"

#!/usr/bin/env bash
set -euo pipefail
#
# 02-gn-args.sh — конфигурация сборки через gn (Модуль 7, этап 3).
#
# ЧЕРНОВИК: не запускать вслепую. Генерирует out/ArbiBrowser/ с args.gn.
#
# Требует уже полученных исходников (01-fetch-chromium.sh).

CHROMIUM_ROOT="${CHROMIUM_ROOT:-$HOME/chromium}"
DEPOT_TOOLS_DIR="${DEPOT_TOOLS_DIR:-$CHROMIUM_ROOT/depot_tools}"
SRC_DIR="$CHROMIUM_ROOT/src"
OUT_DIR="${OUT_DIR:-out/ArbiBrowser}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

export PATH="$DEPOT_TOOLS_DIR:$PATH"
[ -d "$SRC_DIR" ] || { echo "Нет исходников: $SRC_DIR — сначала 01-fetch-chromium.sh"; exit 1; }
command -v gn >/dev/null 2>&1 || { echo "нет gn (depot_tools не в PATH?)"; exit 1; }

cd "$SRC_DIR"
mkdir -p "$OUT_DIR"

# ─── Кладём args.gn из примера ───
if [ ! -f "$OUT_DIR/args.gn" ]; then
  echo "==> Копирую args.gn из примера..."
  cp "$SCRIPT_DIR/args.gn.example" "$OUT_DIR/args.gn"
else
  echo "==> args.gn уже есть, оставляю как есть: $OUT_DIR/args.gn"
fi

echo "==> Текущий args.gn:"
sed 's/^/    /' "$OUT_DIR/args.gn"

# ─── Генерация build-файлов ───
echo "==> gn gen $OUT_DIR ..."
gn gen "$OUT_DIR"

echo "Готово. Проверь: gn args $OUT_DIR --list --short"
echo "Далее: 03-build.sh"

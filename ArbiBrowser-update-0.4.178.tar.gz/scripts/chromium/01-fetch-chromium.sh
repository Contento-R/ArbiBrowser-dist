#!/usr/bin/env bash
set -euo pipefail
#
# 01-fetch-chromium.sh — получение исходников Chromium (Модуль 7, этап 2).
#
# ЧЕРНОВИК: не запускать вслепую. Скачивает ДЕСЯТКИ ГБ (полный чекаут ~100+ ГБ
# с историей). Занимает от десятков минут до часов в зависимости от сети/диска.
#
# По умолчанию закрепляемся на конкретном релизном теге для воспроизводимости.

# ─── Параметры ───
CHROMIUM_ROOT="${CHROMIUM_ROOT:-$HOME/chromium}"
DEPOT_TOOLS_DIR="${DEPOT_TOOLS_DIR:-$CHROMIUM_ROOT/depot_tools}"
SRC_DIR="$CHROMIUM_ROOT/src"
# Тег/ветка релиза Chromium (пример; синхронизируй с целевой версией отпечатков).
CHROMIUM_REF="${CHROMIUM_REF:-141.0.7390.65}"

export PATH="$DEPOT_TOOLS_DIR:$PATH"
command -v fetch  >/dev/null 2>&1 || { echo "depot_tools не в PATH — сначала 00-setup-depot-tools.sh"; exit 1; }
command -v gclient >/dev/null 2>&1 || { echo "нет gclient"; exit 1; }

echo "==> Корень: $CHROMIUM_ROOT ; целевой ref: $CHROMIUM_REF"
cd "$CHROMIUM_ROOT"

# ─── Первичный fetch (без hooks, чтобы быстрее и контролируемо) ───
if [ ! -d "$SRC_DIR/.git" ]; then
  echo "==> fetch --nohooks chromium (долго)..."
  fetch --nohooks chromium
else
  echo "==> src уже есть, пропускаю fetch."
fi

cd "$SRC_DIR"

# ─── Закрепление на релизном теге ───
echo "==> Переключаюсь на тег $CHROMIUM_REF..."
git fetch --tags --depth 1 origin "refs/tags/$CHROMIUM_REF" || git fetch --tags
git checkout "$CHROMIUM_REF"

# ─── Синхронизация зависимостей под этот ref ───
echo "==> gclient sync (под тег)..."
gclient sync --with_branch_heads --with_tags -D

# ─── Хуки (генерация build-файлов, скачивание бинарных зависимостей) ───
echo "==> gclient runhooks..."
gclient runhooks

echo "Готово. Далее: 02-gn-args.sh"

#!/usr/bin/env bash
set -euo pipefail
#
# 03-build.sh — сборка Chromium (Модуль 7, этап 4).
#
# ЧЕРНОВИК: не запускать вслепую. Первая сборка занимает от 1 до нескольких
# часов и требует много CPU/RAM. Инкрементальные пересборки — минуты.

CHROMIUM_ROOT="${CHROMIUM_ROOT:-$HOME/chromium}"
DEPOT_TOOLS_DIR="${DEPOT_TOOLS_DIR:-$CHROMIUM_ROOT/depot_tools}"
SRC_DIR="$CHROMIUM_ROOT/src"
OUT_DIR="${OUT_DIR:-out/ArbiBrowser}"
TARGET="${TARGET:-chrome}"       # цель ninja (chrome, content_shell и т.д.)

export PATH="$DEPOT_TOOLS_DIR:$PATH"
[ -d "$SRC_DIR/$OUT_DIR" ] || { echo "Нет $OUT_DIR — сначала 02-gn-args.sh"; exit 1; }
command -v autoninja >/dev/null 2>&1 || { echo "нет autoninja (depot_tools не в PATH?)"; exit 1; }

cd "$SRC_DIR"
echo "==> Сборка цели '$TARGET' в $OUT_DIR (долго)..."
autoninja -C "$OUT_DIR" "$TARGET"

echo ""
echo "Готово. Бинарь:"
case "$(uname -s)" in
  Linux)  echo "    $SRC_DIR/$OUT_DIR/chrome" ;;
  Darwin) echo "    $SRC_DIR/$OUT_DIR/Chromium.app" ;;
  *)      echo "    $SRC_DIR/$OUT_DIR/" ;;
esac
echo ""
echo "Чтобы ArbiBrowser (Node-часть) запускал собственную сборку:"
echo "    ARBI_CHROMIUM_PATH=$SRC_DIR/$OUT_DIR/chrome node bin/browser.js <profile> --headful"

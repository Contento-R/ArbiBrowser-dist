@echo off
rem ArbiBrowser.bat - launch the ArbiBrowser control panel (with a console window).
rem The console stays open while the panel runs; closing the panel window ends it.
cd /d "%~dp0"
node bin\browser.js gui

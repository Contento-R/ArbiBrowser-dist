'use strict';

/**
 * src/launcher — запуск браузера для профиля.
 *
 * Пайплайн: загрузка профиля → валидация → GeoIP выходного IP прокси →
 * автозаполнение locale/timezone/geolocation → запуск Chromium с ОТДЕЛЬНЫМ,
 * полностью изолированным user-data-dir → применение отпечатка → открытие окна.
 *
 * Изоляция: каждый профиль получает собственный каталог data/user-data/<name>.
 * Это отдельные cookies, storage, кэш, история — среды не пересекаются.
 */

const fs = require('node:fs');
const { isFreshPairTab, isFreshSplitTab, markOwned } = require('../integration/pair-tabs');
const path = require('node:path');
const { chromium } = require('playwright');
const config = require('../../config');
const profileStore = require('../profile');
const net = require('../network');
const fingerprint = require('../fingerprint');
const proxyBridge = require('../network/proxy-bridge');
const settings = require('../settings');
const { isBlockedFlag } = require('./flag-guard');

/**
 * Возвращает пути распакованных расширений из config.extensionsDir.
 * Расширением считается каталог с manifest.json. Расширения Manifest V2
 * ПРОПУСКАЮТСЯ: свежий Chromium их не грузит и показывает блокирующее окно
 * ошибки, которое роняет сессию. Пропускаем их заранее.
 * @param {(m:string)=>void} [warn]
 */
function listExtensions(warn) {
  const dir = config.extensionsDir;
  if (!fs.existsSync(dir)) return [];
  // uBlock грузим (виден в браузере, пользователь может включить фильтрацию), но его
  // ДЕФОЛТНЫЙ режим — «No filtering» (пропатчен при сборке, см. scripts/fetch-extensions.js),
  // чтобы он НИЧЕГО не блокировал по умолчанию и не ломал сенсор Akamai на MEXC.
  const out = [];
  for (const d of fs.readdirSync(dir, { withFileTypes: true })) {
    if (!d.isDirectory()) continue;
    const manifestPath = path.join(dir, d.name, 'manifest.json');
    if (!fs.existsSync(manifestPath)) continue;
    // Сторонний менеджер прокси больше не грузим: его настройка ПРИОРИТЕТНЕЕ прокси
    // профиля, и в свежем каталоге он перехватил весь трафик обязательным PAC-скриптом
    // (ERR_MANDATORY_PROXY_CONFIGURATION_FAILED, 2026-09-12), а в режимах «system»/
    // «direct» увёл бы трафик МИМО прокси без единой ошибки на экране. ArbiBrowser
    // задаёт прокси сам, расширение ему не нужно. Каталог УДАЛЯЕМ с диска: пакет
    // самообновления extensions/ не переписывает, а Chromium мог бы поднять уже
    // установленное unpacked-расширение по сохранённому пути — без каталога он его
    // снимает сам. Вернуть осознанно: ARBI_LOAD_PROXY_SWITCHER=1 + scripts/fetch-extensions.js.
    if (d.name === 'proxy-switcher' && process.env.ARBI_LOAD_PROXY_SWITCHER !== '1') {
      try { fs.rmSync(path.join(dir, d.name), { recursive: true, force: true }); } catch { /* занят — пропустим хотя бы загрузку */ }
      if (warn) warn('Расширение "proxy-switcher" не загружено и удалено намеренно: менеджер прокси перекрывал бы прокси профиля.');
      continue;
    }
    let mv = 3;
    try { mv = JSON.parse(fs.readFileSync(manifestPath, 'utf8')).manifest_version; } catch { /* битый манифест */ }
    if (mv !== 3) {
      if (warn) warn(`Расширение "${d.name}" пропущено: manifest_version=${mv} (несовместимо с текущим Chromium). Нужна MV3-версия.`);
      continue;
    }
    out.push(path.join(dir, d.name));
  }
  return out;
}

/**
 * Стабилизирующий список фич, который Playwright гасит через --disable-features.
 * ВАЖНО: если мы добавим СВОЙ --disable-features, Chrome возьмёт только ПОСЛЕДНИЙ
 * (наши args идут после дефолтных Playwright) и затрёт этот список целиком —
 * тогда включатся RenderDocument/PaintHolding/… и браузер начинает падать.
 * Поэтому свой --disable-features делаем НАДМНОЖЕСТВОМ: этот список + нужная фича.
 * Читаем список из самого Playwright (чтобы не устареть), с фолбэком.
 */
function playwrightDisabledFeatures() {
  const FALLBACK = [
    'AcceptCHFrame', 'AvoidUnnecessaryBeforeUnloadCheckSync', 'DestroyProfileOnBrowserClose',
    'DialMediaRouteProvider', 'GlobalMediaControls', 'HttpsUpgrades', 'LensOverlay', 'MediaRouter',
    'PaintHolding', 'ThirdPartyStoragePartitioning', 'Translate', 'AutoDeElevate', 'RenderDocument',
  ];
  const candidates = [];
  try {
    candidates.push(path.join(path.dirname(require.resolve('playwright')),
      'node_modules', 'playwright-core', 'lib', 'server', 'chromium', 'chromiumSwitches.js'));
  } catch (_) { /* нет пути */ }
  try { candidates.push(require.resolve('playwright-core/lib/server/chromium/chromiumSwitches')); } catch (_) { /* нет модуля */ }
  for (const c of candidates) {
    try {
      if (!c || !fs.existsSync(c)) continue;
      const arr = require(c).chromiumSwitches(false);
      const df = arr.find((a) => typeof a === 'string' && a.startsWith('--disable-features='));
      if (df) {
        const list = df.slice('--disable-features='.length).split(',').filter(Boolean);
        if (list.length) return list;
      }
    } catch (_) { /* следующий кандидат / фолбэк */ }
  }
  return FALLBACK;
}

/**
 * @typedef {object} LaunchOptions
 * @property {boolean} [headless=false]  запуск без окна
 * @property {boolean} [skipGeo=false]   не ходить в GeoIP (использовать поля профиля как есть)
 * @property {(msg:string)=>void} [log]  логгер прогресса
 */

/**
 * Запускает браузер для профиля.
 * @param {string} profileName
 * @param {LaunchOptions} [options]
 * @returns {Promise<{context: import('playwright').BrowserContext, profile: object, geo: object|null}>}
 */
async function launch(profileName, options = {}) {
  const log = options.log || (() => {});
  const headless = !!options.headless;

  // 1. Загрузка + валидация (бросает при невалидном профиле).
  log(`Загрузка профиля "${profileName}"...`);
  const baseProfile = profileStore.load(profileName);

  // 2. GeoIP выходного IP прокси и автозаполнение согласованных полей.
  let geo = null;
  let profile = baseProfile;
  let acceptLanguage = net.acceptLanguage(
    baseProfile.languages || net.languagesFromLocale(baseProfile.locale || 'en-US')
  );

  if (!options.skipGeo) {
    try {
      log('Определение гео выходного IP прокси...');
      geo = await net.resolveGeo(baseProfile);
      const applied = net.applyGeo(baseProfile, geo);
      profile = applied.profile;
      acceptLanguage = applied.acceptLanguage;
      log(`Гео: ${geo.city || '?'}, ${geo.country || '?'} → tz=${profile.timezone}, locale=${profile.locale}`);
    } catch (e) {
      log(`GeoIP не удался (${e.message}). Использую поля профиля как есть.`);
    }
  }

  // 3. Изолированный user-data-dir.
  const userDataDir = config.userDataDirFor(profileName);
  fs.mkdirSync(userDataDir, { recursive: true });
  // SEC-5: куки бирж и сессии в user-data-dir не должны быть читаемы другими
  // пользователями машины (дефолтный umask даёт 0755). Best-effort chmod 0700;
  // на Windows mode игнорируется — там разграничение через ACL/профиль ОС.
  try { fs.chmodSync(userDataDir, 0o700); } catch { /* best-effort */ }
  log(`user-data-dir: ${userDataDir}`);

  // Каталог загрузок профиля — ПОСТОЯННЫЙ. Дефолт Playwright (temp + GUID-имя,
  // удаление при закрытии контекста) означал, что экспорт с биржи невозможно
  // ни открыть, ни найти. См. обработчик 'download' ниже.
  const downloadsDir = config.downloadsDirFor(profileName);
  fs.mkdirSync(downloadsDir, { recursive: true });
  try { fs.chmodSync(downloadsDir, 0o700); } catch { /* best-effort */ }

  // 4. Опции контекста из профиля + прокси + аргументы окна.
  const ctxOpts = fingerprint.contextOptions(profile, acceptLanguage);

  // Прокси. ЛЮБОЙ прокси с логином/паролем идём через локальный мост:
  //  • socks5 — потому что Chromium вообще не умеет его авторизацию;
  //  • http/https — потому что запрос авторизации от ВЫШЕСТОЯЩЕГО прокси
  //    Chromium показывает СИСТЕМНЫМ окном «Прокси требует имя пользователя и
  //    пароль». Оно висит поверх вкладки, глотает клики и клавиши, Playwright его
  //    не видит и закрыть не может — торговля встаёт до ручной «Отмены» (инцидент
  //    2026-09-07: пять сорванных заявок MEXC подряд, в поле оставалась
  //    подставленная биржей цена). Через мост браузер общается только с
  //    127.0.0.1, логин/пароль к вышестоящему подставляем мы, а его отказ
  //    приходит обычным 502 — страница не грузится, но окно управляемо.
  // Рубильник: ARBI_BRIDGE_HTTP=0 возвращает прежнее прямое подключение.
  let proxy = net.playwrightProxy(profile.proxy);
  let bridge = null;
  const pr = profile.proxy;
  // ⚠️ ПО УМОЛЧАНИЮ ВЫКЛЮЧЕН (2026-09-08). Мост для http-прокси вводился в 0.4.123
  // против системного окна «прокси требует логин/пароль». После него у оператора
  // посыпались пустые вкладки about:blank и отказ запуска профиля
  // («launchPersistentContext: Target page, context or browser has been closed»).
  // Причинность не доказана, но сетевой путь ЕДИНСТВЕННОЕ, что я в нём менял, а
  // known-good важнее незаконченной правки: http-прокси снова подключается напрямую,
  // как до 0.4.123. Включить обратно осознанно: ARBI_BRIDGE_HTTP=1.
  // Для socks5 мост как был — там он обязателен (Chromium не умеет его авторизацию)
  // и работал задолго до этой истории.
  // 15.09 (оператор 22:01): окно логина прокси вернулось и перехватило ввод заявки
  // MEXC. Разбор Playwright 1.56: креды прокси подставляются через Fetch только для
  // страниц и сервис-воркеров, к которым он подключён; запрос любого другого таргета
  // или отказ прокси принять кэшированные креды (ротация сессии) → системное окно.
  // Мост убирает класс целиком: Chromium видит локальный прокси, отказ вышестоящего
  // приходит как 502. Откат 0.4.126 причинность не доказал; при повторе «пустых
  // вкладок / профиль не стартует» — ARBI_BRIDGE_HTTP=0 в .env и перезапуск.
  const bridgeHttp = (process.env.ARBI_BRIDGE_HTTP || '1') !== '0';
  // Только socks5 и http: к прокси типа https надо идти по TLS, а мост говорит
  // с вышестоящим открытым TCP — такие профили оставляем на прежнем прямом пути.
  if (pr && pr.username && (pr.type === 'socks5' || (pr.type === 'http' && bridgeHttp))) {
    log(pr.type === 'socks5'
      ? 'Chromium не поддерживает авторизацию SOCKS5 — поднимаю локальный прокси-мост...'
      : 'Прокси с авторизацией — поднимаю локальный мост (иначе Chromium может показать системное окно ввода пароля)...');
    bridge = await proxyBridge.startBridge(pr, { log: (m) => log(m) });
    // SEC-2: мост требует basic-auth; отдаём креды Chromium через Playwright proxy
    // (Proxy-Authorization). Чужой локальный процесс без них получит 407.
    proxy = { server: bridge.server, username: bridge.username, password: bridge.password };
    log(`Мост: Chromium → ${bridge.server} → ${pr.type}://${pr.host}:${pr.port} (auth)`);
  } else if (pr) {
    // Почему без моста — в лог (#58): лог оператора 15.09 22:16 без строки «Мост»
    // при окне логина прокси на экране — причину без этой строки не установить.
    log(!pr.username
      ? `Прокси ${pr.type}://${pr.host}:${pr.port} без логина/пароля в профиле — мост не нужен. Если Chromium показывает окно «прокси требует логин и пароль», прокси всё же требует авторизацию (или IP не в его белом списке) — добавьте логин/пароль в профиль`
      : `Прокси ${pr.type}://${pr.host}:${pr.port} с авторизацией идёт напрямую (${pr.type === 'https' ? 'тип https мост не обслуживает' : 'ARBI_BRIDGE_HTTP=0'}) — возможно системное окно логина прокси`);
  }

  // --test-type убирает жёлтый инфобар "--no-sandbox не поддерживается"
  // (Playwright запускает с --no-sandbox, когда chromiumSandbox!==true). Это
  // только UI-инфобар; веб-страницы флаг не видят (в navigator его нет).
  //
  // --disable-blink-features=AutomationControlled — КЛЮЧЕВОЙ антидетект: без него
  // Blink под управлением CDP выставляет navigator.webdriver=true (явный флаг бота
  // для Google/reCAPTCHA). Флаг убирает признак НАТИВНО на уровне движка — свойство
  // остаётся нативным геттером на Navigator.prototype (webdriver=false), без own-
  // property и без JS-патча, который сам детектируется (arrow-getter, toString-leak,
  // hasOwnProperty). Поэтому JS-override webdriver в fingerprint больше НЕ нужен.
  const args = ['--no-first-run', '--no-default-browser-check', '--test-type',
    '--disable-blink-features=AutomationControlled',
    // Глушим ФОНОВЫЕ сети Chrome, которые сами лезут в Google МИМО нашей задачи:
    // FCM/push (mtalk.google.com:5228, постоянное соединение), safe-browsing,
    // component/extension update, domain-reliability, sync, ping'и. Через
    // антидетект-прокси этот паразитный трафик (а) жрёт лимит прокси, (б) триггерит
    // abuse-эвристику провайдера («много обращений к google/auth-страницам» —
    // ровно на это ругнулся Webshare), (в) линкует профили через Google
    // (FCM-токен/аккаунт). Биржевой трафик (навигация/fetch страницы) не затронут.
    '--disable-background-networking',
    // Фоновая вкладка НЕ должна тормозить ордер. Chromium душит таймеры и кадры у
    // невидимых вкладок (выравнивание к 1 с, рендер-процесс в фоне), а Playwright
    // перед кликом ждёт «стабильности» элемента по кадрам → на фоновой вкладке пары
    // клик и evaluate стоят секунды (лог оператора 2026-09-08 07:20: первая заявка
    // BingX — зачистки=1878 клик=1955, вторая через 11 с — 151/82). Стандартный
    // набор для автоматизации; страница из JS этих флагов не видит.
    '--disable-background-timer-throttling',
    '--disable-renderer-backgrounding',
    '--disable-backgrounding-occluded-windows',
    '--disable-component-update',
    '--disable-domain-reliability',
    '--disable-sync',
    '--no-pings'];
  if (profile.screen) {
    args.push(`--window-size=${profile.screen.width},${profile.screen.height}`);
    // Умеренный desktop-viewport (1366×768) — и для видимого окна (пользователь
    // работает в нём как в антидетекте), и для скрытого exec-окна. Ширина на поиск
    // пары не влияет: XT ищет через всегда-видимый хедер-поиск, MEXC — через click-
    // поповер, оба width-независимы. Переопределяемо ARBI_HIDDEN_WINDOW_SIZE.
    args.push(`--window-size=${process.env.ARBI_HIDDEN_WINDOW_SIZE || '1366,768'}`);
  }
  // Скрытый режим («под капотом»): реальное headful-окно (расширения + анти-бот
  // работают как обычно), но за пределами экрана — пользователь его не видит.
  // Используется для авто-запуска профиля под исполнение ордеров без открытого окна.
  if (options.hidden) {
    args.push('--window-position=-32000,-32000');
  }
  // Защита от утечки реального IP через WebRTC. WebRTC-трафик по UDP не проходит
  // через TCP-прокси (socks5/http) и берёт реальный сетевой интерфейс — публичный
  // srflx-кандидат светит реальный IP (даже когда HTTP идёт через прокси/системный
  // VPN). Запрещаем НЕПРОКСИРОВАННЫЙ UDP БЕЗУСЛОВНО: с прокси — обязательно; без
  // прокси на профиле (трафик может идти через системный VPN) — тоже, иначе тот же
  // публичный IP утекает мимо. Локальный IP уже прячется mDNS.
  args.push('--force-webrtc-ip-handling-policy=disable_non_proxied_udp');
  // Синоним для части сборок, где force-вариант флага не срабатывает.
  args.push('--webrtc-ip-handling-policy=disable_non_proxied_udp');

  // Расширения. Грузим распакованные из config.extensionsDir во ВСЕ профили.
  // Работает только в headful (Chromium не грузит расширения в headless).
  // ВАЖНО: НЕ передаём --disable-extensions-except — этот флаг запрещает все
  // расширения, кроме перечисленных, и ломает Chrome Web Store / ручную установку.
  // Только --load-extension: встроенные грузятся, а любые другие (из магазина,
  // в user-data-dir профиля) продолжают работать.
  let loadExtensions = false;
  // Фичи, которые гасим СВЕРХ списка Playwright (надмножество, см. playwrightDisabledFeatures).
  // CalculateNativeWinOcclusion: на Windows Chromium сам вычисляет, перекрыто ли окно
  // другим окном, и перекрытому перестаёт рисовать кадры — --disable-backgrounding-
  // occluded-windows это не отменяет. Наши окна пар стоят ПОД окном профиля (0.4.150),
  // и всё, что ждёт кадров, тормозит: клик Playwright по кнопке XT 954–1093 мс,
  // набор количества ~100 мс на знак, rAF-проба 250 мс (лог оператора 15.09 18:12).
  // Без расчёта перекрытия окно считается видимым и рисует в полном темпе.
  // Рубильник: ARBI_WIN_OCCLUSION=1 — вернуть расчёт перекрытия.
  const extraDisabled = process.env.ARBI_WIN_OCCLUSION === '1' ? [] : ['CalculateNativeWinOcclusion'];
  if (!headless) {
    const extDirs = listExtensions(log);
    if (extDirs.length) {
      loadExtensions = true;
      args.push(`--load-extension=${extDirs.join(',')}`);
      // Chrome 137+ ОТКЛЮЧИЛ флаг --load-extension (защита от подсовывания
      // расширений малварью). Возвращаем загрузку фичей DisableLoadExtension...
      // НО добавляем её к списку Playwright (надмножество), а не вместо него —
      // иначе затрём стабилизирующие флаги и браузер начнёт падать.
      extraDisabled.push('DisableLoadExtensionCommandLineSwitch');
      log(`Расширения: ${extDirs.length} загружено (${extDirs.map((d) => require('path').basename(d)).join(', ')})`);
    }
  }
  if (extraDisabled.length) args.push('--disable-features=' + playwrightDisabledFeatures().concat(extraDisabled).join(','));

  // ── ЭКОНОМИЯ РЕСУРСОВ (оператор 2026-08-03) ────────────────────────────────
  // По умолчанию Chromium держит отдельный процесс-рендерер почти на каждую
  // вкладку (site-per-process). Для арбитражного браузера это худший случай:
  // на профиле открыто по нескольку вкладок ОДНОЙ биржи, и каждая берёт свои
  // сотни МБ (замер оператора: 19 процессов, 10.8 ГБ на один профиль).
  //   --process-per-site      → все вкладки одного сайта делят ОДИН рендерер.
  //   --renderer-process-limit → жёсткий потолок рендереров на профиль.
  // Изоляция между профилями не затрагивается (разные user-data-dir и разные
  // браузеры), внутри профиля вкладки одного сайта и так делят cookie-джар —
  // новых утечек флаг не создаёт. Отключается настройкой saveMemory:false.
  const st = settings.read ? settings.read() : {};
  if (st.saveMemory !== false) {
    args.push('--process-per-site');
    const lim = Number(st.rendererLimit);
    if (Number.isFinite(lim) && lim > 0) args.push(`--renderer-process-limit=${Math.floor(lim)}`);
  }

  // SEC-6: профильные флаги подмешиваем С ФИЛЬТРОМ (см. flag-guard.js) — иначе
  // remote-debugging открыл бы CDP наружу, proxy/host-resolver увели бы трафик мимо
  // антидетект-прокси (утечка IP). Фильтр ловит и одиночный, и двойной дефис.
  if (Array.isArray(profile.flags)) {
    for (const f of profile.flags) {
      if (isBlockedFlag(f)) {
        log(`Флаг профиля отклонён (небезопасен): ${f}`);
        continue;
      }
      args.push(f);
    }
  }

  log(`Запуск Chromium (${headless ? 'headless' : 'headful'})${proxy ? ` через ${proxy.server}` : ''}...`);
  let context;
  try {
    // Playwright всегда добавляет --disable-extensions; чтобы наши расширения
    // грузились, снимаем его через ignoreDefaultArgs (только когда грузим).
    const ignoreDefault = ['--enable-automation']; // не афишировать автоматизацию
    if (loadExtensions) ignoreDefault.push('--disable-extensions');
    context = await chromium.launchPersistentContext(userDataDir, {
      headless,
      proxy,
      executablePath: settings.effectiveChromiumPath() || undefined,
      args,
      ignoreDefaultArgs: ignoreDefault,
      downloadsPath: downloadsDir,
      ...ctxOpts,
    });
  } catch (e) {
    if (bridge) await bridge.close().catch(() => {});
    throw e;
  }

  // Закрываем мост вместе с контекстом.
  if (bridge) context.on('close', () => bridge.close().catch(() => {}));

  // ── Загрузки: РОДНОЙ режим Chromium вместо перехвата Playwright ──────────
  // Playwright по умолчанию ставит download-поведение 'allowAndName': файл
  // кладётся во временный каталог артефактов и НАЗЫВАЕТСЯ GUID'ом без расширения
  // («98157f86-8289-4e7f-…»). Из-за этого в шелфе Chrome клик по файлу и кнопка
  // «Показать в папке» не работают (запись указывает на временный артефакт), а
  // при закрытии профиля файл удаляется.
  // Переключаем на 'allow' + свой downloadPath: Chromium сохраняет САМ, под
  // настоящим именем, и его собственные кнопки открытия работают штатно.
  // Ставится ПОСЛЕ создания контекста (перекрывает настройку Playwright).
  let nativeDownloads = false;
  try {
    const p0 = context.pages()[0] || await context.newPage();
    const dlClient = await context.newCDPSession(p0);
    await dlClient.send('Browser.setDownloadBehavior', {
      behavior: 'allow',
      downloadPath: downloadsDir,
      // eventsEnabled:false — Playwright больше НЕ перехватывает загрузку, значит
      // не пытается «сохранить» уже сохранённый Chromium'ом файл (дубль/зависание).
      eventsEnabled: false,
    });
    await dlClient.detach().catch(() => {});
    nativeDownloads = true;
    log(`Загрузки: ${downloadsDir}`);
  } catch (e) {
    log(`Загрузки: родной режим не включился (${e.message}) — работает запасной путь`);
  }

  // Страховка: если родной режим выше не встал, Playwright всё ещё перехватывает
  // загрузку — сохраняем её под РЕАЛЬНЫМ именем сами. Тихо, best-effort.
  context.on('download', (download) => {
    if (nativeDownloads) return; // Chromium уже сохранил файл сам
    (async () => {
      const base = download.suggestedFilename() || `download-${Date.now()}`;
      const ext = path.extname(base);
      const stem = path.basename(base, ext);
      let dest = path.join(downloadsDir, base);
      for (let i = 2; fs.existsSync(dest); i++) dest = path.join(downloadsDir, `${stem} (${i})${ext}`);
      await download.saveAs(dest);
      log(`Загрузка сохранена: ${dest}`);
    })().catch((e) => log(`Загрузка: сохранить не удалось — ${e.message}`));
  });

  // 5. Применение отпечатка (init-скрипты + CDP на все страницы).
  await fingerprint.applyAll(context, profile, acceptLanguage);
  log('Отпечаток применён.');

  return { context, profile, geo };
}

/**
 * Открывает вкладку «спящей»: вместо реальной страницы — лёгкая заглушка,
 * которая сама загрузит нужный URL, когда пользователь на неё переключится.
 *
 * Зачем: восстановление 8 вкладок бирж грузило их ВСЕ сразу — каждая тянет
 * свой рендерер и сотни МБ (замер оператора 2026-08-03: 19 процессов, 10.8 ГБ
 * на профиль). Спящая вкладка стоит единицы МБ и просыпается за одну навигацию.
 *
 * Реальный URL остаётся на объекте страницы (`__arbiSleepUrl`) — так его видят
 * сохранялка вкладок (снимок сессии не теряет спящие) и интеграции (могут
 * разбудить нужную вкладку вместо открытия дубля).
 */
async function openSleepingTab(context, url) {
  const page = markOwned(await context.newPage());
  page.__arbiSleepUrl = url;
  await sleepPage(page, url);
  return page;
}

/** Превращает страницу в «спящую» заглушку, помнящую свой URL. */
async function sleepPage(page, url) {
  let host = url;
  try { host = new URL(url).host; } catch { /* оставляем как есть */ }
  const u = JSON.stringify(url);
  await page.setContent(
    '<!doctype html><meta charset="utf-8"><title>' + host + '</title>'
    + '<style>html,body{height:100%;margin:0;display:flex;align-items:center;justify-content:center;'
    + 'background:#0f1115;color:#8b93a7;font:14px system-ui,sans-serif;cursor:pointer}'
    + 'b{color:#cbd3e1;font-weight:600}</style>'
    + '<div style="text-align:center;line-height:1.7">💤 <b>' + host + '</b><br>'
    + 'вкладка спит — экономит память<br><span style="opacity:.6">переключитесь на неё или кликните</span></div>'
    + '<script>var U=' + u + ';var went=false;function go(){if(went)return;went=true;location.replace(U);}'
    + 'document.addEventListener("visibilitychange",function(){if(!document.hidden)go();});'
    + 'document.addEventListener("click",go);</scr' + 'ipt>',
    { waitUntil: 'domcontentloaded' },
  ).catch(() => {});
  // Сбрасываем метку, как только вкладка реально ушла на свой URL.
  if (!page.__arbiSleepHooked) {
    page.__arbiSleepHooked = true;
    page.on('framenavigated', (f) => { if (f === page.mainFrame() && !page.url().startsWith('about:')) page.__arbiSleepUrl = null; });
  }
}

/**
 * Ключ биржи по URL вкладки ('mexc' | 'xt' | 'bingx' | 'gate' | ...), либо null.
 * Нужен, чтобы по КАЖДОЙ бирже профиля всегда оставалась одна ТЁПЛАЯ вкладка:
 * с неё ордер выставляется мгновенно, тогда как спящая тратит навигацию
 * (требование оператора 2026-08-03).
 */
const EXCHANGE_RE = /(^|\.)(mexc|xt|bingx|gate|gateio|bybit|bitget|kucoin|coinex|poloniex)\.(com|io)$/i;
function exchangeKey(url) {
  try {
    const m = new URL(url).hostname.match(EXCHANGE_RE);
    return m ? m[2].toLowerCase().replace('gateio', 'gate') : null;
  } catch { return null; }
}

/** Файл со снимком открытых вкладок профиля (для восстановления при след. старте). */
function tabsFile(profileName) {
  return path.join(config.userDataDirFor(profileName), 'arbi-open-tabs.json');
}

/** Файл с последней позицией/размером окна профиля (видимая сессия). */
function boundsFile(profileName) {
  return path.join(config.userDataDirFor(profileName), 'arbi-window-bounds.json');
}

/** Через CDP получить windowId окна первой страницы контекста. */
async function windowCdp(context) {
  const page = context.pages()[0];
  if (!page) return null;
  const cdp = await context.newCDPSession(page);
  const { windowId } = await cdp.send('Browser.getWindowForTarget');
  return { cdp, windowId };
}

/**
 * Восстанавливает позицию/размер окна из прошлой сессии (только видимая сессия).
 * Валидация: если сохранённая точка «за экраном» (напр. осталась от прошлого
 * мультимонитора) — не применяем, пусть Chromium ставит сам. Off-screen скрытой
 * сессии НЕ трогаем.
 */
async function restoreWindowBounds(context, profileName, log) {
  let b = null;
  try { b = JSON.parse(fs.readFileSync(boundsFile(profileName), 'utf8')); } catch { return; }
  if (!b || typeof b.left !== 'number' || typeof b.top !== 'number') return;
  // Не восстанавливаем ЯВНО уехавшие координаты (защита от окна за экраном).
  if (b.left <= -20000 || b.top <= -20000 || b.left > 20000 || b.top > 20000) return;
  try {
    const page = context.pages()[0];
    if (!page) return;
    const cdp = await context.newCDPSession(page);
    const { windowId } = await cdp.send('Browser.getWindowForTarget');
    let width = b.width || 1280;
    let height = b.height || 800;
    await cdp.send('Browser.setWindowBounds', {
      windowId, bounds: { left: b.left, top: b.top, width, height, windowState: 'normal' },
    });
    // ПРОВЕРКА, что окно реально оказалось НА экране. Сохранённая точка могла быть на
    // втором мониторе, которого сейчас нет (конфигурация мониторов изменилась) — тогда
    // окно уходит за пределы видимой области (жалоба: «изредка окно за экраном»).
    // window.screen после setWindowBounds сообщает дисплей, на котором сейчас окно;
    // если значимая часть окна (заголовок + край) не попадает в его рабочую область —
    // переносим на видимое место ТЕКУЩЕГО дисплея, сохранив размер.
    const info = await page.evaluate(() => {
      const s = window.screen;
      return {
        dl: (typeof s.availLeft === 'number' ? s.availLeft : 0),
        dt: (typeof s.availTop === 'number' ? s.availTop : 0),
        dw: s.availWidth, dh: s.availHeight,
        wx: window.screenX, wy: window.screenY,
        ww: window.outerWidth || 0, wh: window.outerHeight || 0,
      };
    }).catch(() => null);
    // Окно должно ПОЛНОСТЬЮ помещаться в рабочую область: и когда уехало за экран
    // (сменилась конфигурация мониторов), и когда просто СЛИШКОМ ВЫСОКОЕ/широкое —
    // сохранённая высота больше монитора → низ с панелью ордеров уходит под экран
    // (жалоба: «на XT не вижу свои заявки»). Поджимаем размер под дисплей и двигаем внутрь.
    if (info) {
      const maxW = Math.max(600, info.dw - 40);
      const maxH = Math.max(400, info.dh - 40);
      const nw = Math.min(width, maxW);
      const nh = Math.min(height, maxH);
      const onScreen = (info.wx + info.ww > info.dl + 80) && (info.wx < info.dl + info.dw - 80)
        && (info.wy + info.wh > info.dt + 20) && (info.wy < info.dt + info.dh - 40);
      let left = b.left;
      let top = b.top;
      if (!onScreen) { left = Math.round(info.dl + 40); top = Math.round(info.dt + 40); }
      if (left + nw > info.dl + info.dw) left = Math.max(info.dl, Math.round(info.dl + info.dw - nw));
      if (top + nh > info.dt + info.dh) top = Math.max(info.dt, Math.round(info.dt + info.dh - nh));
      if (nw !== width || nh !== height || left !== b.left || top !== b.top) {
        await cdp.send('Browser.setWindowBounds', {
          windowId, bounds: { left, top, width: nw, height: nh, windowState: 'normal' },
        });
        log(`Окно подогнано под экран: (${left},${top}) ${nw}×${nh}`);
      } else {
        log(`Окно восстановлено на позицию прошлой сессии (${b.left},${b.top})`);
      }
    }
    await cdp.detach().catch(() => {});
  } catch (e) { log(`restore bounds: ${e.message}`); }
}

/** Периодически сохраняет позицию окна (только нормальное, на экране) + при закрытии. */
function startBoundsSaver(context, profileName) {
  const save = async () => {
    try {
      const w = await windowCdp(context);
      if (!w) return;
      const { bounds } = await w.cdp.send('Browser.getWindowBounds', { windowId: w.windowId });
      await w.cdp.detach().catch(() => {});
      // Сохраняем только нормальное окно на экране (не свёрнутое, не off-screen).
      if (bounds && bounds.windowState === 'normal'
          && bounds.left > -20000 && bounds.top > -20000 && bounds.left < 20000) {
        fs.writeFileSync(boundsFile(profileName), JSON.stringify(bounds));
      }
    } catch { /* не критично */ }
  };
  const timer = setInterval(save, 15000);
  context.on('close', () => { clearInterval(timer); save(); });
}

/** Читает сохранённые URL вкладок профиля (только http(s), максимум 8). */
function readSavedTabs(profileName) {
  try {
    const arr = JSON.parse(fs.readFileSync(tabsFile(profileName), 'utf8'));
    const st = settings.read ? settings.read() : {};
    const cap = Number(st.maxRestoredTabs);
    const max = Number.isFinite(cap) && cap > 0 ? Math.floor(cap) : 8;
    return (Array.isArray(arr) ? arr : []).filter((u) => typeof u === 'string' && /^https?:/i.test(u)).slice(0, max);
  } catch { return []; }
}

/** Периодически сохраняет URL открытых вкладок; финальный снимок — при закрытии. */
function startTabSaver(context, profileName) {
  const save = () => {
    try {
      const urls = context.pages()
        // Спящая вкладка физически на about:blank — берём её настоящий URL,
        // иначе снимок сессии терял бы всё, что не успели разбудить.
        .map((p) => { try { return p.__arbiSleepUrl || p.url(); } catch { return ''; } })
        .filter((u) => /^https?:/i.test(u) && !u.startsWith('about:'));
      const uniq = [...new Set(urls)].slice(0, 8);
      // НЕ перезаписываем пустым снимком: при закрытии контекста (в т.ч. по Ctrl+C)
      // pages() уже пуст, и раньше это ЗАТИРАЛО сохранённые вкладки → потеря вкладок.
      // Пишем только непустой набор — последний известный список вкладок сохраняется.
      if (uniq.length) fs.writeFileSync(tabsFile(profileName), JSON.stringify(uniq));
    } catch { /* не критично */ }
  };
  const timer = setInterval(save, 10000);
  context.on('page', () => setTimeout(save, 2500));
  context.on('close', () => { clearInterval(timer); save(); });
}

/**
 * Контроль открытых вкладок в течение сессии: вкладка, которую давно не
 * открывали, засыпает сама и освобождает свой процесс-рендерер.
 *
 * Почему по «давно скрыта», а не по числу вкладок: усыплять активно
 * используемую вкладку биржи опасно (в ней живёт форма ордера). Порог в
 * десятки минут гарантирует, что вкладка не участвует в текущей работе —
 * исполнение ордера занимает секунды. Просыпание — одна навигация, сессия
 * биржи (куки профиля) при этом не теряется.
 *
 * Дополнительно держим потолок ЗАГРУЖЕННЫХ вкладок: сверх него усыпляем
 * те, что скрыты дольше всех.
 */
function startIdleTabSleeper(context, log) {
  const st = settings.read ? settings.read() : {};
  if (st.sleepingTabs === false) return;
  const idleMs = Math.max(1, Number(st.idleSleepMinutes) || 20) * 60_000;
  const maxLoaded = Math.max(1, Number(st.maxLoadedTabs) || 4);
  const lastSeen = new WeakMap();

  const tick = async () => {
    const now = Date.now();
    const loaded = [];
    let visibleLoaded = 0;
    // Сколько ЗАГРУЖЕННЫХ вкладок держит каждая биржа: последнюю не усыпляем.
    const warm = new Map();
    for (const p of context.pages()) {
      let url = '';
      try { url = p.url(); } catch { continue; }
      if (!/^https?:/i.test(url) || p.__arbiSleepUrl) continue; // уже спит / служебная
      // Служебные фоновые страницы интеграций (чтение баланса / истории) не
      // усыпляем, ПОКА ими пользуются: сон = лишняя навигация на каждом чтении.
      // Но если чтений не было давно (ARBI_BG_IDLE_MIN, 15 мин), держать
      // загруженной тяжёлую страницу биржи незачем — на слабой машине она одна
      // даёт заметный тормоз (жалоба оператора 11.09). Следующее чтение поднимет
      // её обычным goto: getBalanceBgPage и так навигирует, если URL не на паре.
      if (p.__arbiBalanceBg === true || p.__arbiOrdersBg === true) {
        const bgIdleMs = Math.max(1, Number(process.env.ARBI_BG_IDLE_MIN) || 15) * 60_000;
        const usedAt = Number(p.__arbiBgUsedAt) || 0;
        if (!usedAt || now - usedAt < bgIdleMs) continue;
        try {
          p.__arbiSleepUrl = url;
          await sleepPage(p, url);
          log(`Фоновая страница усыплена (чтений не было ${Math.round((now - usedAt) / 60_000)} мин): ${url}`);
        } catch { p.__arbiSleepUrl = null; }
        continue;
      }
      // Вкладки ПУЛА ПАР (по одной на активную пару биржи) тоже не усыпляем: весь
      // их смысл — быть тёплыми к моменту заявки. Усыплённая вкладка стоила бы
      // навигации ровно тогда, когда пара понадобилась (оператор 01.09).
      // Метка ПРОТУХАЕТ: терминал закрыли — подтверждать пару стало некому, и
      // вкладка снова становится обычной (иначе брошенные жили бы вечно).
      // Вкладка-ЧАСТЬ дробления — вторая защита, независимая от метки пула:
      // именно из неё уходит часть крупной заявки, и усыплённая часть = заявка
      // не уйдёт вовсе. Сверх потолка `maxLoadedTabs` сторож вытесняет вкладки
      // СРАЗУ, не дожидаясь простоя, поэтому одной метки пула с её TTL мало.
      if (isFreshSplitTab(p)) continue;
      if (isFreshPairTab(p)) continue;
      let hidden = true;
      try { hidden = await p.evaluate(() => document.hidden); } catch { continue; } // навигация — пропускаем тик
      const k = exchangeKey(url);
      if (k) warm.set(k, (warm.get(k) || 0) + 1);
      if (!hidden) { visibleLoaded += 1; lastSeen.set(p, now); continue; }
      if (!lastSeen.has(p)) { lastSeen.set(p, now); continue; } // первую отсидку отсчитываем с этого тика
      loaded.push({ p, url, key: k, hiddenFor: now - lastSeen.get(p) });
    }
    // Сверх потолка — усыпляем самые «холодные»; плюс всё, что пересидело порог.
    loaded.sort((a, b) => b.hiddenFor - a.hiddenFor);
    // Сколько вкладок держат рендерер сверх потолка (видимая всегда остаётся).
    const over = Math.max(0, loaded.length + visibleLoaded - maxLoaded);
    for (let i = 0; i < loaded.length; i++) {
      const { p, url, key, hiddenFor } = loaded[i];
      if (hiddenFor < idleMs && i >= over) continue;
      // ПОСЛЕДНЮЮ тёплую вкладку биржи не трогаем НИКОГДА: с неё ордер уходит
      // мгновенно, а разбуженная стоила бы навигации в самый нужный момент
      // (требование оператора 2026-08-03). Экономим на дублях той же биржи.
      if (key && (warm.get(key) || 0) <= 1) continue;
      try {
        if (key) warm.set(key, warm.get(key) - 1);
        p.__arbiSleepUrl = url;
        await sleepPage(p, url);
        log(`Вкладка усыплена (экономия памяти): ${url}`);
      } catch { p.__arbiSleepUrl = null; }
    }
  };

  const timer = setInterval(() => { void tick().catch(() => {}); }, 60_000);
  context.on('close', () => clearInterval(timer));
}

/**
 * Запускает браузер и открывает стартовую страницу (для интерактивного режима).
 * Восстанавливает вкладки, открытые в прошлой сессии профиля (если были).
 * @param {string} profileName
 * @param {LaunchOptions & {startUrl?: string}} [options]
 */
async function open(profileName, options = {}) {
  const res = await launch(profileName, options);
  const log = options.log || (() => {});
  const saved = readSavedTabs(profileName);

  let page;
  if (saved.length) {
    // Восстанавливаем прошлые вкладки: первую — в стартовую страницу, остальные —
    // новыми. Стартовый URL (если задан явно, напр. пара под ордер) добавляем,
    // только если его нет среди восстановленных, чтобы не плодить дубли.
    log(`Восстанавливаю вкладки прошлой сессии: ${saved.length}`);
    const urls = [...saved];
    const want = options.startUrl;
    if (want && !urls.some((u) => u === want)) urls.unshift(want);
    const stt = settings.read ? settings.read() : {};
    const sleep = stt.sleepingTabs !== false;
    // Первую вкладку (позиция 0 = стартовый URL под ордер) грузим СИНХРОННО — её
    // возвращаем и на ней сразу пойдёт первый ордер.
    const first = markOwned(res.context.pages()[0] || await res.context.newPage());
    await first.goto(urls[0], { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    page = first;
    if (urls.length > 1) {
      if (sleep) {
        // ПО ОДНОЙ ТЁПЛОЙ ВКЛАДКЕ НА КАЖДУЮ БИРЖУ (оператор 2026-08-03): с
        // прогретой вкладки ордер уходит мгновенно, спящая стоила бы навигации
        // в самый неподходящий момент. Остальные вкладки той же биржи — спящие.
        const warmed = new Set([exchangeKey(urls[0])].filter(Boolean));
        const warmLater = [];
        for (let i = 1; i < urls.length; i++) {
          const k = exchangeKey(urls[i]);
          if (k && !warmed.has(k)) { warmed.add(k); warmLater.push(urls[i]); continue; }
          // Спящая вкладка НЕ ходит к бирже вовсе — поэтому здесь не нужен ни
          // фоновый догон, ни stagger: паттерн «залп goto с одного IP», который
          // Akamai принимает за робота, физически не возникает.
          await openSleepingTab(res.context, urls[i]);
        }
        // Последняя созданная вкладка становится активной — возвращаем фокус,
        // иначе спящая проснулась бы сразу.
        await first.bringToFront().catch(() => {});
        log(`Спящих вкладок: ${urls.length - 1 - warmLater.length}; тёплых бирж: ${warmed.size}`);
        // Тёплые догоняем В ФОНЕ и ПОСЛЕДОВАТЕЛЬНО со stagger-паузой — их мало
        // (по одной на биржу), но это всё же реальные заходы на биржу.
        if (warmLater.length) {
          const stagger = Number(process.env.ARBI_RESTORE_STAGGER_MS || 1500);
          (async () => {
            for (const u of warmLater) {
              try {
                const p = markOwned(await res.context.newPage());
                await p.goto(u, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
              } catch { /* вкладка не критична для первого ордера */ }
              await first.bringToFront().catch(() => {});
              await new Promise((r) => setTimeout(r, stagger));
            }
          })().catch(() => {});
        }
      } else {
        // ОСТАЛЬНЫЕ восстанавливаем В ФОНЕ (не блокируя первый ордер), но СТРОГО
        // ПОСЛЕДОВАТЕЛЬНО с паузой между вкладками: параллельный залп из N
        // одновременных goto к бирже с одного IP — ровно тот паттерн, что Akamai
        // Bot Manager принимает за бота и отвечает Access Denied на ВЕСЬ
        // профиль/IP (человек открывает вкладки по одной, а не разом).
        const stagger = Number(process.env.ARBI_RESTORE_STAGGER_MS || 1500);
        (async () => {
          for (let i = 1; i < urls.length; i++) {
            try {
              const p = markOwned(await res.context.newPage());
              await p.goto(urls[i], { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
            } catch { /* вкладка не критична для первого ордера */ }
            await new Promise((r) => setTimeout(r, stagger));
          }
        })().catch(() => {});
      }
    }
  } else {
    page = markOwned(res.context.pages()[0] || (await res.context.newPage()));
    const url = options.startUrl || config.startUrl;
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    } catch (e) {
      log(`Не удалось открыть ${url}: ${e.message}`);
    }
  }

  startTabSaver(res.context, profileName);
  startIdleTabSleeper(res.context, log);

  // Позиция окна: восстанавливаем/сохраняем ТОЛЬКО для видимой сессии. Скрытая
  // (hidden) намеренно off-screen (-32000) — её позицию не трогаем и не сохраняем,
  // чтобы не перетереть последнюю «человеческую» позицию видимой сессии.
  if (!options.hidden) {
    await restoreWindowBounds(res.context, profileName, log).catch(() => {});
    startBoundsSaver(res.context, profileName);
  }

  return { ...res, page };
}

module.exports = { launch, open };

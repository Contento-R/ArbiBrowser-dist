'use strict';
// Прямой вывод Ourbit: порядок запросов, заголовки шага, самообучение (пауза / одновременная подготовка), отказ → форма.
const test = require('node:test');
const assert = require('node:assert/strict');
const captcha = require('./ourbit-captcha');
const { _withdrawDirect: direct, _deviceOf: deviceOf } = require('./ourbit-order-page');

function setup({ learned = {}, replies = {} } = {}) {
  let st = { gapMs: 0, par: null, seqOk: 0, ...learned };
  captcha.known = () => true;
  captcha.take = () => 'geetest TOKEN';
  captcha.learned = () => ({ ...st });
  captcha.learnedSet = (p) => { st = { ...st, ...p }; };
  const calls = [];
  const context = { cookies: async () => [] };
  const page = {
    context: () => context,
    evaluate: async (_fn, a) => {
      if (!a || !a.url) return '';
      const step = /check_chain/.test(a.url) ? 'check' : /captcha\/robot/.test(a.url) ? 'robot' : /save_withdraw/.test(a.url) ? 'save'
        : /submit_withdraw/.test(a.url) ? 'submit' : /check_risk/.test(a.url) ? 'risk' : /ping/.test(a.url) ? 'ping' : 'other';
      calls.push({ step, hdr: a.hdr, ref: a.ref, at: Date.now() });
      const q = replies[step];
      const r = Array.isArray(q) ? (q.length > 1 ? q.shift() : q[0]) : q;
      return r || { status: 200, code: 0, data: null, success: true };
    },
  };
  deviceOf.set(context, 'SUBMIT-DEVICE');
  const c = {
    page, context, log: () => {}, ref: 'https://www.ourbit.com/ru-RU/assets/withdraw/USDT',
    hdr: { 'luminex-uid': 'u1', 'content-type': 'application/json' },
    uh: { 'ucenter-token': 'T', 'device-id': 'UC-DEVICE', 'timezone-login': 'UTC+1', language: 'ru-RU' },
    want: { coin: 'USDT', chainName: 'BNB Smart Chain(BEP20)', address: '0xabc', amount: '10' },
  };
  return { c, calls, state: () => st };
}
const QUICK = { status: 200, code: 0, data: { isQuickWithdraw: true } };
const SAVED = { status: 200, code: 0, data: { requestId: 'R1' } };
const DONE = { status: 200, code: 0, data: { withdrawId: 'W1', needVerify: false } };
const NO = { status: 200, code: 60008, data: null, msg: 'x' };
const steps = (calls) => calls.map((x) => x.step).join(',');

test('по порядку: проверка и капча вместе, затем подготовка и подтверждение; device-id у каждого шага свой', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: DONE } });
  const r = await direct(c);
  assert.deepEqual(r, { ok: true, withdrawId: 'W1' });
  assert.deepEqual(calls.slice(0, 2).map((x) => x.step).sort(), ['check', 'robot']);
  assert.equal(steps(calls.slice(2)), 'save,submit');
  const robot = calls.find((x) => x.step === 'robot');
  assert.equal(robot.hdr['device-id'], 'UC-DEVICE');
  assert.equal(robot.hdr['captcha-token'], 'geetest TOKEN');
  assert.equal(calls.find((x) => x.step === 'submit').hdr['device-id'], 'SUBMIT-DEVICE');
  assert.ok(calls.every((x) => x.ref === c.ref));
  assert.equal(state().seqOk, 1);
});

test('сайт просит показать капчу (данные в ответе) — подготовки и подтверждения нет, вывод формой', async () => {
  const { c, calls } = setup({ replies: { check: QUICK, robot: { status: 200, code: 0, success: true, data: { type: 'slide' } } } });
  const r = await direct(c);
  assert.equal(r.form, true);
  assert.ok(!calls.some((x) => x.step === 'save' || x.step === 'submit'));
});

test('сайт просит коды — отказ без формы и без подтверждения', async () => {
  const { c, calls } = setup({ replies: { check: { status: 200, code: 0, data: { isQuickWithdraw: false } } } });
  const r = await direct(c);
  assert.equal(r.ok, false);
  assert.match(r.error, /коды/);
  assert.ok(!calls.some((x) => x.step === 'submit'));
});

test('подтверждение сразу отказано 60008 — повтор той же подготовки через 1,2 с, пауза запоминается', async () => {
  const { c, calls, state } = setup({ replies: { check: QUICK, save: SAVED, submit: [NO, DONE] } });
  const r = await direct(c);
  assert.equal(r.ok, true);
  assert.equal(calls.filter((x) => x.step === 'save').length, 1);
  const subs = calls.filter((x) => x.step === 'submit');
  assert.equal(subs.length, 2);
  assert.ok(subs[1].at - calls.find((x) => x.step === 'save').at >= 1150);
  assert.ok(calls.some((x) => x.step === 'risk') && calls.some((x) => x.step === 'ping'));
  assert.equal(state().gapMs, 1200);
  assert.equal(state().seqOk, 0);
});

test('оба подтверждения отказаны — вывод формой, не больше двух попыток', async () => {
  const { c, calls } = setup({ replies: { check: QUICK, save: SAVED, submit: NO } });
  const r = await direct(c);
  assert.equal(r.form, true);
  assert.equal(calls.filter((x) => x.step === 'submit').length, 2);
});

test('после вывода по порядку — подготовка одновременно с капчей; прошло — запоминается', async () => {
  const { c, calls, state } = setup({ learned: { seqOk: 1 }, replies: { check: QUICK, save: SAVED, submit: DONE } });
  const r = await direct(c);
  assert.equal(r.ok, true);
  assert.deepEqual(calls.slice(0, 3).map((x) => x.step).sort(), ['check', 'robot', 'save']);
  assert.equal(state().par, true);
});

test('одновременная подготовка отказана — новая подготовка по порядку и подтверждение; больше так не делает', async () => {
  const { c, calls, state } = setup({ learned: { seqOk: 1 }, replies: { check: QUICK, save: [SAVED, { status: 200, code: 0, data: { requestId: 'R2' } }], submit: [NO, DONE] } });
  const r = await direct(c);
  assert.equal(r.ok, true);
  assert.equal(calls.filter((x) => x.step === 'save').length, 2);
  assert.equal(state().par, false);
});

test('подтверждение без ответа — «мог пройти», формой не повторяем', async () => {
  const { c } = setup({ replies: { check: QUICK, save: SAVED, submit: { error: 'timeout' } } });
  const r = await direct(c);
  assert.equal(r.maybe, true);
  assert.ok(!r.form);
});

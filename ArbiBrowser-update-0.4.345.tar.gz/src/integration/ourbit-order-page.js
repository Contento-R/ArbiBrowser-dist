'use strict';

/**
 * ourbit-order-page.js — исполнитель Ourbit через сайт (оператор 2026-11-16: «ourbit не даёт торговать спот
 * по api, делаем все токены через arbibr»).
 *
 * API Ourbit даёт ключам только чтение истории, поэтому заявки, отмены, открытые ордера и балансы — запросы
 * самого сайта из залогиненной вкладки профиля (fetch из страницы, cookie сессии). Проба 2 (0.4.322):
 * заявка без x-ourbit-sign/nonce принимается — подпись не нужна, формы нет, ≈0,3 с на заявку.
 * Остальные заголовки сайта (luminex-uid, language, …) берутся из любого его запроса к /api/ — значения
 * нигде не пишутся.
 *
 * ⛔ МОНЕТА ПО КОНТРАКТУ (оператор 16.11: «лучше не исполнить заявку и пропустить сделку, чем купить
 * однофамильца»). Заявка сайта называет монету тикером (`currency`). Тикер берётся ТОЛЬКО из intent.symbol,
 * и заявка уходит, только если терминал приложил сверку: hints.ourbit.ticker = этот тикер, и либо
 * verified (контракты, по которым Ourbit сам называет этот тикер; сверено ≤10 мин назад), либо manual
 * (ручная заявка человека с экрана — разрешено оператором). После постановки — проверка в открытых
 * ордерах, что встала та же монета; иначе отмена.
 */

const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { formatDecimal, isPlainPositive } = require('./order-utils');
const ourbitSign = require('./ourbit-sign');
const ourbitCaptcha = require('./ourbit-captcha');
const { withdrawViaForm, prewarmForm, ensureCaptcha } = require('./ourbit-withdraw-page');

const ORIGIN = 'https://www.ourbit.com';
const SKIP_HDR = /^(cookie|host|content-length|content-type|user-agent|origin|referer|accept|accept-encoding|accept-language|connection|priority|cache-control|sec-|:|x-ourbit-(sign|nonce)$)/i;
const VERIFY_MAX_MS = 10 * 60_000;
const OPEN_PATH = '/api/platform/spot/order/current/orders/v2?orderTypes=1,2,3,4,5,100&pageNum=1&pageSize=100&states=0,1,3';

const hdrOf = new WeakMap(); // context → заголовки последнего запроса сайта к /api/ (без подписи и cookie)
const attached = new WeakSet();

function onPage(page) {
  if (attached.has(page)) return;
  attached.add(page);
  page.on('response', (resp) => { try { ourbitCaptcha.onResponse(page, resp); } catch { /* закрыта */ } });
  page.on('request', (req) => {
    try {
      ourbitCaptcha.onRequest(page, req);
      if (!req.url().startsWith(`${ORIGIN}/api/`) || !/^(xhr|fetch)$/.test(req.resourceType())) return;
      const h = {};
      for (const [k, v] of Object.entries(req.headers() || {})) if (!SKIP_HDR.test(k)) h[k] = v;
      if (h['device-id']) rememberDevice(page, h['device-id'], h['luminex-uid']);
      delete h['device-id'];
      if (h['luminex-uid']) hdrOf.set(page.context(), h);
      if (req.method() === 'POST' && (req.headers() || {})['x-ourbit-sign']) ourbitSign.probe(page, req, (m) => console.log('[ourbit-exec] ' + m)).catch(() => {});
    } catch { /* страница закрыта */ }
  });
}

/** Следить за запросами сайта Ourbit во всех вкладках профиля (для заголовков). */
function attach(context) {
  if (!context) return;
  try {
    for (const p of context.pages()) onPage(p);
    context.on('page', onPage);
  } catch { /* контекст закрыт */ }
}

const toPair = (symbol) => String(symbol || 'BTC/USDT').toUpperCase().replace('/', '_');
const usable = (pg, context) => { try { return !!pg && !pg.isClosed() && pg.context() === context && pg.url().startsWith(ORIGIN); } catch { return false; } };

const opening = new WeakMap();
/** Живая вкладка Ourbit профиля; нет — одна новая на страницу пары (навигация не параллелится). */
async function ensurePage(context, symbol, log) {
  let pages = [];
  try { pages = context.pages(); } catch { pages = []; }
  // Вкладку вывода (OURBIT-WD) не берём: она перезагружается под каждый вывод — запрос оборвался бы.
  const pg = pages.find((p) => p.__arbiDuty === 'OURBIT' && usable(p, context)) || pages.find((p) => usable(p, context) && p.__arbiDuty !== 'OURBIT-WD');
  if (pg) return pg;
  if (opening.has(context)) return opening.get(context);
  const p = (async () => {
    const page = await context.newPage();
    page.__arbiDuty = 'OURBIT';
    onPage(page);
    const url = `${ORIGIN}/exchange/${toPair(symbol)}`;
    log(`открываю вкладку ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30_000 });
    return page;
  })();
  opening.set(context, p);
  try { return await p; } finally { opening.delete(context); }
}

async function headers(context, waitMs = 8000) {
  const t0 = Date.now();
  while (!hdrOf.get(context) && Date.now() - t0 < waitMs) await new Promise((r) => setTimeout(r, 200));
  return { ...(hdrOf.get(context) || {}) };
}

async function call(page, method, path, hdr, body, ref) {
  return page.evaluate(async ({ url, method, hdr, body, ref }) => {
    try {
      // Предел 12 с: зависший запрос сайта держал намерение по 20 с (журнал 16.11). ref — страница, от имени которой
      // идёт запрос (Referer): шаги вывода сайт получает со страницы вывода, а не со страницы торгов.
      const init = { method, headers: hdr, body: body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)), credentials: 'include', signal: AbortSignal.timeout(12_000) };
      if (ref) init.referrer = ref;
      const res = await fetch(url, init);
      const txt = await res.text();
      let j = null;
      try { j = JSON.parse(txt); } catch { /* не JSON */ }
      return { status: res.status, code: j ? j.code : null, data: j ? j.data : null, success: j ? j.success : undefined, msg: j ? String(j.msg || '').slice(0, 160) : 'не JSON' };
    } catch (e) { return { error: String((e && e.message) || e).slice(0, 160) }; }
  }, { url: ORIGIN + path, method, hdr, body, ref }).catch((e) => ({ error: String((e && e.message) || e).slice(0, 160) }));
}

/** POST с подписью сайта (ourbit-sign.js): тело сериализуется ОДИН раз — подписывается ровно оно. */
async function signedPost(page, path, hdr, body, ref) {
  const str = JSON.stringify(body);
  return call(page, 'POST', path, { ...hdr, ...(await ourbitSign.signFor(page, str)) }, str, ref);
}

const ok = (r) => !!r && r.status === 200 && (r.code === 200 || r.code === 0);
const noLogin = (r) => !!r && (r.status === 401 || r.code === 401 || /log ?in|登录|未登录|session/i.test(String(r.msg || '')));
const fail = (what, r) => (noLogin(r)
  ? { ok: false, loginRequired: true, error: `Ourbit: нет входа в аккаунт в ArbiBrowser — ${what} не выполнено. Войдите в окне профиля.` }
  : { ok: false, error: `Ourbit: ${what} — отказ сайта (HTTP ${r && r.status != null ? r.status : '-'} code=${r && r.code != null ? r.code : '-'} «${(r && (r.msg || r.error)) || ''}»)` });

/** Проверка, которую обязан пройти каждый боевой ордер: монета подтверждена терминалом. null — можно. */
function coinGate(intent) {
  const base = String(intent.symbol || '').split('/')[0].toUpperCase();
  const g = intent.hints && intent.hints.ourbit;
  if (!g || String(g.ticker || '').toUpperCase() !== base) return 'терминал не подтвердил монету';
  if (g.manual === true) return null;
  if (!Array.isArray(g.verified) || !g.verified.length) return 'монета не сверена по контракту';
  const lag = Number(intent.createdAt) - Number(g.at);
  if (!(Number(g.at) > 0) || !(lag >= -60_000 && lag <= VERIFY_MAX_MS)) return 'сверка по контракту устарела';
  return null;
}

let loggedKeys = false;
const rowId = (x) => String((x && (x.id != null ? x.id : x.orderId)) || '');
const rowCoin = (x) => String((x && (x.currency || String(x.symbol || '').split(/[_/]/)[0])) || '').toUpperCase();

async function openRows(page, hdr) {
  const r = await call(page, 'GET', OPEN_PATH, hdr);
  if (!ok(r)) return { r };
  const rows = Array.isArray(r.data && r.data.resultList) ? r.data.resultList : [];
  return { rows };
}

async function cancel(page, hdr, orderId) {
  return call(page, 'DELETE', `/api/platform/spot/order/cancel/v2?orderId=${encodeURIComponent(orderId)}`, hdr);
}

async function placeOrder(context, intent, log) {
  const why = coinGate(intent);
  if (why) return { ok: false, error: `Ourbit: ${why} — заявка не отправлена` };
  if (intent.type !== 'limit') return { ok: false, error: 'Ourbit: через сайт — только лимитные заявки (рыночная = агрессивная лимитка терминала)' };
  const [base, quote = 'USDT'] = String(intent.symbol).toUpperCase().split('/');
  const price = formatDecimal(intent.price);
  const quantity = formatDecimal(intent.quantity);
  if (!isPlainPositive(price) || !isPlainPositive(quantity)) return { ok: false, error: `Ourbit: цена/объём не числа (${intent.price} / ${intent.quantity})` };
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = { ...(await headers(context)), 'content-type': 'application/json' };
  const body = { currency: base, market: quote, tradeType: intent.side === 'sell' ? 'SELL' : 'BUY', price, quantity, orderType: 'LIMIT_ORDER' };
  const t0 = Date.now();
  const r = await call(page, 'POST', '/api/platform/spot/order/place', hdr, body);
  const ms = Date.now() - t0;
  if (r.error || (r.status >= 500)) return { ok: false, error: `Ourbit: ответа на заявку нет (${r.error || `HTTP ${r.status}`}) — заявка МОГЛА встать, проверьте открытые ордера` };
  const orderId = ok(r) && typeof r.data === 'string' && r.data ? r.data : null;
  if (!orderId) return fail(`заявка ${base}/${quote}`, r);
  log(`Ордер выставлен: ${orderId} — ${intent.side} ${quantity} ${base} @ ${price}, ответ ${ms} мс${intent.hints.ourbit.manual ? ' (ручная, без сверки контракта)' : ''}`);
  // Встала та же монета? Не нашли строку (уже исполнилась) — тело заявки и так несло подтверждённый тикер.
  const { rows } = await openRows(page, { ...hdr });
  const row = (rows || []).find((x) => rowId(x) === orderId);
  if (row && !loggedKeys) { loggedKeys = true; log(`поля открытого ордера сайта: ${Object.keys(row).join(',')}`); }
  const coin = row ? rowCoin(row) : '';
  if (coin && coin !== base) {
    const c = await cancel(page, hdr, orderId);
    return { ok: false, error: `Ourbit поставил заявку по ${coin} вместо ${base} — ${ok(c) ? 'заявка отменена' : `⚠ ОТМЕНИТЬ НЕ УДАЛОСЬ, снимите заявку ${orderId} руками`}` };
  }
  return { ok: true, orderId, direct: true };
}

// Сеть сайта (chainName «Solana(SOL)», walletType «SOL») → канон терминала (как canonChain в CEX exchange/ourbit.ts).
function canonChain(raw) {
  const s = String(raw || '').toLowerCase();
  if (s.includes('bep20') || s === 'bsc' || s === 'bnb' || s.includes('bnb smart')) return 'BSC';
  if (s.includes('erc20') || s === 'eth' || s === 'ethereum') return 'ETH';
  if (s.includes('trc20') || s === 'tron' || s === 'trx') return 'TRX';
  if (s === 'sol' || s.startsWith('solana')) return 'SOL';
  if (s === 'base' || s.startsWith('base(') || s.startsWith('base ')) return 'BASE';
  if (s.startsWith('arbitrum') || s === 'arb') return 'ARBITRUM';
  if (s.startsWith('polygon') || s === 'matic') return 'POLYGON';
  return String(raw || '').toUpperCase();
}

/**
 * Сеть монеты по справочнику сайта (`spot/currency/v3`, как страницы депозита и вывода). У сети своя «монета сайта»
 * (`currency`: USDT-BNB, USDT-ETH; USDT = TRC20), и адрес депозита выдаётся ПО НЕЙ (запись 16.11) — запрос с общим
 * «USDT» и сетью BSC давал адрес TRON. Ровно одна сеть под запрошенную, иначе отказ.
 */
const chainsMemo = new Map(); // монета → { at, r } — справочник сетей монеты (для вывода: до 5 мин, решает всё равно сайт)
async function chainOf(page, hdr, coin, chain, maxAgeMs = 0) {
  const hit = chainsMemo.get(coin);
  const r = hit && Date.now() - hit.at < maxAgeMs ? hit.r
    : await call(page, 'GET', `/api/platform/asset/api/asset/spot/currency/v3?currency=${encodeURIComponent(coin)}`, hdr);
  if (!ok(r) || !r.data || !Array.isArray(r.data.chains)) return { r };
  if (!hit || hit.r !== r) chainsMemo.set(coin, { at: Date.now(), r });
  const want = canonChain(chain);
  const hits = r.data.chains.filter((n) => canonChain(n.walletType) === want || canonChain(n.chainName) === want);
  if (hits.length !== 1) return { why: `у ${coin} на Ourbit ${hits.length ? 'несколько сетей' : 'нет сети'} ${chain} (есть: ${r.data.chains.map((n) => n.chainName).join(', ') || '—'})` };
  return { c: hits[0], available: r.data.available };
}

const fmtOf = (a) => (/^0x[0-9a-fA-F]{40}$/.test(a) ? 'EVM' : /^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(a) ? 'TRON' : /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(a) ? 'base58' : 'другой');

const deviceOf = new WeakMap(); // context → заголовок device-id сайта (его шлёт только подтверждение вывода)

/*
 * device-id сайта (16.11): без него подтверждение быстрого вывода отвечает 60008 «неверный код» — сайт шлёт его только
 * в submit_withdraw. Запоминаем на диске по аккаунту Ourbit (luminex-uid) — переживает перезапуск ArbiBrowser, и один
 * раз ищем, где страница его хранит (в журнал — только ИМЯ ключа хранилища, не значение).
 */
const DEV_FILE = () => path.join(config.reportsDir, 'ourbit-device.json');
function devStore() { try { return JSON.parse(fs.readFileSync(DEV_FILE(), 'utf8')) || {}; } catch { return {}; } }
const devLogged = new Set();
function rememberDevice(page, dev, uid) {
  deviceOf.set(page.context(), dev);
  if (!uid) return;
  const st = devStore();
  if (st[uid] !== dev) {
    st[uid] = dev;
    try { fs.mkdirSync(path.dirname(DEV_FILE()), { recursive: true }); fs.writeFileSync(DEV_FILE(), JSON.stringify(st)); } catch { /* не записали — живёт до перезапуска */ }
  }
  if (devLogged.has(uid)) return;
  devLogged.add(uid);
  page.evaluate((v) => {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (String(localStorage.getItem(k) || '').includes(v)) out.push(`localStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (let i = 0; i < sessionStorage.length; i++) { const k = sessionStorage.key(i); if (String(sessionStorage.getItem(k) || '').includes(v)) out.push(`sessionStorage «${k}»`); } } catch { /* нет доступа */ }
    try { for (const c of document.cookie.split(';')) { const [k, ...r] = c.split('='); if (r.join('=').includes(v)) out.push(`cookie «${k.trim()}»`); } } catch { /* нет доступа */ }
    return out;
  }, dev).then((where) => console.log(`[ourbit-exec] device-id сайта запомнен (${dev.length} симв.); на странице — ${where.length ? where.join(', ') : 'не найден в хранилищах'}`))
    .catch(() => {});
}

/**
 * БЫСТРЫЙ ВЫВОД: сеть и check_chain/v3 — запросом (сайт сам говорит isQuickWithdraw: адрес в белом списке Ourbit,
 * сумма в лимите; иначе он попросит коды почты/Google — вывод не начинаем), дальше — форма сайта (ourbit-withdraw-page).
 */
const WD = '/api/platform/asset/api/withdraw';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const codeOf = (r) => (r ? (r.code ?? r.error ?? r.status ?? '-') : '-');

async function withdraw(page, context, hdr0, s, log) {
  const coin = String(s.coin || '').toUpperCase();
  const address = String(s.address || '').trim();
  const amount = formatDecimal(s.amount);
  if (!address || !isPlainPositive(amount)) return { ok: false, error: 'Ourbit: вывод без адреса или суммы' };
  const n = await chainOf(page, hdr0, coin, s.chain, 5 * 60_000);
  if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
  if (!n.c) return fail('справочник сетей', n.r);
  if (n.c.enableWithdraw === false) return { ok: false, error: `Ourbit: вывод ${coin} в сети ${n.c.chainName} закрыт` };
  const chainName = String(n.c.chainName);
  // Прямому выводу нужна свежая капча вкладки вывода: нет (вкладка закрыта / капча израсходована) — открыть или
  // обновить вкладку и дождаться (≈4–6 с) — это всё равно быстрее формы.
  if (ourbitCaptcha.known() && !ourbitCaptcha.hasFresh(context)) {
    const t = Date.now();
    const got = await ensureCaptcha(context, coin, 12_000);
    log(`вывод: свежей капчи не было — ${got ? `получена за ${Date.now() - t} мс` : 'не получена за 12 с'}`);
  }
  const uh = ourbitCaptcha.headersOf(context);
  const hdr = { ...hdr0, 'content-type': 'application/json' };
  if (!hdr.language && uh.language) hdr.language = uh.language; // страница шлёт language на каждом шаге вывода
  const want = { coin, chainName, address, amount };
  const ctx = { page, context, hdr, uh, want, log, ref: `${ORIGIN}/ru-RU/assets/withdraw/${coin}` };
  const d = await withdrawDirect(ctx);
  if (d && !d.form) {
    prewarmForm(context, coin, true).catch(() => {}); // капча израсходована — сразу новая, к следующему выводу
    return d;
  }
  // Запасной путь — ФОРМА сайта: капчу проходит сама страница, сверка суммы/адреса/сети — по её запросу (16.11).
  // Перед формой — та же проверка сайта «без кодов?» (прямой путь мог её уже сделать).
  const cc = (d && d.cc) || await checkChain(ctx);
  const bad = quickRefusal(cc, want);
  if (bad) return bad;
  return withdrawViaForm(context, want, log);
}

const checkChain = (c) => signedPost(c.page, `${WD}/check_chain/v3`, c.hdr, { amount: c.want.amount, address: c.want.address, chainName: c.want.chainName, currency: c.want.coin }, c.ref);
const saveReq = (c) => signedPost(c.page, `${WD}/save_withdraw/v4`, c.hdr, {
  amount: c.want.amount, address: c.want.address, chain: c.want.chainName, currency: c.want.coin, isQuickWithdraw: true,
  drawImageRequest: { backGroundColor: { colorR: 248, colorG: 248, colorB: 249 }, fontColor: { colorR: 27, colorG: 28, colorB: 29 }, fontSize: 28, width: 616, alignRight: true },
}, c.ref);
/** Отказ по проверке сайта (нет ответа / просит коды) либо null — вывод без кодов возможен. */
function quickRefusal(cc, want) {
  if (!ok(cc) || !cc.data) return fail(`проверка вывода ${want.coin} ${want.chainName}`, cc);
  if (cc.data.isQuickWithdraw !== true) {
    return { ok: false, error: 'Ourbit просит коды почты/Google для этого вывода (сумма больше лимита быстрого вывода или адрес не в белом списке Ourbit) — сделайте вывод на сайте' };
  }
  return null;
}

/**
 * ПРЯМОЙ ВЫВОД (16.11, оператор: «меньше секунды»). Запросы страницы вывода, без формы:
 *   check_chain (сайт: без кодов?) ∥ GET robot.assets.withdraw с captcha-token (капча, решённая вкладкой вывода заранее)
 *   → save_withdraw → submit_withdraw (device-id — тот, что страница шлёт именно в подтверждении).
 * Заголовки шага — как у страницы на ЭТОМ шаге: у капчи — заголовки её запросов к /ucgateway, у подтверждения —
 * device-id её подтверждения (0.4.344 слал в подтверждении device-id от /ucgateway — отказ 60008).
 * Чего по журналам не видно — узнаёт сам и запоминает (ourbit-captcha → learned), значения не пишет:
 *   • подтверждение сразу после подготовки отказано 60008 → ждёт 1,2 с (страница подтверждает через ≥1,1 с), шлёт её
 *     же служебные запросы и подтверждает ещё раз ту же подготовку; прошло — впредь ждёт сразу;
 *   • после первого вывода по порядку пробует готовить вывод ОДНОВРЕМЕННО с капчей (на один ответ сайта быстрее);
 *     отказ — готовит заново по порядку и больше так не делает.
 * Возврат: итог | { form: true, cc } — прямой путь недоступен или отказан ДО денег: вывод формой. Подтверждение без
 * ответа — «мог пройти», формой НЕ повторяем (двойной вывод). Отказ 60008 — определённое «нет»: повтор безопасен.
 */
async function withdrawDirect(c) {
  const { page, context, hdr, uh, want, log, ref } = c;
  if (!ourbitCaptcha.known()) { log('вывод: формат капчи ещё не разобран — этот вывод формой (он же его разберёт)'); return { form: true }; }
  if (!uh['ucenter-token']) { log('вывод: нет заголовков капчи сайта (вкладка вывода не открыта) — формой'); return { form: true }; }
  const subDev = deviceOf.get(context) || devStore()[hdr['luminex-uid']] || '';
  if (!subDev) { log('вывод: device-id подтверждения ещё не известен — этот вывод формой (он его запомнит)'); return { form: true }; }
  const tok = ourbitCaptcha.take(context);
  if (!tok) { log('вывод: нет свежей капчи вкладки вывода — формой'); return { form: true }; }
  const st = ourbitCaptcha.learned();
  const par = st.par === true || (st.par == null && st.seqOk >= 1 && !st.gapMs);
  const t0 = Date.now();
  const lap = (() => { let t = t0; return () => { const d = Date.now() - t; t = Date.now(); return d; }; })();
  const ccP = checkChain(c);
  const rbP = call(page, 'GET', ourbitCaptcha.ROBOT_PATH, { ...hdr, ...uh, 'captcha-token': tok }, null, ref);
  let svP = par ? saveReq(c) : null;
  const [cc, rb] = await Promise.all([ccP, rbP]);
  const tCheck = lap();
  const refusal = quickRefusal(cc, want);
  if (refusal) return refusal;
  // Капча принята — ответ как у страницы: success, code=0, data пусто (данные в ответе = сайт просит показать капчу).
  if (!ok(rb) || rb.success === false || rb.data != null) {
    log(`вывод: капча не принята (code=${codeOf(rb)}, success=${rb.success}, данные ${rb.data == null ? 'нет' : 'есть'}) — формой`);
    return { form: true, cc };
  }
  let sv = await (svP || saveReq(c));
  const tSave = lap();
  if (!ok(sv) || !sv.data || !sv.data.requestId) { log(`вывод: подготовка отказана (code=${codeOf(sv)} «${sv.msg || ''}») — формой`); return { form: true, cc }; }
  let savedAt = Date.now();
  const submit = () => signedPost(page, `${WD}/submit_withdraw/v3`, { ...hdr, 'device-id': subDev }, { isQuickWithdraw: 'true', requestId: String(sv.data.requestId) }, ref);
  if (!par && st.gapMs > 0) await sleep(st.gapMs);
  let sb = await submit();
  let note = par ? 'подготовка одновременно с капчей' : (st.gapMs ? `пауза ${st.gapMs} мс` : 'по порядку');
  let parOk = par;
  if (sb.code === 60008 && par) {
    // Подготовка раньше капчи не засчитана: готовим заново (капча уже принята) и подтверждаем; впредь — по порядку.
    parOk = false;
    ourbitCaptcha.learnedSet({ par: false });
    sv = await saveReq(c);
    if (ok(sv) && sv.data && sv.data.requestId) { savedAt = Date.now(); sb = await submit(); note = 'одновременно — отказ, повтор по порядку'; }
  } else if (sb.code === 60008 && !st.gapMs) {
    // Страница подтверждает через ≥1,1 с после подготовки и перед этим шлёт два служебных запроса — повторяем так же.
    const gap = 1200;
    await sleep(Math.max(0, gap - (Date.now() - savedAt)));
    await Promise.all([call(page, 'GET', '/api/customer/risk_material/check_risk', hdr, null, ref), call(page, 'GET', '/api/common/ping', hdr, null, ref)]);
    sb = await submit();
    note = 'сразу — отказ, повтор через 1,2 с';
    if (ok(sb)) ourbitCaptcha.learnedSet({ gapMs: gap });
  }
  const tSubmit = lap();
  const times = `проверка и капча ${tCheck} мс, подготовка ${tSave} мс, подтверждение ${tSubmit} мс, всего ${Date.now() - t0} мс`;
  if (sb.error || sb.status == null) return { ok: false, error: 'Ourbit: ответа на подтверждение вывода нет — вывод МОГ пройти, проверьте историю выводов', maybe: true };
  if (!ok(sb)) {
    if (sb.code === 60008) {
      // Разбор для журнала (без значений): чем наш запрос мог отличаться от запроса страницы.
      const ucDev = uh['device-id'] || '';
      log(`вывод: подтверждение отказано 60008 (${note}; ${times}); device-id капчи и подтверждения ${!ucDev ? 'у капчи нет' : ucDev === subDev ? 'совпадают' : 'РАЗНЫЕ'}; заголовки подтверждения=[${Object.keys(hdr).concat('device-id').join(',')}]; капча: success=${rb.success} — формой`);
      return { form: true, cc };
    }
    return { ok: false, error: `Ourbit: подтверждение вывода — отказ сайта (code=${sb.code} «${sb.msg || ''}»)` };
  }
  if (sb.data && sb.data.needVerify) return { ok: false, error: 'Ourbit просит проверку (коды) — подтвердите вывод на сайте Ourbit' };
  if (parOk && st.par == null) ourbitCaptcha.learnedSet({ par: true });
  if (!par && !st.gapMs && note === 'по порядку') ourbitCaptcha.learnedSet({ seqOk: (st.seqOk || 0) + 1 });
  log(`Вывод ${want.amount} ${want.coin} → ${want.chainName}: подтверждён прямым запросом (${note}): ${times}`);
  return { ok: true, withdrawId: String((sb.data && sb.data.withdrawId) || '') };
}

async function siteCall(context, intent, log) {
  const t0 = Date.now();
  const r = await siteCallInner(context, intent, log);
  const ms = Date.now() - t0;
  if (ms > 3000) log(`запрос сайта ${intent.site && intent.site.op} шёл ${ms} мс${r && r.error ? ` (ошибка: ${String(r.error).slice(0, 80)})` : ''}`);
  return r;
}

async function siteCallInner(context, intent, log) {
  const s = intent.site || {};
  const t0 = Date.now();
  const page = await ensurePage(context, intent.symbol, log);
  const hdr = await headers(context);
  if (Date.now() - t0 > 3000) log(`вкладка/заголовки сайта готовы за ${Date.now() - t0} мс`);
  if (s.op === 'cancel') {
    if (!s.orderId) return { ok: false, error: 'Ourbit: отмена без номера заявки' };
    const r = await cancel(page, hdr, s.orderId);
    return ok(r) ? { ok: true, canceled: s.orderId } : fail(`отмена ${s.orderId}`, r);
  }
  if (s.op === 'open') {
    const { rows, r } = await openRows(page, hdr);
    return rows ? { ok: true, rows } : fail('открытые ордера', r);
  }
  if (s.op === 'depositAddress') {
    const coin = String(s.coin || '').toUpperCase();
    const n = await chainOf(page, hdr, coin, s.chain);
    if (n.why) return { ok: false, error: `Ourbit: ${n.why}` };
    if (!n.c) return fail('справочник сетей', n.r);
    if (n.c.supportMemo === true) return { ok: false, error: `Ourbit: сеть ${n.c.chainName} с memo — адрес с сайта не выдаю, возьмите адрес и memo на сайте` };
    const vcoin = String(n.c.currency || coin);
    let address = String(n.c.address || '');
    if (!address) {
      const r = await call(page, 'POST', '/api/platform/deposit/address/create', { ...hdr, 'content-type': 'application/json' }, { currency: vcoin, chainName: n.c.chainName });
      if (!ok(r) || !r.data || !r.data.address) return fail(`адрес депозита ${vcoin} ${n.c.chainName}`, r);
      // Перепроверка: тот же адрес сайт показывает у ЭТОЙ сети монеты.
      const again = await chainOf(page, hdr, coin, s.chain);
      if (!again.c || String(again.c.address || '') !== String(r.data.address)) {
        return { ok: false, error: `Ourbit: выданный адрес ${vcoin} не совпал с адресом сети ${n.c.chainName} в списке сайта — адрес не показан` };
      }
      address = String(r.data.address);
    }
    log(`адрес депозита ${coin}: просили ${s.chain} → сеть сайта «${n.c.chainName}» (${vcoin}), адрес формата ${fmtOf(address)}`);
    return { ok: true, address, vcoin, chainName: n.c.chainName, enableDeposit: n.c.enableDeposit !== false };
  }
  if (s.op === 'withdraws') {
    prewarmForm(context).catch(() => {}); // панель вывода открыта в терминале — форма вывода ждёт заранее
    const r = await call(page, 'GET', '/api/platform/withdraw/latest', hdr);
    if (!ok(r)) return fail('история выводов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      id: String(x.id || ''), coin: String(x.vcoinName || '').toUpperCase(), chain: canonChain(x.walletType), address: String(x.address || ''),
      amount: String(x.amount || '0'), fee: x.fee != null ? String(x.fee) : undefined, txHash: String(x.txid || ''),
      state: String(x.state || ''), time: Number(x.createTime) || 0, updated: Number(x.updateTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'wdConfig') {
    const r = await call(page, 'GET', '/api/platform/asset/api/withdraw/query/config/v3', hdr);
    if (!ok(r) || !r.data) return fail('настройки вывода', r);
    return { ok: true, quick: r.data.quickWithdrawEnabled === true, perWithdraw: Number(r.data.perWithdrawAmount) || 0, whiteList: r.data.whiteListEnabled === true };
  }
  if (s.op === 'withdraw') return withdraw(page, context, hdr, s, log);
  if (s.op === 'deposits') {
    const r = await call(page, 'GET', '/api/platform/asset/api/deposit/v2/latest', hdr);
    if (!ok(r)) return fail('история депозитов', r);
    const rows = (Array.isArray(r.data) ? r.data : []).map((x) => ({
      coin: String(x.vcoinName || x.currency || '').toUpperCase(), chain: canonChain(x.walletType || x.chainName),
      amount: String(x.amount || '0'), txHash: String(x.transactionHash || String(x.txid || '').split(':')[0] || ''),
      confirmations: Number(x.confirmations) || 0, required: Number(x.requireConfirmations) || 0,
      state: String(x.state || ''), time: Number(x.receiptTime || x.createTime) || 0,
    }));
    return { ok: true, rows };
  }
  if (s.op === 'balances') {
    // Список монет спота — из сводки, точные «доступно / в заявках» — запросом по этим монетам.
    const o = await call(page, 'GET', '/api/platform/asset/api/asset/overview/convert/v2', hdr);
    if (!ok(o)) return fail('балансы', o);
    const coins = (Array.isArray(o.data) ? o.data : []).filter((x) => Number(x && x.spot) > 0).map((x) => String(x.currency || '').toUpperCase()).filter(Boolean);
    if (!coins.includes('USDT')) coins.push('USDT');
    const b = await call(page, 'GET', `/api/platform/spot/asset/currency/balances?currency=${coins.map(encodeURIComponent).join(',')}`, hdr);
    if (!ok(b)) return fail('балансы', b);
    const rows = (Array.isArray(b.data) ? b.data : []).map((x) => ({ currency: String(x.currency || '').toUpperCase(), available: String(x.available || '0'), frozen: String(x.frozen || '0') }));
    return { ok: true, rows };
  }
  return { ok: false, error: `Ourbit: неизвестный запрос сайта ${s.op}` };
}

async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  attach(context);
  if (intent.site) return siteCall(context, intent, log);
  if (intent.warmup) { await ensurePage(context, intent.symbol, log); return { ok: true, warmed: true }; }
  if (intent.loginCheck || intent.closeStale || intent.balance || intent.orders || intent.cancelAll) {
    return intent.loginCheck || intent.closeStale ? { ok: true, skipped: true } : { ok: false, error: 'Ourbit: этот вид намерения не поддержан (балансы/ордера — запросом сайта)' };
  }
  return placeOrder(context, intent, log);
}

module.exports = { attach, executeIntent, toPair, _coinGate: coinGate, _rowCoin: rowCoin, _canonChain: canonChain, _withdrawDirect: withdrawDirect, _deviceOf: deviceOf };

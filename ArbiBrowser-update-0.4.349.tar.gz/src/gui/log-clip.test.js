'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { fullClip, testClip } = require('./log-clip');

const E = (line, t = new Date(2026, 10, 16, 22, 5, 7, 42).getTime()) => ({ t, line });

test('весь журнал — строки со временем, как на экране', () => {
  assert.equal(fullClip([E('a'), E('b')]), '[22:05:07.042] a\n[22:05:07.042] b');
});

test('запись теста: успешные опросы и выбор профиля убраны, вывод и ошибочный опрос остаются', () => {
  const r = testClip([
    E('[ourbit-exec] Намерение aa11 [запрос сайта: balances]'),
    E('[exec] accountId=acc1 → открытый прокси-профиль p1'),
    E('[ourbit-exec] Результат aa11: ok'),
    E('[ourbit-exec] Намерение bb22 [запрос сайта: withdraw USDT bsc]'),
    E('[exec] accountId=acc1 → открытый прокси-профиль p1'),
    E('[ourbit-exec] вывод: подтверждение отказано 60008'),
    E('[ourbit-exec] Результат bb22: ok'),
    E('[ourbit-exec] Намерение cc33 [запрос сайта: open]'),
    E('[ourbit-exec] Результат cc33: ошибка: нет входа'),
    E('[ourbit-exec] Намерение dd44: BUY 1 BTC/USDT LIMIT'),
    E('[ourbit-exec] Результат dd44: ok'),
  ]);
  const lines = r.text.split('\n').map((l) => l.slice(15));
  assert.deepEqual(lines, [
    '[ourbit-exec] Намерение bb22 [запрос сайта: withdraw USDT bsc]',
    '[ourbit-exec] вывод: подтверждение отказано 60008',
    '[ourbit-exec] Результат bb22: ok',
    '[ourbit-exec] Намерение cc33 [запрос сайта: open]',
    '[ourbit-exec] Результат cc33: ошибка: нет входа',
    '[ourbit-exec] Намерение dd44: BUY 1 BTC/USDT LIMIT',
    '[ourbit-exec] Результат dd44: ok',
  ]);
  assert.equal(r.kept, 7);
  assert.equal(r.total, 11);
});

test('очень длинная строка обрезается с пометкой', () => {
  const r = testClip([E('x'.repeat(1000))]);
  assert.match(r.text, /x{900} …\(\+100 симв\.\)$/);
});

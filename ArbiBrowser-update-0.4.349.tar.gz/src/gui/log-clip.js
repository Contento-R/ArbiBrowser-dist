'use strict';

/**
 * log-clip.js — журнал для вставки в чат одним щелчком (оператор 16.11: «пока выделяю кусок, журнал уезжает»).
 *   fullClip — весь буфер журнала как на экране;
 *   testClip — запись «Начать тест → Закончить тест» без фонового шума: опросы сайта (остатки, ордера, история),
 *              завершившиеся «ok», и строки выбора профиля убираются; всё остальное — как есть. Ошибочный опрос остаётся.
 */
const POLL = /Намерение (\S+) \[запрос сайта: (?:balances|open|deposits|withdraws|wdConfig)\b[^\]]*\]/;
const RESULT = /Результат (\S+): (.*)$/;
const PICK = /\[exec\] accountId=\S+ → открытый прокси-профиль/;
const MAX_LINE = 900;

const p = (n, w = 2) => String(n).padStart(w, '0');
function fmt(e) {
  const d = new Date(e.t);
  return `[${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}] ${e.line}`;
}
const fullClip = (entries) => entries.map(fmt).join('\n');

function testClip(entries) {
  const polls = new Set();
  const failed = new Set();
  for (const e of entries) {
    const m = e.line.match(POLL);
    if (m) polls.add(m[1]);
    const r = e.line.match(RESULT);
    if (r && !/^ok\b/.test(r[2])) failed.add(r[1]);
  }
  const kept = entries.filter((e) => {
    if (PICK.test(e.line)) return false;
    const m = e.line.match(POLL) || e.line.match(RESULT);
    return !(m && polls.has(m[1]) && !failed.has(m[1]));
  });
  const text = kept.map((e) => fmt(e.line.length > MAX_LINE ? { t: e.t, line: `${e.line.slice(0, MAX_LINE)} …(+${e.line.length - MAX_LINE} симв.)` } : e)).join('\n');
  return { text, kept: kept.length, total: entries.length };
}

module.exports = { fullClip, testClip };

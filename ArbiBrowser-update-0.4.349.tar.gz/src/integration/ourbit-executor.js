'use strict';

/**
 * ourbit-executor.js — исполнитель Ourbit (вся спот-торговля через сайт, оператор 2026-11-16).
 * Тонкая обёртка над общим транспортом executor-core.js, как xt-executor.js.
 */

const { makeExecutor, requestJson } = require('./executor-core');

const impl = makeExecutor({
  pendingPath: '/api/integrations/arbibrowser/ourbit/pending',
  resultPath: '/api/integrations/arbibrowser/ourbit/result',
  waitEnv: 'ARBI_OURBIT_WAIT_MS',
  pollEnv: 'ARBI_OURBIT_POLL_MS',
});

module.exports = { pollOnce: impl.pollOnce, startLoop: impl.startLoop, requestJson };

'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { _learn } = require('./ourbit-captcha');

const sc = { captcha_id: 'c'.repeat(32), lot_number: 'a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6', pass_token: 'p'.repeat(64), gen_time: '1794856897', captcha_output: 'Zx_9+/abcDEF0123456789==' };

test('шаблон captcha-token: поля на места, разделители остаются', () => {
  const tok = `gen_time=${sc.gen_time}&lot_number=${sc.lot_number}&pass_token=${sc.pass_token}&captcha_output=${encodeURIComponent(sc.captcha_output)}&captcha_id=${sc.captcha_id}`;
  const l = _learn(tok, sc);
  assert.strictEqual(l.clean, true);
  assert.strictEqual(l.template, 'gen_time={gen_time}&lot_number={lot_number}&pass_token={pass_token}&captcha_output={captcha_output|u}&captcha_id={captcha_id}');
});

test('чужой seccode — шаблон не принимается', () => {
  const l = _learn('g' + 'x'.repeat(40), sc);
  assert.strictEqual(l.clean, false);
});

test('шаблон captcha-token: «geetest base64(JSON)» с ключами в camelCase', () => {
  const o = { lotNumber: sc.lot_number, captchaOutput: sc.captcha_output, passToken: sc.pass_token, genTime: sc.gen_time };
  const tok = 'geetest ' + Buffer.from(JSON.stringify(o)).toString('base64');
  const l = _learn(tok, sc);
  assert.strictEqual(l.clean, true);
  assert.strictEqual(l.template.prefix, 'geetest ');
  assert.deepStrictEqual(l.template.keys.map((x) => x.f), ['lot_number', 'captcha_output', 'pass_token', 'gen_time']);
});

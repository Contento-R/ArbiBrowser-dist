'use strict';

/**
 * bingx-order-page.js — Стадия 3: РЕАЛЬНОЕ исполнение web-ордера BingX в живой
 * странице браузера профиля. Точное зеркало проверенной логики xt-order-page.js
 * (доверенный Playwright-ввод через CDP Input — isTrusted=true; SPA-смена пары;
 * strict fieldFresh; ensureFilled; ST-детект по DOM-метке; confirmOrderPrompt для
 * цены вне рынка; nofunds soft-retry; закрытие risk/предупреждающих модалок).
 *
 * BingX-специфика ПОДТВЕРЖДЕНА оператором 2026-07-09 (DevTools на живом BingX):
 *   - URL: https://bingx.com/ru/spot/{PAIR}, пара СЛИТНО uppercase (GENSYNUSDT);
 *   - поля ордера: input.tl-input-inner ([0]=цена,[1]=кол-во,[2]=сумма);
 *   - кнопка ордера: button.btn-order-bl (текст «Купить»/«Продать»);
 *   - поиск пары: input.symbol-picker__search-input;
 *   - endpoint: POST api-app.we-api.com/api/v1/spot/order/confirm
 *     → {code:0, data:{orderNo, status}} (orderNo — точный из raw, int64).
 * НЕ до конца подтверждено (broad-заготовки, переопределяемы env ARBI_BINGX_SEL_*):
 *   - SELECTORS.searchResult (строка результата в symbol-picker);
 *   - вкладки стороны/лимита (по тексту).
 * Живой прогон в DRY-RUN обязателен ДО ARBI_BINGX_EXEC_LIVE=1.
 *
 * Нюанс: displayName ≠ coinName (токен «AI» в URL/API = GENSYN) — при
 * несоответствии терминал должен слать canonical coinName в symbol.
 */

const { canOpenPairTab, markPairTab, markOwned, ensureTabInFront, newBackgroundPage, isTradePairUrl } = require('./pair-tabs');
const fs = require('node:fs');
const path = require('node:path');
const config = require('../../config');
const { formatDecimal, isPlainPositive, parseVolumeLimit, parseRejectLimit, VOLUME_LIMIT_HINT_RE, VOLUME_MIN_HINT_RE, pairGate, fieldFresh } = require('./order-utils');

const BINGX_ORIGIN = process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com';
// URL спот-пары: env-шаблон с {pair}. ПОДТВЕРЖДЕНО оператором 2026-07-09:
// https://bingx.com/ru/spot/GENSYNUSDT — пара в URL СЛИТНО, uppercase, БЕЗ разделителя.
const BINGX_TRADE_URL_TMPL = process.env.ARBI_BINGX_TRADE_URL || 'https://bingx.com/ru/spot/{pair}';
// regex ответа постановки ордера. ПОДТВЕРЖДЁН на бою 2026-07-09:
// POST https://api-app.we-api.com/api/v1/spot/order/confirm → {code:0, data:{orderNo, status}}.
// IM-2: только ТОЧНЫЕ endpoint'ы постановки (подтверждён на бою 2026-07-09:
// POST …/spot/order/confirm). Прежняя широкая альтернатива /spot/.*order матчила
// частый поллинг открытых ордеров BingX → захват ЧУЖОГО ответа как ответа нашего
// ордера (ложный успех с чужим orderNo). Переопределяемо ARBI_BINGX_ORDER_RE.
const ORDER_PLACE_RE = new RegExp(process.env.ARBI_BINGX_ORDER_RE || '/spot/order/(confirm|create|place)\\b', 'i');

// Селекторы формы ордера BingX. ПОДТВЕРЖДЕНЫ оператором 2026-07-09 (DevTools на
// https://bingx.com/ru/spot/GENSYNUSDT). Каждый переопределяется через env.
/**
 * Снимок состояния страницы ордера: почему заявка не ушла — кнопка disabled,
 * какие значения в полях, есть ли логин-стена, что говорят ошибки и модалки.
 *
 * Вынесено из главной ветки отказа, чтобы ТОТ ЖЕ снимок можно было снять и с
 * вкладки-части при дроблении (#58: молчаливых отказов не бывает). Раньше часть
 * сообщала только «клик не отправил запрос ордера», а диагностика печаталась с
 * ГЛАВНОЙ вкладки, где лежит полная сумма — и в логе была видна ошибка биржи про
 * лимит 500 USDT, не имеющая отношения к настоящей причине отказа части
 * (разбор инцидента STONK/BingX 2026-09-16).
 */
async function orderPageDiag(pg) {
  if (pg.isClosed && pg.isClosed()) return { closed: true };
  return pg.evaluate((SEL) => {
    const vis = (el) => el && el.offsetParent !== null;
    const q = (s) => Array.from(document.querySelectorAll(s));
    const sub = q(SEL.submit).find(vis) || q(SEL.submit)[0] || null;
    const st = sub ? getComputedStyle(sub) : null;
    const inputs = q(SEL.numberInput).filter(vis).map((i) => i.value);
    const body = (document.body.innerText || '').slice(0, 4000);
    const errs = q('[class*="error" i],[class*="invalid" i],[class*="tip" i],[class*="warn" i]')
      .filter(vis).map((e) => (e.innerText || '').replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 6);
    const dialogs = q('[role="dialog"],[class*="odal"],[class*="ialog"],[class*="opup"]')
      .filter(vis).map((el) => (el.innerText || '').replace(/\s+/g, ' ').slice(0, 120)).slice(0, 3);
    // Кто РЕАЛЬНО лежит в точке клика. Кнопка бывает активна и без ошибок, а
    // клик всё равно не доходит до обработчика биржи — потому что сверху лежит
    // прозрачная накладка (у BingX идёт A/B-раскатка интерфейса, hs-prod-abtest-sdk).
    // `force: true` актуальность элемента не проверяет: событие уходит по
    // координатам, а браузер отдаёт его САМОМУ ВЕРХНЕМУ элементу в этой точке.
    // Без этого поля причина «клик не отправил запрос ордера» неотличима от
    // десятка других (разбор STONK/BingX 2026-09-16).
    const desc = (n) => {
      if (!n || !n.tagName) return '?';
      const cls = typeof n.className === 'string' && n.className.trim()
        ? '.' + n.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
      return `${n.tagName.toLowerCase()}${n.id ? '#' + n.id : ''}${cls}`;
    };
    let hitPoint = null;
    if (sub) {
      const r = sub.getBoundingClientRect();
      const x = Math.round(r.left + r.width / 2);
      const y = Math.round(r.top + r.height / 2);
      const el = document.elementFromPoint(x, y);
      const chain = [];
      for (let n = el, i = 0; n && i < 4; n = n.parentElement, i += 1) chain.push(desc(n));
      hitPoint = {
        rect: `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}`,
        point: `${x},${y}`,
        hit: el ? chain.join(' < ') : '(в точке клика ничего нет)',
        // true = клик попадёт в кнопку; false = перехватывает кто-то другой.
        reachesSubmit: !!el && (el === sub || sub.contains(el) || el.contains(sub)),
      };
    }
    return {
      hitPoint,
      submitText: sub ? (sub.innerText || '').replace(/\s+/g, ' ').trim() : '(нет кнопки сабмита)',
      submitDisabled: sub ? !!(sub.disabled || sub.getAttribute('aria-disabled') === 'true' || /disabl/i.test(sub.className) || (st && (st.pointerEvents === 'none' || parseFloat(st.opacity || '1') < 0.5))) : null,
      inputValues: inputs,
      loginWall: /войдите|войти в|log ?in|sign ?in|请登录|登录/i.test(body),
      errors: errs,
      dialogs,
      url: location.href,
      hidden: document.visibilityState,
    };
  }, SELECTORS).catch((e) => ({ err: e.message }));
}

const SELECTORS = {
  // Строка поиска пары в дропдауне выбора пары (symbol-picker). ПОДТВЕРЖДЕНО:
  // <input class="symbol-picker__search-input" placeholder="Искать криптовалюту">.
  search: process.env.ARBI_BINGX_SEL_SEARCH || 'input.symbol-picker__search-input,input[placeholder*="Искать"],input[placeholder*="Search"]',
  // Открывашка дропдауна выбора пары — клик по названию текущей пары (h1 «AI/USDT»
  // со стрелкой ▾). h1-клик делает focusSearchInput; тут доп. фолбэки.
  searchOpen: process.env.ARBI_BINGX_SEL_SEARCH_ICON || '[class*="symbol-picker"],[class*="symbolName"],[class*="pair-select"]',
  // ТРИГГЕР открытия дропдауна выбора пары. ПОДТВЕРЖДЕНО оператором 2026-07-09:
  // открывает поиск клик по ЗАГОЛОВКУ <h1 class="symbol-name">AI/USDT</h1>.
  // Ставим `.symbol-name` ПЕРВЫМ (точный триггер); прежний общий `h1` брал .first()
  // и мог попасть в ДРУГОЙ <h1> на странице → дропдаун не открывался → перезагрузка.
  // symbol-wrap/detail-wrap — фолбэки для сборок с иной вёрсткой заголовка.
  pairOpen: process.env.ARBI_BINGX_SEL_PAIR_OPEN
    || 'h1.symbol-name,[class*="symbol-name"],[class*="symbol-detail-wrap"],[class*="symbol-wrap"],[class*="symbolName"],[class*="pair-select"]',
  // Числовые поля формы (3 шт: [0]=цена, [1]=количество, [2]=сумма). ПОДТВЕРЖДЕНО:
  // <input class="tl-input-inner"> — цена val=0.02675, кол-во и сумма пустые.
  numberInput: process.env.ARBI_BINGX_SEL_NUMBER || 'input.tl-input-inner',
  // Кнопки САБМИТА ордера. ПОДТВЕРЖДЕНО оператором 2026-07-09: РАЗНЫЕ по стороне —
  // Buy=<button class="...btn-order-blue">Купить</button>,
  // Sell=<button class="...btn-order-red">Продать</button>. Неактивная сторона имеет
  // класс bx-btn-disabled. Обе кнопки присутствуют в DOM.
  submitBuy: process.env.ARBI_BINGX_SEL_BUY || 'button.btn-order-blue',
  submitSell: process.env.ARBI_BINGX_SEL_SELL || 'button.btn-order-red',
  submit: process.env.ARBI_BINGX_SEL_SUBMIT || 'button[class*="btn-order-"]',
  // Переключатель стороны — вкладки «Купить»/«Продать» над формой (текст ровно).
  sideBuyRe: process.env.ARBI_BINGX_SIDE_BUY_RE || '^\\s*(Купить|Buy)\\s*$',
  sideSellRe: process.env.ARBI_BINGX_SIDE_SELL_RE || '^\\s*(Продать|Sell)\\s*$',
  // Вкладка «Лимитный» (BingX: Рыночный/Лимитный/Т-п/с-л).
  limitTab: process.env.ARBI_BINGX_SEL_LIMIT || 'text=/^(Limit|Лимитный|Лимит)$/i',
  // Кнопка подтверждения в модалке ордера BingX. ВАЖНО: у BingX модалки
  // подтверждения ордера НЕТ (ордер уходит по одному клику Buy), поэтому «Купить»/
  // «Продать» сюда НЕ включаем — иначе confirm вслепую кликал бы сам сабмит
  // (повторный ордер). Оставляем только реальные confirm-кнопки на случай промо-модалок.
  confirm: process.env.ARBI_BINGX_SEL_CONFIRM || 'button:has-text("Подтвердить"),button:has-text("Confirm"),button:has-text("确认")',
  // Строка результата в выпадающем поиске пары (symbol-picker). Broad — уточнить при diag.
  // Строка результата в выпадающем списке пары. ПОДТВЕРЖДЕНО DOM оператора: строки
  // содержат блок `symbol-wrap`/`symbol-detail-wrap` с текстом «BASE/USDT».
  searchResult: process.env.ARBI_BINGX_SEL_SEARCH_RESULT || '[class*="symbol-picker"] [class*="symbol-detail-wrap"],[class*="symbol-picker"] [class*="symbol-wrap"],[class*="symbol-detail-wrap"],[class*="symbol-wrap"],[class*="symbol-picker"] [class*="item"],[class*="symbol-item"],[class*="coin-item"]',
  // Строка результата СТРОГО внутри дропдауна выбора пары (scoped) — для фолбэка
  // «кликнуть верхний результат», когда точный текст не совпал (displayName ≠ тикер).
  // Scoped, чтобы .first() не поймал заголовок текущей пары в шапке.
  searchResultScoped: process.env.ARBI_BINGX_SEL_SEARCH_RESULT_SCOPED || '[class*="symbol-picker"] [class*="symbol-detail-wrap"],[class*="symbol-picker"] [class*="symbol-wrap"],[class*="symbol-picker"] [class*="item"]',
};
// Общие хелперы страницы (ввод/оверлеи/модалки/готовность сабмита) — один код на три
// биржи, различия — в профиле `page-driver.js`.
const { typeNumber, fastSetInputs, isSubmitReady, dismissBlockingModal, dismissOverlays, loginWall } = require('./page-driver').driverFor('bingx', SELECTORS);
const { loginRequiredError } = require('./page-driver');

// Канон "BASE/QUOTE" → ВНУТРЕННИЙ формат "BASE_USDT" (uppercase, underscore) —
// совместим со split('_') в changePairSpa (base для поиска). Для URL '_' убирается
// (bingxUrlPair → "GENSYNUSDT"), т.к. BingX держит пару в адресе СЛИТНО.
function toBingxPair(symbol) {
  return String(symbol).toUpperCase().replace('/', '_');
}

// Внутренний "BASE_USDT" → URL-форма BingX "BASEUSDT" (слитно, регистр как есть).
function bingxUrlPair(pair) {
  return String(pair).replace(/_/g, '');
}

/**
 * Содержит ли URL нужную пару — ТЕРПИМО к percent-кодировке. Токены с non-ASCII
 * именем (напр. китайское 币安底裤_usdt) в адресной строке XT кодируются
 * (%E5%B8%81…), поэтому сырое u.includes('/trade/币安底裤_usdt') НЕ находит
 * совпадения НИКОГДА → ложный вывод «пара не открыта» → лишняя смена пары/
 * перезагрузка, и ложный timeout завершения SPA. Сравниваем и сырой, и
 * декодированный URL.
 */
function urlHasPair(u, pair) {
  const needle = '/spot/' + bingxUrlPair(pair).toLowerCase();
  let dec = u;
  try { dec = decodeURIComponent(u); } catch { /* битый % — оставляем сырой */ }
  return String(u).toLowerCase().includes(needle) || String(dec).toLowerCase().includes(needle);
}

/**
 * Кэш «какая пара открыта на этой вкладке» (page.__arbiPair = {pair, path}) —
 * зеркало mexc-order-page.rememberPair. Валиден, пока pathname вкладки совпадает
 * с записанным (ручная навигация оператора инвалидирует сам собой). Пишем ТОЛЬКО
 * в точках подтверждённого перехода — кэш не может увести ордер на чужую пару.
 * Убирает повторные DOM-проверки между интентами одного токена (warmup → ордер
 * → баланс), особенно для пар с displayName ≠ coinName (urlHasPair не совпадает).
 */
function rememberPair(page, pair) {
  try { page.__arbiPair = { pair: String(pair), path: new URL(page.url()).pathname }; }
  catch { page.__arbiPair = null; }
}
function cachedPairWarm(page, u, pair) {
  const c = page.__arbiPair;
  if (!c || c.pair !== String(pair)) return false;
  try { return new URL(u).pathname === c.path; } catch { return false; }
}

/**
 * Находит уже открытую страницу bingx.com в контексте профиля, либо открывает
 * новую. Возвращает Playwright Page.
 */
async function getBingxPage(context, pair, log) {
  const wantUrl = BINGX_TRADE_URL_TMPL.replace('{pair}', bingxUrlPair(pair));
  // Переиспользуем существующую вкладку bingx.com (там живая залогиненная сессия).
  // Спящая вкладка (экономия памяти) физически на about:blank, но помнит свой URL.
  // ⚠️ Без этого поиск её НЕ ВИДЕЛ и открывал ДУБЛЬ рядом (жалоба оператора
  // 2026-08-30: «старые вкладки подвисают, открываются новые»): спящих вкладок
  // BingX копилось всё больше, каждая с живой залогиненной сессией. Разбудить
  // свою дешевле и безопаснее, чем плодить новые. Образец — getMexcPage.
  let sleeping = null;
  let sleepingSame = null; // спящая вкладка ИМЕННО этой пары
  let firstLive = null; // первая живая вкладка BingX не на нашей паре
  for (const p of context.pages()) {
    let u = '';
    try { u = p.url(); } catch { /* закрыта */ }
    // ФОНОВУЮ страницу баланса (__arbiBalanceBg) НЕ отдаём под реальный ордер: она
    // read-only и её в любой момент уводит/закрывает параллельное чтение баланса —
    // ордер ушёл бы в скрытый таб, который тут же навигируют прочь.
    try { if (p.__arbiBalanceBg === true || p.__arbiOrdersBg === true) continue; } catch { /* игнор */ }
    if (!u.startsWith(BINGX_ORIGIN) && typeof p.__arbiSleepUrl === 'string' && p.__arbiSleepUrl.startsWith(BINGX_ORIGIN)) {
      if (urlHasPair(p.__arbiSleepUrl, pair)) sleepingSame = p;
      if (!sleeping) sleeping = p;
      continue;
    }
    if (u.startsWith(BINGX_ORIGIN)) {
      // Уже на нужной паре — тёплая вкладка (терпимо к кодировке URL). Плюс
      // DOM-подтверждение: заголовок пары h1 содержит base токена — надёжно даже
      // если XT кладёт в URL внутренний id вместо имени. Тёплая вкладка → НИКАКОЙ
      // смены пары/перезагрузки: ордер уходит напрямую (та самая жалоба по ST).
      // switched=false → пара НЕ менялась: React-обработчик кнопки ордера уже
      // «живой», первый клик отправит POST сразу.
      // Кэш пары (__arbiPair): та же пара И pathname не менялся с подтверждённого
      // перехода → тёплая сразу, без DOM-проверок и повторного поиска.
      if (cachedPairWarm(p, u, pair)) return { page: markPairTab(p), cold: false, switched: false };
      if (urlHasPair(u, pair)) { rememberPair(p, pair); return { page: markPairTab(p), cold: false, switched: false }; }
      const base = String(pair).split('_')[0];
      // CR-1: граница токена — иначе клон-тикер (ARTX⊃ART) ложно считается тёплой
      // вкладкой, ордер уходит на чужой токен без навигации.
      const h1Match = await p.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![A-Za-z0-9])', 'i') })
        .first().isVisible().catch(() => false);
      if (h1Match) return { page: markPairTab(p), cold: false, switched: false };
      // Кандидат под смену пары / место в пуле — решаем ПОСЛЕ осмотра ВСЕХ вкладок.
      if (!firstLive) firstLive = p;
    }
  }
  // СПЯЩАЯ ВКЛАДКА ЭТОЙ ЖЕ ПАРЫ — будим её, а не открываем соседку. Лог оператора
  // 2026-09-08 06:48: после рестарта пара STONK лежала спящей (about:blank с
  // запомненным URL), но живая вкладка другой пары дала «место в пуле» → открылась
  // ВТОРАЯ вкладка STONK, и уборка потом закрыла обе. Дубль невозможен, если
  // спящую своей пары проверять ДО пула.
  if (sleepingSame) {
    log(`Бужу спящую вкладку своей пары: ${wantUrl}`);
    sleepingSame.__arbiSleepUrl = null;
    await sleepingSame.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleepingSame.url(), pair)) rememberPair(sleepingSame, pair);
    return { page: markPairTab(sleepingSame), cold: true, switched: true };
  }
  // Тёплой вкладки пары нет. Раньше решение принималось на ПЕРВОЙ чужой вкладке
  // BingX, не глядя дальше: если вкладка нужной пары стояла в списке второй,
  // открывался ДУБЛЬ (лог 05.09: два прогрева AMEMECOIN подряд → две вкладки, а
  // уборка потом закрывала обе). Теперь дубль невозможен по построению.
  if (firstLive) {
    const p = firstLive;
    // ПУЛ ТЁПЛЫХ ВКЛАДОК: место в пуле есть → пару НЕ меняем, а открываем ей
    // отдельную вкладку. Так вкладка прежней пары остаётся тёплой, и обе пары
    // дальше работают без навигации вовсе (оператор торгует несколькими
    // одновременно). Пул полон → прежний путь: смена пары в этой вкладке.
    if (canOpenPairTab(context, BINGX_ORIGIN)) {
      log(`Открываю отдельную вкладку под пару (пул тёплых вкладок): ${pair}`);
      const fresh = markPairTab(markOwned(await newBackgroundPage(context)));
      await fresh.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      // Навигация не состоялась вовсе (прокси/сеть) — НЕ оставляем пустую about:blank
      // вкладку висеть и не заполняем форму на пустой странице: закрываем и честно
      // отказываем (скрин оператора 2026-09-08: восемь about:blank в окне профиля).
      if (String(fresh.url()).startsWith('about:')) {
        await fresh.close().catch(() => {});
        throw new Error(`страница пары не открылась (${wantUrl}) — проверьте прокси/сеть профиля`);
      }
      if (urlHasPair(fresh.url(), pair)) rememberPair(fresh, pair);
      return { page: fresh, cold: true, switched: true };
    }
    // Смена пары ПО УМОЛЧАНИЮ — SPA-поиск (без перезагрузки): форма остаётся
    // ТЁПЛОЙ (React не перегружается) → первый ордер быстрее, чем через goto.
    // goto-режим (свежая страница с нуля) доступен через ARBI_BINGX_NAV=goto.
    const navMode = (process.env.ARBI_BINGX_NAV || 'spa').toLowerCase();
    if (navMode === 'goto') {
      log(`Открываю страницу токена с нуля (goto): ${pair}`);
      await p.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      if (urlHasPair(p.url(), pair)) rememberPair(p, pair); // goto с catch — кэшируем только подтверждённый URL
      return { page: p, cold: true, switched: true };
    }
    const r = await changePairSpa(p, pair, log);
    return { page: p, cold: !r.spa, switched: true };
  }
  // Живых вкладок BingX нет, но есть СПЯЩАЯ — будим её вместо открытия дубля.
  if (sleeping) {
    log(`Бужу спящую вкладку BingX: ${wantUrl}`);
    sleeping.__arbiSleepUrl = null;
    await sleeping.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(sleeping.url(), pair)) rememberPair(sleeping, pair);
    return { page: sleeping, cold: true, switched: true };
  }
  log(`Открываю страницу BingX: ${wantUrl}`);
  const page = markOwned(await newBackgroundPage(context));
  await page.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 });
  // goto резолвится и на РЕДИРЕКТЕ (логин/регион-блок) — кэшируем только подтверждённый
  // URL пары, иначе отравленный кэш вечно отдаёт чужую страницу как «тёплую».
  if (urlHasPair(page.url(), pair)) rememberPair(page, pair);
  markPairTab(page);
  return { page, cold: true, switched: true }; // первая загрузка вкладки → форма «сырая»
}

/**
 * Смена торговой пары БЕЗ перезагрузки страницы — через строку поиска сайта
 * (как это делает пользователь вручную). Best-effort: любой сбой → фолбэк на
 * page.goto (XT может быть SPA или нет — фолбэк обязателен).
 * @returns {Promise<{spa:boolean}>} spa=true если сменили без перезагрузки.
 */
/**
 * Открыть дропдаун выбора пары и сфокусировать его строку поиска; вернуть её локатор.
 *
 * Ключевое (подтверждено оператором 2026-07-09): поиск пары XT спрятан ВНУТРИ дропдауна,
 * который открывается кликом по ЗАГОЛОВКУ текущей пары <h1>BASE/USDT>. Поэтому:
 * 1) клик по заголовку-h1 (содержит "/") → дропдаун с поиском и списком пар;
 * 2) ждём поле поиска ВИДИМЫМ (не открылось — throw → быстрый фолбэк на перезагрузку);
 * 3) фокус ТРОЙНЫМ КЛИКОМ мышью (element-targeted). НЕ page-level Ctrl+A/JS focus —
 *    они выделяли всю страницу, а ввод уходил в никуда.
 */
async function focusSearchInput(page) {
  // ⚠️ ГЛАВНАЯ причина медленного 1-го ордера (перезагрузка вместо SPA): залипшая
  // risk/ST-модалка от ПРОШЛОГО токена (напр. 币安底裤 «Предупреждение о рисках» с
  // «Понятно», не нажатым пользователем) перехватывает pointer events → клик по h1
  // НЕ открывает дропдаун выбора пары → поле поиска не становится visible → timeout
  // → фолбэк на перезагрузку (6с). Закрываем модалку ПЕРЕД кликом (дёшево, ~мс).
  await dismissBlockingModal(page);
  // Открыть дропдаун ВЫБОРА ПАРЫ кликом по заголовку текущей пары. ВАЖНО: НЕ кликаем
  // иконку хедер-поиска (_searchIconWrapper_) — она открывает ГЛОБАЛЬНЫЙ поиск
  // (Деривативы/Спот/Функции), ввод уходит не туда. Заголовок пары на разных сборках
  // BingX — это НЕ всегда <h1>: подтверждён DOM оператора, где триггер — блок
  // symbol-wrap/symbol-detail-wrap. Перебираем кандидаты (SELECTORS.pairOpen), плюс
  // <h1> как последний фолбэк; для каждого КОРОТКО ждём появления поля поиска пары.
  const input = page.locator(SELECTORS.search).first();
  const triggers = [
    ...SELECTORS.pairOpen.split(',').map((s) => page.locator(s.trim(), { hasText: '/' }).first()),
    ...SELECTORS.pairOpen.split(',').map((s) => page.locator(s.trim()).first()),
    page.locator('h1', { hasText: '/' }).first(),
  ];
  let opened = false;
  for (const trigger of triggers) {
    try {
      await trigger.click({ timeout: 1200 });
    } catch { await dismissBlockingModal(page); continue; }
    try {
      await input.waitFor({ state: 'visible', timeout: 1200 });
      opened = true;
      break;
    } catch { await dismissBlockingModal(page); }
  }
  if (!opened) {
    // Ни один триггер не открыл дропдаун — последняя попытка force-кликом по первому
    // кандидату (на случай остаточного невидимого оверлея), затем ждём поле дольше.
    await dismissBlockingModal(page);
    await triggers[0].click({ timeout: 1500, force: true }).catch(() => {});
    await input.waitFor({ state: 'visible', timeout: 2500 });
  }
  await input.scrollIntoViewIfNeeded({ timeout: 1000 }).catch(() => {});
  // ФОКУС без указателя: input.focus() = DOM-focus, не требует поле в видимой области
  // (клик мышью падал "Element is outside of the viewport", когда дропдаун за окном).
  await input.focus();
  return input;
}

async function changePairSpa(page, pair, log) {
  page.__arbiPair = null; // уходим со старой пары — кэш вкладки недействителен
  const [base, quote] = String(pair).split('_');
  // Путь ДО перехода — чтобы finishSpa засчитал успех по САМОМУ ФАКТУ смены URL для
  // токенов, где displayName ≠ coinName (GENSYN показан как «AI/USDT», в адресе
  // /spot/AIUSDT): ни urlpair 'gensynusdt', ни base 'gensyn' в h1 НЕ совпадут, и
  // раньше finishSpa падал в timeout 4с → перезагрузка → задержка (жалоба оператора).
  let prevPath = '';
  try { prevPath = await page.evaluate(() => location.pathname); } catch { /* игнор */ }
  const finishSpa = async () => {
    // Завершение SPA-перехода терпимо к кодировке URL И к тому, что XT может
    // держать в адресе внутренний id: успех, если decoded pathname содержит пару
    // ИЛИ заголовок h1 уже показывает base токена (напр. 币安底裤/USDT). Раньше
    // сырое includes('/trade/币安底裤_usdt') не совпадало → timeout 4с → перезагрузка.
    await page.waitForFunction((args) => {
      let dec = location.pathname;
      try { dec = decodeURIComponent(location.pathname); } catch { /* оставляем сырой */ }
      const path = (dec + ' ' + location.pathname).toLowerCase();
      if (path.includes('/spot/' + args.urlpair)) return true;
      // ЛЮБОЙ видимый h1 с base (не только первый в DOM: первый может быть
      // ещё не перерисован/скрыт баннером → ложный «не перешли» → лишний reload).
      for (const h1 of document.querySelectorAll('h1')) {
        if (h1.offsetParent !== null && (h1.textContent || '').toLowerCase().includes(args.base)) return true;
      }
      // displayName ≠ coinName: URL сменился на ДРУГУЮ спот-пару (не прежнюю) —
      // засчитываем переход (форму дождёмся ниже waitForSelector).
      return !!(args.prev && location.pathname !== args.prev && /\/spot\//i.test(location.pathname));
    }, { urlpair: bingxUrlPair(pair).toLowerCase(), base: String(base).toLowerCase(), prev: prevPath },
      // 4000 → 5000 (env ARBI_BINGX_SPA_WAIT_MS): клик уже состоялся, ранний
      // timeout вёл в полный reload уже выбранного токена (зеркало MEXC-фикса).
      { timeout: Number(process.env.ARBI_BINGX_SPA_WAIT_MS || 5000) });
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 4000 }).catch(() => {});
    rememberPair(page, pair); // переход подтверждён — следующие интенты без DOM-проверок
  };

  let step = 'search-input';
  try {
    const input = await focusSearchInput(page);
    // Ввод названия токена ЦЕЛИКОМ (fill = очистка + вставка всей строки разом +
    // input-событие), а не посимвольно — быстрее и React-фильтр поиска триггерится.
    // Фолбэк: если fill не дал результата — досылаем один keystroke (пробел+backspace).
    await input.fill(base).catch(async () => {
      await input.selectText().catch(() => {});
      await input.pressSequentially(base, { delay: 0 }).catch(() => {});
    });
    step = 'result-item';
    // Строка результата НУЖНОЙ пары по тексту тикера. У части токенов displayName ≠
    // coinName (напр. GENSYN показан как «AI/USDT») — тогда точный текст не совпадёт;
    // раз мы ввели ТОЧНЫЙ тикер, ПЕРВАЯ строка списка и есть нужный токен → кликаем её.
    const wantRe = new RegExp(`${base}\\s*/?\\s*${(quote || '').toUpperCase()}`, 'i');
    const byText = page.locator(SELECTORS.searchResult, { hasText: wantRe }).first();
    // Первая строка ВНУТРИ дропдауна выбора пары (scoped — не заголовок в шапке).
    const firstRow = page.locator(SELECTORS.searchResultScoped).first();
    let result = byText;
    try {
      await result.waitFor({ state: 'visible', timeout: 1500 });
    } catch {
      // Точный текст не найден (displayName ≠ тикер) → берём верхний результат списка.
      result = firstRow;
      await result.waitFor({ state: 'visible', timeout: 2000 });
    }
    await result.click({ timeout: 2000 });
    step = 'url-change';
    await finishSpa();
    log(`Смена пары через поиск (SPA, без перезагрузки): ${pair}`);
    return { spa: true };
  } catch (e) {
    // Диагностика: какие поля ввода / элементы поиска реально есть на странице —
    // чтобы подобрать точный ARBI_BINGX_SEL_SEARCH без гадания (как чинили форму MEXC).
    if (step === 'search-input') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const inputs = Array.from(document.querySelectorAll('input')).filter(vis).slice(0, 12)
          .map((i) => ({ ph: i.placeholder || '', al: i.getAttribute('aria-label') || '', cls: String(i.className || '').slice(0, 45), t: i.type }));
        const searchish = Array.from(document.querySelectorAll('[class*="earch" i],[aria-label*="search" i],[aria-label*="поиск" i]')).filter(vis).slice(0, 6)
          .map((e) => ({ tag: e.tagName, al: e.getAttribute('aria-label') || '', cls: String(e.className || '').slice(0, 45) }));
        return { inputs, searchish };
      }).catch(() => ({}));
      console.log('[bingx-exec] [diag поиск] ' + JSON.stringify(diag).slice(0, 950));
    }
    // Диагностика провала на строке-результате: какие строки реально в выпадающем
    // списке (класс+текст) — чтобы подобрать точный ARBI_BINGX_SEL_SEARCH_RESULT / понять,
    // почему нужная пара не подхватилась (частая причина медленного 1-го ордера).
    if (step === 'result-item') {
      const diag = await page.evaluate(() => {
        const vis = (el) => el && el.offsetParent !== null;
        const rows = Array.from(document.querySelectorAll('[class*="list_content__"],[class*="list_pairName__"],[class*="earch" i] [class*="item" i],[class*="result" i]'))
          .filter(vis).slice(0, 10)
          .map((e) => ({ cls: String(e.className || '').slice(0, 50), txt: (e.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 40) }));
        return { rows };
      }).catch(() => ({}));
      console.log('[bingx-exec] [diag результат] ' + JSON.stringify(diag).slice(0, 950));
    }
    log(`SPA-навигация не удалась на шаге «${step}» (${String(e.message).slice(0, 50)}) — фолбэк на перезагрузку`);
    await page.goto(BINGX_TRADE_URL_TMPL.replace('{pair}', bingxUrlPair(pair)), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (urlHasPair(page.url(), pair)) rememberPair(page, pair); // goto с catch — кэшируем только подтверждённый URL
    return { spa: false };
  }
}

/**
 * ПОДТВЕРЖДАЕТ (не закрывает!) модалку XT «Цена вашего ордера на X% выше/ниже
 * последней цены исполнения. Вы уверены?» — она появляется, когда лимитная цена
 * далеко от рынка (ставим в стакан / в 2× ниже — штатный сценарий оператора).
 * Без подтверждения order/place НЕ уходит. Отмечаем чекбокс «Никаких подсказок в
 * течение 1 часа» (модалка не будет мешать час) и жмём primary-кнопку подтверждения
 * (НЕ «Отмена»). Возвращает true, если подтвердили.
 */
async function confirmOrderPrompt(page) {
  return page.evaluate(() => {
    const vis = (el) => el && el.offsetParent !== null;
    const modals = Array.from(document.querySelectorAll('.ant-modal-wrap,[class*="ant-modal-confirm"],[role="dialog"],[class*="odal"]')).filter(vis);
    for (const m of modals) {
      const txt = (m.innerText || '').replace(/\s+/g, ' ').trim();
      // Модалка подтверждения цены вне рынка (RU/EN). НЕ баланс/ошибка (те закрываем).
      // Покрываем ДВА варианта BingX:
      //  1) «Цена на X% выше/ниже последней…» (лимитка далеко от рынка);
      //  2) «Примечание: Лимитная цена ниже/равна наилучшей цене бида, поэтому ордер
      //     может быть исполнен сразу» — всплывает, когда лимитка ПЕРЕСЕКАЕТ рынок
      //     (жалоба оператора: продажа блокировалась этой модалкой). Оба подтверждаем.
      const isPricePrompt = /уверен|are you sure|последней цены|last (traded )?price|% (выше|ниже|higher|lower)|отклонени|deviat|наилучш\w* цен|лимитная цена (ниже|выше|равна)|limit price|может быть исполнен|исполнен сразу|executed immediately|filled immediately|best (bid|ask)/i.test(txt);
      if (!isPricePrompt) continue;
      if (/insufficient|not enough|недостаточн/i.test(txt)) continue;
      // Чекбокс «Никаких подсказок в течение 1 часа» — снимаем модалку на час.
      const cb = m.querySelector('input[type="checkbox"]');
      if (cb && !cb.checked) { try { cb.click(); } catch (_) {} }
      // Primary-кнопка подтверждения: «Подтвердить/Да/Продолжить/Уверен/OK/Confirm» —
      // НЕ «Отмена/Cancel/Нет».
      const btns = Array.from(m.querySelectorAll('button.ant-btn-primary,button'));
      const btn = btns.find((b) => vis(b)
        && /подтверд|confirm|продолж|continue|^да$|уверен|^ок$|^ok$|sure/i.test((b.innerText || '').trim())
        && !/отмен|cancel|^нет$|назад|back/i.test((b.innerText || '').trim()));
      if (btn && vis(btn)) { try { btn.click(); return true; } catch (_) {} }
    }
    return false;
  }).catch(() => false);
}

/**
 * ST-токен? У ST-токенов XT рядом с заголовком пары стоит метка «ST» (см. скрин
 * оператора: «WFCA/USDT ST»). Определяем это ПРЯМО ИЗ DOM — тогда знаем про
 * risk-модалку «Предупреждение о рисках» ЗАРАНЕЕ, даже для нового токена, которого
 * ещё нет в общей базе known_tokens (не дожидаясь, пока модалка перебьёт форму).
 */
async function detectStToken(page) {
  return page.evaluate(() => {
    // 1) BingX: баннер/модалка «инновационная зона» / «Предупреждение о риске» —
    //    надёжный ST-сигнал (виден на странице любого ST-токена сразу при открытии).
    const bodyTxt = (document.body.innerText || '').slice(0, 3000);
    if (/инновацион|innovation zone|предупреждение о риск|risk warning/i.test(bodyTxt)) return true;
    // 2) Метка «ST» рядом с заголовком пары. Якорь — h1 ИЛИ короткий элемент с "/USDT".
    const anchor = document.querySelector('h1')
      || Array.from(document.querySelectorAll('*')).find((e) => e.children.length <= 3
        && /\/(USDT|USDC)\b/i.test(e.textContent || '') && (e.textContent || '').trim().length < 30);
    let root = anchor || document.body;
    for (let i = 0; i < 4 && root.parentElement; i++) root = root.parentElement;
    const els = Array.from(root.querySelectorAll('*'));
    return els.some((el) => el.children.length === 0 && /^ST$/.test((el.textContent || '').trim()));
  }).catch(() => false);
}

/**
 * ПРОГРЕВ формы БЕЗ выставления ордера — БЕЗОПАСНО, ничего не покупаем/продаём.
 * Грузит страницу пары, закрывает промо-оверлеи, дожидается готовности лимит-формы
 * (≥2 number-инпутов + кнопки Buy/Sell = React догидрировался). БЕЗ единого клика
 * по кнопке ордера.
 */
// ── ВКЛАДКИ-ЧАСТИ (оператор 2026-09-08: «делай параллельные вкладки») ──
// Лимит объёма одной заявки биржа показывает только на заполненной форме, поэтому
// помним его ПО ПАРЕ после первого прочтения (в памяти процесса). Для пары с лимитом
// на прогреве заранее открываем ещё ARBI_BINGX_SPLIT_TABS−1 вкладок той же пары
// (по умолчанию всего 3), а части заявки ставим ОДНОВРЕМЕННО — по одной на вкладку:
// каждая вкладка = свой React-стейт формы, сброс формы по ответу одной части не
// трогает остальные (это и был пол 0.4.135 при частях в одной вкладке).
// pair → { limit, at }; limit 0 = проверяли на прогреве, подсказки не было (перепроверка
// через 10 мин: подсказка не видна, когда баланс меньше лимита); limit>0 живёт сутки.
// Файл в каталоге данных — лимиты известны и после перезапуска (оператор 15.09:
// «мы должны знать заранее, какие токены на bingx имеют лимиты»).
const volumeLimitByPair = new Map();
const LIMIT_FLOOR = Number(process.env.ARBI_BINGX_LIMIT_MIN_USDT || 10); // ниже — не лимит, а минимум/мусор
const LIMITS_FILE = path.join(config.dataDir, 'bingx-volume-limits.json');
try { for (const [k, v] of Object.entries(JSON.parse(fs.readFileSync(LIMITS_FILE, 'utf8')))) if (v && typeof v.limit === 'number' && (v.limit === 0 || v.limit >= LIMIT_FLOOR)) volumeLimitByPair.set(k, v); } catch { /* файла ещё нет */ }
function saveLimits() { try { fs.mkdirSync(config.dataDir, { recursive: true }); fs.writeFileSync(LIMITS_FILE, JSON.stringify(Object.fromEntries(volumeLimitByPair))); } catch { /* не критично */ } }
function rememberVolumeLimit(pair, limit) { if (limit >= LIMIT_FLOOR) { volumeLimitByPair.set(pair, { limit, at: Date.now() }); saveLimits(); } }
function knownVolumeLimit(pair) { const r = volumeLimitByPair.get(pair); return r && r.limit > 0 ? r.limit : 0; }
function limitNeedsProbe(pair) {
  const r = volumeLimitByPair.get(pair);
  if (!r) return true;
  return Date.now() - r.at > (r.limit > 0 ? 24 * 3600e3 : Number(process.env.ARBI_BINGX_LIMIT_RECHECK_MIN || 10) * 60e3);
}
function splitTabsWanted() { const n = Number(process.env.ARBI_BINGX_SPLIT_TABS || 3); return Number.isFinite(n) && n >= 1 ? Math.floor(n) : 3; }
/** Потолок вкладок-ЧАСТЕЙ на всю биржу. Отдельный от пула пар: пул считает
 *  пары (mainTradeTabs), части — этот счётчик. Держим его явным, потому что
 *  упирается он не в логику, а в память: вкладка BingX весит сотни мегабайт
 *  (перепись оператора 22.09: 785 МБ), и «пусть открывается сколько нужно»
 *  кончится тем, что затормозит весь профиль. */
function splitTabsMax() { const n = Number(process.env.ARBI_BINGX_SPLIT_TABS_MAX || 6); return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 6; }
/** Сколько вкладок-частей открыто на бирже сейчас (по всем парам). */
function splitTabsTotal(context) {
  let n = 0;
  for (const p of context.pages()) {
    try { if (p.__arbiSplitTab === true && !p.isClosed() && String(p.url()).startsWith(BINGX_ORIGIN)) n += 1; } catch { /* закрыта */ }
  }
  return n;
}
/** Доп. вкладки этой пары (кроме главной): открытые нами под части, живые, на паре. */
function splitTabsOf(context, pair, mainPage, includeUnready = false) {
  const out = [];
  for (const p of context.pages()) {
    if (p === mainPage) continue;
    try {
      if (p.__arbiSplitTab !== true || p.__arbiBalanceBg === true) continue;
      if (!includeUnready && p.__arbiSplitReady !== true) continue;
      const u = p.url();
      if (u.startsWith(BINGX_ORIGIN) && urlHasPair(u, pair)) out.push(p);
    } catch { /* закрыта */ }
  }
  return out;
}
/** Довести вкладку до готовой Limit-формы (без ордера). */
async function warmSplitTab(pg) {
  await dismissOverlays(pg).catch(() => {});
  let inputs = await pg.$$(SELECTORS.numberInput).catch(() => []);
  if (inputs.length < 2) {
    try { await pg.click(SELECTORS.limitTab, { timeout: 1000 }); } catch { /* уже limit */ }
    await pg.waitForSelector(SELECTORS.numberInput, { timeout: 9000 }).catch(() => {});
  }
  await pg.waitForSelector(SELECTORS.submit, { state: 'visible', timeout: 9000 }).catch(() => {});
  await pg.waitForTimeout(Number(process.env.ARBI_BINGX_WARMUP_SETTLE_MS || 250));
  await dismissBlockingModal(pg).catch(() => {});
  pg.__arbiSplitReady = true;
}
/** Открыть/прогреть недостающие вкладки-части пары (навигации — по очереди, не залпом). */
async function ensureSplitTabs(context, pair, mainPage, log, wantTabs = 0) {
  // wantTabs — сколько ВСЕГО вкладок нужно под то, что реально лежит на бирже
  // (главная + части). Ноль = прежнее поведение, фиксированное ARBI_BINGX_SPLIT_TABS.
  const want = Math.min(wantTabs > 0 ? wantTabs : splitTabsWanted(), splitTabsMax() + 1) - 1;
  if (want <= 0) return;
  if (context.__arbiSplitOpening) return; // уже открываем (фоновый вызов после серийного split)
  context.__arbiSplitOpening = true;
  try {
    const have = splitTabsOf(context, pair, mainPage, true);
    // Продлеваем защиту от усыпления УЖЕ ГОТОВЫМ частям. Метка ставилась только
    // в момент открытия и протухала через TTL пула (30 мин): в длинной сессии
    // сторож памяти уводил часть навигацией прочь, форма в ней исчезала, и
    // «доверенный клик» уходил в пустоту — в журнале «клик не отправил запрос
    // ордера», заявка не уходила (разбор STONK/BingX 2026-09-16). Пара греется
    // постоянно, значит она нужна — и её части тоже.
    for (const p of have) { try { markPairTab(p); p.__arbiSplitAt = Date.now(); } catch { /* закрыта */ } }
    const toWarm = have.filter((p) => p.__arbiSplitReady !== true);
    const wantUrl = BINGX_TRADE_URL_TMPL.replace('{pair}', bingxUrlPair(pair));
    for (let k = have.length; k < want; k++) {
      if (splitTabsTotal(context) >= splitTabsMax()) { log(`Вкладки-части ${pair}: потолок частей на бирже (${splitTabsMax()}) — открыл ${k - have.length} из ${want - have.length}; лишние снимет уборка, когда пара уйдёт из терминала`); break; }
      // Вкладкой в окне, не своим окном (оператор 15.09: «вкладками, а не отдельными
      // страницами»): части ставятся залпом, кадры им не нужны — ввод залпом (evaluate)
      // и force-клик, ответ ловим по сети.
      const pg = markPairTab(markOwned(await newBackgroundPage(context, { tab: true })));
      pg.__arbiSplitTab = true;
      pg.__arbiSplitAt = Date.now();
      await pg.goto(wantUrl, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
      if (String(pg.url()).startsWith('about:')) { await pg.close().catch(() => {}); log(`Вкладка-часть ${pair} не открылась — проверьте прокси/сеть профиля`); break; }
      rememberPair(pg, pair);
      toWarm.push(pg);
    }
    if (toWarm.length) {
      const t = Date.now();
      await Promise.all(toWarm.map((pg) => warmSplitTab(pg).catch(() => {})));
      // Вкладки-части открываются В ФОНЕ (newBackgroundPage), активную вкладку
      // оператора они не перехватывают — возвращать фокус на главную больше не
      // надо (и НЕ НАДО: оператор мог смотреть совсем другую вкладку). Со старым
      // поведением (ARBI_BG_TABS=0) фокус по-прежнему возвращаем.
      if ((process.env.ARBI_BG_TABS || '1') === '0') { try { await mainPage.bringToFront(); } catch { /* игнор */ } }
      log(`Вкладки-части ${pair}: готово ${splitTabsOf(context, pair, mainPage).length} + главная (лимит ${knownVolumeLimit(pair)} USDT, прогрев ${Date.now() - t} мс)`);
    }
  } finally { context.__arbiSplitOpening = false; }
}
/** Сторона Buy/Sell на вкладке: помечаем ВКЛАДКУ-переключатель (не кнопку сабмита) и говорим, активна ли. */
function markSideTab(page, sideRe) {
  return page.evaluate((args) => {
    const re = new RegExp(args.sideRe, 'i');
    const inBtnOrder = (el) => {
      for (let n = el; n; n = n.parentElement) {
        if (/btn-order/i.test(String((n.className && n.className.baseVal) || n.className || ''))) return true;
      }
      return false;
    };
    const activeOf = (el) => {
      for (let n = el, i = 0; n && i < 5; n = n.parentElement, i++) {
        if (n.getAttribute && n.getAttribute('aria-selected') === 'true') return true;
        const c = String((n.className && n.className.baseVal) || n.className || '');
        if (/(^|[-_ ])(active|selected|checked|current|is-active|cur)([-_ ]|$)/i.test(c)) return true;
      }
      return false;
    };
    document.querySelectorAll('[data-arbi-sidetab]').forEach((e) => e.removeAttribute('data-arbi-sidetab'));
    const tab = Array.from(document.querySelectorAll('div,span,label,a,button'))
      .find((e) => e.children.length === 0 && re.test((e.textContent || '').trim())
        && e.offsetParent !== null && !inBtnOrder(e));
    if (!tab) return { found: false, active: false };
    tab.setAttribute('data-arbi-sidetab', '1');
    return { found: true, active: activeOf(tab) };
  }, { sideRe }).catch(() => ({ found: false, active: false }));
}
/** Подготовить вкладку-часть к стороне ордера (sell — с перекликом Buy→Sell для свежего баланса). */
async function prepSplitTab(pg, side) {
  await dismissBlockingModal(pg).catch(() => {});
  const sideRe = side === 'sell' ? SELECTORS.sideSellRe : SELECTORS.sideBuyRe;
  if (side === 'sell') {
    const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
    await clickSideTab(pg, SELECTORS.sideBuyRe); await pg.waitForTimeout(refMs);
    await clickSideTab(pg, SELECTORS.sideSellRe); await pg.waitForTimeout(refMs);
  }
  let st = await markSideTab(pg, sideRe);
  for (let attempt = 0; attempt < 2 && !(st.found && st.active); attempt++) {
    await pg.locator('[data-arbi-sidetab="1"]').first().click({ timeout: 1500, force: true }).catch(() => {});
    await pg.waitForTimeout(200);
    st = await markSideTab(pg, sideRe);
  }
  return st.active;
}

/** Первое число из текста биржи («Доступно: 3611.0139 STONK» → 3611.0139). */
function numFrom(text) {
  const m = String(text || '').replace(/\s+/g, ' ').match(/(\d+(?:[.,]\d+)?)/);
  if (!m) return 0;
  const n = Number(m[1].replace(',', '.'));
  return Number.isFinite(n) ? n : 0;
}

/**
 * Сколько ВСЕГО вкладок (главная + части) нужно под остаток монеты на бирже.
 *
 * Оператор 22.09: «когда мы отправляем с декс монеты, мы уже знаем, сколько их
 * нужно будет продать… если отправлено на 1,5к USDT при лимите 500, нужно греть
 * 4 вкладки». Сигнал из терминала для этого не нужен: остаток к продаже написан
 * на самой странице («Доступно»), и он же САМ решает задачу нескольких раундов —
 * два свопа подряд просто складываются в остаток, гадать про «сколько посылок
 * было» не приходится.
 *
 * Читаем со вкладки-ЧАСТИ: она фоновая и уже стоит на стороне «Продать» после
 * переклика баланса. На главной сторону не трогаем — она у оператора на экране.
 * Цена берётся из поля формы (там рыночная) — этого хватает, чтобы посчитать
 * ЧИСЛО вкладок; точную разбивку всё равно считает сам ордер по своей цене.
 */
async function neededSplitTabs(pg, pair) {
  const limit = knownVolumeLimit(pair);
  if (!(limit > 0)) return 0;
  const [availTxt, vals] = await Promise.all([
    readAvailText(pg, AVAIL_LABEL_RE.source).catch(() => ''),
    pg.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value)).catch(() => []),
  ]);
  const qty = numFrom(availTxt);
  const price = numFrom(vals[0]);
  if (!(qty > 0) || !(price > 0)) return 0;
  return Math.max(1, Math.ceil((qty * price) / limit));
}

async function readVolumeLimitOn(page) {
  const r = await page.evaluate(({ hintReSrc, minReSrc }) => {
    const hintRe = new RegExp(hintReSrc, 'i');
    const minRe = new RegExp(minReSrc, 'i');
    const vis = (el) => el && el.offsetParent !== null;
    const txt = (e) => (e.innerText || '').replace(/\s+/g, ' ').trim();
    const hasUsdt = (t) => /\d\s*[kKmMкКмМ]?\s*(usdt|usd)\b/i.test(t);
    // Подсказка о МИНИМУМЕ («Мин. стоимость - 1 USDT») — не лимит: лог оператора
    // 15.09 21:05 — проба на прогреве приняла её за максимум, лимит=1 USDT лёг на
    // диск, заявка распалась на 20 частей по 0,98 USDT ниже минимума биржи.
    const isMin = (t) => minRe.test(t);
    // 1) точно: div.error-msg формы ордера
    for (const e of document.querySelectorAll('.limit-input-wrapper div.error-msg, .trader-input-wrap-dark div.error-msg, .amount-multi-input-wrap div.error-msg, div.error-msg')) {
      if (!vis(e)) continue;
      const t = txt(e);
      if (t && t.length < 300 && hasUsdt(t) && !isMin(t)) return { exact: true, text: t };
    }
    // 2) запасной: классы error/tip/warn + слова-подсказки
    for (const e of document.querySelectorAll('[class*="error-msg"],[class*="error" i],[class*="tip" i],[class*="warn" i]')) {
      if (!vis(e)) continue;
      const t = txt(e);
      if (t && t.length < 300 && hintRe.test(t) && hasUsdt(t) && !isMin(t)) return { exact: false, text: t };
    }
    // 3) запасной: любой видимый листовой элемент с подсказкой «… N USDT»
    for (const e of document.querySelectorAll('span,div,p,em,i,label')) {
      if (e.children.length || !vis(e)) continue;
      const t = txt(e);
      if (t && t.length < 300 && hintRe.test(t) && hasUsdt(t) && !isMin(t)) return { exact: false, text: t };
    }
    return null;
  }, { hintReSrc: VOLUME_LIMIT_HINT_RE.source, minReSrc: VOLUME_MIN_HINT_RE.source }).catch(() => null);
  if (!r) return { limit: 0, text: '' };
  const n = parseVolumeLimit(r.text);
  // Лимит меньше LIMIT_FLOOR USDT правдоподобным не считаем (это минимум/шаг, не потолок).
  return { limit: n && n >= LIMIT_FLOOR ? n : 0, text: r.text, exact: !!r.exact };
}


/**
 * ПРОБА ЛИМИТА НА ПРОГРЕВЕ (оператор 15.09): лимит одной заявки биржа показывает
 * только на заполненной форме («Стоимость не может быть больше 500 USDT»). Вводим
 * залпом заведомо огромное количество (~10 млн USDT по текущей цене), читаем
 * подсказку, возвращаем поля как были. Ни одного клика по кнопке ордера — заявка
 * не ставится. Итог — в volumeLimitByPair (и на диск); тогда заявка сверх лимита
 * идёт частями СРАЗУ, а вкладки-части открываются заранее.
 */
async function probeVolumeLimit(page, pair, log) {
  const t = Date.now();
  const vals = await page.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value)).catch(() => []);
  const p0 = parseFloat(String(vals[0] || '').replace(/[,\s]/g, ''));
  const price = p0 > 0 ? String(vals[0]).replace(/[,\s]/g, '') : '1';
  const qty = String(Math.ceil(1e7 / parseFloat(price)));
  await fastSetInputs(page, price, qty).catch(() => {});
  let r = { limit: 0, text: '' };
  const dl = Date.now() + Number(process.env.ARBI_BINGX_LIMIT_PROBE_MS || 800);
  for (;;) { r = await readVolumeLimitOn(page); if (r.limit > 0 || Date.now() >= dl) break; await page.waitForTimeout(100); }
  await fastSetInputs(page, p0 > 0 ? String(vals[0]) : '', '').catch(() => {});
  if (r.limit > 0) { rememberVolumeLimit(pair, r.limit); log(`BingX: лимит объёма ${r.limit} USDT прочитан на прогреве («${r.text}», ${Date.now() - t} мс)`); }
  else { volumeLimitByPair.set(pair, { limit: 0, at: Date.now() }); saveLimits(); log(`BingX: подсказки о максимальном объёме на форме нет (проба ${Date.now() - t} мс${r.text ? `, видел: «${r.text}»` : ''}) — лимит узнаем по первой заявке`); }
  return r.limit;
}

async function warmupForm(context, pair, log, opts = {}) {
  const { page, cold } = await getBingxPage(context, pair, log);
  await dismissOverlays(page);
  // ОБНОВЛЕНИЕ БАЛАНСА ТОРГОВОЙ ВКЛАДКИ (оператор 01.09). BingX показывает
  // зачисленный баланс на странице с большой задержкой, и раньше это оплачивалось
  // ВНУТРИ выстрела: переклик вкладок + цикл ожидания до 4с (ARBI_BINGX_QTY_WAIT_MS).
  // Терминал знает момент, когда монета реально легла на Спот (успешный перевод
  // Фонд→Спот), и присылает прогрев с refreshBalance — переклик делается ЗАРАНЕЕ, в
  // фоне, а выстрел приходит на уже свежую форму. Именно ТОРГОВАЯ вкладка: у каждой
  // страницы BingX свой React-стейт, и переклик в фоновой её не обновит.
  if (opts.refreshBalance) {
    const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
    const reclick = async (pg) => {
      await clickSideTab(pg, SELECTORS.sideBuyRe); await pg.waitForTimeout(refMs);
      await clickSideTab(pg, SELECTORS.sideSellRe); await pg.waitForTimeout(refMs);
    };
    // Вкладки-части — тоже (лог 16.09 STONK: главная вкладка заполнилась за 14 мс,
    // вкладка-часть — 949 мс + 1751 мс ожидания кнопки: её баланс отстал, форма
    // резала количество). У каждой вкладки свой стейт — греем все разом.
    const parts = splitTabsOf(context, pair, page);
    await Promise.all([page, ...parts].map((pg) => reclick(pg).catch(() => {})));
    log(`Обновил баланс формы перекликом Buy→Sell (после зачисления на Спот)${parts.length ? `, вкладок-частей: ${parts.length}` : ''}`);
  }
  // ST-детект НА ПРОГРЕВЕ: терминал открывает web-токен → warmup. Если это ST-токен
  // (метка «ST» в DOM), закрываем «Предупреждение о рисках» здесь и возвращаем
  // riskModal=true → терминал запишет токен в ОБЩУЮ базу known_tokens ЕЩЁ ДО первого
  // ордера. Тогда у ЛЮБОГО пользователя (не только у того, кто первым столкнулся)
  // ордер по этому ST-токену идёт уже с превентивным закрытием — быстро.
  let sawSt = await detectStToken(page);
  if (sawSt) {
    for (let i = 0; i < 3; i++) {
      const r = await dismissBlockingModal(page);
      if (r && r.closed) break;
      await page.waitForTimeout(120);
    }
  }
  let inputs = await page.$$(SELECTORS.numberInput);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: 1000 }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 9000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.numberInput);
  }
  // Ждём общий сабмит (активной стороны) ВИДИМЫМ. Кнопка неактивной стороны в DOM
  // отсутствует до выбора вкладки — её здесь НЕ ждём (иначе таймаут впустую).
  await page.waitForSelector(SELECTORS.submit, { state: 'visible', timeout: 9000 }).catch(() => {});
  // ВАЖНО (жалоба оператора: «первый ордер думает 1-2с, а после паузы 5с —
  // мгновенно»): НЕ ждём enabled-состояния кнопки. На ПУСТОЙ форме прогрева кнопка
  // «Купить» ЗАВЕДОМО disabled (нет цены/кол-ва → bx-btn-disabled), поэтому цикл
  // ожидания готовности крутил бы ~5с (25×200мс) ВПУСТУЮ — и реальный ордер,
  // пришедший следом, эти 5с ждал бы в очереди (warmup и ордер сериализованы в
  // одном профиле). Форма уже готова: numberInput есть, кнопка видима. Короткая
  // пауза на догидрацию React (привязка onClick) — и хватит; enabled проверит уже
  // executeIntent ПОСЛЕ заполнения полей (там кнопка становится активной).
  await page.waitForTimeout(Number(process.env.ARBI_BINGX_WARMUP_SETTLE_MS || 250));
  await dismissOverlays(page);
  // Ещё раз проверим ST после гидрации (метка могла появиться позже) + добьём модалку.
  if (!sawSt) sawSt = await detectStToken(page);
  if (sawSt) { await dismissBlockingModal(page).catch(() => {}); }
  {
    const lw = await loginWall(page);
    if (lw.wall) { log(`Нет входа в аккаунт BingX в этом профиле (на форме: «${lw.text}») — прогрев невозможен`); return { ok: false, cold, loginRequired: true, error: loginRequiredError('BingX') }; }
  }
  log(`Форма прогрета (${pair})${cold ? ' [была холодная]' : ''}${sawSt ? ' [ST]' : ''} — ордер НЕ ставился`);
  if (limitNeedsProbe(pair) && (process.env.ARBI_BINGX_LIMIT_PROBE || '1') === '1') await probeVolumeLimit(page, pair, log).catch((e) => log(`Проба лимита: ${e && e.message ? e.message : e}`));
  // Пара с известным лимитом объёма → заранее открыть вкладки-части (см. ensureSplitTabs).
  if (knownVolumeLimit(pair) > 0) await ensureSplitTabs(context, pair, page, log).catch((e) => log(`Вкладки-части: ${e && e.message ? e.message : e}`));
  // БАЛАНС ВКЛАДОК-ЧАСТЕЙ СТАРЕЕТ И БЕЗ ЗАЧИСЛЕНИЯ (оператор 22.09, STONK).
  // Переклик выше делается только по сигналу терминала о приходе на Спот. Но
  // между заявками вкладки-части не трогает НИКТО, их React-стейт держит старый
  // баланс, форма режет количество — и цикл ожидания (до 2,5 с) оплачивается
  // ВНУТРИ выстрела: лог 22.09 — часть 2 заполнялась 2693 мс против 54 мс на
  // главной, вся заявка 4166 мс вместо 1416 мс у следующей. Греем части на
  // КАЖДОМ прогреве: они фоновые, оператор в них не смотрит, стоит это ~160 мс
  // в простое. Главную вкладку тут НЕ трогаем — она у оператора перед глазами,
  // и её переклик остаётся только по явному refreshBalance.
  if (!opts.refreshBalance) {
    const parts = splitTabsOf(context, pair, page);
    if (parts.length) {
      const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
      const t = Date.now();
      await Promise.all(parts.map(async (pg) => {
        await clickSideTab(pg, SELECTORS.sideBuyRe); await pg.waitForTimeout(refMs);
        await clickSideTab(pg, SELECTORS.sideSellRe); await pg.waitForTimeout(refMs);
      })).catch(() => { /* вкладка закрылась — часть просто заполнится медленнее */ });
      log(`Баланс вкладок-частей освежён перекликом Buy→Sell: ${parts.length} за ${Date.now() - t} мс`);
    }
  }
  // ── ВКЛАДОК СТОЛЬКО, СКОЛЬКО МОНЕТЫ ЛЕЖИТ НА БИРЖЕ, И КОЛИЧЕСТВО ВПИСАНО ──
  // Оператор 22.09. Считаем по остатку на странице (см. neededSplitTabs) — он же
  // сам учитывает несколько раундов. Рубильник ARBI_BINGX_PREWARM_BY_BALANCE=0.
  if (knownVolumeLimit(pair) > 0 && (process.env.ARBI_BINGX_PREWARM_BY_BALANCE || '1') === '1') {
    const first = splitTabsOf(context, pair, page)[0];
    const need = first ? await neededSplitTabs(first, pair).catch(() => 0) : 0;
    if (need > 1) {
      const have = splitTabsOf(context, pair, page).length + 1;
      const cap = splitTabsMax() + 1;
      if (need > have) {
        // Говорим и сколько НУЖНО, и сколько откроем: потолок памяти может
        // оказаться ниже потребности, и молча выдать меньше — значит соврать.
        log(`Остатка на бирже хватает на ${need} заявок по лимиту — догреваю вкладки (было ${have}, открою до ${Math.min(need, cap)}${need > cap ? `, потолок ${cap}` : ''})`);
        await ensureSplitTabs(context, pair, page, log, need).catch((e) => log(`Вкладки-части: ${e && e.message ? e.message : e}`));
      }
      // ПРЕДЗАПОЛНЕНИЕ КОЛИЧЕСТВА. Цену заранее не ставим: к моменту продажи она
      // будет другая, и заполненная чужой ценой форма — это риск. А вот
      // количество вписать надо обязательно: именно оно упирает форму в её
      // (устаревший) остаток и запускало цикл ожидания до 2,5 с ВНУТРИ выстрела.
      // Здесь этот цикл проходит в простое, на выстрел остаются цена и клик.
      if ((process.env.ARBI_BINGX_PREFILL_QTY || '1') === '1') {
        const margin = Number(process.env.ARBI_BINGX_SPLIT_MARGIN || 0.98);
        const tabs = splitTabsOf(context, pair, page);
        let done = 0; let clipped = 0;
        for (const pg of tabs) {
          try {
            const vals = await pg.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value));
            const price = numFrom(vals[0]);
            if (!(price > 0)) continue;
            const chunk = ((knownVolumeLimit(pair) / price) * margin).toFixed(6);
            await fastSetInputs(pg, vals[0], chunk);
            await pg.waitForTimeout(60);
            const after = await pg.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value));
            // Форма срезала — значит её остаток ещё не подтянулся. Это НЕ ошибка:
            // сам факт записи уже заставил её пересчитаться, к выстрелу успеет.
            if (numFrom(after[1]) < numFrom(chunk) * 0.99) clipped += 1;
            done += 1;
          } catch { /* вкладка закрылась/навигация — пропускаем */ }
        }
        if (done) log(`Количество вписано заранее в ${done} вкладок-частей${clipped ? ` (в ${clipped} форма пока срезала по своему остатку — подтянется)` : ''}`);
      }
    }
  }
  return { ok: true, cold, riskModal: sawSt };
}

/**
 * Исполняет ОДНО намерение в живой странице XT.
 *
 * @param {import('playwright').BrowserContext} context  контекст профиля аккаунта
 * @param {object} intent  { id, accountId, symbol, side, type, price, quantity, dryRun }
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{ok:boolean, orderId?:string, error?:string}>}
 */
async function executeIntent(context, intent, opts = {}) {
  const log = opts.log || (() => {});
  const pair = toBingxPair(intent.symbol);

  // v1: только limit (как и терминал-реплей). Market — отдельная вёрстка формы.
  if (intent.type !== 'limit' || intent.price == null) {
    return { ok: false, error: 'Стадия 3 v1: поддержан только limit-ордер с ценой' };
  }
  // IM-1: развернуть экспоненту (1.2e-7 → 0.00000012) и отсечь мусорные значения ДО ввода.
  const priceStr = formatDecimal(intent.price);
  const qtyStr = formatDecimal(intent.quantity);
  if (!isPlainPositive(priceStr) || !isPlainPositive(qtyStr)) {
    return { ok: false, error: `Некорректные цена/количество: price=${intent.price} qty=${intent.quantity}. Ордер НЕ отправлен.` };
  }
  intent = { ...intent, price: priceStr, quantity: qtyStr };

  const t0 = Date.now();
  const { page, cold, switched } = await getBingxPage(context, pair, log);
  const tPage = Date.now();
  await ensureTabInFront(page, log); // скрытая вкладка = запросы/клики ждут кадров (см. pair-tabs)
  // Сброс метки risk-модалки за эту попытку (dismissBlockingModal её выставит).
  try { page.__arbiSawRisk = false; } catch { /* игнор */ }
  // ПРЕВЕНТИВНОЕ закрытие risk-модалки ST-токена. Источники «токен = ST»:
  //   1) hints.riskModal из ОБЩЕЙ базы known_tokens (терминал, едино для всех юзеров);
  //   2) метка «ST» ПРЯМО В DOM заголовка пары — работает для НОВОГО токена, которого
  //      ещё нет в базе (не ждём, пока модалка перебьёт поиск/форму — жалоба оператора).
  // Если ST — активно закрываем «Понятно» (модалка всплывает не мгновенно → пара
  // попыток с паузой) и метим __arbiSawRisk, чтобы терминал записал токен в базу.
  // Если база УЖЕ знает про ST (hint) — не тратим DOM-детект (evaluate). Иначе
  // проверяем метку в DOM (новый токен). Закрываем risk-модалку ОДНОЙ попыткой БЕЗ
  // цикла ожидания: на прогретом/повторно открытом ST-токене модалки уже нет, а
  // ждать её впустую 3×120мс = лишняя ~0.4с на КАЖДОМ ордере. Если модалка всплывёт
  // позже — её закроют ensureFilled/typeNumber (dismissBlockingModal там уже есть).
  // Превентивно закрываем risk-модалку ТОЛЬКО на СВЕЖЕЙ странице (cold/switched):
  // именно там модалка ST всплывает при открытии пары. На ТЁПЛОЙ переиспользуемой
  // странице модалку уже закрыл warmup; если всплывёт позже — её добьёт
  // ensureFilled/typeNumber ПЕРЕД кликом (там dismissBlockingModal уже есть, а
  // typeNumber при перехвате клика сам закрывает модалку и повторяет). Поэтому на
  // тёплом ордере НЕ тратим DOM-скан (detectStToken/dismissBlockingModal ≈ 0.2-0.4с
  // на каждом ордере — главный вклад в фазу tabs). Обучение реестра (riskModal) не
  // теряем: ST-метку уже записал warmup, а __arbiSawRisk выставит поздний dismiss.
  const stHint = !!(intent.hints && intent.hints.riskModal);
  if (cold || switched) {
    const stBadge = stHint ? true : await detectStToken(page);
    if (stBadge) {
      try { page.__arbiSawRisk = true; } catch { /* игнор */ }
      await dismissBlockingModal(page).catch(() => {});
    }
  }

  // Собираем URL всех POST-запросов страницы за попытку — чтобы в диагностике
  // увидеть, ушёл ли ордер вообще и на какой URL (вдруг мимо ORDER_PLACE_RE).
  const postUrls = [];
  // ПОСТОЯННЫЙ захват ОТВЕТА ордера (зеркало XT): повторный waitForResponse пропускает
  // ответ, пришедший между таймаутом первого ожидания и новой подпиской → ложная
  // «order/place не ушёл», хотя заявка встала. Листенер подписан до клика.
  let capturedOrderResp = null;
  // CR-2: ответ ордера захватываем ТОЛЬКО на POST-запрос, реально ушедший В ЭТОЙ
  // попытке (firedReqs) — иначе на тёплой вкладке ловился ПОЗДНИЙ ответ прошлого
  // ордера / поллинг открытых → чужой orderNo, ложный успех. Подписка после t0.
  const firedReqs = new Set();
  const onResp = (r) => {
    try {
      if (r.request().method() !== 'POST') return;
      postUrls.push(r.url().replace(/\?.*$/, ''));
      if (!capturedOrderResp && firedReqs.has(r.request())) capturedOrderResp = r;
    } catch { /* игнор */ }
  };
  page.on('response', onResp);

  // Отслеживаем, УШЁЛ ли реальный POST order/place (не ответ, а сам запрос). Нужно
  // для БЕЗОПАСНОГО быстрого повтора: если первый клик не породил запрос ордера —
  // повтор безопасен; если запрос УЖЕ ушёл (а ответ медленный из-за прокси) —
  // повторять клик НЕЛЬЗЯ (задвоим ордер), надо просто дождаться ответа.
  let orderReqFired = false;
  const onReq = (req) => { try { if (req.method() === 'POST' && ORDER_PLACE_RE.test(req.url())) { orderReqFired = true; firedReqs.add(req); } } catch { /* игнор */ } };
  page.on('request', onReq);
  // IM-7: единая точка снятия листенеров для ранних return (форма/поля/сверка пары).
  const cleanup = () => { page.off('response', onResp); page.off('request', onReq); };
  // Страховка от накопления слушателей на ДОЛГОЖИВУЩЕЙ тёплой вкладке
  // (оператор 2026-09-21: «после перезагрузки работает лучше»). Снятие ниже
  // расставлено по каждому раннему return руками, и любой пропущенный путь —
  // или исключение по дороге — оставлял пару слушателей на вкладке навсегда:
  // за сотни заявок вкладка начинает прогонять каждый ответ сети через сотни
  // обработчиков. Снимаем ОСТАВШИЕСЯ ОТ ПРОШЛОЙ заявки на этой же вкладке —
  // утечка ограничена одной парой, сколько бы путей ни пропустили.
  try { if (typeof page.__arbiOffOrderListeners === 'function') page.__arbiOffOrderListeners(); } catch { /* вкладка закрыта */ }
  page.__arbiOffOrderListeners = cleanup;

  const TAB_TIMEOUT = Number(process.env.ARBI_BINGX_TAB_TIMEOUT_MS || 400);

  // Быстрая проверка: лимит-форма уже готова? Если ≥2 инпутов есть — вкладку Limit
  // НЕ трогаем. Клик по Limit нужен только если формы ещё нет.
  let inputs = await page.$$(SELECTORS.numberInput);
  if (inputs.length < 2) {
    try { await page.click(SELECTORS.limitTab, { timeout: TAB_TIMEOUT }); } catch { /* уже limit */ }
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 8000 }).catch(() => {});
    inputs = await page.$$(SELECTORS.numberInput);
  }
  const tTabs = Date.now();

  if (inputs.length < 2) {
    cleanup();
    return { ok: false, error: `Форма ордера BingX не распознана (найдено инпутов: ${inputs.length}). Проверьте ARBI_BINGX_SEL_NUMBER.` };
  }
  await dismissOverlays(page);
  // Закрыть блокирующую модалку-ошибку от ПРОШЛОГО ордера (напр. нехватка баланса),
  // иначе она перехватит клики и завалит эту заявку.
  await dismissBlockingModal(page);
  // ВЫБОР СТОРОНЫ Buy/Sell ПЕРЕД вводом. Форма XT — переключатель (вкладки
  // "Купить"/"Продать"); кнопка-сабмит неактивной стороны в DOM отсутствует, а
  // переключение стороны может сбросить поля — поэтому сторону выбираем до заполнения.
  // Вкладку берём по ТЕКСТУ (Sell-вкладка не имеет класса btnSell пока неактивна).
  // BingX: обе кнопки сторон присутствуют в DOM (Buy=btn-order-blue,
  // Sell=btn-order-red); неактивная сторона имеет bx-btn-disabled. Переключаем
  // сторону вкладкой ТОЛЬКО если мы ЗАВЕДОМО на чужой стороне (нужная кнопка
  // disabled, а противоположная — активна). На пустой форме обе disabled →
  // НЕ переключаем (по умолчанию форма на Buy) — это убирает ложный timeout 3с.
  const sideRe = intent.side === 'sell' ? SELECTORS.sideSellRe : SELECTORS.sideBuyRe;
  // КРИТИЧНО (баг: sell уходил как buy). ДВЕ ловушки BingX:
  //  1) текст «Продать»/«Купить» есть И у ВКЛАДКИ-переключателя, И у самой кнопки
  //     сабмита (btn-order-red/blue) → клик по «первому совпадению» попадал в
  //     КНОПКУ, а не вкладку → форма оставалась на Buy;
  //  2) на пустой форме обе кнопки disabled → сторону по ним не определить.
  // Поэтому ищем именно ВКЛАДКУ: leaf-элемент с точным текстом стороны, который НЕ
  // является кнопкой сабмита и НЕ внутри неё (btn-order-*). Помечаем его data-атрибутом
  // и кликаем строго по нему (trusted-клик Playwright). Затем ПРОВЕРЯЕМ, что вкладка
  // стала активной; если нет — повторяем клик (force).
  const markTab = () => markSideTab(page, sideRe);

  // BingX: ПЕРЕД продажей перекликиваем Buy→Sell, чтобы биржа обновила баланс токена.
  // ТОЛЬКО на BingX баланс после зачисления появляется с ЗАДЕРЖКОЙ; переключение
  // вкладок форсит обновление (приём оператора — так баланс подхватывается быстрее,
  // чем простым ожиданием). Без этого количество на продаже усекается до устаревшего
  // (мелкого) баланса, и страж fieldFresh верно блокирует ордер до догрузки (ловили на
  // ASTEROIDETH: хотели 6.2M, в форме 0.006 → 3 провала, пока баланс не догрузился).
  // Клик по вкладке — синтетический (навигация, не money-action); саму заявку жмём
  // доверенным кликом. Сторону всё равно подтверждаем ниже (markTab).
  const clickTab = (re) => page.evaluate((rs) => {
    const rx = new RegExp(rs, 'i');
    const inBtnOrder = (el) => { for (let n = el; n; n = n.parentElement) { if (/btn-order/i.test(String((n.className && n.className.baseVal) || n.className || ''))) return true; } return false; };
    const tab = Array.from(document.querySelectorAll('span,div,label,a,li'))
      .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null && !inBtnOrder(e));
    if (!tab) return false;
    try { tab.click(); return true; } catch (_) { return false; }
  }, re).catch(() => false);
  // Переключение вкладок Buy→Sell форсит перечитывание баланса токена. Вынесено
  // в функцию: тем же приёмом добиваем «схлопнутое» количество после заполнения
  // (см. блок «баланс страницы устарел» ниже).
  const refreshSellBalance = async () => {
    const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
    await clickTab(SELECTORS.sideBuyRe); await page.waitForTimeout(refMs);
    await clickTab(SELECTORS.sideSellRe); await page.waitForTimeout(refMs);
    log('Перекликнул Buy→Sell для обновления баланса (BingX)');
  };
  if (intent.side === 'sell' && (process.env.ARBI_BINGX_SELL_TAB_REFRESH || '1') === '1') {
    await refreshSellBalance();
  }
  let st = await markTab();
  if (st.found && st.active) {
    log(`Сторона ${intent.side} — уже активна`);
  } else {
    // Кликаем именно вкладку (по data-атрибуту). Форма ещё пустая — сброс не важен.
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        await page.locator('[data-arbi-sidetab="1"]').first().click({ timeout: 1500, force: attempt > 0 });
      } catch { /* повторим */ }
      await page.waitForTimeout(200); // форма перерисовывается на новую сторону
      st = await markTab();
      if (st.active) break;
    }
    log(st.active ? `Сторона выбрана: ${intent.side}` : `Сторона ${intent.side}: клик по вкладке не подтверждён (active=false) — продолжаю`);
  }
  {
    const lw = await loginWall(page);
    if (lw.wall) { cleanup(); log(`Нет входа в аккаунт BingX в этом профиле (на форме: «${lw.text}») — заявка НЕ отправлена`); return { ok: false, loginRequired: true, error: loginRequiredError('BingX') }; }
  }
  log(`Заполняю форму: price=${intent.price} amount=${intent.quantity} (${intent.side})${cold ? ' [холодная]' : ''}`);
  // Сабмит СТРОГО по кнопке нужной стороны (btn-order-red для sell, btn-order-blue
  // для buy). НЕ фолбэчим на общий SELECTORS.submit: он ловит ОБЕ кнопки btn-order-*
  // и .first() мог оказаться КУПИТЬ — тогда продажа ушла бы покупкой. Обе кнопки у
  // BingX всегда в DOM, так что side-qualified селектор есть; фолбэк на общий
  // оставляем ТОЛЬКО для buy (там ошибочная сторона = та же buy, не опасно).
  let submitSel = intent.side === 'sell' ? SELECTORS.submitSell : SELECTORS.submitBuy;
  if (intent.side !== 'sell' && !(await page.$(submitSel))) submitSel = SELECTORS.submit;
  // Заполнение цены + количества с ПРОВЕРКОЙ ФАКТИЧЕСКИХ значений. XT не принимает
  // программный value для поля КОЛИЧЕСТВА (React/слайдер), а кнопка "Buy TIG" активна
  // даже при пустом кол-ве — поэтому опираться на isSubmitReady нельзя. Проверяем сами
  // значения и добиваем пустое поле реальным вводом с клавиатуры (свежий хэндл, т.к.
  // форма пересобирается после выбора стороны).
  const wantPrice = String(intent.price);
  const wantQty = String(intent.quantity);
  const wantP = parseFloat(wantPrice);
  const wantQ = parseFloat(wantQty);
  const readValsOf = (pg) => pg.$$eval(SELECTORS.numberInput, (els) => els.map((e) => e.value));
  const readVals = () => readValsOf(page);
  const setFieldOn = async (pg, idx, val) => {
    const cur = await pg.$$(SELECTORS.numberInput);
    if (cur[idx]) await typeNumber(pg, cur[idx], val);
  };
  const setField = (idx, val) => setFieldOn(page, idx, val);
  // Значение поля «похоже» на нужное: XT усекает по шагу токена, поэтому не точное
  // равенство, а близость (f ≈ want). Главное — отличить наше значение от значения
  // ПРОШЛОГО ордера (напр. 12.89 в поле, когда хотим 2.86 → далеко → перезаписать).
  const closeEnough = (v, want) => {
    const f = parseFloat(String(v).replace(/[,\s]/g, ''));
    return isFinite(f) && want > 0 && f <= want * 1.03 && f >= want * 0.85;
  };
  if (cold) {
    await page.waitForSelector(submitSel, { state: 'visible', timeout: 10000 }).catch(() => {});
    // ST-токены (напр. 币安底裤) на холодной странице показывают risk-модалку
    // «Предупреждение о рисках» → закрываем её (кнопка «Понятно»), иначе перехватит
    // клики по форме на 30с.
    await dismissBlockingModal(page);
    // ХОЛОДНАЯ форма: XT инициализирует форму АСИНХРОННО уже после появления кнопки —
    // проставляет рыночную цену и держит количество пустым. Если заполнить ДО этого,
    // React затрёт наши значения своими дефолтами (ловили: цена 0.10→0.1291, кол-во →
    // пусто → order/place не ушёл). Ждём, пока XT сам проставит цену (init завершён).
    for (let i = 0; i < 25; i++) {
      const v = await readVals().catch(() => []);
      if (v[0] && parseFloat(String(v[0]).replace(/[,\s]/g, '')) > 0) break;
      await page.waitForTimeout(150);
    }
    await dismissBlockingModal(page); // модалка могла появиться за время init
  }
  // Заполняем оба поля так, чтобы КАЖДОЕ реально содержало нужное значение (строгая
  // проверка fieldFresh ниже). Поле количества на XT может сохранить значение прошлого
  // ордера (программный/быстрый ввод его не обновляет) → его надо перепечатать заново.
  const settleMs = Number(process.env.ARBI_BINGX_FILL_SETTLE_MS || 40); // было 120→60→40
  // СТРОГАЯ проверка «поле УЖЕ содержит нужное значение» — в пределах одного шага
  // последнего отображаемого разряда XT (усечение/округление). В ОТЛИЧИЕ от closeEnough
  // (±%, широкая, для усадки по балансу) она НЕ принимает близкое-но-ЧУЖОЕ значение
  // прошлого ордера. Это критично: быстрый ввод (fastSetInputs) НЕ обновляет поле
  // КОЛИЧЕСТВА на XT → без строгой проверки закрепилась бы сумма прошлого ордера
  // (напр. 92.37 вместо 95.23, обе в пределах ±3% → ошибочная заявка). Здесь такое
  // поле признаётся «не своим» и добивается клавиатурой.
  // fieldFresh — единая строгая проверка из order-utils (M3: допуск от want, см. там).
  const bothFresh = (v) => fieldFresh(v[0], wantP) && fieldFresh(v[1], wantQ);
  let finalVals = [];
  // Лимит объёма известен ЗАРАНЕЕ (прогрев / прошлые заявки / файл) и заявка больше
  // него: полную сумму в форму НЕ вводим. Она переводила форму в состояние ошибки
  // («не может быть больше 500»), из которого BingX выходит ~1,5–2 с — лог 15.09
  // 20:39: кнопка=1564/2138 у части в главной вкладке против 113 у свежих. Части сразу.
  const knownLimit = knownVolumeLimit(pair);
  const knownOver = knownLimit > 0 && wantQ * wantP > knownLimit * 1.001;
  if (knownOver) log(`BingX: лимит объёма ${knownLimit} USDT известен заранее, заявка ~${(wantQ * wantP).toFixed(2)} USDT → сразу частями, форму целиком не заполняю`);
  // Быстрый путь (ARBI_BINGX_FAST_FILL, по умолчанию ВКЛ): установка обоих полей
  // залпом нативным сеттером за один evaluate (как у MEXC) вместо посимвольного
  // ввода двух полей (~0.25с). БЕЗОПАСНО: значения проверяются СТРОГО (fieldFresh);
  // поле, которое быстрый ввод не прижал (напр. количество с React-слайдером),
  // добивается клавиатурой в цикле ниже, а ensureFilled перепроверяет перед кликом.
  // Отключить: ARBI_BINGX_FAST_FILL=0. Cold-форма — всегда посимвольно (там React
  // асинхронно затирает значения, залп ненадёжен).
  if ((process.env.ARBI_BINGX_FAST_FILL || '1') === '1' && !cold && !knownOver) {
    await fastSetInputs(page, wantPrice, wantQty).catch(() => {});
    await page.waitForTimeout(settleMs);
    finalVals = await readVals().catch(() => []);
  }
  // Посимвольный ввод: добиваем ЛЮБОЕ поле, которое ещё не содержит НУЖНОГО значения
  // (строгая проверка — чтобы не оставить сумму прошлого ордера). На холодной форме /
  // без быстрого пути finalVals=[] → печатаются оба.
  for (let attempt = 0; !knownOver && attempt < 3 && !bothFresh(finalVals); attempt++) {
    if (!fieldFresh(finalVals[0], wantP)) await setField(0, wantPrice);
    if (!fieldFresh(finalVals[1], wantQ)) await setField(1, wantQty);
    await page.waitForTimeout(settleMs);
    finalVals = await readVals().catch(() => []);
  }
  // ── Количество «схлопнулось»: страница держит УСТАРЕВШИЙ баланс ─────────────
  // Форма BingX сама ужимает количество до доступного баланса. Сразу после
  // зачисления депозита / перевода Фонд→Спот страница ещё показывает старый
  // (часто НУЛЕВОЙ) баланс — количество превращается в 0.00000000, и страж
  // fieldFresh верно блокирует заявку («Поля не совпали … в форме 0.00000000»,
  // ASTEROIDETH 30.07: ручная продажа всего объёма сорвалась, AutoSell молчал).
  // Цикл заполнения выше укладывается в ~0.12с — баланс просто не успевает
  // доехать, и все попытки видят один и тот же ноль.
  //
  // Поэтому даём бирже дотянуть: переклик Buy→Sell (тот же приём, что перед
  // заполнением) + повторный ввод, суммарно до ARBI_BINGX_QTY_WAIT_MS.
  // БЕЗОПАСНОСТЬ: ждём и ПЕРЕЗАПОЛНЯЕМ, но НЕ ослабляем проверку — если баланс
  // так и не доедет, ниже вернётся прежняя ошибка, ордер не уйдёт. Только sell:
  // на покупке количество балансом токена не ограничено. Выключить: =0.
  const qtyWaitMs = Number(process.env.ARBI_BINGX_QTY_WAIT_MS || 4000);
  if (!knownOver && intent.side === 'sell' && qtyWaitMs > 0 && !closeEnough(finalVals[1], wantQ)) {
    const qtyDeadline = Date.now() + qtyWaitMs;
    log(`Количество в форме ${JSON.stringify(finalVals[1])} ≪ ${wantQty} — похоже, баланс страницы устарел, жду до ${qtyWaitMs}мс`);
    // Выход ПО ФАКТУ, а не по таймеру (оператор 12.09: «постоянно переклик»).
    // Устаревший баланс на то и устаревший, что он МЕНЯЕТСЯ, когда биржа его
    // дотянет. Если после переклика количество осталось тем же — баланс не
    // догружается, он такой и есть, и ждать нечего: дальше идут только лишние
    // клики по бирже (лог 09:08: 9 перекликов × 20 повторов намерения подряд по
    // STONK, где на бирже реально лежало 0.00435907). Порог — env.
    const stableNeed = Math.max(1, Number(process.env.ARBI_BINGX_QTY_STABLE_TRIES || 2));
    let lastQty = String(finalVals[1] ?? '');
    let stable = 0;
    while (Date.now() < qtyDeadline && !closeEnough(finalVals[1], wantQ)) {
      await refreshSellBalance();
      // Переключение вкладок перерисовывает форму — перезаполняем ОБА поля.
      await setField(0, wantPrice);
      await setField(1, wantQty);
      await page.waitForTimeout(settleMs);
      finalVals = await readVals().catch(() => []);
      const nowQty = String(finalVals[1] ?? '');
      if (nowQty === lastQty) {
        if (++stable >= stableNeed) {
          log(`Количество не изменилось после ${stable} перекликов (${JSON.stringify(finalVals[1])}) — это не устаревший баланс, а реальный остаток; прекращаю ждать`);
          break;
        }
      } else {
        stable = 0;
        lastQty = nowQty;
      }
    }
    log(closeEnough(finalVals[1], wantQ)
      ? `Баланс догрузился, количество принято: ${JSON.stringify(finalVals)}`
      : `Количество так и не принято: ${JSON.stringify(finalVals)} — блокирую заявку`);
  }
  // CR-3: ЦЕНА — строгая (fieldFresh), НЕ closeEnough ±15% (пропускал бы sell на 15%
  // ниже рынка). Широкий допуск — только количеству (усадка по балансу).
  if (!knownOver && (!fieldFresh(finalVals[0], wantP) || !closeEnough(finalVals[1], wantQ))) {
    console.log('[bingx-exec] [diag заполнение] ' + JSON.stringify({ finalVals, wantPrice, wantQty }));
    cleanup();
    // ПРИЧИНА, а не «поля не совпали» (#58: молчаливых/непонятных срезов не бывает).
    // Лог оператора 11:59: в форме ["0.1","7407.56","740.756"] при запросе 11000 —
    // цена принята, количество биржа сама урезала под доступный баланс (третье поле
    // «Всего» = доступные USDT). Это НЕ сбой ввода: денег на бирже меньше, чем нужно
    // на заявку. Говорим это прямо, с цифрами, и не даём заявке уйти урезанной.
    const inQ = parseFloat(String(finalVals[1] || '').replace(/[,\s]/g, ''));
    const capped = fieldFresh(finalVals[0], wantP) && isFinite(inQ) && inQ > 0 && inQ < wantQ * 0.85;
    const totalTxt = finalVals[2] ? `, «Всего» в форме ${finalVals[2]}` : '';
    const avail = capped ? await readAvailText(page, AVAIL_LABEL_RE.source).catch(() => '') : '';
    // На ПРОДАЖЕ ограничивает баланс МОНЕТЫ, а не USDT — прежний текст советовал
    // «пополнить баланс» и показывал доступные USDT (лог 09:08: «USDT доступно
    // 719.16» при нехватке STONK). Это уводило в другую сторону: денег на бирже
    // хватало, не было самой монеты. Говорим про ту сторону, которая упёрлась.
    const baseSym = String(pair).split('_')[0];
    const sellCap = capped && intent.side === 'sell';
    return { ok: false, error: sellCap
      ? `На бирже доступно к продаже ≈ ${finalVals[1]} ${baseSym}, а нужно ${wantQty} ${baseSym}${totalTxt} — форма сама урезала количество по балансу МОНЕТЫ (USDT тут ни при чём${avail ? `; на странице: ${avail}` : ''}). Ордер НЕ отправлен. Проверьте, дошёл ли депозит ${baseSym} и на тот ли аккаунт биржи.`
      : capped
      ? `Биржа урезала количество до ${finalVals[1]} из ${wantQty} по доступному балансу${totalTxt}${avail ? ` (на странице: ${avail})` : ''}. Ордер НЕ отправлен — пополните баланс на бирже или уменьшите объём.`
      : `Поля не совпали с ордером: хотели цена=${wantPrice} кол-во=${wantQty}, в форме ${JSON.stringify(finalVals)}. Ордер НЕ отправлен.` };
  }
  if (!knownOver) log(`Поля заполнены: ${JSON.stringify(finalVals)} (хотели ${wantPrice}/${wantQty})`);
  const tFill = Date.now();
  // Разбор фазы submit+resp по шагам (#66: тюнить только по замеру). Она у BingX
  // держится ~1.8с и включает НЕ только ответ биржи: сверку пары, зачистки перед
  // кликом, сам клик, опрос и разбор модалок. Без разбивки непонятно, что лечить.
  const bs = { pair: 0, prep: 0, ovl: 0, blk: 0, rd: 0, refill: 0, click: 0, poll: 0, modal: 0, retry: 0 };
  const _tPair = Date.now();

  // CR-1 (learn-on-confirm): строгая сверка токена на странице с базой интента.
  // GENSYN на BingX = «AI» (displayName≠coinName) легитимен — оператор подтверждает
  // разово в терминале (тогда приходит hints.coinAlias, блока нет). Без алиаса — блок
  // со структурным pairMismatch (терминал: «это верный токен?» → сохранит алиас → повтор).
  const base = String(pair).split('_')[0];
  const pageBase = await page.evaluate(() => {
    for (const h of document.querySelectorAll('h1')) {
      const m = (h.textContent || '').trim().match(/([A-Za-z0-9一-鿿]+)\s*[/\-]\s*[A-Za-z]{2,}/);
      if (m) return m[1];
    }
    return null;
  }).catch(() => null);
  bs.pair = Date.now() - _tPair;
  const gate = pairGate(pageBase, base, intent.hints && intent.hints.coinAlias);
  if (gate.block) {
    cleanup();
    // Кэш пары этой вкладки НЕДЕЙСТВИТЕЛЕН: страница показала не тот/нечитаемый токен.
    // Без сброса cachedPairWarm вечно отдавал бы её «тёплой» → следующий интент того же
    // токена повторял бы блок без ре-навигации (застревание на mismatch/unreadable).
    page.__arbiPair = null;
    if (gate.reason === 'unreadable') {
      return { ok: false, riskModal: !!page.__arbiSawRisk,
        error: `Не удалось прочитать пару на странице BingX (ожидался ${base}) — ордер НЕ отправлен. Обновите страницу пары и повторите.` };
    }
    return { ok: false, pairMismatch: true, pageBase, wanted: base,
      error: `Биржа показывает пару ${pageBase}/…, а ордер для ${base}. Подтвердите, что это верный токен.`,
      riskModal: !!page.__arbiSawRisk };
  }
  if (gate.reason === 'alias') log(`M8: BingX — ордер по ${base} пропущен по подтверждённому алиасу «${pageBase}» (доверенный реестр терминала для этой пары)`);

  // Один клик + ожидание ответа. Если ответа нет за attemptMs — возвращаем null
  // (заявка НЕ ушла — значит клик не отправил ордер, повтор безопасен).
  // У XT сторона выбирается кликом кнопки (Buy/Sell видны одновременно), поэтому
  // тут (в отличие от MEXC) НЕТ логики «активной вкладки» — просто жмём нужную кнопку.
  const clickAndWait = async (attemptMs) => {
    const respP = page.waitForResponse(
      (r) => firedReqs.has(r.request()),
      { timeout: attemptMs },
    );
    const respOrNull = respP.then((r) => r, () => null);
    // CR-2: POST ордера УЖЕ ушёл (мог уйти, пока дозаполняли/подтверждали) — повторный
    // клик ЗАДВОИТ ордер. Не кликаем: ждём захваченный ответ и возвращаем его.
    if (orderReqFired) {
      let cap = capturedOrderResp;
      for (let i = 0; !cap && i < Math.ceil(attemptMs / 100); i++) { await page.waitForTimeout(100); cap = capturedOrderResp; }
      return cap;
    }
    // Доверенный клик (CDP Input → isTrusted=true → анти-бот минтит подпись).
    // .catch: если модалка подтверждения (ant-modal-confirm) перехватывает клик,
    // НЕ роняем ордер жёсткой ошибкой (ловили на KTA: page.click Timeout 5000мс) —
    // идём в ветку __slow__ ниже, где жмём подтверждение и ждём ответ / повтор.
    const _tClick = Date.now();
    await page.click(submitSel, { timeout: 3000, noWaitAfter: true }).catch(() => {});
    bs.click += Date.now() - _tClick;
    // БЫСТРЫЙ ДЕТЕКТ (было: фиксированное ожидание slowMs до 1200мс → лишняя ~1с на
    // КАЖДОЙ агрессивной лимитке, где всплывает модалка «может быть исполнен сразу»).
    // Поллим коротко: как только пришёл РЕАЛЬНЫЙ ответ ордера — готово; как только
    // видна модалка подтверждения/ошибки — сразу в ветку обработки, не ждём зря.
    const pollUntil = Math.min(attemptMs, 1500);
    const startedAt = Date.now();
    const _tPoll = startedAt;
    let r = null;
    while (Date.now() - startedAt < pollUntil) {
      const raced = await Promise.race([
        respOrNull,
        new Promise((res) => setTimeout(() => res('__tick__'), 100)),
      ]);
      if (raced !== '__tick__') { r = raced; break; } // пришёл ответ (или null)
      const modalUp = await page.evaluate(() => {
        const vis = (e) => e && e.offsetParent !== null;
        return Array.from(document.querySelectorAll('[role="dialog"],[class*="odal" i],[class*="ialog" i]')).some(vis);
      }).catch(() => false);
      if (modalUp) { r = '__slow__'; break; }
    }
    bs.poll += Date.now() - _tPoll;
    if (r === '__tick__' || r === null) r = '__slow__'; // ничего явного → проверим модалку/повтор
    const _tModal = Date.now();
    if (r === '__slow__') {
      // Модалка «Недостаточно средств»? НЕ жмём confirm — внутри неё кнопка «Купить»
      // (= пополнение за фиат), и confirm-селектор по «Купить» попал бы по ней (лишний
      // клик/уход на пополнение). Сигналим наружу — там закроем и выйдем без повтора.
      const blk = await dismissBlockingModal(page);
      if (/insufficient|not enough|недостаточн/i.test(blk.text || '')) {
        return '__nofunds__';
      }
      // Модалка «Цена на X% выше/ниже последней — Вы уверены?» (лимитка вне рынка,
      // штатный сценарий: ставим в стакан). Её надо ПОДТВЕРДИТЬ, иначе ордер не уйдёт.
      // Отмечаем «Никаких подсказок час» + жмём «Подтвердить».
      const confirmedPrice = await confirmOrderPrompt(page);
      if (confirmedPrice) log('Подтвердил цену вне рынка (модалка «Вы уверены?»)');
      // Реальную модалку подтверждения ордера dismissBlockingModal НЕ трогает —
      // подтверждаем её кликом confirm (если не была модалка цены выше).
      if (!confirmedPrice) {
        // Кнопку подтверждения жмём ТОЛЬКО ЕСЛИ ОНА УЖЕ НА ЭКРАНЕ. Прежний
        // безусловный клик ждал её все 1500 мс и уходил в catch, когда модалки нет
        // вовсе — а нет её почти всегда: детектор выше считает модалкой и промо-тост
        // BingX («Спот листинг»). Замер оператора 2026-09-08:
        // [timing submit] ожидание=101 модалки=1519 при submit+resp=1795 — полторы
        // секунды из двух уходило на ожидание кнопки, которой не существует.
        const cbtn = page.locator(SELECTORS.confirm).first();
        if (await cbtn.isVisible().catch(() => false)) {
          await cbtn.click({ timeout: 1500, noWaitAfter: true })
            .then(() => log('Подтвердил модалку ордера'))
            .catch(() => { /* исчезла, пока жали */ });
        }
      }
      r = await respOrNull;
    }
    bs.modal += Date.now() - _tModal;
    return r;
  };

  // СТРАХОВКА перед кликом: между заполнением и сабмитом холодная форма XT могла
  // сбросить поля (React ре-гидратация) → перезаполняем ЛЮБОЕ поле, где значение слетело.
  // Без этого ордер уходил с пустым количеством (ловили: поля=[цена,"",""]).
  const ensureFilled = async () => {
    let t = Date.now();
    await dismissOverlays(page);      // закрыть промо/опрос BingX (Satisfaction Survey), перехватывающий клик по ордеру
    bs.ovl += Date.now() - t; t = Date.now();
    await dismissBlockingModal(page); // убрать risk/ошибка-модалку, если перехватывает клики
    bs.blk += Date.now() - t; t = Date.now();
    const v = await readVals().catch(() => []);
    bs.rd += Date.now() - t; t = Date.now();
    if (!fieldFresh(v[0], wantP)) await setField(0, wantPrice);
    if (!fieldFresh(v[1], wantQ)) await setField(1, wantQty);
    bs.refill += Date.now() - t;
  };

  // Доверенный клик по кнопке сабмита + ОДИН повтор, если ордер не ушёл.
  // Первая попытка КОРОТКАЯ (2000мс, было 5000): на risk-token/Innovation-Zone парах
  // (WOJAK и т.п.) первый trusted-клик стабильно НЕ отправляет order/place, и заявку
  // ставит именно повтор — ждать 5с перед ним впустую (ловили submit+resp≈5.4с на бою).
  const _tPrep = Date.now();
  if (knownOver) { await dismissOverlays(page); await dismissBlockingModal(page); } else await ensureFilled();
  // M5 (BingX): сверка стороны кнопки сабмита ПЕРЕД кликом. Для buy submitSel может
  // сфолбэчиться на общий SELECTORS.submit (обе btn-order-* в DOM), и .first() из них
  // мог оказаться КРАСНОЙ (Sell) кнопкой → buy ушёл бы продажей. Читаем сторону РЕАЛЬНОЙ
  // кнопки (класс btn-order-red/blue + текст) и блокируем явно противоположную.
  {
    const domSide = await page.$eval(submitSel, (el) => {
      const c = String((el.className && el.className.baseVal) || el.className || '');
      if (/btn-order-red/i.test(c)) return 'sell';
      if (/btn-order-blue/i.test(c)) return 'buy';
      const t = (el.textContent || '').toLowerCase();
      if (/sell|продать/.test(t)) return 'sell';
      if (/buy|купить/.test(t)) return 'buy';
      return '';
    }).catch(() => '');
    if (domSide && domSide !== intent.side) {
      cleanup();
      return { ok: false, error: `BingX: сторона на форме (${domSide}) ≠ запрошенной (${intent.side}) — ордер НЕ отправлен.` };
    }
  }
  // ЛИМИТ ОБЪЁМА ЧИТАЕМ ДО ОЖИДАНИЯ КНОПКИ (замер оператора 2026-09-08 12:24: между
  // «Поля заполнены» и «Нажимаю кнопку» уходило ~2 с). Когда объём заявки БОЛЬШЕ
  // лимита пары, биржа кнопку не активирует ВООБЩЕ — цикл ожидания (25×60 мс)
  // выкручивался впустую на каждой такой заявке. Порядок исправлен: сперва читаем
  // подсказку лимита, и при превышении сразу идём в разбивку по частям.
  // split-C3: текст подсказок о лимите объёма берём из браузера, а РАЗБОР числа —
  // тестируемым parseVolumeLimit (RU-локаль: "5 000" пробелом, "5,5" запятой, K/M).
  // Два прохода: по классам (error/tip/warn) и — если пусто — по ЛЮБОМУ видимому
  // листовому элементу с подсказкой «… N USDT»: BingX переименовывает классы, а
  // текст «Стоимость не может быть больше 500 USDT» стабилен (скрин оператора
  // 2026-09-08). Без фолбэка лимит не находился → split не запускался → заявка
  // «не выставляется» при заблокированной биржей кнопке.
  // ТОЧНЫЙ ЭЛЕМЕНТ (оператор 2026-09-08, DevTools): подсказка биржи о лимите живёт в
  //   <div class="error-msg"> Стоимость не может быть больше 500 USDT </div>
  // внутри .limit-input-wrapper › .amount-multi-input-wrap › .trader-input-wrap-dark.
  // Читаем ЕГО напрямую, без поиска по похожим словам: видимый div.error-msg в форме
  // ордера с числом и USDT = лимит одной заявки. Прежние пути (классы+слова, листья)
  // остаются запасными на случай смены вёрстки. Возвращает {limit, text}.
  const readVolumeLimit = () => readVolumeLimitOn(page);
  const readVolumeLimitUsdt = async () => (await readVolumeLimit()).limit;
  // ЛИМИТ ОБЪЁМА ВИДЕН ДО КЛИКА. Биржа показывает «Стоимость не может быть больше
  // N USDT» и БЛОКИРУЕТ кнопку сразу после ввода суммы. Прежний путь всё равно
  // кликал: Playwright ждал «кнопка активна» 3 с, потом опрос и медленная ветка
  // ещё до 3,5 с — и только затем разбивка. Теперь при видимом лимите идём в
  // разбивку сразу (≈6 с экономии, и ни одного клика по заблокированной кнопке).
  const pre = knownOver ? { limit: knownLimit, text: '', exact: true } : await readVolumeLimit();
  const preLimit = pre.limit;
  rememberVolumeLimit(pair, preLimit);
  const preOver = preLimit > 0 && wantQ * wantP > preLimit * 1.001;
  if (preOver) { if (!knownOver) log(`BingX: лимит объёма ${preLimit} USDT — биржа пишет «${pre.text}»${pre.exact ? '' : ' (найдено запасным путём)'}; запрошено ~${(wantQ * wantP).toFixed(2)} USDT → сразу ставлю частями не больше лимита`); }
  else if (preLimit > 0) log(`BingX: лимит объёма ${preLimit} USDT — заявка ~${(wantQ * wantP).toFixed(2)} USDT в пределах, ставлю целиком`);

  // BingX держит кнопку «Купить/Продать» (btn-order-bl) DISABLED, пока асинхронно
  // валидирует форму после заполнения (класс bx-btn-disabled). Клик по disabled
  // игнорируется → «первый клик не отправил» → лишний повтор (главный тормоз, 8с).
  // Дожидаемся, пока кнопка станет активной (до ~2с), ТОГДА жмём — первый клик уходит.
  if (!preOver) {
    for (let i = 0; i < 25; i++) {
      if (await isSubmitReady(page, intent.side)) break;
      await page.waitForTimeout(60);
    }
    log('Нажимаю кнопку ордера (trusted-клик)...');
  }
  // На ТОЛЬКО ЧТО переключённой/холодной паре первый trusted-клик часто не рождает
  // POST (React ещё перепривязывает onClick после SPA) → первую попытку делаем
  // КОРОТКОЙ (ARBI_BINGX_RESP_TIMEOUT_FRESH_MS, ~800мс), чтобы быстрее перейти к повтору,
  // который заявку и ставит. На тёплой паре (switched=false) держим обычный таймаут —
  // там первый клик почти всегда срабатывает, короткий риск лишнего повтора не нужен.
  // BingX ставит ордер по ОДНОМУ клику Buy (модалки подтверждения НЕТ), но POST
  // /order/confirm + ответ идут через резидентный прокси (~1-3с). Первый таймаут —
  // достаточный, чтобы дождаться ответ с первой попытки, без лишнего повтора.
  const firstMs = (switched || cold)
    ? Number(process.env.ARBI_BINGX_RESP_TIMEOUT_FRESH_MS || 2500)
    : Number(process.env.ARBI_BINGX_RESP_TIMEOUT_MS || 3500);
  bs.prep = Date.now() - _tPrep;
  let resp = preOver ? null : await clickAndWait(firstMs);
  // Модалка «Недостаточно средств» (баланса реально нет): повтор клика БЕСПОЛЕЗЕН
  // (та же модалка) и ВРЕДЕН (риск клика по «Купить»=пополнение — «лишний клик»,
  // на который жаловался оператор; + модалки копились). clickAndWait сигналит
  // '__nofunds__', ИЛИ проверяем сами при пустом ответе. Закрываем и выходим СРАЗУ
  // с понятной ошибкой, без повтора (быстрый fail вместо потери ~1.5-6с).
  // Модалка «Недостаточно средств» на ПЕРВОМ клике: clickAndWait её уже закрыл
  // крестиком (не жали «Купить» внутри — тот самый лишний клик; модалки не копятся).
  // ВАЖНО: после смены пары эта модалка ЧАСТО ЛОЖНАЯ (форма ещё не пересчитала
  // «Всего» → XT думает, что баланса нет), и тот же ордер проходит со ВТОРОЙ попытки.
  // Поэтому здесь НЕ фейлим — сбрасываем в null и идём в обычный повтор ниже; fail
  // только если недостаток ПОДТВЕРДИТСЯ на повторе.
  if (resp === '__nofunds__') {
    await dismissBlockingModal(page); // добить, если ещё висит
    resp = null;
  }
  // ЛИМИТ ОБЪЁМА ИЗ ОТКАЗА БИРЖИ (лог напарника 2026-09-08: «BingX отклонил ордер:
  // Максимальная стоимость для ордера - 500.0000»). Подсказки в форме может не быть
  // вовсе — тогда лимит виден ТОЛЬКО в ответе, и заявка падала целиком, хотя её надо
  // просто разбить. Отказ = на бирже НИЧЕГО не встало, поэтому повтор частями
  // безопасен даже при orderReqFired (задвоения нет — первый ордер отклонён).
  let limitFromResp = 0;
  if (resp && typeof resp !== 'string') {
    const rawR = await resp.text().catch(() => '');
    let jr = null; try { jr = rawR ? JSON.parse(rawR) : null; } catch { /* не JSON */ }
    const okR = resp.status() >= 200 && resp.status() < 300 && jr && (jr.code === 0 || jr.rc === 0 || jr.mc === 'SUCCESS');
    if (!okR) {
      const lim = parseRejectLimit(jr ? String(jr.msg || jr.message || jr.mc || '') : rawR);
      if (lim > 0 && wantQ * wantP > lim * 1.001) {
        limitFromResp = lim;
        rememberVolumeLimit(pair, lim);
        log(`BingX отклонил заявку по лимиту объёма ${lim} USDT (запрошено ~${(wantQ * wantP).toFixed(2)}) — ставлю частями`);
        resp = null;
      }
    }
  }
  // ── Авто-разбивка заявки по ЛИМИТУ ОБЪЁМА BingX (ARBI_BINGX_SPLIT_ORDERS, по
  // умолчанию ВКЛ; выключить: =0) ──. Часть токенов на BingX ограничивает объём одной
  // заявки («доступно только 500 USDT» / «Стоимость не может быть больше 500 USDT»).
  // Если запрошенный объём БОЛЬШЕ лимита —
  // ставим заявку частями (макс + остаток), пока не разместим весь объём; терминалу
  // возвращаем ОДИН успех (детали — в поле split). MONEY-PATH: строгая сверка полей
  // (fieldFresh/closeEnough) на каждой части сохранена; жёсткий предел числа частей.
  // Проверяем ДО тяжёлого повтора (при лимите повтор всё равно не поможет).
  // КРИТИЧНО: !orderReqFired — если POST ордера УЖЕ ушёл (ответ медленный из-за
  // прокси), split ЗАПРЕЩЁН: части легли бы ПОВЕРХ уже ушедшего полного ордера
  // (задвоение объёма). Тогда просто ждём ответ в обычной ветке ниже.
  if (!resp && (!orderReqFired || limitFromResp > 0) && (process.env.ARBI_BINGX_SPLIT_ORDERS || '1') === '1' && wantP > 0) {
    // Лимит: из отказа биржи → из подсказки, прочитанной ДО клика → чтением сейчас.
    const limitUsdt = limitFromResp || (preOver ? preLimit : await readVolumeLimitUsdt());
    if (limitUsdt > 0 && wantQ * wantP > limitUsdt * 1.001) {
      const margin = Number(process.env.ARBI_BINGX_SPLIT_MARGIN || 0.98);
      const MAX_CHUNKS = Number(process.env.ARBI_BINGX_SPLIT_MAX_CHUNKS || 20);
      const curMaxQty = (limitUsdt / wantP) * margin; // макс количество на одну часть
      const placedIds = []; let placedQty = 0;
      log(`BingX: лимит объёма ~${limitUsdt} USDT, запрошено ~${(wantQ * wantP).toFixed(2)} USDT → ставлю частями [SPLIT], макс ~${curMaxQty.toFixed(6)}/часть`);
      await dismissBlockingModal(page).catch(() => {});
      // ── ЧАСТИ ДРУГ ЗА ДРУГОМ, БЕЗ ЛИШНЕГО (оператор 2026-09-08) ──
      // Замер 09:51 (старый путь): ~2.3 с на часть — посимвольный ввод обоих полей
      // (~0.4 с), ответ биржи (~0.7 с), пауза 150 мс, подтверждения на каждой.
      // Замер 10:23 (конвейер без ожидания ответа): часть 1 ok, часть 2 — «клик не
      // отправил запрос», 8.3 с. Причина: по ОТВЕТУ на часть 1 BingX сбрасывает
      // форму (стирает количество) и кнопка гаснет — заполненная до ответа часть 2
      // стёрта, клик по неактивной кнопке ждал впустую. Значит ответ биржи — пол:
      // раньше него следующую часть заполнять нельзя. Оставляем быстрым всё
      // остальное: части заранее, заполнение залпом, без паузы, без лишних
      // подтверждений, клик → появление ЗАПРОСА → ответ по ЕГО request-объекту →
      // сразу следующая часть. Ожидаемо ~0.8–0.9 с на часть вместо 2.3.
      const chunks = [];
      { let rem = wantQ; for (let c = 0; c < MAX_CHUNKS && rem > 1e-12; c++) { const q = Math.min(rem, curMaxQty); if (!(q > 0)) break; chunks.push(q); rem -= q; } }
      rememberVolumeLimit(pair, limitUsdt);
      const fillChunkOn = async (pg, cq) => {
        const cqStr = String(cq);
        let v = [];
        if ((process.env.ARBI_BINGX_FAST_FILL || '1') === '1') {
          await fastSetInputs(pg, wantPrice, cqStr).catch(() => {});
          // Не спим settleMs вслепую: читаем сразу, пересчитываем короткими шагами.
          for (let k = 0; k < 6; k++) {
            v = await readValsOf(pg).catch(() => []);
            if (fieldFresh(v[0], wantP) && fieldFresh(v[1], cq)) break;
            await pg.waitForTimeout(20);
          }
        }
        // Что залп не прижал — добиваем клавиатурой (строгая сверка обоих полей).
        for (let a = 0; a < 2 && !(fieldFresh(v[0], wantP) && fieldFresh(v[1], cq)); a++) {
          if (!fieldFresh(v[0], wantP)) await setFieldOn(pg, 0, wantPrice);
          if (!fieldFresh(v[1], cq)) await setFieldOn(pg, 1, cqStr);
          await pg.waitForTimeout(settleMs);
          v = await readValsOf(pg).catch(() => []);
        }
        // Продажа: количество схлопнулось — баланс страницы отстал (тот же приём, что в основном пути).
        if (intent.side === 'sell' && qtyWaitMs > 0 && fieldFresh(v[0], wantP) && !closeEnough(v[1], cq)) {
          const dl = Date.now() + Math.min(qtyWaitMs, 2500);
          const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
          while (Date.now() < dl && !closeEnough(v[1], cq)) {
            await clickSideTab(pg, SELECTORS.sideBuyRe); await pg.waitForTimeout(refMs);
            await clickSideTab(pg, SELECTORS.sideSellRe); await pg.waitForTimeout(refMs);
            await fastSetInputs(pg, wantPrice, cqStr).catch(() => {});
            await pg.waitForTimeout(settleMs);
            v = await readValsOf(pg).catch(() => []);
          }
        }
        return v;
      };
      const fillChunkFast = (cq) => fillChunkOn(page, cq);
      // Проглоченный клик (лог 0.4.136: часть 3 — клик→запрос 1,7 с) — ждём запрос
      // недолго и повторяем. Повтор безопасен: он только когда запроса НЕ было.
      const reqWaitMs = Number(process.env.ARBI_BINGX_SPLIT_REQ_WAIT_MS || 400);
      const waitPartRequest = async (before) => {
        const dl = Date.now() + reqWaitMs;
        while (Date.now() < dl) {
          if (firedReqs.size > before) return [...firedReqs].pop();
          await page.waitForTimeout(15);
        }
        return null;
      };
      const isOrderReq = (r) => { try { return r.method() === 'POST' && ORDER_PLACE_RE.test(r.url()); } catch { return false; } };
      const parsePart = async (cr, i) => {
        if (!cr) return { err: `часть ${i + 1}: нет ответа биржи` };
        let rawc = ''; try { rawc = await cr.text(); } catch { /* нет тела */ }
        let jc = null; try { jc = rawc ? JSON.parse(rawc) : null; } catch { /* не JSON */ }
        const okc = cr.status() >= 200 && cr.status() < 300 && jc && (jc.code === 0 || jc.rc === 0 || jc.mc === 'SUCCESS');
        if (!okc) return { err: `часть ${i + 1}: отклонена (${(jc && (jc.msg || jc.mc || jc.message)) || `HTTP ${cr.status()}`})` };
        const mm = rawc.match(/"order(?:No|Id)"\s*:\s*"?(\d+)"?/);
        return { id: mm ? mm[1] : '?' };
      };
      const tSplit = Date.now();
      let stopReason = null;
      let respMsTotal = 0;
      // ── ПАРАЛЛЕЛЬНО ПО ВКЛАДКАМ: по одной части на вкладку, клики залпом ──
      const extraTabs = chunks.length > 1 ? splitTabsOf(context, pair, page) : [];
      if (extraTabs.length > 0) {
        const pages = [page, ...extraTabs].slice(0, chunks.length);
        const tPrepTabs = Date.now();
        await Promise.all(extraTabs.slice(0, pages.length - 1).map((pg) => prepSplitTab(pg, intent.side).catch(() => false)));
        log(`[SPLIT] параллельно: ${pages.length} вкладок на ${chunks.length} частей (подготовка сторон ${Date.now() - tPrepTabs} мс)`);
        const placePartOn = async (pg, cq, i, tabNo) => {
          const t1 = Date.now();
          // Сколько вкладка простояла без прогрева до этой заявки: именно возраст
          // объясняет разброс «заполнения» (свежая — десятки мс, отстоявшаяся —
          // цикл ожидания баланса до 2,5 с).
          const idleS = pg.__arbiSplitAt ? Math.round((t1 - pg.__arbiSplitAt) / 1000) : null;
          const v = await fillChunkOn(pg, cq);
          if (!fieldFresh(v[0], wantP) || !closeEnough(v[1], cq)) return { ok: false, err: `часть ${i + 1} (вкладка ${tabNo}): поля не совпали (в форме ${JSON.stringify(v)}, хотели ${wantPrice}/${cq})` };
          const t2 = Date.now();
          for (let k = 0; k < 50; k++) { if (await isSubmitReady(pg, intent.side)) break; await pg.waitForTimeout(20); }
          const t3 = Date.now();
          // Запрос и ответ ловим подписками, взведёнными ДО клика (ответ мог бы прийти
          // между «запрос есть» и подпиской на ответ). На вкладке-части order/place шлём только мы.
          let reqP = pg.waitForRequest(isOrderReq, { timeout: reqWaitMs }).catch(() => null);
          let respP = pg.waitForResponse((r) => isOrderReq(r.request()), { timeout: 8000 + reqWaitMs }).catch(() => null);
          await pg.click(submitSel, { timeout: 2000, noWaitAfter: true, force: true }).catch(() => {});
          let req = await reqP;
          if (!req) {
            respP.catch(() => {});
            await confirmOrderPrompt(pg).catch(() => {});
            reqP = pg.waitForRequest(isOrderReq, { timeout: reqWaitMs * 2 }).catch(() => null);
            respP = pg.waitForResponse((r) => isOrderReq(r.request()), { timeout: 8000 }).catch(() => null);
            await pg.click(submitSel, { timeout: 2000, noWaitAfter: true, force: true }).catch(() => {});
            req = await reqP;
          }
          if (!req) {
            // Снимок ИМЕННО этой вкладки-части: без него в логе оставалась только
            // фраза «клик не отправил запрос ордера», а печатавшаяся следом
            // диагностика бралась с ГЛАВНОЙ вкладки (там полная сумма и ошибка
            // биржи про лимит 500 USDT) — причина отказа части была не видна
            // вовсе (#58, инцидент STONK/BingX 2026-09-16).
            const d = await orderPageDiag(pg);
            console.log(`[bingx-exec] [diag часть ${i + 1}/вкладка ${tabNo}] ` + JSON.stringify(d));
            return { ok: false, err: `часть ${i + 1} (вкладка ${tabNo}): клик не отправил запрос ордера` };
          }
          const t4 = Date.now();
          const cr = await respP;
          const respMs = Date.now() - t4;
          const pr = await parsePart(cr, i);
          if (pr.err) return { ok: false, err: `${pr.err} (вкладка ${tabNo})`, respMs };
          log(`  [SPLIT] часть ${i + 1} (вкладка ${tabNo}): ok ${pr.id} кол-во ${cq} (заполнение ${t2 - t1}, кнопка ${t3 - t2}, клик→запрос ${t4 - t3}, ответ ${respMs} мс; старт +${t1 - tSplit}${idleS === null ? '' : `, вкладка без прогрева ${idleS} с`})`);
          return { ok: true, id: pr.id, cq, respMs };
        };
        for (let ci = 0; ci < chunks.length && !stopReason; ) {
          const batch = pages.slice(0, chunks.length - ci).map((pg, j) => placePartOn(pg, chunks[ci + j], ci + j, j + 1));
          const rs = await Promise.all(batch);
          for (const r of rs) {
            if (r.ok) { placedIds.push(r.id); placedQty += r.cq; respMsTotal += r.respMs; }
            else if (!stopReason) stopReason = r.err;
          }
          ci += batch.length;
        }
      } else for (let i = 0; i < chunks.length; i++) {
        const cq = chunks[i];
        const t1 = Date.now();
        const v = await fillChunkFast(cq);
        // CR-3: ЦЕНА — строгая (fieldFresh), количество части — closeEnough (усадка по балансу).
        if (!fieldFresh(v[0], wantP) || !closeEnough(v[1], cq)) { stopReason = `часть ${i + 1}: поля не совпали (в форме ${JSON.stringify(v)}, хотели ${wantPrice}/${cq})`; break; }
        const t2 = Date.now();
        for (let k = 0; k < 50; k++) { if (await isSubmitReady(page, intent.side)) break; await page.waitForTimeout(20); }
        const t3 = Date.now();
        let before = firedReqs.size;
        // force: активность кнопки уже проверена isSubmitReady, ожидание «стабильности»
        // Playwright здесь только стоит времени (замер 0.4.128: клик 61–116 мс).
        await page.click(submitSel, { timeout: 2000, noWaitAfter: true, force: true }).catch(() => {});
        let req = await waitPartRequest(before);
        if (!req) { // модалка «цена вне рынка» / промо перехватили клик — подтвердить и повторить один раз
          await confirmOrderPrompt(page).catch(() => {});
          before = firedReqs.size;
          await page.click(submitSel, { timeout: 2000, noWaitAfter: true, force: true }).catch(() => {});
          req = await waitPartRequest(before);
        }
        if (!req) { stopReason = `часть ${i + 1}: клик не отправил запрос ордера`; break; }
        const t4 = Date.now();
        // Ответ ЭТОЙ части (по её request-объекту). Ждём здесь: по ответу BingX
        // сбрасывает форму, следующую часть заполняем только после этого.
        const tR = Date.now();
        const cr = await page.waitForResponse((r) => r.request() === req, { timeout: 8000 }).then((r) => r, () => null);
        respMsTotal += Date.now() - tR;
        const pr = await parsePart(cr, i);
        if (pr.err) { stopReason = pr.err; break; }
        placedIds.push(pr.id); placedQty += cq;
        log(`  [SPLIT] часть ${i + 1}: ok ${pr.id} кол-во ${cq} (заполнение ${t2 - t1}, кнопка ${t3 - t2}, клик→запрос ${t4 - t3}, ответ ${Date.now() - tR} мс)`);
      }
      log(`[SPLIT] ${placedIds.length} из ${chunks.length} частей за ${Date.now() - tSplit} мс, из них ответы биржи ${respMsTotal} мс${extraTabs.length ? ` [параллельно, вкладок ${Math.min(extraTabs.length + 1, chunks.length)}]` : ' [в одной вкладке]'}`);
      // Частей было больше, чем вкладок → к следующему разу дооткрыть вкладки-части
      // (в фоне, после ответа терминалу; навигации по очереди).
      if (chunks.length > extraTabs.length + 1 && splitTabsWanted() > 1) setTimeout(() => ensureSplitTabs(context, pair, page, log).catch(() => {}), 50);
      if (stopReason) log(`  [SPLIT] стоп: ${stopReason}`);
      if (placedQty > 0) {
        page.off('response', onResp); page.off('request', onReq);
        const shortfall = Math.max(0, wantQ - placedQty);
        log(`[SPLIT] итог: размещено ~${placedQty.toFixed(6)} из ${wantQ} в ${placedIds.length} заявок${shortfall > wantQ * 0.02 ? ` (недобор ${shortfall.toFixed(6)})` : ''}`);
        // Разбивка ДО частей (#66: тюним только по замеру) — на split-пути её раньше не было,
        // и невидимыми оставались как раз секунды перед разбивкой, а не сама разбивка.
        log(`[timing submit] до разбивки: пара=${bs.pair} подготовка=${bs.prep}(оверлеи=${bs.ovl} блок-модалки=${bs.blk} чтение=${bs.rd} дозаполнение=${bs.refill}) клик=${bs.click}`);
        return { ok: true, orderId: String(placedIds[0]), split: { count: placedIds.length, orderIds: placedIds, placedQty, requestedQty: wantQ, shortfall }, riskModal: !!page.__arbiSawRisk };
      }
      log('[SPLIT] ни одна часть не размещена — обычная обработка ошибки');
      // ── Самолечение вкладок-частей (разбор STONK/BingX 2026-09-16) ─────────
      // Наблюдение из лога оператора: две попытки подряд сорвались на вкладках,
      // созданных сразу после старта профиля («клик не отправил запрос ордера»
      // при АКТИВНОЙ кнопке, верных полях и видимой вкладке), а следующая
      // попытка — уже на пересозданных вкладках — прошла за 1090 мс.
      //
      // Поэтому «глухие» вкладки закрываем, чтобы ensureSplitTabs открыл их
      // заново (навигации там по очереди — правило Akamai не нарушается).
      // Здесь НИЧЕГО не размещается и не повторяется: мы в ветке, где размещено
      // РОВНО НОЛЬ частей, поэтому задвоить заявку нечем. Худший исход правки —
      // вкладки пересоздадутся зря, то есть ровно сегодняшнее поведение.
      // Рубильник: ARBI_BINGX_SPLIT_HEAL=0.
      if ((process.env.ARBI_BINGX_SPLIT_HEAL || '1') === '1'
        && placedIds.length === 0
        && /клик не отправил запрос ордера/.test(stopReason || '')) {
        const dead = splitTabsOf(context, pair, page, true);
        let closed = 0;
        for (const pg of dead) { try { await pg.close(); closed += 1; } catch { /* уже закрыта */ } }
        if (closed) {
          log(`[SPLIT] вкладки-части (${closed}) не донесли нажатие до биржи — закрыл, открою заново к следующей попытке`);
          setTimeout(() => ensureSplitTabs(context, pair, page, log).catch(() => {}), 50);
        }
      }
      // ДАЛЬШЕ ПОЛНОЙ СУММОЙ ИДТИ НЕЛЬЗЯ. Мы в этой ветке ровно потому, что
      // заявка БОЛЬШЕ лимита биржи. Обычный путь ниже перезаполнит форму целиком
      // и нажмёт — кнопка заведомо disabled, BingX пишет «Стоимость не может
      // быть больше N USDT», и оператор получает отказ ПРО ЛИМИТ вместо
      // настоящей причины (лог 22.09 STONK: разбивка сорвалась о модалку
      // подтверждения отмены, а в отчёт попал лимит 846 USDT). Ноль размещённых
      // частей — задваивать нечего, отвечаем честно и отдаём ход терминалу.
      log(`[SPLIT] полной суммой не пробуем — она больше лимита биржи (${limitUsdt} USDT)`);
      page.off('response', onResp); page.off('request', onReq); // как на успешном выходе выше
      return {
        ok: false,
        error: `Разбивка не состоялась: ${stopReason || 'ни одна часть не размещена'}. Полной суммой нельзя — лимит биржи ~${limitUsdt} USDT, заявка ~${(wantQ * wantP).toFixed(2)} USDT. Вкладки-части пересоздаются, повторите заявку.`,
        riskModal: !!page.__arbiSawRisk,
      };
    }
  }
  if (!resp) {
    // Повторяем клик ТОЛЬКО если реальный запрос ордера НЕ ушёл — иначе (запрос ушёл,
    // ответ медленный из-за прокси) повтор задвоит ордер. Тогда просто ждём ответ.
    if (orderReqFired) {
      log('Запрос ордера УЖЕ ушёл — ответ медленный, жду без повтора (не дублируем)');
      // Захваченный листенером ответ приоритетно (повторный waitForResponse пропускает
      // ответ, пришедший до новой подписки), дальше — поллинг переменной до 8с.
      resp = capturedOrderResp;
      for (let i = 0; !resp && i < 80; i++) {
        await page.waitForTimeout(100);
        resp = capturedOrderResp;
      }
    } else {
      log('Ответа нет и запрос ордера не ушёл — повтор клика (первый клик не отправил)');
      await ensureFilled(); // форма могла слететь снова — перезаполняем перед повтором
      bs.retry++;
      resp = await clickAndWait(6000);
      // Недостаток ПОДТВЕРДИЛСЯ и на повторе (форма уже готова) → реальный fail.
      if (resp === '__nofunds__') {
        await dismissBlockingModal(page);
        page.off('response', onResp);
        page.off('request', onReq);
        log('BingX: недостаточно баланса — подтверждено на повторе');
        return { ok: false, error: `BingX отклонил: недостаточно баланса для ордера (кол-во ${wantQty} @ ${wantPrice}).`, riskModal: !!page.__arbiSawRisk };
      }
    }
  }
  if (resp === '__nofunds__') resp = null; // страховка: не превратить маркер в «успех»
  if (!resp && capturedOrderResp) resp = capturedOrderResp; // последний шанс — захваченный ответ

  page.off('response', onResp);
  page.off('request', onReq);
  // POST ордера УШЁЛ, но ответ так и не получен: заявка, вероятно, стоит на бирже —
  // честное сообщение вместо ложного «не ушёл», провоцирующего ручной дубль.
  if (!resp && orderReqFired) {
    return {
      ok: false,
      ambiguous: true, // CR-6: неопределённость — терминал НЕ авторетраит (риск дубля)
      error: 'Запрос ордера отправлен на BingX, но ответ не получен (медленный прокси). Заявка, вероятно, ВЫСТАВЛЕНА — проверьте «Открытые ордера» перед повтором. Повторная отправка не выполнялась (защита от дублирования).',
      riskModal: !!page.__arbiSawRisk,
    };
  }
  if (!resp) {
    // Детальная диагностика: почему ордер не ушёл — кнопка disabled? поля пустые?
    // логин-стена (сессия истекла)? какие POST реально ушли?
    const diag = await orderPageDiag(page);
    console.log('[bingx-exec] [diag POST] ' + JSON.stringify(postUrls.slice(-10)));
    console.log('[bingx-exec] [diag страница] ' + JSON.stringify(diag));
    // XT показал модалку-ошибку (нехватка баланса и т.п.) — закрываем её (иначе
    // заблокирует следующий ордер) и возвращаем понятную причину.
    const modalText = (diag.dialogs || []).join(' | ');
    const closed = await dismissBlockingModal(page);
    if (/insufficient|not enough|недостаточн/i.test(modalText + ' ' + (closed.text || ''))) {
      return { ok: false, error: `BingX отклонил: недостаточно баланса для ордера (кол-во ${wantQty} @ ${wantPrice}).` };
    }
    return {
      ok: false,
      error: `order/place не ушёл. Кнопка "${diag.submitText}" disabled=${diag.submitDisabled}; поля=${JSON.stringify(diag.inputValues)}; loginWall=${diag.loginWall}; errors=${JSON.stringify(diag.errors)}; modal=${modalText.slice(0, 80)}; POST=${JSON.stringify(postUrls.slice(-6))}`,
    };
  }

  const tResp = Date.now();
  log(`[timing submit] пара=${bs.pair} зачистки=${bs.prep}(оверлеи=${bs.ovl} блок-модалки=${bs.blk} чтение=${bs.rd} дозаполнение=${bs.refill} сторона=${bs.prep - bs.ovl - bs.blk - bs.rd - bs.refill}) клик=${bs.click} ожидание=${bs.poll} модалки=${bs.modal}${bs.retry ? ` повторов=${bs.retry}` : ''}`);
  // Тайминг по фазам — чтобы видеть, где уходит время (цель ≤500мс на тёплой странице).
  log(`[timing] page=${tPage - t0} tabs=${tTabs - tPage} fill=${tFill - tTabs} submit+resp=${tResp - tFill} ИТОГО=${tResp - t0}мс`);

  const status = resp.status();
  // Читаем СЫРОЙ текст: orderNo BingX — большой int64, JSON.parse его ОКРУГЛЯЕТ
  // (2075161027569156096 → …000), а по округлённому id отмена ордера не найдёт заявку.
  // Точное значение достаём regex-ом из raw-текста.
  let raw = '';
  try { raw = await resp.text(); } catch { /* нет тела */ }
  let json = null;
  try { json = raw ? JSON.parse(raw) : null; } catch { /* не JSON */ }
  // Формат ответа BingX ПОДТВЕРЖДЁН на бою 2026-07-09:
  // {code:0, msg:"", data:{orderNo, coinName, status:11, price, side}}.
  // Совместимо и с XT-конвертом {rc:0, mc:"SUCCESS", result:{orderId}}.
  const data = json && json.data;
  const result = json && json.result;
  const okCode = json && (json.rc === 0 || json.code === 0 || json.mc === 'SUCCESS');
  if (status >= 200 && status < 300 && okCode) {
    let orderId = (result && result.orderId) || (data && (data.orderNo || data.orderId))
      || (typeof data === 'string' ? data : undefined) || (result && result.id);
    // Точный orderNo из raw (обходит округление int64) — приоритетно.
    const m = raw && raw.match(/"order(?:No|Id)"\s*:\s*"?(\d+)"?/);
    if (m) orderId = m[1];
    if (!orderId) return { ok: false, error: `success, но нет orderId: ${String(raw).slice(0, 160)}` };
    log(`Ордер выставлен: ${orderId}`);
    // ФАКТИЧЕСКОЕ количество заявки. Форма BingX усаживает его по доступному балансу
    // и шагу лота, а допуск closeEnough (до −15%) это осознанно пропускает — но
    // отдавать наверх просто «ok» нельзя: терминал считает, что ушло запрошенное.
    // Кейс CATE 2026-09-08: просили 5369.12751678, в форме было 5171.21601600
    // (−3,7%), вернули «ok» — и следующая автопродажа запросила объём, которого
    // уже нет. Отдаём placedQty и пишем расхождение в журнал (#58: молчаливых
    // расхождений на денежном пути не бывает).
    const placedQty = parseFloat(String((finalVals && finalVals[1]) || '').replace(/[,\s]/g, ''));
    // Порог 1%: усечение по шагу лота даёт доли процента (39389.80 против
    // 39389.80914600 — это 2e-5), а реальная усадка по балансу — единицы процентов
    // (CATE: −3,7%). Ниже порога — шум, выше — расхождение, о котором надо сказать.
    if (isFinite(placedQty) && wantQ > 0 && Math.abs(placedQty - wantQ) / wantQ > 0.01) {
      log(`⚠ В заявку ушло количество ${placedQty}, запрошено ${wantQty} (форма усадила по доступному балансу / шагу лота)`);
    }
    // riskModal — терминал обучит реестр known_tokens (в след. раз hint придёт заранее).
    return { ok: true, orderId: String(orderId), riskModal: !!page.__arbiSawRisk,
      ...(isFinite(placedQty) ? { placedQty, requestedQty: wantQ } : {}) };
  }
  const msg = json ? String(json.msg || json.message || json.mc || json.code) : `HTTP ${status}`;
  return { ok: false, error: `BingX отклонил ордер: ${String(msg).slice(0, 200)}`, riskModal: !!page.__arbiSawRisk };
}

/** Отмена ВСЕХ ордеров нативной кнопкой биржи «Cancel all» — для web-only токенов.
 * Селектор оператора: button.bx-btn-secondary.bx-btn-round.bx-btn-small с текстом «Cancel all». */
async function cancelAllOrders(context, pair, log) {
  const { page } = await getBingxPage(context, pair, log);
  await dismissOverlays(page);
  await dismissBlockingModal(page);
  const sel = process.env.ARBI_BINGX_SEL_CANCEL_ALL;
  // BingX: <button class="bx-btn-...">Cancel all</button> → getByText (устойчиво к вёрстке).
  const btn = sel ? page.locator(sel).first()
    : page.getByText(/^\s*(cancel all|отменить\s+вс[её]|отмена всех)\s*$/i).first();
  try { await btn.waitFor({ state: 'visible', timeout: 8000 }); }
  catch { return { ok: false, error: 'Кнопка «Отменить все» не найдена (задайте ARBI_BINGX_SEL_CANCEL_ALL).' }; }
  // ФАКТ отмены — ответ биржи на POST отмены, а не «кнопка нажата» (оператор 15.09:
  // журнал писал «подтверждение нажато», заявки оставались). Подписка ДО клика;
  // все POST за операцию — в след, чтобы по логу видеть реальный URL отмены.
  const posts = [];
  const onReq = (r) => { try { if (r.method() === 'POST') posts.push(r.url().replace(/\?.*$/, '')); } catch { /* игнор */ } };
  page.on('request', onReq);
  const cancelRe = new RegExp(process.env.ARBI_BINGX_CANCEL_URL_RE || 'cancel|revoke', 'i');
  const cancelResp = page.waitForResponse((r) => r.request().method() === 'POST' && cancelRe.test(r.url()), { timeout: Number(process.env.ARBI_BINGX_CANCEL_RESP_MS || 4000) }).then((r) => r, () => null);
  await btn.click({ timeout: 4000 }).catch(() => {});
  // ПОДТВЕРЖДЕНИЕ (скрин оператора 2026-09-08 11:55: «Вы уверены, что хотите отменить
  // все ордера (Лимитный)?» с кнопками «Закрыть» / «Подтвердить»). Прежний селектор
  // `[role="dialog"] button,[class*="modal"] button` эту модалку НЕ находил — журнал
  // писал «кнопка нажата», ордера оставались висеть. Ищем по СМЫСЛУ: видимый листовой
  // элемент с точным текстом подтверждения, у которого среди предков есть текст «отменить
  // все ордера» — тогда это точно наша модалка, а не кнопка формы. Клик — доверенный.
  const CONFIRM_RE = '^\\s*(подтвердить|подтверждаю|confirm|ok|да|yes)\\s*$';
  const markConfirm = () => page.evaluate((src) => {
    const re = new RegExp(src, 'i');
    const askRe = /(отменить\s+вс[её]|отмена\s+всех|cancel\s+all)/i;
    document.querySelectorAll('[data-arbi-cancelconfirm]').forEach((e) => e.removeAttribute('data-arbi-cancelconfirm'));
    // ПОСЛЕДНЕЕ совпадение, а не первое. Модалки подтверждения СТАКАЮТСЯ: каждая
    // неудачная отмена оставляет свою, и в логе оператора 22.09 их было видно
    // полдюжины разом. `find` брал самую раннюю в DOM — она лежит ПОД верхней,
    // клик по ней не проходит хит-тест, а журнал писал «подтверждение нажато».
    // Верхняя модалка в DOM идёт последней — её и берём.
    const all = Array.from(document.querySelectorAll('button,div,span,a')).filter((e) => {
      if (e.children.length || e.offsetParent === null) return false;
      if (!re.test((e.textContent || '').trim())) return false;
      for (let n = e.parentElement, i = 0; n && i < 6; n = n.parentElement, i++) {
        if (askRe.test((n.textContent || '').replace(/\s+/g, ' '))) return true;
      }
      return false;
    });
    const el = all[all.length - 1];
    if (!el) return false;
    (el.closest('button') || el).setAttribute('data-arbi-cancelconfirm', '1');
    return true;
  }, CONFIRM_RE).catch(() => false);
  const confirmDl = Date.now() + Number(process.env.ARBI_BINGX_CANCEL_CONFIRM_MS || 2500);
  let confirmed = false;
  while (Date.now() < confirmDl) {
    if (await markConfirm()) {
      // «Нажато» — только если клик ДЕЙСТВИТЕЛЬНО прошёл. Прежде результат клика
      // глотался catch'ем, и в журнал шла ложь: «подтверждение нажато» при
      // накрытой кнопке (оператор 22.09 — отмена не сработала дважды подряд,
      // а лог обоих раз сообщал об успешном нажатии). Догадка не имеет права
      // выглядеть фактом (#54).
      confirmed = await page.locator('[data-arbi-cancelconfirm="1"]').last()
        .click({ timeout: 1500, noWaitAfter: true }).then(() => true, () => false);
      if (!confirmed) {
        // Кнопку накрыли соседней модалкой — жмём из самой страницы. Для диалога
        // подтверждения доверенный клик не требуется (ордер этим не ставится),
        // а честность результата сохраняется: успех всё равно решает ОТВЕТ биржи.
        confirmed = await page.evaluate(() => {
          const el = document.querySelector('[data-arbi-cancelconfirm="1"]');
          if (!el) return false;
          try { el.click(); return true; } catch (_) { return false; }
        }).catch(() => false);
        if (confirmed) log('Подтверждение отмены было накрыто другой модалкой — нажал из страницы');
      }
      break;
    }
    await page.waitForTimeout(100);
  }
  const cr = await cancelResp;
  page.off('request', onReq);
  let okResp = false; let facts;
  if (cr) {
    const raw = await cr.text().catch(() => '');
    let j = null; try { j = JSON.parse(raw); } catch { /* не JSON */ }
    okResp = cr.status() < 300 && (!j || j.code === 0 || j.code === '0' || j.rc === 0 || j.success === true);
    facts = `ответ биржи ${cr.status()} ${raw.replace(/\s+/g, ' ').slice(0, 140)}`;
  } else {
    const seen = await page.evaluate(() => {
      const vis = (e) => e && e.offsetParent !== null;
      const dlg = Array.from(document.querySelectorAll('[role="dialog"],[class*="modal" i],[class*="dialog" i]')).filter(vis)
        .map((d) => (d.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 160));
      return dlg.join(' | ');
    }).catch(() => '');
    facts = `ответа биржи на отмену не было (POST за это время: ${posts.slice(-6).join(', ') || 'нет'}${seen ? `; на экране модалка: «${seen}»` : ''})`;
  }
  // Висящая модалка подтверждения — не косметика: следующий ордер кликает В НЕЁ,
  // и в журнале это выглядит как «клик не отправил запрос ордера» (лог 22.09:
  // две сорванные отмены оставили стопку модалок, и продажа STONK после них не
  // ушла вовсе). Закрываем всё, что осталось от этой операции, — «Закрыть» ордер
  // не ставит и отмену не отменяет.
  const leftovers = await page.evaluate(() => {
    const askRe = /(отменить\s+вс[её]|отмена\s+всех|cancel\s+all)/i;
    const closeRe = /^\s*(закрыть|отмена|cancel|close|нет|no)\s*$/i;
    let n = 0;
    for (const e of Array.from(document.querySelectorAll('button,div,span,a'))) {
      if (e.children.length || e.offsetParent === null) continue;
      if (!closeRe.test((e.textContent || '').trim())) continue;
      let inDialog = false;
      for (let p = e.parentElement, i = 0; p && i < 6; p = p.parentElement, i++) {
        if (askRe.test((p.textContent || '').replace(/\s+/g, ' '))) { inDialog = true; break; }
      }
      if (!inDialog) continue;
      try { (e.closest('button') || e).click(); n += 1; } catch (_) { /* исчезла */ }
    }
    return n;
  }).catch(() => 0);
  if (leftovers) log(`Закрыл оставшиеся модалки подтверждения: ${leftovers} — иначе следующий ордер кликнет в них`);
  log(`Отмена всех ордеров (${pair}): кнопка нажата${confirmed ? ', подтверждение нажато' : ' (подтверждение НЕ нажалось)'}; ${facts}`);
  if (!okResp) return { ok: false, confirmed, error: `Отмена не подтверждена биржей: ${facts}` };
  return { ok: true, cancelledAll: true, confirmed };
}

// ── Чтение доступного баланса по ОТКРЫТОМУ токену (для отображения в терминале) ──
// BingX показывает «Доступно / Available» у формы ордера: на стороне «Купить» —
// доступный QUOTE (USDT), на «Продать» — доступный BASE (токен). Баланс у BingX
// появляется с ЗАДЕРЖКОЙ, если просто ждать на одной стороне; ПЕРЕКЛИК вкладок
// Buy/Sell форсит обновление (тот же приём оператора, что в executeIntent перед
// продажей). Поэтому читаем, перекликивая стороны — заодно снимаем обе величины.
// Read-only: поля не заполняет, ордер не жмёт. Метка «доступно» — env-переопределяема.
const AVAIL_LABEL_RE = new RegExp(process.env.ARBI_BINGX_AVAIL_RE || '(Доступно|Available|Avbl|可用)', 'i');

/** Кликает ВКЛАДКУ-переключатель стороны по тексту (не кнопку сабмита btn-order-*). */
async function clickSideTab(page, sideRe) {
  return page.evaluate((rs) => {
    const rx = new RegExp(rs, 'i');
    const inBtnOrder = (el) => { for (let n = el; n; n = n.parentElement) { if (/btn-order/i.test(String((n.className && n.className.baseVal) || n.className || ''))) return true; } return false; };
    const tab = Array.from(document.querySelectorAll('span,div,label,a,li'))
      .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null && !inBtnOrder(e));
    if (!tab) return false;
    try { tab.click(); return true; } catch (_) { return false; }
  }, sideRe).catch(() => false);
}

/** Текст контейнера с меткой «Доступно» активной стороны (метка+значение рядом). */
async function readAvailText(page, labelReSource) {
  return page.evaluate((rs) => {
    const rx = new RegExp(rs, 'i');
    const vis = (el) => el && el.offsetParent !== null;
    const cand = Array.from(document.querySelectorAll('div,span,label,p'))
      .filter((e) => vis(e) && rx.test(e.textContent || ''));
    if (!cand.length) return '';
    // Самый «узкий» по тексту — ближе всего к паре метка+значение.
    cand.sort((a, b) => (a.textContent || '').length - (b.textContent || '').length);
    for (const el of cand) {
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (/\d/.test(t)) return t;
      const p = el.parentElement; // метка без числа → берём родителя (значение в соседнем span)
      if (p) { const pt = (p.textContent || '').replace(/\s+/g, ' ').trim(); if (/\d/.test(pt)) return pt; }
    }
    return (cand[0].textContent || '').replace(/\s+/g, ' ').trim();
  }, labelReSource).catch(() => '');
}

/**
 * Ждёт, пока блок «Доступно» перерисуется под ВЫБРАННУЮ сторону формы.
 *
 * Признак готовности — любой из двух:
 *   • у значения явно указан ожидаемый тикер (`expectAsset`);
 *   • текст изменился относительно предыдущей стороны (`prevText`) — значение
 *     без тикера принимаем только так, иначе рискуем принять неперерисованное
 *     число соседней стороны.
 * Не дождались — возвращаем null: честное «не знаю» вместо чужого числа.
 */
async function waitAvailFor(page, labelReSource, expectAsset, prevText, log) {
  // ⚠️ ЖДЁМ МАЛО (жалоба «браузер стал очень медленным», 2026-08-30). Чтение
  // баланса идёт ВНУТРИ прогрева формы и под общей блокировкой контекста —
  // каждая лишняя секунда здесь это секунда задержки ордера. Строка обычно
  // перерисовывается за 100-300 мс; полный лимит выбирается только когда она
  // не обновится вовсе — и тогда значение всё равно отбрасывается.
  const deadline = Date.now() + Number(process.env.ARBI_BINGX_AVAIL_WAIT_MS || 1200);
  const want = String(expectAsset || '').toUpperCase();
  for (;;) {
    const text = await readAvailText(page, labelReSource);
    const parsed = parseAvail(text, AVAIL_LABEL_RE);
    if (parsed) {
      const asset = (parsed.asset || '').toUpperCase();
      if (asset && (!want || asset === want)) return text;
      if (!asset && text && text !== prevText) return text;
    }
    if (Date.now() >= deadline) {
      (log || (() => {}))(`«Доступно» не перерисовалось под ${want || 'нужную сторону'} за ${Math.round((Date.now() - deadline) / 1000 + 2.5)}с — баланс базы не читаем`);
      return null;
    }
    await page.waitForTimeout(100);
  }
}

/** «Доступно 1 234.5 USDT» → {raw, value, asset}. Best-effort нормализация числа. */
function parseAvail(text, labelRe) {
  if (!text) return null;
  const after = text.replace(new RegExp('^[\\s\\S]*?' + labelRe.source, 'i'), '');
  const m = after.match(/(-?\d[\d\s .,]*)\s*([A-Za-z][A-Za-z0-9]{0,11})?/);
  if (!m) return null;
  const raw = m[1].replace(/[\s ]/g, '');
  let norm = raw;
  if (raw.includes(',') && raw.includes('.')) {
    // И запятая, и точка → последний разделитель по позиции считаем десятичным.
    norm = raw.lastIndexOf(',') > raw.lastIndexOf('.') ? raw.replace(/\./g, '').replace(',', '.') : raw.replace(/,/g, '');
  } else if (raw.includes(',')) {
    norm = raw.replace(',', '.');
  }
  const value = Number(norm);
  return { raw: m[1].trim(), value: Number.isFinite(value) ? value : null, asset: m[2] ? m[2].toUpperCase() : null };
}

/**
 * Читает доступный баланс по открытому токену BingX: доступный QUOTE (USDT, сторона
 * «Купить») и доступный BASE (токен, сторона «Продать»). Перекликивает Buy/Sell для
 * форс-обновления (иначе BingX отдаёт баланс с задержкой). Read-only.
 *
 * @param {import('playwright').BrowserContext} context
 * @param {string} pair  "BASE_USDT"
 * @param {{log?:(m:string)=>void}} [opts]
 * @returns {Promise<{ok:boolean, pair:string, base:object|null, quote:object|null, error?:string}>}
 */
async function readBalance(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  const [baseAsset, quoteAsset] = String(pair).toUpperCase().split('_');
  try {
    // opts.page — читать на ЗАДАННОЙ странице (фоновая, см. readBalanceBg), не хайджекая
    // активную вкладку оператора. Иначе — активная вкладка через getBingxPage (SPA).
    const page = opts.page || (await getBingxPage(context, pair, log)).page;
    await dismissOverlays(page).catch(() => {});
    await page.waitForSelector(SELECTORS.numberInput, { timeout: 8000 }).catch(() => {}); // форма (и «Доступно») отрисованы
    const refMs = Number(process.env.ARBI_BINGX_TAB_REFRESH_MS || 80);
    const src = AVAIL_LABEL_RE.source;

    await clickSideTab(page, SELECTORS.sideBuyRe); await page.waitForTimeout(refMs);
    const buyText = await readAvailText(page, src);           // доступный QUOTE (USDT)
    await clickSideTab(page, SELECTORS.sideSellRe);
    // ⚠️ НЕ фиксированная пауза. «Доступно» перерисовывается асинхронно, и на
    // занятой странице (идёт зачисление депозита — BingX как раз перерисовывает
    // балансы) за refMs она НЕ успевает: на стороне «Продать» ещё висит значение
    // стороны «Купить». Прежний код брал его как BASE и подписывал именем токена —
    // терминал получал «на счету 2419 BASECAT», хотя там 2419 USDT и НОЛЬ токена.
    // Автопродажа стреляла по несуществующему балансу (кейс BASECAT 30.08).
    // Ждём подтверждения, что читаем именно сторону «Продать»: либо актив совпал
    // с базовым, либо текст реально сменился относительно стороны «Купить».
    const sellText = await waitAvailFor(page, src, baseAsset, buyText, log);
    await clickSideTab(page, SELECTORS.sideBuyRe).catch(() => {}); // вернуть форму на «Купить»

    let quote = parseAvail(buyText, AVAIL_LABEL_RE);
    let base = sellText == null ? null : parseAvail(sellText, AVAIL_LABEL_RE);
    // Жёсткая сверка активов: значение с ЧУЖИМ тикером — это не наша сторона.
    // Лучше отдать «не знаю» (терминал возьмёт баланс по API), чем подсунуть
    // автопродаже чужое число.
    if (quote && quote.asset && quoteAsset && quote.asset !== quoteAsset) quote = null;
    if (base && base.asset && baseAsset && base.asset !== baseAsset) {
      log(`Баланс ${pair}: сторона «Продать» отдала ${base.asset} вместо ${baseAsset} — читаем как «неизвестно» (страница не успела перерисоваться)`);
      base = null;
    }
    if (quote && !quote.asset) quote.asset = quoteAsset || 'USDT';
    if (base && !base.asset) base.asset = baseAsset || null;
    log(`Баланс ${pair}: base=${base ? base.value + ' ' + base.asset : '?'} quote=${quote ? quote.value + ' ' + quote.asset : '?'}`);
    return { ok: !!(base || quote), pair, base: base || null, quote: quote || null };
  } catch (e) {
    return { ok: false, pair, base: null, quote: null, error: e.message };
  }
}

/**
 * Выделенная ФОНОВАЯ страница для чтения баланса — отдельный таб профиля,
 * помеченный `__arbiBalanceBg`. Никогда не трогает активную торговую вкладку
 * оператора (сценарий: AutoSell по старому токену, пока оператор смотрит другой).
 * Переиспользуется между чтениями; навигирует на нужную пару goto (не SPA — это
 * фон, скорость не критична, зато не зависит от состояния активной вкладки).
 */
async function getBalanceBgPage(context, pair, log) {
  let page = context.pages().find((p) => { try { return p.__arbiBalanceBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context));
    page.__arbiBalanceBg = true;
    log('Открыл фоновую страницу баланса (активная вкладка оператора не трогается)');
  }
  // Отметка «страницей только что пользовались»: сборщик памяти усыпляет её,
  // если чтений давно не было (иначе тяжёлая страница биржи висит загруженной
  // сутками — на слабой машине это заметный тормоз, жалоба оператора 11.09).
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  if (!urlHasPair(page.url(), pair)) {
    await page.goto(BINGX_TRADE_URL_TMPL.replace('{pair}', bingxUrlPair(pair)), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
  }
  // Подтвердить, что фоновая страница РЕАЛЬНО на нужной паре: goto с .catch мог не долететь
  // (редирект/логин/медленный прокси) → страница осталась на ПРОШЛОЙ паре, и readBalance
  // вернул бы баланс ЧУЖОГО токена как запрошенного. Матч по URL ИЛИ по base в h1 (для
  // displayName≠coinName URL не совпадёт, но h1 покажет токен). Ни то, ни другое → throw:
  // readBalanceBg отдаст ok:false, терминал трактует как «нет данных» (безопаснее ложного).
  if (!urlHasPair(page.url(), pair)) {
    const base = String(pair).split('_')[0];
    const h1ok = await page.locator('h1', { hasText: new RegExp('(?<![A-Za-z0-9])' + base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '(?![A-Za-z0-9])', 'i') })
      .first().isVisible().catch(() => false);
    if (!h1ok) throw new Error(`фоновая страница баланса не на паре ${pair} (URL ${String(page.url()).slice(0, 80)})`);
  }
  return page;
}

// ── Чтение ИСТОРИИ ОРДЕРОВ по открытой паре (сверка web-ордеров терминала) ──
// Терминал записывает web-ордера в момент выставления; факт биржи (исполнен /
// отменён / частично, реальные кол-во и ср. цена) он сверяет ЭТИМ чтением —
// оператор ничего не правит руками. Читаем вкладку «История ордеров» нижней
// панели страницы пары. Парсинг языконезависимый: колонки определяются по
// ЗАГОЛОВКАМ таблицы (regex env-переопределяемы), значения отдаём строками —
// числа разбирает сервер. Read-only, работает в фоновой странице.
const _ordHistDiagAt = new Map(); // пара → когда последний раз клали диагностику вёрстки в лог
const ORD_TAB_RE = new RegExp(process.env.ARBI_BINGX_ORDHIST_TAB_RE || '^\\s*(Order History|История ордеров|历史委托)\\s*$', 'i');
// Реальная шапка BingX (проверено оператором 30.08, RU-локаль):
//   Время ордера | Пара | Тип | Сторона | Ср. цена | Исполнено | Итого | Цена | Действие
// Колонки «Количество» и «Статус» в ней ОТСУТСТВУЮТ — исходное количество заявки
// биржа тут не показывает вовсе, а состояние выводится из «Исполнено».
const ORD_HDR = {
  time: process.env.ARBI_BINGX_ORDHIST_TIME_RE || '(time|время|дата|date|时间|日期)',
  pair: process.env.ARBI_BINGX_ORDHIST_PAIR_RE || '(^\\s*пара|^\\s*pair|symbol|交易对)',
  side: process.env.ARBI_BINGX_ORDHIST_SIDE_RE || '(side|сторона|направление|方向)',
  avg: process.env.ARBI_BINGX_ORDHIST_AVG_RE || '(average|avg|средн|ср\\.?\\s*цена|均价)',
  executed: process.env.ARBI_BINGX_ORDHIST_EXEC_RE || '(executed|исполнено|成交)',
  total: process.env.ARBI_BINGX_ORDHIST_TOTAL_RE || '(^\\s*итого|^\\s*total|成交额)',
  qty: process.env.ARBI_BINGX_ORDHIST_QTY_RE || '(quantity|количество|кол-во|数量)',
  status: process.env.ARBI_BINGX_ORDHIST_STATUS_RE || '(^\\s*status|^\\s*статус|状态)',
};

async function readOrders(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const page = opts.page || (await getBingxPage(context, pair, log)).page;
    await dismissOverlays(page).catch(() => {});
    // Вкладка «История ордеров» (лист-таб нижней панели, не кнопка формы).
    // Вкладку ищем С ПОВТОРОМ: на только что открытой фоновой странице React
    // ещё не отрисовал нижнюю панель, и единственная попытка через 0.9с ловила
    // «вкладка не найдена» (лог оператора 30.08, 9:09:55) — читалка уходила в
    // ошибку на пустой странице.
    const clickDeadline = Date.now() + Number(process.env.ARBI_BINGX_ORDHIST_TAB_WAIT_MS || 1500);
    let clicked = false;
    for (;;) {
      clicked = await page.evaluate((reSrc) => {
        const rx = new RegExp(reSrc, 'i');
        const tab = Array.from(document.querySelectorAll('span,div,li,a'))
          .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null);
        if (!tab) return false;
        try { tab.click(); return true; } catch (_) { return false; }
      }, ORD_TAB_RE.source).catch(() => false);
      if (clicked || Date.now() >= clickDeadline) break;
      await page.waitForTimeout(300);
    }
    if (!clicked) {
      // Страница могла быть только что разбужена из сна (усыпление фоновых
      // страниц при простое): нижняя панель BingX появляется уже после load, и
      // 1.5с ожидания её не застают — лог оператора 15.09, 6:23:01, ровно через
      // 9 секунд после «Фоновая страница усыплена». Дожидаемся загрузки и
      // пробуем ещё раз, прежде чем признать вкладку ненайденной.
      await page.waitForLoadState('load', { timeout: 5000 }).catch(() => {});
      const retryDeadline = Date.now() + Number(process.env.ARBI_BINGX_ORDHIST_TAB_RETRY_MS || 3000);
      for (;;) {
        clicked = await page.evaluate((reSrc) => {
          const rx = new RegExp(reSrc, 'i');
          const tab = Array.from(document.querySelectorAll('span,div,li,a'))
            .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && e.offsetParent !== null);
          if (!tab) return false;
          try { tab.click(); return true; } catch (_) { return false; }
        }, ORD_TAB_RE.source).catch(() => false);
        if (clicked || Date.now() >= retryDeadline) break;
        await page.waitForTimeout(300);
      }
      log(clicked
        ? 'История ордеров: вкладка появилась со второй попытки (страница досыпала после пробуждения)'
        : 'История ордеров: вкладка не найдена (ARBI_BINGX_ORDHIST_TAB_RE)');
    }
    await page.waitForTimeout(Number(process.env.ARBI_BINGX_ORDHIST_SETTLE_MS || 900));
    // ФИЛЬТР ТИПА ОРДЕРА (диагностика 05.09: в панели «… Скрыть отменен./недейств.
    // Рыночный 1д 1н 1М 3М …» — фильтр стоял на «Рыночный», а наши заявки лимитные →
    // таблица пуста при живой истории). Если фильтр показывает «Рыночный/Market»,
    // переключаем на «Все/All» (иначе — «Лимитный/Limit»). Best-effort, со следом.
    // ⚠️ КЛИКАЕМ ИМЕННО ВЫПАДАЮЩИЙ СПИСОК ИСТОРИИ, А НЕ ВКЛАДКУ ФОРМЫ ОРДЕРА.
    // Разбор 2026-09-08 (скрин оператора + DevTools): слово «Рыночный» есть на
    // странице ДВАЖДЫ — вкладка формы ордера (Рыночный/Лимитный/TP-SL, классы
    // bx-tab-*) и фильтр истории (div.bx-select.bx-select_size_small). Прежний
    // поиск брал ПЕРВЫЙ подходящий листовой элемент, то есть вкладку ФОРМЫ:
    // журнал бодро писал «выбрал Лимитный», фильтр истории оставался на
    // «Рыночный» («Записи не найдены» при живой истории), а форма ордера при
    // каждом чтении дёргалась Рыночный→Лимитный — на денежном пути.
    // Теперь: элемент обязан лежать внутри [class*="bx-select"] и НЕ внутри
    // [class*="bx-tab"]; вариант в раскрытом списке — тоже не из вкладок формы;
    // и результат СВЕРЯЕТСЯ чтением подписи фильтра (без сверки «выбрал» — это
    // рассказ, а не факт).
    if ((process.env.ARBI_BINGX_ORDHIST_TYPE_FIX || '1') === '1') {
      // Итерация 5 — по DevTools оператора 2026-09-08 11:24 (точная структура):
      // триггер — div.bx-select.bx-select_size_small с подписью типа (Рыночный /
      // Лимитный / TP/SL / Триггерный / OCO); по КЛИКУ открывается попап
      // div.tip-base[data-popper-placement] (position:fixed) → div.bx-dp →
      // div.dp-item-group → div.dp-item[.active] › div.dp-item-title «Лимитный».
      // Прежний hover-путь по ul.bx-select-menu-wrap был про стакан (точность).
      // Нужен тип «Лимитный» (наши заявки лимитные). Best-effort, со следом и сверкой.
      const TYPE_SRC = '^\\s*(Рыночный|Market|Лимитный|Лимит|Limit|TP\\/SL|Триггерный|Trigger|OCO)\\s*$';
      const LIMIT_RE = /^\s*(Лимитный|Лимит|Limit)\s*$/i;
      // Триггер помечаем в DOM и кликаем доверенным кликом. ⚠️ Лог 11:57:49: подстрочный
      // поиск `[class*="bx-select"]` схватил `bx-select-modal-item-content` — ОПЦИЮ («TP/SL»)
      // уже раскрытого списка ДРУГОГО селекта (точность стакана), а не наш триггер. Класс
      // триггера — ОТДЕЛЬНОЕ слово `bx-select` (+ модификатор `bx-select_size_small`);
      // всё с дефисом (`bx-select-menu-…`, `bx-select-modal-…`, `bx-select-item`) — это
      // ВНУТРЕННОСТИ выпадающих списков, их исключаем, как и вкладки формы (bx-tab) и
      // сами попапы (tip-base / bx-dp).
      const markTrigger = () => page.evaluate((src) => {
        const re = new RegExp(src, 'i');
        document.querySelectorAll('[data-arbi-histsel]').forEach((e) => e.removeAttribute('data-arbi-histsel'));
        const txt = (e) => (e.textContent || '').replace(/\s+/g, ' ').trim();
        const isTrigger = (e) => /(^|\s)bx-select(_[A-Za-z0-9_]+)?(\s|$)/.test(String((e.className && e.className.baseVal) || e.className || ''));
        const el = Array.from(document.querySelectorAll('[class*="bx-select"]')).find((e) => e.offsetParent !== null
          && isTrigger(e) && !e.closest('[class*="bx-tab"],[class*="tip-base"],[class*="bx-dp"]') && re.test(txt(e)));
        if (!el) return null;
        el.setAttribute('data-arbi-histsel', '1');
        return txt(el);
      }, TYPE_SRC).catch(() => null);
      const curType = await markTrigger();
      if (curType == null) {
        // След: какие bx-select вообще видны (кратко), чтобы чинить по логу, а не гадать.
        const seen = await page.evaluate(() => Array.from(document.querySelectorAll('[class*="bx-select"]'))
          .filter((e) => e.offsetParent !== null && !e.querySelector('[class*="bx-select"]'))
          .slice(0, 8).map((e) => `${String(e.className).slice(0, 40)}=«${(e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 30)}»`).join(' | ')).catch(() => '');
        log(`История ордеров: фильтр типа не найден — не трогаю${seen ? ` (видны: ${seen})` : ''}`);
      } else if (LIMIT_RE.test(curType)) {
        log(`История ордеров: фильтр типа уже «${curType}»`);
      } else {
        await page.locator('[data-arbi-histsel="1"]').first().click({ timeout: 2000 }).catch(() => {});
        const opt = page.locator('.dp-item').filter({ has: page.locator('.dp-item-title', { hasText: LIMIT_RE }) }).first();
        let picked;
        let opened = await opt.waitFor({ state: 'visible', timeout: 1500 }).then(() => true, () => false);
        if (!opened) {
          // Клик по контейнеру `div.bx-select` список не раскрывает — попадаем во
          // внутренний слой (лог оператора 15.09: «список типов после клика не
          // открылся» подряд, при этом diag показал вложенность
          // bx-select > bx-select-content > …-inner > .bx-select-label и стрелку
          // i.bx-select-arrow). Жмём то, что реально ловит клик: сперва подпись,
          // затем стрелку. Каждая попытка дешёвая, обе — по элементам из diag.
          for (const sel of ['[data-arbi-histsel="1"] .bx-select-label', '[data-arbi-histsel="1"] .bx-select-arrow']) {
            await page.locator(sel).first().click({ timeout: 1500 }).catch(() => {});
            opened = await opt.waitFor({ state: 'visible', timeout: 1200 }).then(() => true, () => false);
            if (opened) break;
          }
        }
        if (opened) {
          await opt.click({ timeout: 2000 }).catch(() => {});
          picked = 'выбрал «Лимитный»';
        } else {
          picked = 'список типов после клика не открылся';
          const html = await page.locator('[data-arbi-histsel="1"]').first().evaluate((el) => (el.outerHTML || '').slice(0, 600)).catch(() => '');
          if (html) console.log(`[bingx-exec] [diag фильтр] ${html}`);
          await page.keyboard.press('Escape').catch(() => {});
        }
        await page.waitForTimeout(Number(process.env.ARBI_BINGX_ORDHIST_SETTLE_MS || 900));
        const now = (await markTrigger()) || '?';
        log(`История ордеров: фильтр типа стоял на «${curType}» — ${picked}; сейчас «${now}»`);
      }
    }

    // ГАЛКА «Скрыть отменен./недейств.» — она и прячет ровно то, что нам нужно.
    // Доказано логом оператора 15.09: в 8:18:06 выставлены две части BASECAT,
    // в 8:18:23 отменены, и все последующие чтения дают «Записи не найдены» при
    // живой панели (её текст: «… Скрыть отменен./недейств. Рыночный 1д 1н 1М 3М
    // 2026-08-16 До 2026-09-15 Записи не найдены»). Период тут ни при чём —
    // окно месяц. Отменённые заявки для сверки нужны не меньше исполненных:
    // без них «ордер не найден» неотличимо от «ордер не поставлен».
    // Снимаем галку, если она стоит. Выключатель: ARBI_BINGX_ORDHIST_SHOW_CANCELED=0.
    if ((process.env.ARBI_BINGX_ORDHIST_SHOW_CANCELED || '1') === '1') {
      const hideRe = process.env.ARBI_BINGX_ORDHIST_HIDE_RE || '(скрыть\\s+отмен|hide\\s+cancel|隐藏)';
      const res = await page.evaluate((reSrc) => {
        const rx = new RegExp(reSrc, 'i');
        const nodes = Array.from(document.querySelectorAll('span,div,label,li'))
          .filter((e) => e.children.length <= 2 && e.offsetParent !== null && rx.test((e.textContent || '').trim()));
        if (!nodes.length) return { found: false };
        const host = nodes[0].closest('label,[class*="checkbox"],[class*="check"]') || nodes[0];
        const box = host.querySelector('input[type="checkbox"]');
        const on = box ? !!box.checked
          : /checked|active|_on\b/i.test(String((host.className && host.className.baseVal) || host.className || ''))
            || host.getAttribute('aria-checked') === 'true';
        if (!on) return { found: true, was: 'снята' };
        try { (box || host).click(); } catch (_) { return { found: true, was: 'стоит', clicked: false }; }
        return { found: true, was: 'стоит', clicked: true };
      }, hideRe).catch(() => ({ found: false }));
      if (res.found && res.was === 'стоит') {
        log(`История ордеров: галка «скрыть отменённые» ${res.clicked ? 'снята — отменённые заявки теперь видны' : 'стоит, но снять не удалось'}`);
        await page.waitForTimeout(Number(process.env.ARBI_BINGX_ORDHIST_SETTLE_MS || 900));
      }
    }

    // Таблица: ищем строку заголовков, маппим колонки по заголовкам и снимаем
    // видимые строки данных.
    //
    // ⚠️ ЗАГОЛОВОК УЗНАЁМ ПО ЧИСЛУ СОВПАВШИХ КОЛОНОК, а не по паре «время+сторона»
    // (кейс BASECAT 30.08: «снято строк 0» каждую минуту сутки подряд при живой
    // истории на странице). Прежнее условие требовало, чтобы совпали ОБА
    // конкретных заголовка: биржа переименовала один («Время»→«Дата»,
    // локализация, редизайн) — и map не строился НИКОГДА, для любой пары, молча.
    // Теперь достаточно трёх любых узнанных колонок; при неудаче ниже уходит в
    // лог реальный текст шапки — чинится переменной ARBI_BINGX_ORDHIST_*_RE без
    // выпуска новой версии.
    const extract = () => page.evaluate((hdr) => {
      const rex = Object.fromEntries(Object.entries(hdr).map(([k, v]) => [k, new RegExp(v, 'i')]));
      const vis = (el) => el && el.offsetParent !== null;
      const txt = (c) => (c.innerText || '').replace(/\s+/g, ' ').trim();
      // Ячейки: прямые дети строки; если строка — обёртка над одной колонкой,
      // берём размеченные ячейки грида (BingX рисует историю виртуальным списком).
      const cellTexts = (row) => {
        const direct = Array.from(row.children).map(txt);
        if (direct.length >= 4) return direct;
        const cells = row.querySelectorAll('td,th,[role="gridcell"],[role="cell"],[role="columnheader"]');
        return cells.length >= 4 ? Array.from(cells).map(txt) : direct;
      };
      // Кандидаты «строк»: таблица, ARIA-грид ИЛИ div-строки табличных вёрсток.
      // ⚠️ `[class*="row"]` БЕЗ требования предка с "table" в классе: у BingX
      // строки истории лежат не под таким предком, и прежний селектор не давал
      // НИ ОДНОГО кандидата — отсюда «строк 0» при живой таблице на экране.
      const allRows = [
        ...Array.from(document.querySelectorAll('tr,[role="row"]')).filter(vis),
        ...Array.from(document.querySelectorAll('[class*="row" i]')).filter(vis),
      ];
      const SIDE_RE = /^(buy|sell|купить|продать|покупка|продажа)$/i;
      let map = null;
      let probe = '';
      const out = [];
      const seen = new Set();
      for (const r of allRows) {
        const cells = cellTexts(r);
        if (cells.length < 4) continue;
        if (!map) {
          const hit = {};
          cells.forEach((c, i) => {
            for (const k of Object.keys(rex)) { if (hit[k] == null && rex[k].test(c)) hit[k] = i; }
          });
          if (Object.keys(hit).length >= 3) { map = hit; continue; }
          if (!probe) probe = cells.join(' | ').slice(0, 200); // первая непонятая строка — в лог
          continue; // до заголовка строки данных не разбираем
        }
        const pick = (k) => (map[k] != null && map[k] < cells.length ? cells[map[k]] : '');
        // Сторону берём из размеченной колонки, только если там реально сторона:
        // при съехавшей разметке (в колонке «Тип» — «Лимит») ищем её по всей строке.
        const mapped = pick('side');
        const side = SIDE_RE.test(mapped) ? mapped : (cells.find((c) => SIDE_RE.test(c)) || mapped);
        if (!side) continue;
        // Селекторы строк намеренно широкие → одна визуальная строка может
        // прийти и как <tr>, и как вложенный div: дедуп по тексту строки.
        const rawKey = cells.join(' | ');
        if (seen.has(rawKey)) continue;
        seen.add(rawKey);
        out.push({
          time: pick('time'),
          pair: pick('pair'),
          side,
          avgPrice: pick('avg'),
          executed: pick('executed'),
          total: pick('total'),
          quantity: pick('qty'),
          status: pick('status'),
          raw: cells.join(' | ').slice(0, 300),
        });
        if (out.length >= 60) break;
      }
      return { rows: out, headerFound: !!map, probe };
    }, ORD_HDR).catch(() => null);

    // Ждём отрисовку: строки приезжают отдельным запросом биржи, одной попытки
    // сразу после клика по вкладке мало (пустая таблица ≠ «истории нет»).
    const deadline = Date.now() + Number(process.env.ARBI_BINGX_ORDHIST_WAIT_MS || 2000);
    let out0 = null;
    for (;;) {
      out0 = await extract();
      if ((out0 && out0.rows.length) || Date.now() >= deadline) break;
      await page.waitForTimeout(400);
    }

    const all = (out0 && out0.rows) || [];
    // Таблица истории BingX показывает ВСЕ пары (колонка «Пара»), а сервер
    // записывает полученные строки под ЗАПРОШЕННЫЙ символ — без фильтра сюда
    // попали бы чужие ордера под чужим именем. Колонки «Пара» нет → не фильтруем
    // (прежнее поведение: страница уже открыта на нужной паре).
    const norm = (v) => String(v).toUpperCase().replace(/[^A-Z0-9]/g, '');
    const want = norm(pair);
    const hasPairCol = all.some((r) => r.pair);
    // ОБЩАЯ страница истории (anyPair: одна на биржу, стоит на первой открытой паре) —
    // строка принимается ТОЛЬКО с прочитанным и совпавшим значением пары. Учёт 16.09:
    // пять покупок POWER легли в учёт как ANYONE — строки без значения пары проходили
    // как «свои» (fail-open), сервер записывает их под запрошенный символ (#71: нет
    // данных ≠ данные говорят «своя»). Торговая вкладка пары (не anyPair) — как раньше.
    let rows;
    if (hasPairCol) {
      rows = all.filter((r) => (r.pair ? norm(r.pair) === want : !opts.anyPair));
      const noPair = all.filter((r) => !r.pair).length;
      if (opts.anyPair && noPair) log(`История ордеров ${pair}: ${noPair} строк без значения пары на общей странице — не беру`);
    } else if (opts.anyPair && all.length) {
      rows = [];
      log(`История ордеров ${pair}: на общей странице истории колонки «Пара» не узнал (${all.length} строк) — строки не беру, чужой журнал хуже пустого`);
    } else rows = all;

    if (!all.length && out0 && !out0.headerFound) {
      log(`История ордеров ${pair}: шапка таблицы не узнана${out0.probe ? ` — что на странице: «${out0.probe}»` : ' (подходящих строк на странице нет)'}`);
      // «Подходящих строк нет» = ни одного видимого элемента с ≥4 ячейками: BingX
      // сменил вёрстку нижней панели (лог 04–05.09: каждая читалка по BASECAT/FONE/
      // AMEMECOIN — «строк 0»). Чтобы чинить по факту, а не вслепую, раз в 5 минут
      // на пару кладём в лог текст панели рядом с вкладкой истории и URL ответов
      // биржи, похожих на историю ордеров. Выключить: ARBI_BINGX_ORDHIST_DIAG=0.
      if ((process.env.ARBI_BINGX_ORDHIST_DIAG || '1') === '1' && Date.now() - (_ordHistDiagAt.get(String(pair)) || 0) > 5 * 60_000) {
        _ordHistDiagAt.set(String(pair), Date.now());
        const diag = await page.evaluate((reSrc) => {
          const rx = new RegExp(reSrc, 'i');
          const vis = (el) => el && el.offsetParent !== null;
          const tab = Array.from(document.querySelectorAll('span,div,li,a'))
            .find((e) => e.children.length === 0 && rx.test((e.textContent || '').trim()) && vis(e));
          let panel = tab;
          for (let i = 0; panel && i < 10; i++) {
            const t = (panel.innerText || '').replace(/\s+/g, ' ').trim();
            if (t.length > 300) break;
            panel = panel.parentElement;
          }
          // Панель вкладок отдельно, и ЕЁ РОДИТЕЛЬ шире (строки истории — соседний
          // блок под панелью вкладок, диагностика 05.09 показала только вкладки и фильтры).
          const wide = panel && panel.parentElement ? panel.parentElement : panel;
          const text = wide ? (wide.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 900) : '(вкладка истории не найдена)';
          const tables = document.querySelectorAll('table').length;
          const grids = document.querySelectorAll('[role="grid"],[role="table"],[role="row"]').length;
          const cls = wide ? Array.from(wide.querySelectorAll('[class]')).slice(0, 600)
            .map((e) => String(e.className && e.className.baseVal != null ? e.className.baseVal : e.className))
            .filter((c) => /row|cell|table|list|item|history|order/i.test(c)).slice(0, 12) : [];
          return { text, tables, grids, cls: Array.from(new Set(cls)) };
        }, ORD_TAB_RE.source).catch((e) => ({ text: `diag failed: ${e && e.message}`, tables: 0, grids: 0, cls: [] }));
        log(`[diag история] table=${diag.tables} aria=${diag.grids} классы=${JSON.stringify(diag.cls)} панель: «${diag.text}»`);
      }
    }
    // Когда на странице строки ЕСТЬ, а нашей пары среди них нет — по прежнему
    // тексту («остальные — другие пары») причину не установить: это могло быть
    // и чужое имя пары в таблице, и не тот период, и не тот тип ордера. У
    // оператора 15.09 BASECAT и STONK так падали каждые пять минут подряд.
    // Печатаем, ЧТО именно лежит в колонке пары (до 6 имён) — по одной строке
    // видно, дело в формате имени или в фильтре (#68: диагноз по прочитанной
    // причине, не по совпадению).
    let seen = '';
    if (hasPairCol && all.length && !rows.length) {
      const names = Array.from(new Set(all.map((r) => String(r.pair || '').trim()).filter(Boolean))).slice(0, 6);
      seen = names.length ? ` [в таблице: ${names.join(', ')}; искали ${want}]` : ' [колонка пары пуста]';
    }
    log(`История ордеров ${pair}: снято строк ${rows.length}${hasPairCol && all.length !== rows.length ? ` (из ${all.length} на странице, остальные — другие пары)` : ''}${seen}`);
    return { ok: rows.length > 0, pair, rows };
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/**
 * Фоновая страница ИСТОРИИ BingX (`__arbiOrdersBg`) — ОДНА на биржу, живёт между
 * чтениями и по парам НЕ навигируется (оператор 15.09: «по одной вкладке каждой
 * биржи для чтения истории, постоянно актуальные данные»): панель истории
 * показывает все пары, readOrders фильтрует по колонке «Пара». Навигация — только
 * если страница не на торговой странице BingX (свежая / разбужена из сна).
 */
async function getOrdersBgPage(context, pair, log) {
  let page = context.pages().find((p) => { try { return p.__arbiOrdersBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context));
    page.__arbiOrdersBg = true;
    log('Открыл фоновую страницу истории BingX — одна на биржу, живёт между чтениями');
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  const u = String(page.url());
  if (!(u.startsWith(BINGX_ORIGIN) && isTradePairUrl(u))) {
    await page.goto(BINGX_TRADE_URL_TMPL.replace('{pair}', bingxUrlPair(pair)), { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(() => {});
    if (!String(page.url()).startsWith(BINGX_ORIGIN)) throw new Error(`фоновая страница истории не открылась (URL ${String(page.url()).slice(0, 80)})`);
  }
  return page;
}

/** Как readOrders, но в фоновой странице истории (одна на биржу, без навигации по парам). */
async function readOrdersBg(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const page = await getOrdersBgPage(context, pair, log);
    return await readOrders(context, pair, { ...opts, page, anyPair: true });
  } catch (e) {
    return { ok: false, pair, rows: [], error: e.message };
  }
}

/** Как readBalance, но в фоновой странице (не хайджекает вкладку оператора). */
async function readBalanceBg(context, pair, opts = {}) {
  const log = opts.log || (() => {});
  try {
    const page = await getBalanceBgPage(context, pair, log);
    return await readBalance(context, pair, { ...opts, page });
  } catch (e) {
    const [baseAsset, quoteAsset] = String(pair).toUpperCase().split('_');
    return { ok: false, pair, base: null, quote: null, error: e.message, baseAsset, quoteAsset };
  }
}

module.exports = { executeIntent, getBingxPage, warmupForm, cancelAllOrders, readBalance, readBalanceBg, readOrders, readOrdersBg, toBingxPair, SELECTORS, readVolumeLimitOn };

'use strict';

/**
 * bingx-deposit-page.js — «Счёт получения» депозита BingX: проверка и перевод
 * на «Спот счёт» в живой странице профиля (оператор 2026-09-17).
 *
 * Зачем. Депозит BingX по умолчанию падает на Счёт фонда, и терминал тратит
 * секунды и запросы (опрос истории депозитов, чтение Фонда, перевод, ожидание
 * Спота) на то, чтобы монета стала продаваемой. На странице депозита у монеты
 * есть «Счёт получения» (Счёт фонда ⇄ Спот счёт): если у торгуемых монет
 * поставить «Спот счёт», шаг Фонд→Спот исчезает целиком.
 *
 * Что делает интент `depositProbe` ({coins:[…], set:'SPOT'|null}):
 *   • для каждой монеты открывает страницу депозита в ФОНОВОЙ вкладке профиля,
 *     читает показанную монету, сеть и текущий «Счёт получения»;
 *   • при set:'SPOT' и значении «Счёт фонда» — нажимает ⇄ → «Спот счёт» → OK
 *     и перечитывает значение;
 *   • записывает сетевые вызовы страницы к API биржи за это время (метод, URL,
 *     тело запроса, тело ответа) — чтобы найти прямой вызов смены счёта и
 *     дальше не кликать, а звать его.
 *
 * БЕЗОПАСНОСТЬ ВЫВОДА. Заголовки запросов НЕ записываются вовсе (там cookie и
 * токены сессии). В телах запроса/ответа и в query-параметрах вымарываются
 * ключи, похожие на секреты/идентификаторы (token, sign, cookie, auth, uid,
 * phone, email, device…), и ЛЮБЫЕ длинные (≥32 симв.) буквенно-цифровые
 * строки. Наружу уходит только это — в терминал, тем же путём, что и
 * результат любого интента.
 */

const { newBackgroundPage, markOwned } = require('./pair-tabs');

const BINGX_ORIGIN = process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com';
// Страница депозита с монетой в query. Если у BingX другой параметр — env.
const DEPOSIT_URL_TMPL = process.env.ARBI_BINGX_DEPOSIT_URL || `${BINGX_ORIGIN}/ru/assets/recharge?coin={coin}`;
// Хосты API страницы (подтверждённый: api-app.we-api.com — см. bingx-order-page.js).
// По ПУТИ, а не по хосту: BingX раскидывает вызовы по доменам (we-api.com,
// qq-os.com, acc-de.com), и сохранение счёта ушло на qq-os.com мимо фильтра (17.09).
const API_RE = new RegExp(process.env.ARBI_BINGX_DEPOSIT_API_RE || '/api/(wallet-deposit-withdraw|asset-manager|coin|fiat)/|we-api\\.com|bingx\\.com/api', 'i');
// Вызовы, относящиеся к депозиту/счёту — их отдаём подробно; остальные считаем.
const RELEVANT_RE = /recharge|deposit|account|asset|setting|config|wallet|transfer|coin/i;
const SECRET_KEY_RE = /token|secret|sign|cookie|auth|session|passw|apikey|api[_-]?key|private|uid|user[_-]?id|phone|email|device|fingerprint|trace|nonce|captcha/i;
const MAX_REQ_PER_COIN = 25;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Вымарать секреты/идентификаторы из любого JSON-значения. */
function scrub(v, depth = 0) {
  if (depth > 6) return '[глубже не смотрим]';
  if (Array.isArray(v)) return v.slice(0, 20).map((x) => scrub(x, depth + 1));
  if (v && typeof v === 'object') {
    const o = {};
    for (const [k, val] of Object.entries(v).slice(0, 60)) o[k] = SECRET_KEY_RE.test(k) ? '[скрыто]' : scrub(val, depth + 1);
    return o;
  }
  if (typeof v === 'string') {
    // URL — это адрес вызова, ради него проба и нужна; query уже вымаран scrubUrl.
    if (/^https?:\/\//i.test(v)) return scrubUrl(v);
    if (v.length >= 32 && /^[A-Za-z0-9+/=_\-.:]+$/.test(v)) return `[скрыто, ${v.length} симв.]`;
    return v.length > 200 ? v.slice(0, 200) + '…' : v;
  }
  return v;
}
function scrubUrl(u) {
  try {
    const url = new URL(u);
    for (const k of [...url.searchParams.keys()]) {
      const val = url.searchParams.get(k) || '';
      if (SECRET_KEY_RE.test(k) || val.length >= 32) url.searchParams.set(k, 'HIDDEN');
    }
    return url.origin + url.pathname + url.search;
  } catch { return String(u).slice(0, 200); }
}
function scrubBody(text) {
  if (!text) return null;
  // Сначала разбор, потом обрезка: раньше тело резалось до 6000 символов ДО
  // JSON.parse, и валидный ответ попадал в отчёт как «[не JSON]» (17.09).
  try {
    const j = scrub(JSON.parse(text));
    const out = JSON.stringify(j);
    return out.length > 12000 ? `${out.slice(0, 12000)}…[обрезано, всего ${out.length}]` : j;
  } catch { return `[не JSON, ${text.length} симв.]`; }
}

/** Запись вызовов страницы к API биржи. Заголовки не читаем никогда. */
function attachRecorder(page) {
  const rows = [];
  // ВСЕ исходящие запросы (метод, адрес, тип) и кадры веб-сокета: сохранение
  // «Счёта получения» не нашлось среди xhr/fetch, хотя выбор переживает
  // перезагрузку (17.09) — значит оно уходит другим путём. Тел не читаем,
  // только адрес и превью кадра, оба вымараны.
  const all = [];
  const ws = [];
  const onRequest = (req) => {
    try {
      const url = req.url();
      all.push({ t: Date.now(), method: req.method(), url: scrubUrl(url), rt: req.resourceType(), hasBody: !!req.postData() });
      if (all.length > 600) all.shift();
      // Заголовки живого вызова кошелька — ТОЛЬКО в памяти процесса: быстрый режим
      // повторяет ими тот же вызов. В отчёт они не попадают никогда (в них сессия).
      if (/\/api\/wallet-deposit-withdraw\//.test(url)) {
        const h = req.headers();
        const keep = {};
        for (const [k, v] of Object.entries(h)) {
          if (/^(cookie|host|content-length|origin|referer|sec-|accept-encoding|connection)/i.test(k)) continue;
          keep[k] = v;
        }
        lastApiHeaders = keep;
        // Живой адрес API: BingX чередует хосты, и жёстко взятый первый из
        // списка не отвечает вовсе (17.09: «Failed to fetch» на всех монетах).
        // Правда — тот адрес, с которым страница говорит прямо сейчас.
        try { lastApiHost = new URL(url).host; } catch { /* не адрес */ }
        // Собственный вызов страницы «сохранить счёт получения» — с его подписью
        // пробуем тут же повторить сохранение для СЛЕДУЮЩЕЙ монеты (см. loop):
        // если биржа примет, кликать дальше не нужно. Только в памяти.
        if (req.method() === 'POST' && CHARGE_RE.test(url)) lastChargeReq = { url, headers: keep, t: Date.now() };
      }
    } catch { /* диагностика */ }
  };
  const onWs = (sock) => {
    try {
      sock.on('framesent', (d) => {
        try {
          const raw = typeof d.payload === 'string' ? d.payload : String(d.payload);
          ws.push({ t: Date.now(), dir: 'sent', preview: String(scrubBody(raw) ?? raw.slice(0, 300)).slice(0, 600) });
          if (ws.length > 120) ws.shift();
        } catch { /* диагностика */ }
      });
    } catch { /* диагностика */ }
  };
  page.on('request', onRequest);
  page.on('websocket', onWs);
  const onResponse = async (resp) => {
    try {
      const req = resp.request();
      const url = req.url();
      if (!API_RE.test(url)) return;
      const rt = req.resourceType();
      if (rt !== 'xhr' && rt !== 'fetch') return;
      let body = null;
      try { body = await resp.text(); } catch { /* тело недоступно — не критично */ }
      // Справочник монет биржи: в нём может быть счёт зачисления по каждой монете —
      // тогда обходить придётся только те, что на Фонде (оператор: «1000 монет — долго»).
      if (/support-coins/i.test(url) && body) {
        if (!lastSupportCoins) lastSupportCoins = scrubBody(body);
        // Номера монет — из ответа самой страницы: отдельный запрос без её
        // заголовков биржа не отдаёт (17.09: «справочник не получен»).
        try {
          const j = JSON.parse(body);
          const list = j && j.data && Array.isArray(j.data.coins) ? j.data.coins : null;
          if (list && list.length) {
            for (const c of list) for (const k of [c.name, c.coinDisplayName, c.showName]) if (k && c.id != null) coinIds.set(String(k).toUpperCase(), Number(c.id));
          }
        } catch { /* не справочник */ }
      }
      rows.push({
        t: Date.now(), method: req.method(), url: scrubUrl(url), status: resp.status(),
        request: scrubBody(req.postData()), response: body ? scrubBody(body) : null,
      });
      if (rows.length > 400) rows.shift();
    } catch { /* запись — диагностика, страницу не трогает */ }
  };
  page.on('response', onResponse);
  return {
    rows, all, ws,
    detach: () => {
      try { page.off('response', onResponse); page.off('request', onRequest); page.off('websocket', onWs); } catch { /* игнор */ }
    },
  };
}
let lastSupportCoins = null;
/** Заголовки последнего вызова кошелька (в памяти, наружу не отдаются). */
let lastApiHeaders = null;
/** Последний собственный POST страницы «сохранить счёт получения» (в памяти). */
let lastChargeReq = null;
/** Хост API, с которым страница говорила последним (живой из чередующихся). */
let lastApiHost = null;
const CHARGE_RE = /\/user\/config\/charge-account/i;
/** Монета (тикер/имя на бирже, верхний регистр) → её номер на бирже. */
const coinIds = new Map();

/** Ждать условия, опрашивая раз в step мс; вернуть true, если дождались. */
async function waitUntil(fn, ms, step = 250) {
  const deadline = Date.now() + ms;
  for (;;) {
    if (await fn().catch(() => false)) return true;
    if (Date.now() >= deadline) return false;
    await sleep(step);
  }
}

async function getDepositPage(context, log) {
  let page = context.pages().find((p) => { try { return p.__arbiDepositBg === true && !p.isClosed(); } catch { return false; } });
  if (!page) {
    page = markOwned(await newBackgroundPage(context, { tab: true }));
    page.__arbiDepositBg = true;
    log('Открыл фоновую вкладку депозита (активная вкладка оператора не трогается)');
  }
  try { page.__arbiBgUsedAt = Date.now(); } catch { /* игнор */ }
  return page;
}

/** Показана ИМЕННО эта монета? Подстрока не годится: «COINDEPO» содержит «DEP»
 *  (оператор 17.09) — сверяем по границам слова. */
function coinMatches(shown, coin) {
  const re = new RegExp(`(^|[^A-Za-z0-9])${String(coin).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^A-Za-z0-9]|$)`, 'i');
  return re.test(String(shown || ''));
}

/**
 * Монета, сеть и «Счёт получения» ОДНИМ походом в страницу. Раньше на каждый
 * опрос уходило три-четыре вызова (count + innerText на каждое поле), и при
 * шаге опроса 150 мс это и было заметной частью секунд на монету (17.09).
 */
async function readState(page) {
  return page.evaluate(() => {
    const lines = (el) => (el ? el.innerText.split('\n').map((s) => s.trim()).filter(Boolean) : []);
    const steps = document.querySelectorAll('.bx-step-content');
    const c = lines(steps[0]);
    const nl = lines(document.querySelector('.recharge-chain .bx-select-popover')).filter((x) => !/^не уверены/i.test(x));
    let account = null;
    for (const it of document.querySelectorAll('.recharge-info-item')) {
      if (/Счет получения|Счёт получения|Receiving account|Deposit to/i.test(it.innerText)) {
        const rt = it.querySelector('.right-text');
        account = rt ? rt.innerText.replace(/\s+/g, ' ').trim() : '';
        break;
      }
    }
    return { coinShown: (c[1] || c[0] || '').slice(0, 60), network: (nl[0] || '').slice(0, 60), account: account || null };
  }).catch(() => ({ coinShown: '', network: '', account: null }));
}

/** Опрашивать состояние, пока не выполнится условие (или не выйдет время). */
async function waitState(page, pred, ms, step = 150) {
  const deadline = Date.now() + Math.max(0, ms);
  for (;;) {
    const st = await readState(page);
    if (pred(st) || Date.now() >= deadline) return st;
    await sleep(step);
  }
}

/** Текст n-го шага формы (0 — монета, 1 — сеть): вторая непустая строка = выбранное значение. */
async function readStepValue(page, n) {
  const txt = await page.locator('.bx-step-content').nth(n).innerText({ timeout: 5000 }).catch(() => '');
  const lines = txt.split('\n').map((s) => s.trim()).filter(Boolean);
  return (lines[1] || lines[0] || '').slice(0, 60);
}

async function readReceiveAccount(page, waitMs = 0) {
  // Блок «Информация про депозит» рисуется ПОСЛЕ ответа биржи (адрес депозита,
  // справочник сети) — читать сразу после выбора сети рано (17.09, DEP/COINDEPO:
  // сеть выбрана, а счёт «?»). Ждём появления строки, но не дольше waitMs.
  const deadline = Date.now() + Math.max(0, waitMs);
  for (;;) {
    const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
    if (await item.count()) {
      const txt = await item.locator('.right-text').first().innerText({ timeout: 5000 }).catch(() => '');
      const v = txt.replace(/\s+/g, ' ').trim();
      if (v) return v;
    }
    if (Date.now() >= deadline) return null;
    await sleep(150);
  }
}

/** Выбрать монету через выпадающий список, если query-параметр не сработал. */
async function selectCoin(page, coin, log) {
  // Тот же тип выпадашки, что у сети (подтверждено отчётом 17.09): триггер —
  // .bx-select-popover в шаге, список — .dp-item в всплывающем .tip-base.
  // Нужен для монет, у которых ?coin= в адресе не выбирает монету (внутреннее имя
  // на бирже отличается от тикера пары — класс GENSYN/«AI»).
  const step = page.locator('.bx-step-content').nth(0);
  await step.locator('.bx-select-popover, [class*="select"]').first().click({ timeout: 5000 });
  const search = page.locator('.tip-base input, .bx-dp input, input[placeholder]').filter({ visible: true }).first();
  await search.waitFor({ state: 'visible', timeout: 3000 }).catch(() => {});
  if (await search.count().catch(() => 0)) await search.fill(coin, { timeout: 3000 }).catch(() => {});
  else await page.keyboard.type(coin, { delay: 30 });
  const items = page.locator('.tip-base .dp-item, .bx-dp .dp-item').filter({ visible: true });
  // Заголовки пунктов — ОДНИМ вызовом (allInnerTexts): поштучный innerText на 60
  // пунктов, да ещё дважды (ожидание + выбор), стоил больше секунды на монету.
  const want = String(coin).toUpperCase();
  const titles = () => items.allInnerTexts().then((a) => a.map((t) => t.split('\n')[0].trim().toUpperCase()), () => []);
  let list = [];
  const deadline = Date.now() + 2000;
  for (;;) {
    list = await titles();
    if (list.includes(want) || Date.now() >= deadline) break;
    await sleep(120);
  }
  // Пустой список = монета не принимается на депозит этой биржей (Alpha-токены:
  // торгуются, но ввода-вывода нет). Это факт, а не отказ автоматики.
  await items.first().waitFor({ state: 'visible', timeout: 6000 })
    .catch(() => { throw new Error(`монета не найдена в списке депозита биржи (депозит ${coin} не поддерживается)`); });
  if (!list.length) list = await titles();
  // ⛔ НИКАКОГО «возьмём первый из списка» (оператор 17.09, кейс DEP): поиск по
  // «DEP» отдавал COINDEPO — ДРУГОЙ токен, и переключался счёт чужой монеты.
  // Совпадение только точное; нет его — честно говорим, что монеты нет.
  // Сверяем ТИКЕР пункта (первая строка), а не весь его текст: по «AI» иначе
  // находился AGT, у которого «AI» стоит в описании (оператор 17.09).
  // ⚠️ Снимок списка устаревает: пока фильтр дорисовывается, пункты сдвигаются, и
  // клик по индексу из старого снимка попадал в ЧУЖОЙ пункт (17.09, USDT остался
  // «Выберите»). Поэтому перед кликом снимок перечитывается, а у самого пункта
  // сверяется тикер — кликаем только по проверенному.
  for (let attempt = 0; attempt < 3; attempt++) {
    list = await titles();
    const idx = list.indexOf(want);
    if (idx < 0) throw new Error(`монета ${coin} не найдена в списке депозита биржи (есть похожие, но это другие токены)`);
    const it = items.nth(idx);
    const title = (await it.innerText({ timeout: 2000 }).catch(() => '')).split('\n')[0].trim().toUpperCase();
    if (title !== want) { await sleep(150); continue; } // список сдвинулся — перечитать
    await it.click({ timeout: 5000 });
    log(`Монета выбрана через список: «${coin}»`);
    return;
  }
  throw new Error(`список монет не устоялся, ${coin} не выбрана`);
}

/** Сеть не выбрана («Выберите»): открыть список сетей и взять первую. У монет с
 *  одной сетью страница выбирает её сама, у USDT/USDC — ждёт пользователя, и без
 *  сети блок «Информация про депозит» (а с ним и «Счёт получения») не рисуется. */
async function selectFirstNetwork(page, log) {
  // Разметка подтверждена отчётом 17.09: триггер — .recharge-chain .bx-select-popover,
  // список — .recharge-network-select-popper, пункты — .dp-item.network-option
  // (заголовок сети в .network-option__title). Меню шапки сюда не попадает.
  const trigger = page.locator('.recharge-chain .bx-select-popover').first();
  await trigger.click({ timeout: 5000 });
  const opts = page.locator('.recharge-network-select-popper .dp-item.network-option').filter({ visible: true });
  await opts.first().waitFor({ state: 'visible', timeout: 6000 });
  const opt = opts.first();
  const name = (await opt.locator('.network-option__title').first().innerText({ timeout: 3000 }).catch(() => '')).trim().slice(0, 40);
  await opt.click({ timeout: 5000 });
  await waitUntil(async () => !/выберите|select/i.test(await readNetwork(page)), 4000, 200);
  log(`Сеть выбрана из списка: «${name || '?'}»`);
}

/** Выбранная сеть — текст триггера списка (не подсказка внутри выпадашки). */
async function readNetwork(page) {
  const t = await page.locator('.recharge-chain .bx-select-popover').first().innerText({ timeout: 4000 }).catch(() => '');
  const line = t.split('\n').map((x) => x.trim()).filter((x) => x && !/^не уверены/i.test(x))[0] || '';
  return line.slice(0, 60);
}

/** Разметка видимых модалок — в отчёт, если переключение не прошло (секретов там нет). */
async function visibleDialogsHtml(page) {
  return page.evaluate(() => {
    const vis = [...document.querySelectorAll('[class*="modal"],[class*="dialog"],[role="dialog"],[class*="popup"]')]
      .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    return vis.slice(0, 3).map((e) => e.outerHTML.slice(0, 2000)).join('\n---\n');
  }).catch(() => '');
}

/** ⇄ → «Спот счёт» → OK. Модалка «Выберите аккаунт» ищется по тексту: её
 *  разметка не подтверждена (пункты .asset-account-item из отчёта 17.09 оказались
 *  меню «Активы» в шапке, а не модалкой). */
async function setSpot(page, log) {
  const item = page.locator('.recharge-info-item', { hasText: /Счет получения|Счёт получения|Receiving account|Deposit to/i }).first();
  // Триггер — значок ⇄ (ics-assets-huazhuan); текст рядом кликабелен не всегда.
  const icon = item.locator('.ics-assets-huazhuan, [class*="huazhuan"]').first();
  if (await icon.count()) await icon.click({ timeout: 5000 }); else await item.locator('.right-text').first().click({ timeout: 5000 });
  const title = page.getByText(/Выберите аккаунт|Select account|Choose account/i).filter({ visible: true }).first();
  await title.waitFor({ state: 'visible', timeout: 8000 });
  log('Модалка «Выберите аккаунт» открыта');
  const spot = page.getByText(/^\s*(Спот счет|Спот счёт|Spot account)\s*$/i).filter({ visible: true }).last();
  await spot.click({ timeout: 5000 });
  // OK есть не всегда: выбор пункта сам закрывает окно. Нет кнопки — не ошибка
  // (17.09: клик по «Спот счёт» прошёл, а ожидание OK висело 8 с впустую).
  const ok = page.getByText(/^\s*(OK|ОК|Подтвердить|Confirm)\s*$/i).filter({ visible: true }).last();
  let pressedOk = false;
  if (!(await waitUntil(async () => !(await title.count()), 800, 150))) {
    if (await ok.count().catch(() => 0)) { pressedOk = true; await ok.click({ timeout: 3000 }).catch(() => {}); }
  }
  await waitUntil(async () => !(await title.count()), 3000, 150);
  log('Нажал ⇄ → «Спот счёт»' + (pressedOk ? ' → OK' : ' (окно закрылось само)'));
}

// Хосты API BingX: биржа раскидывает вызовы между ними, живой выбирается перебором.
const API_HOSTS = (process.env.ARBI_BINGX_API_HOSTS || 'api-app.we-api.com,api-app.acc-de.com,api-app.qq-os.com,api-app.tra-eo.com').split(',');
/** Тип счёта «Спот» в теле запроса (подтверждено живым переключением 17.09). */
const ACCOUNT_TYPE_SPOT = Number(process.env.ARBI_BINGX_SPOT_ACCOUNT_TYPE || 15);
/** Пауза между монетами: свои же вызовы страницы, но частить по чужому API незачем. */
const FAST_GAP_MS = Math.max(50, parseInt(process.env.ARBI_BINGX_FAST_GAP_MS || '150', 10) || 150);

/**
 * Быстрый режим: «Счёт получения» = «Спот счёт» тем же вызовом, что делает сама
 * страница (POST …/user/config/charge-account, тело {accountType, assetId}).
 * Монета → номер берётся из справочника биржи. Открытие страницы на каждую
 * монету не нужно: 1000 монет проходят минутами, а не часами (оператор 17.09).
 */
async function setSpotFast(page, coins, log) {
  const res = await page.evaluate(async ({ coins, accountType, hosts, gapMs, headers, ids }) => {
    const out = { host: null, results: [], error: null, variant: null };
    // Подпись запроса биржа считает под каждый вызов, поэтому чужие заголовки
    // могут её не устроить (17.09: code=100005 «политика безопасности»). Пробуем
    // варианты на ПЕРВОЙ монете и дальше идём тем, который биржа приняла.
    const strip = (h, re) => Object.fromEntries(Object.entries(h || {}).filter(([k]) => !re.test(k)));
    const VARIANTS = [
      { name: 'без заголовков', h: {} },
      { name: 'без подписи', h: strip(headers, /sign|timestamp|nonce|trace|_t$|digest|checksum/i) },
      { name: 'как у страницы', h: headers || {} },
    ];
    const call = async (host, hdr, body) => {
      const r = await fetch(`https://${host}/api/wallet-deposit-withdraw/v1/user/config/charge-account`, {
        method: 'POST', credentials: 'include',
        headers: { 'content-type': 'application/json', ...hdr },
        body: JSON.stringify(body),
      });
      const j = await r.json().catch(() => null);
      return { status: r.status, code: j && j.code, msg: j && (j.msg || j.message) };
    };
    // Справочник монет — тот, что страница уже получила сама (номера монет в
    // памяти). Отдельный запрос без её заголовков биржа не отдаёт (17.09).
    const byName = new Map(ids);
    if (!byName.size) {
      let list = null;
      for (const h of hosts) {
        try {
          const r = await fetch(`https://${h}/api/wallet-deposit-withdraw/v2/coin/support-coins?type=0`, { credentials: 'include', headers: headers || {} });
          const j = await r.json();
          if (j && j.code === 0 && j.data && Array.isArray(j.data.coins)) { list = j.data.coins; out.host = h; break; }
        } catch { /* следующий адрес */ }
      }
      if (!list) { out.error = 'справочник монет биржи не получен ни с одного адреса'; return out; }
      for (const c of list) {
        for (const k of [c.name, c.coinDisplayName, c.showName]) if (k) byName.set(String(k).toUpperCase(), c.id);
      }
    }
    const first = coins.map((c) => ({ coin: c, id: byName.get(String(c).toUpperCase()) })).find((x) => x.id);
    if (!first) { out.error = 'ни одной монеты пачки нет в справочнике биржи'; return out; }
    // Адрес И заголовки подбираются на первой монете: хосты чередуются, подпись
    // считается под каждый вызов. Сетевой отказ на всех адресах — это «не достучались»
    // (общая ошибка → откат на страницу), а не «биржа отказала по монете».
    let hdr = null; let lastCode = null; let lastMsg = null; let reached = false;
    for (const h of hosts) {
      for (const v of VARIANTS) {
        let res = null;
        try { res = await call(h, v.h, { accountType, assetId: first.id }); } catch (e) { lastMsg = String((e && e.message) || e).slice(0, 120); break; }
        reached = true; lastCode = res.code; lastMsg = res.msg || null;
        if (res.code === 0) { hdr = v.h; out.host = h; out.variant = v.name; break; }
        await new Promise((ok) => setTimeout(ok, gapMs));
      }
      if (hdr) break;
    }
    if (!hdr) {
      out.error = reached
        ? `биржа не приняла прямой вызов (code=${lastCode}${lastMsg ? `, ${lastMsg}` : ''})`
        : `до биржи не достучались ни с одного адреса${lastMsg ? ` (${lastMsg})` : ''}`;
      return out;
    }
    out.results.push({ coin: first.coin, assetId: first.id, status: 200, code: 0 });
    for (const coin of coins) {
      if (coin === first.coin) continue;
      const id = byName.get(String(coin).toUpperCase());
      if (!id) { out.results.push({ coin, notFound: true }); continue; }
      try {
        const r = await call(out.host, hdr, { accountType, assetId: id });
        out.results.push({ coin, assetId: id, ...r });
      } catch (e) {
        out.results.push({ coin, assetId: id, error: String((e && e.message) || e).slice(0, 120) });
      }
      await new Promise((ok) => setTimeout(ok, gapMs));
    }
    return out;
  }, { coins, accountType: ACCOUNT_TYPE_SPOT, hosts: [...new Set([lastApiHost, ...API_HOSTS].filter(Boolean))], gapMs: FAST_GAP_MS, headers: lastApiHeaders, ids: [...coinIds] });
  const ok = res.results.filter((x) => x.code === 0).length;
  log(`Быстрый режим (${res.host || 'адрес не найден'}${res.variant ? `, заголовки: ${res.variant}` : ''}): переключено ${ok} из ${coins.length}${res.error ? ` · ${res.error}` : ''}`);
  return res;
}

/**
 * @param {import('playwright').BrowserContext} context
 * @param {{coins?: string[], set?: 'SPOT'|null, fast?: boolean, verify?: boolean, log?: (m:string)=>void}} opts
 */
async function probeDepositAccount(context, opts = {}) {
  const log = opts.log || (() => {});
  const coins = (Array.isArray(opts.coins) && opts.coins.length ? opts.coins : ['USDT']).slice(0, 400).map((c) => String(c).toUpperCase());
  const set = opts.set === 'SPOT' ? 'SPOT' : null;
  const page = await getDepositPage(context, log);
  const rec = attachRecorder(page);
  const results = [];
  let fastFallbackNote = null;
  try {
    if (opts.fast) {
      // Страница нужна один раз: она даёт сессию и живые заголовки для вызовов.
      if (!/assets\/recharge/i.test(page.url())) {
        await page.goto(DEPOSIT_URL_TMPL.replace('{coin}', 'USDT'), { waitUntil: 'domcontentloaded', timeout: 30000 });
        await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 }).catch(() => {});
        await sleep(2000);
      }
      const fast = await setSpotFast(page, coins, log);
      // Биржа не приняла прямой вызов → работаем как раньше, кликами. Кнопка
      // обязана сделать работу, пусть и медленнее (fail-soft, не fail-silent).
      if (!fast.results.some((x) => x.code === 0)) {
        const why = fast.error || 'ни одной монеты не переключено';
        log(`Быстрый режим не прошёл (${why}) — перехожу на страницу депозита`);
        fastFallbackNote = why;
      } else {
      for (const x of fast.results) {
        results.push({
          coin: x.coin, coinShown: x.coin, network: null,
          before: null, after: x.code === 0 ? 'Спот счет' : null, changed: x.code === 0,
          error: x.notFound ? 'монета не найдена в справочнике биржи' : x.error || (x.code === 0 ? null : `биржа ответила code=${x.code}${x.msg ? ` (${x.msg})` : ''}`),
          notes: [], requests: [], otherRequests: 0, assetId: x.assetId ?? null,
        });
      }
      return { ok: true, set, mode: 'fast', host: fast.host, variant: fast.variant, error: fast.error, results };
      }
    }
    // Путь по странице — «тощий» (оператор 17.09: «8–10 с на монету — долго»):
    // страница открывается один раз, дальше монета меняется в её же списке;
    // фиксированные паузы заменены ожиданием нужного состояния; сохранение
    // подтверждается ответом биржи на её же вызов (code=0), а перезагрузка
    // страницы на каждую монету — только по opts.verify (проба), не в кнопке.
    const verify = opts.verify === true;
    let replayTried = false;
    for (let ci = 0; ci < coins.length; ci++) {
      const coin = coins[ci];
      const r = { coin, url: null, coinShown: null, network: null, before: null, after: null, changed: false, persisted: null, error: null, setAt: null, requests: [], otherRequests: 0, notes: [], debug: null, ms: 0 };
      const t0 = Date.now();
      const idx0 = rec.rows.length;
      const note = (m) => { r.notes.push(String(m).slice(0, 200)); log(m); };
      try {
        if (!/assets\/recharge/i.test(page.url())) {
          await page.goto('about:blank').catch(() => {});
          await page.goto(DEPOSIT_URL_TMPL.replace('{coin}', encodeURIComponent(coin)), { waitUntil: 'domcontentloaded', timeout: 30000 });
          await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 });
          await waitUntil(async () => !!(await readStepValue(page, 0)), 5000, 200);
        }
        r.url = scrubUrl(page.url());
        const step = {};
        let mark = Date.now();
        const took = (k) => { step[k] = Date.now() - mark; mark = Date.now(); };
        let st = await readState(page);
        took('load');
        if (!coinMatches(st.coinShown, coin)) {
          const prevAccount = st.account;
          await selectCoin(page, coin, note).catch((e) => note(`Список монет: ${String(e.message).split('\n')[0].slice(0, 160)}`));
          took('pick');
          // Вызовы, вызванные ОТКРЫТИЕМ списка, за перерисовку не считаем: отсчёт
          // с момента, когда монета уже кликнута.
          const idxSel = rec.rows.length;
          // Ждём и выбора монеты, и перерисовки блока «Информация про депозит»:
          // он может ещё показывать ПРЕЖНЮЮ монету, и «Спот» соседки закрыл бы Фонд.
          // ⛔ НЕ по номеру монеты: в адресах страницы номер ПАРЫ монета-сеть
          // (USDT-BEP20 = 799 при USDT = 4) — ожидание «assetId=4» не наступало
          // никогда и выжигало 4 с на монету (17.09).
          st = await waitState(page, (x) => coinMatches(x.coinShown, coin) && (rec.rows.length > idxSel || x.account !== prevAccount), 4000);
          took('redraw');
          if (!coinMatches(st.coinShown, coin)) {
            r.debug = { ...(r.debug || {}), coinStepHtml: (await page.locator('.bx-step-content').nth(0).evaluate((el) => el.outerHTML).catch(() => '')).slice(0, 3000) };
          }
        }
        r.coinShown = st.coinShown;
        r.network = st.network;
        if (!coinMatches(st.coinShown, coin)) {
          note(`${coin}: монета не выбрана на странице — сеть и счёт не читаем`);
        } else {
          if (/выберите|select/i.test(st.network) || !st.account) {
            st = await waitState(page, (x) => !!x.account && !/выберите|select/i.test(x.network), 1500);
          }
          if (/выберите|select/i.test(st.network) || !st.account) {
            const stepHtml = await page.locator('.bx-step-content').nth(1).evaluate((el) => el.outerHTML).catch(() => '');
            await selectFirstNetwork(page, note).catch((e) => note(`Список сетей: ${e.message}`));
            st = await waitState(page, (x) => !!x.account, 6000);
            if (!st.account) {
              const openHtml = await page.evaluate(() => {
                const vis = [...document.querySelectorAll('[class*="dropdown"],[class*="popper"],[role="listbox"],[class*="select-menu"],[class*="options"]')]
                  .filter((e) => { const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
                return vis.slice(0, 4).map((e) => e.outerHTML.slice(0, 1200)).join('\n---\n');
              }).catch(() => '');
              r.debug = { stepHtml: stepHtml.slice(0, 3000), openHtml: openHtml.slice(0, 4000) };
            }
          }
          r.network = st.network;
          took('network');
        }
        r.before = st.account || (await waitState(page, (x) => !!x.account, 3000)).account;
        took('account');
        r.steps = step;
        note(`${coin}: показано «${r.coinShown}» / сеть «${r.network}» / счёт получения «${r.before || '?'}»`);
        if (set === 'SPOT' && r.before && !/Спот|Spot/i.test(r.before) && coinMatches(r.coinShown, coin)) {
          r.setAt = Date.now();
          const idxSet = rec.rows.length;
          try {
            await setSpot(page, note);
          } catch (e) {
            note(`переключение: ${String(e.message).split('\n')[0].slice(0, 160)}`);
            r.debug = { ...(r.debug || {}), dialogsHtml: (await visibleDialogsHtml(page)).slice(0, 6000) };
            await page.keyboard.press('Escape').catch(() => {});
          }
          r.after = (await waitState(page, (x) => /Спот|Spot/i.test(x.account || ''), 4000)).account;
          // ⚠️ ВТОРОЙ МЕТОД (#34): значение на экране может быть только рисовкой UI.
          // Подтверждение — ответ биржи на вызов сохранения самой страницы (code=0);
          // по verify — ещё и перезагрузка с перечитыванием.
          const saved = () => rec.rows.slice(idxSet).find((x) => /^(POST|PUT)$/i.test(x.method) && CHARGE_RE.test(x.url));
          await waitUntil(async () => !!saved(), 4000, 200);
          const sv = saved();
          if (sv) {
            const code = sv.response && typeof sv.response === 'object' ? sv.response.code : undefined;
            if (code === 0) { r.persisted = 'api'; note(`${coin}: биржа подтвердила сохранение (code=0)`); }
            else note(`${coin}: биржа ответила на сохранение code=${code ?? '?'} (HTTP ${sv.status})`);
          } else note(`${coin}: вызова сохранения от страницы не видно`);
          // Диагностика ОДИН раз за пачку: повтор собственного подписанного вызова
          // страницы с номером СЛЕДУЮЩЕЙ монеты. Примет — путь кликов не нужен вовсе
          // (следующая монета покажет «Спот» ещё до нажатия). Наружу — только код ответа.
          if (!replayTried && lastChargeReq && Date.now() - lastChargeReq.t < 8000) {
            replayTried = true;
            const next = coins.slice(ci + 1).find((c) => coinIds.has(String(c).toUpperCase()));
            const nid = next ? coinIds.get(String(next).toUpperCase()) : null;
            if (nid) {
              try {
                const resp = await page.request.post(lastChargeReq.url, { headers: lastChargeReq.headers, data: { accountType: ACCOUNT_TYPE_SPOT, assetId: nid }, timeout: 10000 });
                const j = await resp.json().catch(() => null);
                r.replay = { coin: next, status: resp.status(), code: j && j.code, msg: j && (j.msg || j.message) ? String(j.msg || j.message).slice(0, 120) : null };
                note(`прямой повтор подписанного вызова для ${next}: HTTP ${r.replay.status}, code=${r.replay.code ?? '?'}${r.replay.msg ? ` (${r.replay.msg})` : ''}`);
              } catch (e) { note(`прямой повтор подписанного вызова: ${String(e.message).split('\n')[0].slice(0, 120)}`); }
            } else note('прямой повтор: номер следующей монеты неизвестен (справочник страницы не пойман)');
          }
          if (verify) {
            try {
              await page.reload({ waitUntil: 'domcontentloaded', timeout: 30000 });
              await page.locator('.recharge-main-page').first().waitFor({ state: 'visible', timeout: 20000 });
              await waitUntil(async () => !!(await readStepValue(page, 0)), 5000, 200);
              if (/выберите|select/i.test(await readNetwork(page))) await selectFirstNetwork(page, () => {}).catch(() => {});
              const persisted = await readReceiveAccount(page, 8000);
              if (persisted) { r.persisted = 'reload'; r.after = persisted; }
            } catch (e) { note(`проверка после перезагрузки: ${String(e.message).split('\n')[0].slice(0, 120)}`); }
          }
          r.changed = !!r.after && /Спот|Spot/i.test(r.after);
          note(`${coin}: счёт получения ${verify ? 'после перезагрузки' : 'на экране'} «${r.after || '?'}»`);
        }
      } catch (e) {
        r.error = e.message;
        note(`${coin}: ${e.message}`);
      }
      const mine = rec.rows.slice(idx0).filter((x) => x.t >= t0);
      // В фазе «set» фильтр по смыслу адреса НЕ применяем: вызов сохранения счёта
      // может называться как угодно, а пропустить его дороже, чем показать лишнее.
      const relevant = mine
        .map((x) => ({ ...x, phase: r.setAt && x.t >= r.setAt ? 'set' : 'load' }))
        .filter((x) => x.phase === 'set' || RELEVANT_RE.test(x.url));
      relevant.sort((a, b) => (a.phase === b.phase ? a.t - b.t : a.phase === 'set' ? -1 : 1));
      r.requests = relevant.slice(0, MAX_REQ_PER_COIN);
      r.otherRequests = mine.length - r.requests.length;
      if (r.setAt) {
        r.allReqs = rec.all.filter((x) => x.t >= r.setAt).slice(0, 60);
        r.wsFrames = rec.ws.filter((x) => x.t >= r.setAt).slice(0, 20);
      }
      // Номер в адресах страницы — это ПАРА монета-сеть, а не монета: гейтом он
      // быть не может (#54), показываем как справку. Что показания именно про нашу
      // монету, гарантирует сверка тикера в шаге «монета» (coinMatches).
      const withId = [...mine].reverse().find((x) => /(assetId|coinId)=(\d+)/.test(x.url));
      if (withId) r.pairId = Number(withId.url.match(/(?:assetId|coinId)=(\d+)/)[1]);
      const coinId = coinIds.get(String(coin).toUpperCase());
      if (coinId) r.coinId = coinId;
      if (lastSupportCoins && !results.some((x) => x.supportCoins)) { r.supportCoins = lastSupportCoins; lastSupportCoins = null; }
      r.ms = Date.now() - t0;
      results.push(r);
      await sleep(FAST_GAP_MS); // темп: страница биржи, не залп
    }
  } finally {
    rec.detach();
  }
  return { ok: true, set, mode: fastFallbackNote ? 'fallback' : 'page', fastError: fastFallbackNote, results };
}

module.exports = { probeDepositAccount, scrub, scrubUrl, _coinMatches: coinMatches };

'use strict';

/**
 * src/gui/server.js — «окно настроек» ArbiBrowser.
 *
 * Локальная панель управления: создание профилей, ввод данных прокси,
 * автогенерация уникального отпечатка, запуск изолированного Chromium,
 * проверка конфигурации. Реализована на встроенном http (без Express/Electron),
 * чтобы работать полностью оффлайн и без тяжёлых зависимостей.
 *
 * Панель управления и рабочие браузеры профилей — независимые процессы Chromium:
 * панель лишь дёргает локальный API, который запускает/закрывает контексты.
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { chromium } = require('playwright');
const { isLocalRequest } = require('./local-guard');

const config = require('../../config');
const profileStore = require('../profile');
const generator = require('../fingerprint/generator');
const net = require('../network');
const launcher = require('../launcher');
const validation = require('../validation');
const terminalSync = require('../integration/terminal-sync');
const mexcExecutor = require('../integration/mexc-executor');
const mexcOrderPage = require('../integration/mexc-order-page');
const xtExecutor = require('../integration/xt-executor');
const xtOrderPage = require('../integration/xt-order-page');
const bingxExecutor = require('../integration/bingx-executor');
const bingxOrderPage = require('../integration/bingx-order-page');
const bingxDepositPage = require('../integration/bingx-deposit-page');
const executorCore = require('../integration/executor-core');
const { withContextLock, isContextBusy } = require('../integration/context-lock');
const { closeStalePairTabs } = require('../integration/pair-tabs');
const appInfo = require('../app-info');
const settings = require('../settings');
const sync = require('../sync');

// Уборка вкладок — фоновая работа, и «браузер сейчас ставит заявку» это не
// ошибка, а нормальный повод подождать. Прежний ok:false терминал читал как
// провал и слал намерение заново — в логе оператора 15.09 девять попыток за
// 15 секунд подряд, все красные. Отвечаем успехом с пометкой «отложено», а в
// лог пишем не чаще раза в 30 секунд на биржу, чтобы след остался (#58), но
// простыни не было.
const deferLogAt = new Map();
function deferCleanup(tag, log) {
  const now = Date.now();
  const last = deferLogAt.get(tag) || 0;
  if (now - last > 30_000) {
    deferLogAt.set(tag, now);
    log('Уборка вкладок отложена — браузер ставит заявку (повторим на следующем тике)');
  }
  return { ok: true, deferred: 'busy', closed: 0 };
}


const PUBLIC_DIR = path.join(__dirname, 'public');

// Запущенные контексты профилей: name → { context }. Держим, чтобы окна жили и
// чтобы не открыть один профиль дважды.
const running = new Map();

/** Скачанное фоном обновление, ждущее установки: {version, notes} либо null. */
let updateReady = null;
// Профили в процессе запуска: name → Promise. Гард от ДВОЙНОГО запуска одного
// профиля (авто-запуск исполнителя + ручной из панели) — иначе два Chrome на один
// user-data-dir → системный Chrome «передаёт управление» существующему и launch
// падает («Target closed» / «existing session»). Один профиль = одна сессия.
const launching = new Map();
// Флаг завершения работы. Ставится в начале close(). Пока идёт закрытие панели,
// НЕ поднимаем новые профили: иначе интент, взятый исполнителем МЕЖДУ stopExecutor()
// и закрытием контекстов, доводился до launchProfileOnce и профиль ПЕРЕоткрывался
// уже после закрытия панели (жалоба: «при закрытии оболочки открывается профиль»).
let shuttingDown = false;
/** Попросить панель штатно завершиться (тот же путь, что закрытие окна панели / Ctrl+C). */
let requestShutdown = null;
// Барьер синхронизации профилей (src/sync). Пока НЕ пройден (облако новее, но
// скачать/проверить не вышло) — открытие профилей заблокировано, чтобы биржа не
// увидела старый отпечаток. Снимается «офлайн-режимом» из панели (на свой риск).
let syncBlocked = false;
let syncBlockReason = '';
function setSyncBlocked(v, reason) { syncBlocked = !!v; syncBlockReason = reason || ''; }
/**
 * Запускает профиль РОВНО ОДИН раз: если уже запущен — переиспользует; если запуск
 * уже идёт — ждёт его; иначе стартует. Устраняет конфликт авто/ручного запуска.
 * @returns {Promise<{context, accountIds, geo?, page?, already?:boolean}>}
 */
async function launchProfileOnce(name, opts = {}) {
  if (shuttingDown) throw new Error('панель закрывается — новый профиль не запускаем');
  // Fail-closed: не открываем профиль, пока синхронизация не подтверждена (иначе
  // рискуем открыть со старым отпечатком/прокси). bypassSync — осознанный офлайн.
  if (syncBlocked && !opts.bypassSync) {
    throw new Error('Синхронизация профилей не завершена — открытие заблокировано. '
      + 'Устраните связь с терминалом и перезапустите, либо включите офлайн-режим в панели. ' + syncBlockReason);
  }
  const existing = running.get(name);
  if (existing) return { ...existing, already: true };
  if (launching.has(name)) return launching.get(name);
  const p = (async () => {
    const opened = await launcher.open(name, opts);
    // Вливаем скачанные барьером cookie сессий (перенос входа на новое устройство).
    if (sync.enabled()) { try { await sync.injectPendingCookies(name, opened.context); } catch { /* cookie best-effort */ } }
    const rec = { context: opened.context, accountIds: accountIdsFromProfile(opened.profile), group: opened.profile && opened.profile.group };
    running.set(name, rec);
    opened.context.on('close', () => running.delete(name));
    return { ...rec, geo: opened.geo, page: opened.page };
  })();
  launching.set(name, p);
  try { return await p; }
  finally { launching.delete(name); }
}

/**
 * Выгрузка в облако профиля с СВЕЖИМИ cookie: если контекст открыт — снимаем cookie
 * из живой сессии, затем пушим профиль+cookie. Best-effort (не бросает).
 */
async function pushProfileWithCookies(name) {
  if (!sync.enabled()) return;
  let cookiesStr = null;
  const rec = running.get(name);
  if (rec && rec.context) { try { cookiesStr = await sync.captureCookies(name, rec.context); } catch { /* cookie best-effort */ } }
  await sync.pushProfile(name, cookiesStr ? { cookiesStr } : {}).catch(() => {});
}

/** Периодическая выгрузка ВСЕХ открытых профилей (heartbeat синка). */
async function pushOpenProfiles() {
  for (const name of Array.from(running.keys())) { await pushProfileWithCookies(name); }
}

/**
 * accountId'ы терминала, привязанные к профилю. Модель «профиль = прокси-профиль»:
 * в note список "accountIds: id1,id2,...". Старый формат ("(accountId <id>)") —
 * поддержан для обратной совместимости. seed НЕ используем (теперь = ключ прокси,
 * а не accountId).
 * @returns {string[]}
 */
function accountIdsFromProfile(profile) {
  if (!profile || typeof profile.note !== 'string') return [];
  const note = profile.note;
  const mMulti = note.match(/accountIds:\s*([A-Za-z0-9_,\s-]+)/i);
  if (mMulti) return mMulti[1].split(/[,\s]+/).map((s) => s.trim()).filter(Boolean);
  const mSingle = note.match(/accountId\s+([^)\s]+)/);
  return mSingle ? [mSingle[1]] : [];
}

/**
 * Находит ИМЯ профиля (среди всех на диске), к которому привязан данный accountId
 * — для авто-запуска нужного прокси-профиля под ордер. Возвращает null, если нет.
 * @returns {string|null}
 */
function findProfileNameByAccountId(accountId) {
  const want = String(accountId);
  let fallback = null;
  for (const name of profileStore.list()) {
    let profile = null;
    try { profile = profileStore.load(name); } catch { continue; }
    if (accountIdsFromProfile(profile).includes(want)) {
      // Предпочитаем НОВЫЙ прокси-профиль (group='by-proxy') старым per-account
      // профилям — чтобы не хватать устаревший XT-SvKuz вместо proxy-<label>.
      if (profile.group === 'by-proxy') return name;
      if (!fallback) fallback = name;
    }
  }
  return fallback;
}

/**
 * Находит контекст ЗАПУЩЕННОГО профиля, к которому привязан accountId.
 * Приоритет — список accountId, ЗАХВАЧЕННЫЙ при запуске (rec.accountIds): надёжно
 * и не зависит от чтения файла профиля, который мог быть перезаписан ре-синком на
 * лету. Фолбэк на чтение с диска — для профилей, запущенных до этой версии.
 * @returns {import('playwright').BrowserContext|null}
 */
function contextForAccountId(accountId) {
  const want = String(accountId);
  let fallback = null; // старый per-account профиль, если прокси-профиль не открыт
  for (const [name, rec] of running.entries()) {
    let ids = rec.accountIds;
    if (!ids || !ids.length) {
      try { ids = accountIdsFromProfile(profileStore.load(name)); } catch { ids = []; }
    }
    if (ids && ids.includes(want)) {
      const isProxy = rec.group === 'by-proxy' || (name && name.startsWith('proxy-'));
      if (isProxy) {
        console.log(`[exec] accountId=${want} → открытый прокси-профиль ${name}`);
        return rec.context;
      }
      if (!fallback) fallback = { name, context: rec.context };
    }
  }
  if (fallback) {
    console.log(`[exec] accountId=${want} → открытый профиль ${fallback.name} (старый per-account)`);
    return fallback.context;
  }
  const have = Array.from(running.entries())
    .map(([n, r]) => `${n}(${(r.accountIds || []).join('|') || '?'})`).join(', ') || '—';
  console.log(`[exec] контекст не найден для accountId=${want}; запущены: ${have}`);
  return null;
}

// ── Утилиты HTTP ──

function sendJson(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      if (!data) return resolve({});
      try {
        resolve(JSON.parse(data));
      } catch (e) {
        reject(new Error(`Некорректный JSON в теле запроса: ${e.message}`));
      }
    });
    req.on('error', reject);
  });
}

function serveStatic(res, relPath) {
  const clean = relPath.replace(/\.\.+/g, '').replace(/^\/+/, '');
  const file = path.join(PUBLIC_DIR, clean || 'index.html');
  fs.readFile(file, (err, buf) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      return res.end('404');
    }
    const ext = path.extname(file);
    const type =
      ext === '.html' ? 'text/html; charset=utf-8'
      : ext === '.js' ? 'text/javascript; charset=utf-8'
      : ext === '.css' ? 'text/css; charset=utf-8'
      : ext === '.png' ? 'image/png'
      : ext === '.svg' ? 'image/svg+xml'
      : ext === '.ico' ? 'image/x-icon'
      : 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type });
    res.end(buf);
  });
}

// ── API-обработчики ──

/** Список профилей + краткий статус валидации и «запущен ли». */
function apiListProfiles(res) {
  const names = profileStore.list();
  const items = names.map((name) => {
    const r = profileStore.loadResult(name);
    const p = r.profile || {};
    return {
      name,
      valid: r.ok,
      errors: r.errors,
      warnings: r.warnings,
      running: running.has(name),
      os: p.navigator && p.navigator.platform,
      userAgent: p.userAgent,
      proxy: p.proxy ? `${p.proxy.type}://${p.proxy.host}:${p.proxy.port}` : null,
      locale: p.locale,
      timezone: p.timezone,
      autoGeo: p.autoGeo !== false,
      group: (p.group || '').trim(),
      autoLaunch: p.autoLaunch === true,
    };
  });
  sendJson(res, 200, { profiles: items, running: Array.from(running.keys()) });
}

/** Генерация отпечатка (не сохраняет). body: {name, os?, locale?, proxy?, note?} */
async function apiGenerate(req, res) {
  const body = await readBody(req);
  if (!body.name) return sendJson(res, 400, { error: 'Требуется имя профиля (name).' });
  const profile = generator.generate({
    name: body.name,
    os: body.os || undefined,
    locale: body.locale || undefined,
    proxy: body.proxy || undefined,
    note: body.note || undefined,
  });
  const v = profileStore.validate(profile);
  sendJson(res, 200, { profile, valid: v.ok, errors: v.errors, warnings: v.warnings });
}

/** Сохранение профиля. body: полный объект профиля. */
async function apiSaveProfile(req, res) {
  const profile = await readBody(req);
  if (!profile.name) return sendJson(res, 400, { error: 'Требуется имя профиля (name).' });
  try {
    // SEC-1 merge: GET не отдаёт прокси-пароль, поэтому при правке форма шлёт его
    // пустым = «не менять». Подставляем прежний пароль с диска, если хост/порт того же
    // прокси не изменились (иначе старый пароль к новому прокси не подходит — не тянем).
    if (profile.proxy && !profile.proxy.password) {
      const prev = profileStore.loadResult(profile.name).profile;
      const pp = prev && prev.proxy;
      if (pp && pp.password && pp.host === profile.proxy.host && String(pp.port) === String(profile.proxy.port)) {
        profile.proxy.password = pp.password;
      }
    }
    if (profile.proxy) delete profile.proxy.passwordSet; // служебный флаг GET — не персистим
    // Новый профиль не наследует каталог браузера удалённого одноимённого (см. profileStore).
    const quarantined = profileStore.exists(profile.name) ? null : profileStore.quarantineStaleUserData(profile.name);
    const { file, warnings } = profileStore.save(profile);
    const extra = quarantined ? [`На диске уже был каталог браузера прежнего профиля «${profile.name}» — отложен как ${path.basename(quarantined)}, новый профиль стартует чистым.`] : [];
    // Синк: выгружаем изменённый профиль в облако (fire-and-forget, не блокируем ответ).
    if (sync.enabled()) sync.pushProfile(profile.name, { force: true }).catch(() => {});
    sendJson(res, 200, { ok: true, file, warnings: [...(warnings || []), ...extra] });
  } catch (e) {
    sendJson(res, 400, { error: e.message });
  }
}

/**
 * Привязка ОДНОГО профиля к аккаунтам терминала — вместо общей синхронизации.
 *
 * Зачем (оператор 2026-09-16, кейс «spot Aylan» на decodo 3): аккаунт, заведённый
 * на прокси ПОСЛЕ последнего sync, остаётся непривязанным — в заметке профиля
 * висит ключ заготовки (`draft-<proxyId>`), и исполнитель отвечает «Профиль для
 * accountId не найден», хотя профиль открыт. Общий sync это чинит, но он
 * пересобирает ВСЕ профили сразу, включая рабочие: у профиля на несколько
 * аккаунтов отпечаток берётся из ПЕРВОГО по алфавиту, и трогать залогиненный
 * рабочий профиль ради чужой строки незачем.
 *
 * Здесь переписывается ТОЛЬКО список accountIds в заметке ЭТОГО профиля.
 * Отпечаток, прокси, группа и каталог браузера с логином не трогаются вовсе —
 * save() пишет один JSON-файл. Перед записью делается его копия (.backups/),
 * чтобы откат не требовал ручного копирования файлов.
 *
 * Аккаунты сопоставляются по ПРОКСИ — тем же ключом, что и общий sync
 * (`terminal-sync.proxyKey`), поэтому расхождения между кнопкой и синхронизацией
 * быть не может.
 */
async function apiRebindProfile(req, res) {
  const body = await readBody(req);
  const name = String((body && body.name) || '').trim();
  if (!name) return sendJson(res, 400, { error: 'Требуется имя профиля (name).' });
  // Имя идёт в путь файла голым path.join — «../» увела бы и чтение, и копию за
  // пределы каталога профилей (ревью 2026-09-16). Тот же класс символов, что в схеме.
  if (!/^[a-zA-Z0-9._-]+$/.test(name)) return sendJson(res, 400, { error: `Недопустимое имя профиля: "${name}".` });
  const r = profileStore.loadResult(name);
  if (!r.ok || !r.profile) return sendJson(res, 404, { error: `Профиль "${name}" не найден или невалиден.` });
  const profile = r.profile;
  // save() пишет по полю name ВНУТРИ файла, а копию мы делаем по имени файла.
  // Разошлись (файл переименовали руками) — правка уехала бы в чужой профиль,
  // причём копия была бы сделана не с него. Отказываемся (ревью 2026-09-16).
  if (profile.name !== name) {
    return sendJson(res, 409, { error: `Файл "${name}.json" описывает профиль «${profile.name}» — привязка отменена, чтобы не изменить чужой профиль.` });
  }
  const px = profile.proxy;
  if (!px || !px.host) {
    return sendJson(res, 400, { error: 'У профиля нет прокси, а привязка идёт по прокси. Для профиля без прокси используйте общую синхронизацию.' });
  }
  let accounts;
  try {
    accounts = await terminalSync.fetchAccounts();
  } catch (e) {
    return sendJson(res, 502, { error: `Терминал не ответил: ${e.message}` });
  }
  const key = `${String(px.type).toLowerCase()}://${px.host}:${px.port}`;
  const mine = accounts.filter((a) => terminalSync.proxyKey(a) === key);
  const before = accountIdsFromProfile(profile);
  if (!mine.length) {
    // Пусто — НЕ пишем: стереть привязку молча хуже, чем оставить как было (#58).
    console.log(`[rebind] ${name}: терминал не знает аккаунтов на ${px.host}:${px.port} — профиль не тронут`);
    return sendJson(res, 200, {
      ok: false, before, after: before,
      error: `Терминал не знает ни одного аккаунта на прокси ${px.host}:${px.port}. Проверьте, что аккаунт заведён именно на этот прокси и включён. Профиль не изменён.`,
    });
  }
  const ids = mine.map((a) => a.accountId);
  const exchanges = [...new Set(mine.map((a) => a.exchange).filter(Boolean))];
  // Терминал отдаёт ТОЛЬКО активные аккаунты (integration.ts: isActive: true).
  // Значит выключенный на минуту аккаунт просто не придёт — и кнопка молча
  // вычеркнула бы его из рабочего профиля, отрапортовав успехом (ревью
  // 2026-09-16). Убавлять привязку не наше дело: гасим со следом и не пишем.
  // Заготовки (draft-<proxyId>) исключены — снять их и есть смысл кнопки.
  const lost = before.filter((id) => !/^draft-/.test(id) && !ids.includes(id));
  if (lost.length) {
    console.log(`[rebind] ${name}: терминал не вернул уже привязанные ${lost.join(',')} — профиль не тронут`);
    return sendJson(res, 200, {
      ok: false, before, after: before,
      error: `Терминал не вернул аккаунты, уже привязанные к этому профилю: ${lost.join(', ')}. Обычно это значит, что аккаунт выключен в терминале. Профиль НЕ изменён — включите аккаунт и повторите; если аккаунт удалён намеренно, привязку обновит общая синхронизация.`,
    });
  }
  const backup = profileStore.backupProfileFile(name);
  const { warnings } = profileStore.save({ ...profile, note: terminalSync.noteWithAccountIds(profile.note, ids, exchanges) });
  // Открытый профиль держит список аккаунтов с момента ЗАПУСКА (rec.accountIds).
  // Без этой строки привязка заработала бы только со следующего запуска, а до
  // него в логе ещё раз мелькало бы «контекст не найден» — и оператор решил бы,
  // что кнопка не помогла. Закрывать и поднимать профиль заново не нужно.
  const rec = running.get(name);
  if (rec) rec.accountIds = ids;
  if (sync.enabled()) sync.pushProfile(name, { force: true }).catch(() => {});
  console.log(`[rebind] ${name}: ${before.join(',') || 'нет'} → ${ids.join(',')}${rec ? ' (профиль открыт — привязка применена сразу)' : ''} (копия: ${backup ? path.basename(backup) : 'нет'})`);
  return sendJson(res, 200, {
    ok: true, before, after: ids, exchanges,
    backup: backup ? path.basename(backup) : null,
    warnings: warnings || [],
  });
}

/** Ручная выгрузка всех локальных профилей в облако (кнопка «Синхронизировать»). */
async function apiSyncPush(res) {
  if (!sync.enabled()) return sendJson(res, 400, { error: 'Синхронизация выключена (ARBI_PROFILE_SYNC=1 + токен терминала).' });
  try {
    // Сначала снимем свежие cookie с открытых профилей, потом выгрузим все.
    for (const name of Array.from(running.keys())) { await pushProfileWithCookies(name); }
    const out = await sync.pushAll();
    sendJson(res, 200, { ok: true, results: out });
  } catch (e) { sendJson(res, 500, { error: e.message }); }
}

/** Полный профиль по имени. */
function apiGetProfile(res, name) {
  const r = profileStore.loadResult(name);
  if (!r.profile) return sendJson(res, 404, { error: `Профиль "${name}" не найден.` });
  // SEC-1: НЕ отдаём прокси-пароль наружу (через CSRF-вектор ответ мог утечь).
  // Вместо значения — флаг passwordSet: форма оставляет поле пустым = «не менять»,
  // а apiSaveProfile подставит прежний пароль с диска (merge ниже).
  let profile = r.profile;
  if (profile.proxy && profile.proxy.password) {
    profile = { ...profile, proxy: { ...profile.proxy, password: undefined, passwordSet: true } };
  }
  sendJson(res, 200, { profile, valid: r.ok, errors: r.errors, warnings: r.warnings });
}

/** Удаление профиля. */
async function apiDeleteProfile(res, name) {
  // Раньше: запущенный профиль → 409 «сначала закройте». Но web-исполнитель
  // АВТО-поднимает профили под ордера (они висят «запущен»), из-за чего кнопка
  // «Удалить» не срабатывала. Теперь: если профиль запущен — СНАЧАЛА закрываем
  // окно, ЗАТЕМ удаляем. После удаления файла профиля исполнитель его уже не
  // поднимет (findProfileNameByAccountId не найдёт).
  const rec = running.get(name);
  if (rec) {
    try { await rec.context.close(); } catch (_) { /* уже закрыт */ }
    running.delete(name);
  }
  // Мягкое удаление: переносим в корзину (можно восстановить). Насовсем — из корзины.
  profileStore.trash(name);
  sendJson(res, 200, { ok: true });
}

/** Список профилей в корзине. */
function apiListTrash(res) {
  sendJson(res, 200, { trash: profileStore.listTrash() });
}

/** Восстановить профиль из корзины. */
function apiRestoreTrash(res, name) {
  const ok = profileStore.restore(name);
  if (!ok) return sendJson(res, 409, { error: `Не удалось восстановить «${name}» (уже есть одноимённый или нет в корзине).` });
  sendJson(res, 200, { ok: true });
}

/** Удалить профиль из корзины НАВСЕГДА. */
function apiPurgeTrash(res, name) {
  profileStore.purge(name);
  sendJson(res, 200, { ok: true });
}

/** Очистить данные браузера профиля (cookies, история, хранилища сайтов, вкладки
 *  прошлой сессии). Прокси и отпечаток остаются. Только у закрытого профиля: у
 *  открытого Chromium держит файлы каталога, и стирание было бы частичным. */
function apiWipeProfile(res, name) {
  if (!profileStore.exists(name)) return sendJson(res, 404, { error: `Профиль "${name}" не найден.` });
  if (running.has(name) || launching.has(name)) {
    return sendJson(res, 409, { error: `Профиль «${name}» открыт — сначала нажмите «Закрыть», потом очищайте.` });
  }
  try {
    const wiped = profileStore.wipeUserData(name);
    sendJson(res, 200, { ok: true, wiped });
  } catch (e) {
    sendJson(res, 500, { error: `Не удалось стереть данные «${name}»: ${e.message}` });
  }
}

/** Запуск профиля в отдельном окне Chromium (headful). */
async function apiLaunch(req, res, name) {
  const body = await readBody(req).catch(() => ({}));
  const logs = [];
  try {
    // launchProfileOnce переиспользует уже запущенный профиль (в т.ч. скрытый,
    // поднятый исполнителем) — двойного запуска на один user-data-dir не будет.
    const r = await launchProfileOnce(name, {
      headless: !!body.headless,
      startUrl: body.startUrl || config.startUrl,
      log: (m) => logs.push(m),
    });
    if (r.already) return sendJson(res, 200, { ok: true, already: true });
    sendJson(res, 200, { ok: true, geo: r.geo, logs });
  } catch (e) {
    // «existing session» / «Target closed» = профиль уже открыт другим процессом
    // Chrome (или остался орфаном от прошлого запуска) — понятное сообщение.
    const msg = /existing|Target.*closed|ProcessSingleton|user data/i.test(e.message || '')
      ? 'Профиль уже открыт в другом окне/процессе Chrome (или остался от прошлого запуска). Закройте все окна этого профиля и повторите.'
      : e.message;
    sendJson(res, 500, { error: msg, logs });
  }
}

/** Закрыть запущенное окно профиля. */
async function apiCloseProfile(res, name) {
  const rec = running.get(name);
  if (!rec) return sendJson(res, 200, { ok: true, notRunning: true });
  try {
    await rec.context.close();
  } catch (_) {}
  running.delete(name);
  sendJson(res, 200, { ok: true });
}

/** Проверка конфигурации (validation-отчёт). */
async function apiCheck(req, res, name) {
  const body = await readBody(req).catch(() => ({}));
  try {
    const { text, report, geo } = await validation.run(name, {
      headless: body.headless !== false,
      save: true,
      log: () => {},
    });
    sendJson(res, 200, { ok: true, text, summary: report.summary, geo });
  } catch (e) {
    sendJson(res, 500, { error: e.message });
  }
}

/** Сохранение пользовательских настроек (путь Chromium, автопроверка версии). */
async function apiSaveSettings(req, res) {
  try {
    const body = await readBody(req);
    const patch = {};
    if (typeof body.chromiumPath === 'string') patch.chromiumPath = body.chromiumPath.trim();
    if (typeof body.autoUpdateCheck === 'boolean') patch.autoUpdateCheck = body.autoUpdateCheck;
    if (typeof body.preferSystemChrome === 'boolean') patch.preferSystemChrome = body.preferSystemChrome;
    // Экономия ресурсов (см. settings.js): общий процесс на сайт, спящие
    // вкладки, потолки. Числа приводим и ограничиваем — из панели прилетает строка.
    if (typeof body.saveMemory === 'boolean') patch.saveMemory = body.saveMemory;
    if (typeof body.sleepingTabs === 'boolean') patch.sleepingTabs = body.sleepingTabs;
    if (body.maxRestoredTabs != null && Number.isFinite(Number(body.maxRestoredTabs))) {
      patch.maxRestoredTabs = Math.max(1, Math.min(20, Math.floor(Number(body.maxRestoredTabs))));
    }
    if (body.rendererLimit != null && Number.isFinite(Number(body.rendererLimit))) {
      patch.rendererLimit = Math.max(0, Math.min(32, Math.floor(Number(body.rendererLimit))));
    }
    if (body.idleSleepMinutes != null && Number.isFinite(Number(body.idleSleepMinutes))) {
      patch.idleSleepMinutes = Math.max(1, Math.min(600, Math.floor(Number(body.idleSleepMinutes))));
    }
    if (body.maxLoadedTabs != null && Number.isFinite(Number(body.maxLoadedTabs))) {
      patch.maxLoadedTabs = Math.max(1, Math.min(20, Math.floor(Number(body.maxLoadedTabs))));
    }
    // Свёрнутые папки профилей: список имён групп ('' — «Без папки»).
    // Ограничиваем и чистим: панель шлёт своё состояние как есть.
    if (Array.isArray(body.collapsedFolders)) {
      patch.collapsedFolders = body.collapsedFolders
        .filter((g) => typeof g === 'string')
        .map((g) => g.slice(0, 64))
        .slice(0, 200);
    }
    // Спец-действие: использовать найденный системный Chrome.
    if (body.useDetectedChrome) {
      const detected = appInfo.detectSystemChrome();
      if (!detected) return sendJson(res, 400, { error: 'Обычный Chrome в системе не найден.' });
      patch.chromiumPath = detected;
    }
    const next = settings.write(patch);
    sendJson(res, 200, { ok: true, settings: next, info: await appInfo.appInfo() });
  } catch (e) {
    sendJson(res, 400, { error: e.message });
  }
}

/**
 * Обновление самого ArbiBrowser: git pull для установки из репозитория,
 * самообновление кода (~1.5 МБ) для .exe-сборки — см. app-info.selfUpdate.
 *
 * `running.size` передаём вниз намеренно: пока открыт профиль, под ним живёт
 * сессия биржи и, возможно, заявка в работе — подменять код и перезапускаться
 * в этот момент нельзя (updater.canInstall вернёт отказ с причиной).
 */
async function apiAppUpdate(res) {
  // ОДНА КНОПКА (оператор 2026-09-08): раньше при открытых профилях обновление
  // отказывало «закройте профили», и это читалось как «ставьте вручную». Теперь:
  // 1) блокируем новые запуски профилей (shuttingDown) — исполнители не поднимут
  //    профиль под свежее намерение посреди обновления;
  // 2) закрываем каждый открытый профиль, ДОЖДАВШИСЬ его денежной дорожки
  //    (withContextLock 'order'): заявка/прогрев в работе завершится, и только потом
  //    окно закроется — деньги не рвём;
  // 3) ставим обновление; 4) успех → отвечаем панели и перезапускаемся сами
  //    (restartSelf); отказ → снимаем блокировку и честно отдаём причину.
  const names = [...running.keys()];
  shuttingDown = true;
  try {
    for (const name of names) {
      const rec = running.get(name);
      if (!rec) continue;
      console.log(`[update] закрываю профиль «${name}» перед обновлением${isContextBusy(rec.context) ? ' — жду завершения заявки' : ''}`);
      try {
        await withContextLock(rec.context, async () => { try { await rec.context.close(); } catch (_) { /* уже закрыт */ } });
      } catch (_) { /* закрытие best-effort */ }
      running.delete(name);
    }
    const r = await appInfo.applyAppUpdate({ openProfiles: running.size });
    if (r.ok && r.installType === 'self') updateReady = null; // установлено — больше не «ждёт»
    const restart = !!(r.ok && (r.installType === 'self' || r.installType === 'git'));
    if (!restart) shuttingDown = false; // не обновились — панель продолжает работать как прежде
    // .exe-сборка (installType==='exe') — не ошибка, а указание скачать установщик:
    // отдаём 200, чтобы панель показала ссылку, а не «не удалось обновить».
    const httpOk = r.ok || r.installType === 'exe';
    sendJson(res, httpOk ? 200 : 500, { ...r, closedProfiles: names, restarting: restart });
    if (restart) setTimeout(restartSelf, 700); // дать ответу долететь до панели
  } catch (e) {
    shuttingDown = false;
    sendJson(res, 500, { error: e.message });
  }
}

/**
 * Перезапуск САМОГО СЕБЯ после обновления. Запускаем копию с той же командой и
 * окружением (node.exe bin/browser.js gui — ровно то, что делает ArbiBrowser-run.cmd;
 * PLAYWRIGHT_BROWSERS_PATH уже в env), передаём ей наш pid: новая копия ждёт,
 * пока мы выйдем и освободим порт панели (см. cmdGui в bin/browser.js). Затем
 * завершаемся штатным путём — как при закрытии окна панели: профили закрыты,
 * сервер останавливается, порт свободен. Если запущены из консоли (.cmd) —
 * новая копия открывает СВОЁ окно консоли, чтобы журнал не пропал; из .vbs
 * (без окна) — тихо, как и была.
 */
function restartSelf() {
  const { spawn } = require('node:child_process');
  const ROOT = path.join(__dirname, '..', '..');
  const env = { ...process.env, ARBI_RESTART_AFTER_PID: String(process.pid) };
  try {
    const runCmd = path.join(ROOT, 'ArbiBrowser-run.cmd');
    if (process.platform === 'win32' && process.stdout.isTTY && fs.existsSync(runCmd)) {
      // shell:true — иначе spawn экранирует кавычки заголовка окна для `start`.
      // cmd /c — окно закрывается, когда node выходит. Без него после обновления
      // прежнее окно оставалось с приглашением командной строки (оператор 17.09:
      // процесс завершился, а окно висит — это уже не node, а cmd).
      spawn(`start "ArbiBrowser" cmd /c ""${runCmd}""`, { shell: true, detached: true, stdio: 'ignore', env, cwd: ROOT }).unref();
    } else {
      spawn(process.execPath, process.argv.slice(1), { detached: true, stdio: 'ignore', env, cwd: process.cwd(), windowsHide: true }).unref();
    }
    console.log('[update] новая копия ArbiBrowser запущена — завершаюсь, чтобы она заняла порт панели');
  } catch (e) {
    console.error(`[update] не удалось запустить новую копию: ${e.message} — запустите ArbiBrowser вручную`);
  }
  if (typeof requestShutdown === 'function') requestShutdown();
  else process.exit(0);
}

/**
 * Скачать новый установщик СЕРВЕРНОЙ стороной (Node, не Chromium панели) в папку
 * «Загрузки» с верным именем ArbiBrowser-Setup.exe и открыть эту папку в проводнике.
 * Прежний путь (window.open в панели) качал файл ВНУТРИ антидетект-Chromium → «мусорное»
 * имя, файл не открывался (жалоба оператора 2026-07-14).
 */
async function apiDownloadInstaller(res) {
  try {
    const r = await appInfo.downloadInstaller();
    if (r.ok && r.path) { appInfo.openExternal(path.dirname(r.path)); } // показать папку с .exe
    sendJson(res, r.ok ? 200 : 500, r);
  } catch (e) {
    sendJson(res, 500, { ok: false, error: e.message });
  }
}

/** Открыть страницу скачивания установщика в СИСТЕМНОМ браузере (кнопка «Скачать в браузере»). */
// Открыть в системном проводнике папку со скачанными в браузере файлами.
// Каталог создаётся при старте профиля, но кнопка может быть нажата и до первого
// запуска — поэтому создаём его здесь же, чтобы проводник всегда открылся.
async function apiOpenDownloads(res) {
  try {
    const dir = config.downloadsRoot;
    fs.mkdirSync(dir, { recursive: true });
    const r = await appInfo.openExternal(dir);
    sendJson(res, r.ok ? 200 : 500, { ...r, path: dir });
  } catch (e) {
    sendJson(res, 500, { ok: false, error: e.message });
  }
}

async function apiOpenDownload(res) {
  try {
    const r = await appInfo.openDownloadInBrowser();
    sendJson(res, r.ok ? 200 : 500, r);
  } catch (e) {
    sendJson(res, 500, { ok: false, error: e.message });
  }
}

/** Скачивание/обновление встроенных расширений (запуск scripts/fetch-extensions.js). */
function apiRefreshExtensions(res) {
  const { execFile } = require('node:child_process');
  const script = path.join(config.root, 'scripts', 'fetch-extensions.js');
  if (!fs.existsSync(script)) {
    return sendJson(res, 500, { error: 'scripts/fetch-extensions.js не найден в сборке.' });
  }
  execFile(process.execPath, [script], { timeout: 90000, cwd: config.root }, (err, stdout, stderr) => {
    const log = ((stdout || '') + (stderr ? '\n' + stderr : '')).slice(-6000);
    if (err) return sendJson(res, 500, { error: (stderr || err.message).slice(-400), log });
    sendJson(res, 200, { ok: true, log });
  });
}

/** Импорт аккаунтов из цекс-терминала (создаёт/обновляет профили). */
async function apiSyncTerminal(res) {
  try {
    // Предупреждения синка (⚠ — отложенный старый каталог и т.п.) должны дойти до
    // панели, а не тонуть в глушёном логе: молчаливых срезов не бывает.
    const logs = [];
    const r = await terminalSync.sync({ log: (m) => logs.push(String(m)) });
    sendJson(res, 200, { ok: true, ...r, warnings: logs.filter((l) => l.startsWith('⚠')) });
  } catch (e) {
    sendJson(res, 500, { error: e.message });
  }
}

/** Перемещение профиля в папку (group). body: {group}. Пусто → «Без папки». */
async function apiSetGroup(req, res, name) {
  try {
    const body = await readBody(req).catch(() => ({}));
    const profile = profileStore.load(name);
    const group = typeof body.group === 'string' ? body.group.trim().slice(0, 64) : '';
    if (group) profile.group = group;
    else delete profile.group;
    profileStore.save(profile);
    sendJson(res, 200, { ok: true, group });
  } catch (e) {
    sendJson(res, 400, { error: e.message });
  }
}

/** Автозагрузка профиля при старте ArbiBrowser (флаг в профиле). body: {enabled}. */
async function apiSetAutoLaunch(req, res, name) {
  try {
    const body = await readBody(req).catch(() => ({}));
    const profile = profileStore.load(name);
    if (body.enabled) profile.autoLaunch = true;
    else delete profile.autoLaunch;
    profileStore.save(profile);
    sendJson(res, 200, { ok: true, autoLaunch: !!body.enabled });
  } catch (e) {
    sendJson(res, 400, { error: e.message });
  }
}

/** Проверка сети профиля (прокси + гео). */
async function apiNetworkCheck(req, res, name) {
  try {
    const profile = profileStore.load(name);
    const r = await net.checkNetworkConfig(profile);
    sendJson(res, 200, r);
  } catch (e) {
    sendJson(res, 500, { error: e.message });
  }
}

// ── Роутинг ──

// SEC-1: локальный хост, к которому привязан GUI (для проверки заголовка Host).
// По умолчанию loopback; start() уточняет по opts.host. Логика проверки — в
// local-guard.js (без playwright-зависимости, покрыта юнит-тестами).
let boundHost = '127.0.0.1';

// ── U1: логи исполнителя прямо в панели (кольцевой буфер + SSE-стрим) ──────────
// Логи исполнителей идут через console.log('[mexc-exec]…'). Перехватываем console.*
// (оригинал сохраняем — консоль работает как раньше), складываем последние строки в
// кольцевой буфер и стримим подписанным SSE-клиентам. Так пользователь видит логи в
// самой панели ArbiBrowser, не держа отдельное окно консоли (частый кейс: запуск из
// терминала, где консоли не видно).
const LOG_BUFFER_MAX = 500;
const logBuffer = [];
const logSubscribers = new Set();
function pushLog(line) {
  const entry = { t: Date.now(), line: String(line) };
  logBuffer.push(entry);
  if (logBuffer.length > LOG_BUFFER_MAX) logBuffer.shift();
  for (const res of logSubscribers) {
    try { res.write(`data: ${JSON.stringify(entry)}\n\n`); } catch { /* соединение закрыто */ }
  }
}
for (const level of ['log', 'warn', 'error']) {
  const orig = console[level].bind(console);
  console[level] = (...a) => {
    orig(...a);
    try { pushLog(a.map((x) => (typeof x === 'string' ? x : require('node:util').inspect(x))).join(' ')); }
    catch { /* перехват не должен мешать самому логированию */ }
  };
}
function apiLogsStream(req, res) {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  for (const e of logBuffer) res.write(`data: ${JSON.stringify(e)}\n\n`); // история сразу
  logSubscribers.add(res);
  req.on('close', () => logSubscribers.delete(res));
}

// ── Снимок DOM страниц бирж — фикстуры для контракта страницы (Этап 2) ────
//
// Оператор 15.09: «регресс то по одной, то по другой бирже». Причина — разметку
// биржи мы узнаём на бою: тестов против реальной страницы нет. Этот снимок
// снимает HTML открытых торговых страниц (форма ордера + нижняя панель с
// историей) из ЖИВОГО браузера профиля — по ним пишутся тесты читалок, и смена
// разметки биржей ловится тестом до релиза, а не оператором после.
//
// Что снимаем: только торговые страницы пар (bingx/mexc/xt). Страницы вывода,
// API-ключей, аккаунта — пропускаем: там личные данные, и для контракта они не
// нужны. Что вычищаем: <script>, значения полей ввода, атрибуты с токенами.
// Файлы кладутся ЛОКАЛЬНО в data/dom-snapshots и никуда не отправляются —
// оператор сам решает, что передать; перед попаданием в репозиторий снимок
// ещё раз чистится вручную (балансы в тексте страницы).
const SNAPSHOT_HOSTS = /^https:\/\/(www\.)?(bingx\.com|mexc\.com|xt\.com)\//i;
async function apiDomSnapshot(res) {
  const { isTradePairUrl } = require('../integration/pair-tabs');
  const dir = path.join(config.dataDir, 'dom-snapshots');
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const saved = [];
  const skipped = [];
  for (const [name, rec] of running) {
    const ctx = rec && rec.context;
    if (!ctx) continue;
    for (const pg of ctx.pages()) {
      let url = '';
      try { if (pg.isClosed()) continue; url = pg.url(); } catch { continue; }
      // Спящая вкладка (усыплена при простое): DOM биржи в ней уже нет, снимать
      // нечего. Раньше такие молча выпадали — оператор 15.09 получил снимок
      // одной биржи из трёх и не понял, почему. Называем их поимённо: разбудить
      // просто — открыть пару в терминале (прогрев) и снять снимок ещё раз.
      const asleep = typeof pg.__arbiSleepUrl === 'string' && pg.__arbiSleepUrl;
      if (asleep && SNAPSHOT_HOSTS.test(asleep)) {
        skipped.push(`СПИТ — откройте пару в терминале и повторите: ${asleep.replace(/^https?:\/\//, '').slice(0, 60)}`);
        continue;
      }
      if (!SNAPSHOT_HOSTS.test(url)) continue;
      if (!isTradePairUrl(url)) { skipped.push(url.replace(/^https?:\/\//, '').slice(0, 60)); continue; }
      try {
        const html = await pg.evaluate(() => {
          const root = document.documentElement.cloneNode(true);
          root.querySelectorAll('script,noscript,iframe').forEach((e) => e.remove());
          root.querySelectorAll('input,textarea').forEach((e) => { e.removeAttribute('value'); e.value = ''; });
          root.querySelectorAll('[data-token],[data-auth],[authorization]').forEach((e) => {
            for (const a of ['data-token', 'data-auth', 'authorization']) e.removeAttribute(a);
          });
          return '<!-- ' + location.href + ' | ' + new Date().toISOString() + ' -->\n<!doctype html>\n' + root.outerHTML;
        });
        const host = new URL(url).hostname.replace(/^www\./, '').split('.')[0];
        const pair = (url.split(/[?#]/)[0].replace(/\/+$/, '').split('/').pop() || 'page').replace(/[^A-Za-z0-9_-]/g, '_');
        // Две страницы с одним URL (вкладка пары и фоновая страница истории) —
        // раньше писались в один файл, второй затирал первый (оператор 15.09:
        // MEXC «saved» дважды, файл один). Нумеруем повторы.
        let file = path.join(dir, `${host}__${pair}__${name}__${stamp}.html`);
        for (let n = 2; fs.existsSync(file); n++) file = path.join(dir, `${host}__${pair}__${name}__${stamp}__${n}.html`);
        fs.writeFileSync(file, html, 'utf8');
        saved.push({ file, bytes: html.length, url: url.slice(0, 80) });
      } catch (e) {
        skipped.push(`${url.slice(0, 60)} (ошибка: ${e && e.message ? e.message.slice(0, 60) : e})`);
      }
    }
  }
  console.log(`[snapshot] Снимок DOM: сохранено ${saved.length}, пропущено ${skipped.length} → ${dir}`);
  return sendJson(res, 200, { ok: true, dir, saved, skipped });
}

async function handle(req, res) {
  const url = new URL(req.url, 'http://localhost');
  const pathn = url.pathname;
  const m = req.method;

  // SEC-1: отсекаем не-локальные Host/Origin (DNS-rebinding, cross-site) до любой логики.
  if (!isLocalRequest(req, boundHost)) return sendJson(res, 403, { error: 'forbidden (non-local host/origin)' });

  try {
    if (pathn === '/' || pathn === '/index.html') return serveStatic(res, 'index.html');
    if (pathn.startsWith('/static/')) return serveStatic(res, pathn.slice('/static/'.length));

    if (pathn === '/api/logs' && m === 'GET') return apiLogsStream(req, res);
    if (pathn === '/api/profiles' && m === 'GET') return apiListProfiles(res);
    if (pathn === '/api/profiles' && m === 'POST') return apiSaveProfile(req, res);
    // Путь НЕ вида /api/profiles/<имя>: иначе профиль, названный «rebind», спорил бы
    // за него с динамическим разбором ниже (строка с regexp по именам профилей).
    if (pathn === '/api/profiles-rebind' && m === 'POST') return apiRebindProfile(req, res);
    if (pathn === '/api/generate' && m === 'POST') return apiGenerate(req, res);
    if (pathn === '/api/sync-terminal' && m === 'POST') return apiSyncTerminal(res);
    if (pathn === '/api/extensions/refresh' && m === 'POST') return apiRefreshExtensions(res);
    if (pathn === '/api/app-info' && m === 'GET') return sendJson(res, 200, await appInfo.appInfo({ force: url.searchParams.get('check') === '1' }));
    if (pathn === '/api/changelog' && m === 'GET') return sendJson(res, 200, { version: require('../../package.json').version, entries: require('../changelog').CHANGELOG });
    // Паник-пауза «Стоп запросы»: тумблер, при котором исполнители перестают опрашивать
    // терминал → ноль запросов к биржам и в лог. GET — состояние (для кнопки), POST — задать.
    if (pathn === '/api/dom-snapshot' && m === 'GET') return apiDomSnapshot(res);
    if (pathn === '/api/executor/pause' && m === 'GET') return sendJson(res, 200, { paused: executorCore.isPaused() });
    if (pathn === '/api/executor/pause' && m === 'POST') {
      const body = await readBody(req);
      executorCore.setPaused(!!body.paused);
      console.log(`[exec] обработка запросов ${executorCore.isPaused() ? 'ПРИОСТАНОВЛЕНА (Стоп запросы)' : 'ВОЗОБНОВЛЕНА'} оператором`);
      return sendJson(res, 200, { paused: executorCore.isPaused() });
    }
    if (pathn === '/api/settings' && m === 'POST') return apiSaveSettings(req, res);
    if (pathn === '/api/app-update' && m === 'POST') return apiAppUpdate(res);
    // Что скачано фоном и ждёт установки (панель может показать «доступна vX»).
    if (pathn === '/api/update-ready' && m === 'GET') {
      return sendJson(res, 200, {
        ready: !!updateReady,
        version: updateReady ? updateReady.version : null,
        notes: updateReady ? updateReady.notes : '',
        openProfiles: running.size,
      });
    }
    if (pathn === '/api/download-installer' && m === 'POST') return apiDownloadInstaller(res);
    if (pathn === '/api/open-download' && m === 'POST') return apiOpenDownload(res);
    if (pathn === '/api/downloads/open' && m === 'POST') return apiOpenDownloads(res);
    if (pathn === '/api/trash' && m === 'GET') return apiListTrash(res);
    const tm = pathn.match(/^\/api\/trash\/([^/]+)(\/restore)?$/);
    if (tm) {
      const tname = decodeURIComponent(tm[1]);
      if (tm[2] === '/restore' && m === 'POST') return apiRestoreTrash(res, tname);
      if (!tm[2] && m === 'DELETE') return apiPurgeTrash(res, tname);
    }
    if (pathn === '/api/sync/status' && m === 'GET') return sendJson(res, 200, { enabled: sync.enabled(), blocked: syncBlocked, reason: syncBlockReason, deviceId: sync.enabled() ? sync.deviceId() : null });
    if (pathn === '/api/sync/override' && m === 'POST') { setSyncBlocked(false, ''); return sendJson(res, 200, { ok: true, blocked: false }); }
    if (pathn === '/api/sync/push' && m === 'POST') return apiSyncPush(res);

    const pm = pathn.match(/^\/api\/profiles\/([^/]+)(\/(launch|check|close|network|group|autolaunch|wipe))?$/);
    if (pm) {
      const name = decodeURIComponent(pm[1]);
      const action = pm[3];
      if (!action && m === 'GET') return apiGetProfile(res, name);
      if (!action && m === 'DELETE') return apiDeleteProfile(res, name);
      if (action === 'wipe' && m === 'POST') return apiWipeProfile(res, name);
      if (action === 'launch' && m === 'POST') return apiLaunch(req, res, name);
      if (action === 'close' && m === 'POST') return apiCloseProfile(res, name);
      if (action === 'check' && m === 'POST') return apiCheck(req, res, name);
      if (action === 'network' && m === 'POST') return apiNetworkCheck(req, res, name);
      if (action === 'group' && m === 'POST') return apiSetGroup(req, res, name);
      if (action === 'autolaunch' && m === 'POST') return apiSetAutoLaunch(req, res, name);
    }

    sendJson(res, 404, { error: 'Не найдено.' });
  } catch (e) {
    sendJson(res, 500, { error: e.message });
  }
}

// ── Запуск сервера ──

/**
 * Запускает GUI-сервер.
 * @param {{port?:number, host?:string, openWindow?:boolean}} [opts]
 * @returns {Promise<{server:http.Server, url:string, close:()=>Promise<void>}>}
 */
function start(opts = {}) {
  const desiredPort = opts.port || 8777;
  const host = opts.host || '127.0.0.1';
  boundHost = host; // SEC-1: разрешаем Host-заголовок фактического адреса привязки
  profileStore.ensureProfilesDir();

  // Фоновая проверка обновления: при старте и дальше раз в 6 часов — панель
  // держат открытой сутками, одной проверки на старте мало. СКАЧИВАЕТ молча
  // (обновление ждёт наготове), но НЕ ставит: установка — только кнопкой
  // «Обновление», и только когда закрыты профили (см. updater.js).
  // Отключить: ARBI_UPDATE_CHECK=0.
  if (process.env.ARBI_UPDATE_CHECK !== '0') {
    try {
      require('../updater').startBackgroundCheck((info) => {
        updateReady = { version: info.latest, notes: (info.manifest && info.manifest.notes) || '' };
        console.log(`[update] версия ${info.latest} скачана и готова к установке — кнопка «Обновление» в панели`);
      });
    } catch (e) {
      console.warn(`[update] фоновая проверка не запущена: ${e.message}`);
    }
  }

  return new Promise((resolve, reject) => {
    const server = http.createServer(handle);
    let triedRandom = false;

    // Если порт занят (панель уже запущена) — берём случайный свободный порт,
    // чтобы новое окно всё равно открылось (важно для повторного клика по ярлыку).
    server.on('error', (e) => {
      if (e.code === 'EADDRINUSE' && !triedRandom) {
        triedRandom = true;
        server.listen(0, host);
      } else {
        reject(e);
      }
    });

    server.once('listening', async () => {
      const actualPort = server.address().port;
      const url = `http://${host}:${actualPort}/`;
      // Отдельный user-data-dir окна панели на процесс — иначе второй экземпляр
      // не запустится (каталог заблокирован первым Chromium).
      const controlDir = path.join(config.dataDir, `control-panel-${process.pid}`);

      // БАРЬЕР синхронизации профилей: ДО старта исполнителей и ДО открытия любого
      // профиля скачиваем и проверяем более свежие облачные слепки (тот же отпечаток/
      // прокси на новом устройстве). Fail-closed: при сбое блокируем открытие профилей
      // (снимается офлайн-режимом в панели). Выключен флагом → секция бездействует.
      if (sync.enabled()) {
        try {
          const r = await sync.runBarrier();
          console.log('[sync] барьер пройден: ' + r.summary);
        } catch (e) {
          setSyncBlocked(true, (e && e.message) || String(e));
          console.error('[sync] БАРЬЕР НЕ ПРОЙДЕН — открытие профилей заблокировано: ' + syncBlockReason);
        }
        // Периодическая выгрузка открытых профилей (профиль+cookie) в облако.
        const hb = setInterval(() => { pushOpenProfiles().catch(() => {}); }, 3 * 60 * 1000);
        if (hb.unref) hb.unref();
      }

      // MEXC web-исполнитель (Стадия 3): опрашивает намерения терминала и
      // исполняет их в живой странице MEXC запущенного профиля. Авто-старт
      // только при ARBI_MEXC_EXEC=1 и заданном токене (иначе панель как раньше).
      let stopExecutor = null;
      if (config.mexcExec && config.terminal.token) {
        stopExecutor = mexcExecutor.startLoop({
          log: (m) => console.log('[mexc-exec] ' + m),
          executeIntent: async (intent) => {
            // Akamai-бэкофф: MEXC заблокировал профиль/IP (Access Denied) — НЕ лезем на
            // биржу вообще (ни авто-запуск, ни навигация), пока бэкофф активен: заходы
            // продлевают бан и мешают оператору восстановиться (сменить IP/подождать).
            if (mexcOrderPage.mexcBlocked()) {
              return { ok: false, error: `MEXC временно недоступен (Access Denied, Akamai) — навигация приостановлена ещё на ${Math.ceil(mexcOrderPage.mexcBlockedMsLeft() / 1000)}с. Смените IP прокси или подождите.` };
            }
            let context = contextForAccountId(intent.accountId);
            // Read-интент (история ордеров) НЕ авто-запускает целый профиль: фоновое
            // чтение не стоит запуска Chromium, а читаем мы всё равно только с УЖЕ
            // открытой тёплой вкладки (защита от Akamai — без навигации).
            if (!context && intent.orders) {
              return { ok: false, error: 'профиль не запущен — историю не читаем (read-интент не запускает браузер)' };
            }
            // Уборка вкладок при незапущенном профиле — убирать нечего. Без этого
            // гарда intent авто-запускал профиль «под ордер» с первой парой
            // keep-списка (02.09: после перезагрузки браузер открыл MEY на MEXC).
            if (!context && intent.closeStale) return { ok: true, closed: 0 };
            if (!context) {
              // «Под капотом»: авто-запуск нужного профиля СКРЫТО (off-screen),
              // чтобы не держать браузер открытым вручную и авто-выбрать профиль
              // с нужным прокси. Профиль должен быть хотя бы раз залогинен в MEXC
              // (куки живут в user-data-dir) — авто-запуск переиспользует сессию.
              // Одна сессия на аккаунт: если уже запущен — не поднимаем второй раз.
              const name = findProfileNameByAccountId(intent.accountId);
              if (name) {
                try {
                  // По умолчанию окно ВИДИМОЕ (на экране): тот же профиль пользователь
                  // использует для ручной работы с антидетектом. Скрыть за экран (старое
                  // поведение) можно ARBI_MEXC_HIDDEN=1. launchProfileOnce переиспользует
                  // уже открытое окно — второй раз не поднимает.
                  const hidden = (process.env.ARBI_MEXC_HIDDEN || '0') === '1';
                  console.log(`[mexc-exec] авто-запуск профиля ${name} (${hidden ? 'скрыто' : 'видимо'}) под ордер ${intent.symbol}...`);
                  // launchProfileOnce: если профиль уже открыт (в т.ч. вручную для
                  // логина) — ПЕРЕИСПОЛЬЗУЕМ его, второй раз не поднимаем (нет конфликта).
                  const opened = await launchProfileOnce(name, {
                    hidden,
                    startUrl: `https://www.mexc.com/exchange/${mexcOrderPage.toMexcPair(intent.symbol)}`,
                    log: (m) => console.log('[mexc-exec] ' + m),
                  });
                  context = opened.context;
                } catch (e) {
                  return { ok: false, error: `Не удалось авто-запустить профиль ${name}: ${e.message}` };
                }
              }
            }
            if (!context) {
              const have = Array.from(running.entries())
                .map(([n, r]) => `${n}(id=${(r.accountIds || []).join('|') || 'нет'})`).join(', ') || 'ничего не запущено';
              return { ok: false, error: `Профиль для accountId=${intent.accountId} не найден (нет импортированного профиля с этим accountId). Запущено: ${have}. Сделайте sync и залогиньтесь в профиль один раз.` };
            }
            // ПРОГРЕВ (warmup) — БЕЗ ВЫСТАВЛЕНИЯ ОРДЕРА (безопасно для денег).
            // Терминал шлёт это при открытии сессии и при открытии web-токена.
            // Профиль уже поднят авто-запуском выше (оплачен самый долгий шаг —
            // запуск браузера). Здесь только грузим страницу пары + гидрируем форму
            // (ждём готовности кнопки) + закрываем промо-оверлеи. Никаких ордеров —
            // ускорение первого реального ордера идёт от ТЁПЛОЙ формы, а не от
            // «прогревочной» заявки (проверено на проде: BTC-ордер скорость токена
            // не менял, но нёс риск непреднамеренной покупки — поэтому убран).
            if (intent.warmup) {
              const pair = mexcOrderPage.toMexcPair(intent.symbol || 'BTC/USDT');
              try {
                const w = await withContextLock(context, () => mexcOrderPage.warmupForm(context, pair, (m) => console.log('[mexc-exec] ' + m)));
                // РАЗЛОГИН — единственный случай, когда прогрев докладывает ошибку
                // (оператор 25.09: «не уведомляет, что на бирже разлогин, и всё равно
                // шлёт заявку»). Прогрев приходит ДО заявки — терминал узнаёт про
                // «залогинься» заранее. Прочие осечки прогрева (404 пары, форма не
                // догрузилась) остаются ok, как было: они не про вход в аккаунт.
                if (w && w.loginRequired) return { ok: false, warmed: false, loginRequired: true, error: w.error };
                return { ok: true, warmed: true };
              } catch (e) {
                return { ok: false, error: `Прогрев не удался: ${e.message}` };
              }
            }
            // Отмена ВСЕХ ордеров нативной кнопкой биржи — для web-only токенов (по API
            // их не отменить). Ордер НЕ ставится → идёт ДО live-kill-switch.
            if (intent.cancelAll) {
              const pair = mexcOrderPage.toMexcPair(intent.symbol || 'BTC/USDT');
              return withContextLock(context, () => mexcOrderPage.cancelAllOrders(context, pair, (m) => console.log('[mexc-exec] ' + m)));
            }
            // Чтение ИСТОРИИ ОРДЕРОВ пары (read-only) — ТОЛЬКО с уже открытой тёплой
            // вкладки пары, БЕЗ навигации (инцидент 2026-07-20: свежая фоновая вкладка
            // + голый goto = Akamai «Access Denied»). Нет тёплой вкладки → мягкий
            // пропуск. Выключить целиком: ARBI_MEXC_ORDERS_READ=0.
            if (intent.orders) {
              if (!config.mexcOrdersRead) {
                return { ok: false, error: 'Чтение истории MEXC через браузер отключено (ARBI_MEXC_ORDERS_READ=0).' };
              }
              const pair = mexcOrderPage.toMexcPair(intent.symbol || 'BTC/USDT');
              // Фон уступает дорогу ордеру — см. тот же гард в ветке BingX ниже.
              if (isContextBusy(context)) {
                return { ok: false, error: 'браузер занят выставлением заявки — чтение истории отложено' };
              }
              try {
                const oh = await withContextLock(context, () => mexcOrderPage.readOrdersWarm(context, pair, { log: (m) => console.log('[mexc-exec] ' + m) }));
                return { ok: !!(oh && oh.ok), orders: oh, loginRequired: !!(oh && oh.loginRequired), error: (oh && oh.ok) ? undefined : ((oh && oh.error) || 'история ордеров не прочитана (вкладка/страница биржи)') };
              } catch (e) {
                return { ok: false, error: `Чтение истории ордеров MEXC не удалось: ${e.message}` };
              }
            }
            // ЗАКРЫТИЕ ВКЛАДОК ЗАКРЫТЫХ ПАР: терминал прислал список своих
            // открытых вкладок — лишние вкладки ПУЛА закрываем (оператор 01.09).
            // Дорожка 'bg': закрытие не срочное и не должно стоять перед заявкой.
            if (intent.closeStale) {
              const keep = Array.isArray(intent.keepSymbols) ? intent.keepSymbols : [];
              if (isContextBusy(context)) {
                return deferCleanup('mexc', (m) => console.log('[mexc-exec] ' + m));
              }
              try {
                const r = await withContextLock(context, () => closeStalePairTabs(context, 'https://www.mexc.com', keep, (m) => console.log('[mexc-exec] ' + m)), { lane: 'bg' });
                return { ok: true, closed: (r && r.closed) || 0 };
              } catch (e) {
                return { ok: false, error: `Уборка вкладок не удалась: ${e.message}` };
              }
            }
            // Чтение баланса — только BingX-фолбэк. Явный ранний возврат, чтобы
            // неизвестный вид интента не проваливался в путь реального ордера.
            if (intent.balance) {
              return { ok: false, error: 'balance-интент не поддержан для MEXC (только BingX)' };
            }
            // Kill-switch: без ARBI_MEXC_EXEC_LIVE реальные ордера не ставим
            // (пока не пройден живой прогон против анти-бота MEXC).
            if (!config.mexcExecLive) {
              return { ok: false, error: 'live-режим выключен (задайте ARBI_MEXC_EXEC_LIVE=1 после проверки).' };
            }
            // IM-5: сериализуем работу со страницей между исполнителями (общий контекст).
            return withContextLock(context, () => mexcOrderPage.executeIntent(context, intent, { log: (m) => console.log('[mexc-exec] ' + m) }));
          },
        });
        console.log(`[mexc-exec] исполнитель запущен (live=${config.mexcExecLive ? 'ON' : 'OFF'}); терминал ${config.terminal.url}`);
      }

      // XT web-исполнитель (Стадия 3): зеркало MEXC-блока выше, опрашивает
      // намерения терминала и исполняет их в живой странице XT запущенного
      // профиля. Авто-старт только при ARBI_XT_EXEC=1 и заданном токене.
      let stopXtExecutor = null;
      if (config.xtExec && config.terminal.token) {
        stopXtExecutor = xtExecutor.startLoop({
          log: (m) => console.log('[xt-exec] ' + m),
          executeIntent: async (intent) => {
            let context = contextForAccountId(intent.accountId);
            if (!context && intent.closeStale) return { ok: true, closed: 0 }; // см. гард MEXC
            if (!context) {
              // «Под капотом»: авто-запуск нужного профиля СКРЫТО (off-screen),
              // чтобы не держать браузер открытым вручную и авто-выбрать профиль
              // с нужным прокси. Профиль должен быть хотя бы раз залогинен в XT
              // (куки живут в user-data-dir) — авто-запуск переиспользует сессию.
              // Одна сессия на аккаунт: если уже запущен — не поднимаем второй раз.
              const name = findProfileNameByAccountId(intent.accountId);
              if (name) {
                try {
                  // По умолчанию окно ВИДИМОЕ (на экране): тот же профиль пользователь
                  // использует для ручной работы с антидетектом. Скрыть за экран (старое
                  // поведение) можно ARBI_XT_HIDDEN=1. launchProfileOnce переиспользует
                  // уже открытое окно — второй раз не поднимает.
                  const hidden = (process.env.ARBI_XT_HIDDEN || '0') === '1';
                  console.log(`[xt-exec] авто-запуск профиля ${name} (${hidden ? 'скрыто' : 'видимо'}) под ордер ${intent.symbol}...`);
                  // launchProfileOnce: если профиль уже открыт (в т.ч. вручную для
                  // логина) — ПЕРЕИСПОЛЬЗУЕМ его, второй раз не поднимаем (нет конфликта).
                  const opened = await launchProfileOnce(name, {
                    hidden,
                    startUrl: process.env.ARBI_XT_TRADE_URL
                      ? process.env.ARBI_XT_TRADE_URL.replace('{pair}', xtOrderPage.toXtPair(intent.symbol))
                      : `https://www.xt.com/ru/trade/${xtOrderPage.toXtPair(intent.symbol)}`,
                    log: (m) => console.log('[xt-exec] ' + m),
                  });
                  context = opened.context;
                } catch (e) {
                  return { ok: false, error: `Не удалось авто-запустить профиль ${name}: ${e.message}` };
                }
              }
            }
            if (!context) {
              const have = Array.from(running.entries())
                .map(([n, r]) => `${n}(id=${(r.accountIds || []).join('|') || 'нет'})`).join(', ') || 'ничего не запущено';
              return { ok: false, error: `Профиль для accountId=${intent.accountId} не найден (нет импортированного профиля с этим accountId). Запущено: ${have}. Сделайте sync и залогиньтесь в профиль один раз.` };
            }
            // ПРОГРЕВ (warmup) — БЕЗ ВЫСТАВЛЕНИЯ ОРДЕРА (безопасно для денег).
            // Терминал шлёт это при открытии сессии и при открытии web-токена.
            if (intent.warmup) {
              const pair = xtOrderPage.toXtPair(intent.symbol || 'BTC/USDT');
              try {
                const w = await withContextLock(context, () => xtOrderPage.warmupForm(context, pair, (m) => console.log('[xt-exec] ' + m)));
                if (w && w.loginRequired) return { ok: false, warmed: false, loginRequired: true, error: w.error };
                // riskModal прокидываем → терминал запишет ST-токен в ОБЩУЮ базу на прогреве.
                return { ok: true, warmed: true, riskModal: !!(w && w.riskModal) };
              } catch (e) {
                return { ok: false, error: `Прогрев не удался: ${e.message}` };
              }
            }
            // Отмена ВСЕХ ордеров нативной кнопкой биржи — web-only, ДО live-kill-switch.
            if (intent.cancelAll) {
              const pair = xtOrderPage.toXtPair(intent.symbol || 'BTC/USDT');
              return withContextLock(context, () => xtOrderPage.cancelAllOrders(context, pair, (m) => console.log('[xt-exec] ' + m)));
            }
            // ЗАКРЫТИЕ ВКЛАДОК ЗАКРЫТЫХ ПАР: терминал прислал список своих
            // открытых вкладок — лишние вкладки ПУЛА закрываем (оператор 01.09).
            // Дорожка 'bg': закрытие не срочное и не должно стоять перед заявкой.
            if (intent.closeStale) {
              const keep = Array.isArray(intent.keepSymbols) ? intent.keepSymbols : [];
              if (isContextBusy(context)) {
                return deferCleanup('xt', (m) => console.log('[xt-exec] ' + m));
              }
              try {
                const r = await withContextLock(context, () => closeStalePairTabs(context, 'https://www.xt.com', keep, (m) => console.log('[xt-exec] ' + m)), { lane: 'bg' });
                return { ok: true, closed: (r && r.closed) || 0 };
              } catch (e) {
                return { ok: false, error: `Уборка вкладок не удалась: ${e.message}` };
              }
            }
            // Read-интенты (баланс/история ордеров) — только BingX-фолбэк. Явный ранний
            // возврат, чтобы неизвестный вид интента не проваливался в путь реального ордера.
            if (intent.balance || intent.orders) {
              return { ok: false, error: 'read-интент (balance/orders) не поддержан для XT (только BingX)' };
            }
            // Kill-switch: без ARBI_XT_EXEC_LIVE реальные ордера не ставим
            // (пока не пройден живой прогон против анти-бота XT).
            if (!config.xtExecLive) {
              return { ok: false, error: 'live-режим выключен (задайте ARBI_XT_EXEC_LIVE=1 после проверки).' };
            }
            // IM-5: сериализуем работу со страницей между исполнителями (общий контекст).
            return withContextLock(context, () => xtOrderPage.executeIntent(context, intent, { log: (m) => console.log('[xt-exec] ' + m) }));
          },
        });
        console.log(`[xt-exec] исполнитель запущен (live=${config.xtExecLive ? 'ON' : 'OFF'}); терминал ${config.terminal.url}`);
      }

      // BingX web-исполнитель (Стадия 3): точное зеркало XT-блока выше. Тот же
      // generic long-poll транспорт (bingx-executor.js), та же логика авто-запуска
      // профиля и warmup. Авто-старт только при ARBI_BINGX_EXEC=1 и заданном токене.
      // По умолчанию OFF — до тех пор, пока оператор не пришлёт реальные DOM-
      // селекторы/endpoint BingX (см. заголовок bingx-order-page.js).
      let stopBingxExecutor = null;
      if (config.bingxExec && config.terminal.token) {
        stopBingxExecutor = bingxExecutor.startLoop({
          log: (m) => console.log('[bingx-exec] ' + m),
          executeIntent: async (intent) => {
            let context = contextForAccountId(intent.accountId);
            if (!context && intent.closeStale) return { ok: true, closed: 0 }; // см. гард MEXC
            if (!context) {
              const name = findProfileNameByAccountId(intent.accountId);
              if (name) {
                try {
                  const hidden = (process.env.ARBI_BINGX_HIDDEN || '0') === '1';
                  console.log(`[bingx-exec] авто-запуск профиля ${name} (${hidden ? 'скрыто' : 'видимо'}) под ордер ${intent.symbol}...`);
                  const opened = await launchProfileOnce(name, {
                    hidden,
                    startUrl: process.env.ARBI_BINGX_TRADE_URL
                      ? process.env.ARBI_BINGX_TRADE_URL.replace('{pair}', bingxOrderPage.toBingxPair(intent.symbol))
                      : `https://bingx.com/en-us/spot/${bingxOrderPage.toBingxPair(intent.symbol)}`,
                    log: (m) => console.log('[bingx-exec] ' + m),
                  });
                  context = opened.context;
                } catch (e) {
                  return { ok: false, error: `Не удалось авто-запустить профиль ${name}: ${e.message}` };
                }
              }
            }
            if (!context) {
              const have = Array.from(running.entries())
                .map(([n, r]) => `${n}(id=${(r.accountIds || []).join('|') || 'нет'})`).join(', ') || 'ничего не запущено';
              return { ok: false, error: `Профиль для accountId=${intent.accountId} не найден (нет импортированного профиля с этим accountId). Запущено: ${have}. Сделайте sync и залогиньтесь в профиль один раз.` };
            }
            // «Счёт получения» депозита (оператор 17.09): проверить/поставить «Спот
            // счёт» по списку монет и записать вызовы страницы (без заголовков, с
            // вымаранными секретами) — см. bingx-deposit-page.js. Дорожка 'bg'.
            if (intent.depositProbe) {
              try {
                const out = await withContextLock(context, () => bingxDepositPage.probeDepositAccount(context, {
                  ...(intent.depositProbe || {}), log: (m) => console.log('[bingx-deposit] ' + m),
                }), { lane: 'bg' });
                return { ok: true, depositProbe: out };
              } catch (e) {
                return { ok: false, error: `Проверка счёта получения не удалась: ${e.message}` };
              }
            }
            // Фоновое чтение баланса по токену (read-only) — в ВЫДЕЛЕННОЙ фоновой
            // странице, не трогая активную вкладку оператора. Для фолбэка терминала,
            // когда API-баланс BingX пуст по web-only/API-заблокированному токену.
            if (intent.balance) {
              const pair = bingxOrderPage.toBingxPair(intent.symbol || 'BTC/USDT');
              try {
                // Дорожка 'bg': чтение идёт на ВЫДЕЛЕННОЙ фоновой странице
                // (__arbiBalanceBg), с формой ордера не пересекается — держать его
                // в очереди денежного пути незачем (оператор 01.09).
                const bal = await withContextLock(context, () => bingxOrderPage.readBalanceBg(context, pair, { log: (m) => console.log('[bingx-exec] ' + m) }), { lane: 'bg' });
                // Провал read-интента ОБЯЗАН нести причину: без неё в логе
                // печаталось «ошибка: undefined» и понять было нечего.
                return bal && bal.ok
                  ? { ok: true, balance: bal }
                  : { ok: false, balance: bal || null, error: (bal && bal.error) || 'баланс не прочитан (вкладка пары не открыта / страница не отрисовалась)' };
              } catch (e) {
                return { ok: false, error: `Чтение баланса не удалось: ${e.message}` };
              }
            }
            // Фоновое чтение ИСТОРИИ ОРДЕРОВ пары (read-only) — сверка web-ордеров
            // терминала с фактом биржи (исполнен/отменён/частично) без участия оператора.
            if (intent.orders) {
              const pair = bingxOrderPage.toBingxPair(intent.symbol || 'BTC/USDT');
              // ⚠️ ЧТЕНИЕ ИСТОРИИ УСТУПАЕТ ДОРОГУ ОРДЕРУ (жалоба «браузер стал
              // очень медленным», 2026-08-30). Блокировка контекста одна на весь
              // профиль и работает как FIFO: чтение, вставшее в очередь первым,
              // задерживает выставление заявки ровно на своё время. Сверка
              // web-ордеров — фон, она повторится по таймеру; заявка ждать не
              // должна. Занят контекст — молча пропускаем круг.
              if (isContextBusy(context)) {
                return { ok: false, error: 'браузер занят выставлением заявки — чтение истории отложено' };
              }
              try {
                const oh = await withContextLock(context, () => bingxOrderPage.readOrdersBg(context, pair, {
                  log: (m) => console.log('[bingx-exec] ' + m),
                  // Внутреннее имя монеты на бирже (GENSYN → «AI»): в таблице
                  // истории пара подписана так, и без алиаса фильтр не находил
                  // ни одной строки (оператор 2026-09-24).
                  alias: intent.hints && intent.hints.coinAlias,
                }), { lane: 'bg' });
                return oh && oh.ok
                  ? { ok: true, orders: oh }
                  : { ok: false, orders: oh || null, loginRequired: !!(oh && oh.loginRequired), error: (oh && oh.error) || 'история ордеров не прочитана (таблица истории на странице не найдена)' };
              } catch (e) {
                return { ok: false, error: `Чтение истории ордеров не удалось: ${e.message}` };
              }
            }
            if (intent.warmup) {
              const pair = bingxOrderPage.toBingxPair(intent.symbol || 'BTC/USDT');
              try {
                // Прогрев + чтение баланса по токену — в ОДНОЙ блокировке контекста,
                // чтобы переключение вкладок Buy/Sell при чтении не пересеклось с
                // ордером другого потока в том же профиле. Баланс read-only; при
                // сбое чтения прогрев всё равно успешен (balance=null).
                const out = await withContextLock(context, async () => {
                  // intent.refreshBalance — терминал сообщил, что монета ТОЛЬКО ЧТО
                  // легла на Спот: обновляем баланс формы заранее, чтобы выстрел не
                  // платил за это своим временем.
                  const warm = await bingxOrderPage.warmupForm(context, pair, (m) => console.log('[bingx-exec] ' + m), { refreshBalance: !!intent.refreshBalance, expectedQty: Number(intent.expectedQty) || 0, expectedUsd: Number(intent.expectedUsd) || 0 });
                  let balance = null;
                  // По умолчанию OFF: пока терминал не читает balance из результата,
                  // не платим за переклик Buy/Sell на каждом прогреве. Включить —
                  // ARBI_BINGX_WARMUP_BALANCE=1 (или когда подключим терминал-сторону).
                  if ((process.env.ARBI_BINGX_WARMUP_BALANCE || '0') === '1') {
                    balance = await bingxOrderPage.readBalance(context, pair, { log: (m) => console.log('[bingx-exec] ' + m) })
                      .catch((e) => ({ ok: false, error: e.message }));
                  }
                  return { warm, balance };
                });
                if (out.warm && out.warm.loginRequired) return { ok: false, warmed: false, loginRequired: true, error: out.warm.error };
                return { ok: true, warmed: true, riskModal: !!(out.warm && out.warm.riskModal), balance: out.balance };
              } catch (e) {
                return { ok: false, error: `Прогрев не удался: ${e.message}` };
              }
            }
            // ЗАКРЫТИЕ ВКЛАДОК ЗАКРЫТЫХ ПАР: терминал прислал список своих
            // открытых вкладок — лишние вкладки ПУЛА закрываем (оператор 01.09).
            // Дорожка 'bg': уборка не срочная и не должна стоять перед заявкой.
            if (intent.closeStale) {
              const keep = Array.isArray(intent.keepSymbols) ? intent.keepSymbols : [];
              if (isContextBusy(context)) {
                return deferCleanup('bingx', (m) => console.log('[bingx-exec] ' + m));
              }
              try {
                const r = await withContextLock(context, () => closeStalePairTabs(context, (process.env.ARBI_BINGX_ORIGIN || 'https://bingx.com'), keep, (m) => console.log('[bingx-exec] ' + m)), { lane: 'bg' });
                return { ok: true, closed: (r && r.closed) || 0 };
              } catch (e) {
                return { ok: false, error: `Уборка вкладок не удалась: ${e.message}` };
              }
            }
            // Отмена ВСЕХ ордеров нативной кнопкой биржи — web-only, ДО live-kill-switch.
            if (intent.cancelAll) {
              const pair = bingxOrderPage.toBingxPair(intent.symbol || 'BTC/USDT');
              return withContextLock(context, () => bingxOrderPage.cancelAllOrders(context, pair, (m) => console.log('[bingx-exec] ' + m)));
            }
            if (!config.bingxExecLive) {
              return { ok: false, error: 'live-режим выключен (задайте ARBI_BINGX_EXEC_LIVE=1 после проверки).' };
            }
            // IM-5: сериализуем работу со страницей между исполнителями (общий контекст).
            return withContextLock(context, () => bingxOrderPage.executeIntent(context, intent, { log: (m) => console.log('[bingx-exec] ' + m) }));
          },
        });
        console.log(`[bingx-exec] исполнитель запущен (live=${config.bingxExecLive ? 'ON' : 'OFF'}); терминал ${config.terminal.url}`);
      }

      let controlWindow = null;
      let controlBoundsTimer = null;
      let resolveClosed;
      const whenControlClosed = new Promise((r) => { resolveClosed = r; });
      requestShutdown = () => { try { resolveClosed(); } catch (_) { /* уже */ } };
      if (opts.openWindow) {
        try {
          controlWindow = await openControlWindow(url, controlDir);
          controlWindow.on('close', () => resolveClosed());
          closeStrayControlPages(controlWindow, url).catch(() => {});
          // Периодически сохраняем позицию окна панели — на случай жёсткого убийства
          // процесса (kill), когда save-перед-закрытием не успеет.
          controlBoundsTimer = setInterval(() => saveControlBounds(controlWindow).catch(() => {}), 15000);
        } catch (e) {
          // Не критично — панель доступна по URL в браузере.
        }
      }
      // АВТОЗАГРУЗКА: профили с флагом autoLaunch запускаем сразу при старте GUI —
      // оператор торгует web-only токенами и хочет, чтобы нужные профили открывались
      // без ручного клика. Fire-and-forget (не блокируем старт панели). launchProfileOnce
      // переиспользует уже открытый профиль — двойного запуска не будет.
      // ПАРАЛЛЕЛЬНО: раньше профили запускались по очереди (await в цикле), и каждый
      // ждал полной загрузки предыдущего (гео-определение выходного IP прокси + старт
      // Chromium + восстановление вкладок ≈ 2с) → N профилей = N×2с задержки. Запускаем
      // все autoLaunch-профили одновременно (launchProfileOnce потокобезопасен: дедуп
      // по имени). Общее время ≈ время ОДНОГО профиля, а не суммы.
      (() => {
        const names = profileStore.list().filter((name) => {
          let p = null;
          try { p = profileStore.load(name); } catch { return false; }
          return p && p.autoLaunch === true && !running.has(name);
        });
        for (const name of names) {
          console.log(`[autoload] запуск профиля ${name}...`);
          launchProfileOnce(name, { hidden: false, startUrl: config.startUrl, log: (mm) => console.log('[autoload] ' + mm) })
            .catch((e) => console.log(`[autoload] не удалось запустить ${name}: ${e.message}`));
        }
      })();
      resolve({
        server,
        url,
        whenControlClosed,
        close: async () => {
          shuttingDown = true; // блокируем любой новый launchProfileOnce на время закрытия
          if (stopExecutor) { try { stopExecutor(); } catch (_) {} }
          if (stopXtExecutor) { try { stopXtExecutor(); } catch (_) {} }
          if (stopBingxExecutor) { try { stopBingxExecutor(); } catch (_) {} }
          if (controlBoundsTimer) { clearInterval(controlBoundsTimer); }
          // Сохраняем позицию окна панели ПОКА оно живо (на Ctrl+C save-на-закрытии
          // не успевает: CDP к уже закрывающемуся окну падает).
          if (controlWindow) { try { await saveControlBounds(controlWindow); } catch (_) {} }
          for (const rec of running.values()) { try { await rec.context.close(); } catch (_) {} }
          if (controlWindow) { try { await controlWindow.close(); } catch (_) {} }
          await new Promise((r) => server.close(() => r()));
          try { fs.rmSync(controlDir, { recursive: true, force: true }); } catch (_) {}
        },
      });
    });

    server.listen(desiredPort, host);
  });
}

// ── Позиция окна панели (переживает Ctrl+C) ─────────────────────────────────
// Папка панели per-pid и удаляется на выходе, поэтому Chromium сам позицию не
// помнит → окно каждый раз по центру (поверх сканера). Храним позицию отдельным
// файлом и восстанавливаем при старте.
const CONTROL_BOUNDS_FILE = path.join(config.dataDir, 'control-window-bounds.json');

function readControlBounds() {
  try {
    const b = JSON.parse(fs.readFileSync(CONTROL_BOUNDS_FILE, 'utf8'));
    if (b && typeof b.left === 'number' && typeof b.top === 'number'
        && b.left > -20000 && b.top > -20000 && b.left < 20000 && b.top < 20000) return b;
  } catch { /* нет файла */ }
  return null;
}

async function saveControlBounds(context) {
  try {
    const page = context.pages()[0];
    if (!page) return;
    const cdp = await context.newCDPSession(page);
    const { windowId } = await cdp.send('Browser.getWindowForTarget');
    const { bounds } = await cdp.send('Browser.getWindowBounds', { windowId });
    await cdp.detach().catch(() => {});
    // Только нормальное окно на экране (не свёрнутое/развёрнутое/off-screen).
    if (bounds && bounds.windowState === 'normal'
        && bounds.left > -20000 && bounds.top > -20000 && bounds.left < 20000) {
      fs.writeFileSync(CONTROL_BOUNDS_FILE, JSON.stringify({
        left: bounds.left, top: bounds.top, width: bounds.width, height: bounds.height,
      }));
    }
  } catch { /* не критично */ }
}

/**
 * Playwright для persistent-context добавляет Chromium стартовую страницу, и вместе
 * с --app это даёт ВТОРОЕ, обычное окно рядом с панелью — пустая вкладка, а в
 * Chrome for Testing без «новой вкладки» ещё и с ошибкой ERR_INVALID_URL
 * (chrome://newtab). Каталог панели создаётся заново на каждый запуск, поэтому
 * окно вылезало при каждом старте (оператор 2026-09-12). Дожидаемся, пока сама
 * панель откроется, и закрываем всё, что не она; панель не трогаем никогда —
 * её закрытие остановило бы ArbiBrowser.
 */
async function closeStrayControlPages(context, url) {
  const deadline = Date.now() + 8000;
  while (Date.now() < deadline) {
    const pages = context.pages();
    const panel = pages.find((p) => p.url().startsWith(url));
    if (panel) {
      for (const p of pages) { if (p !== panel) await p.close().catch(() => {}); }
      return;
    }
    await new Promise((r) => setTimeout(r, 200));
  }
}

/** Открывает саму панель в отдельном окне Chromium (app-mode). */
async function openControlWindow(url, controlDir) {
  // Восстанавливаем позицию/размер прошлой сессии (если сохранены и на экране).
  const saved = readControlBounds();
  const winArgs = saved
    ? [`--window-position=${saved.left},${saved.top}`, `--window-size=${saved.width || 1100},${saved.height || 760}`]
    : ['--window-size=1100,760'];
  const context = await chromium.launchPersistentContext(
    controlDir || path.join(config.dataDir, `control-panel-${process.pid}`),
    {
      headless: false,
      // Панель рисуем во ВСТРОЕННОМ Chromium (executablePath undefined), а НЕ в
      // системном Chrome: системный, уже запущенный у пользователя, при --app
      // перехватывает управление и показывает профиль-пикер «Кто использует
      // Chrome?». Встроенный Chromium — отдельный бинарь, без профилей юзера и
      // без пикера. Профили аккаунтов по-прежнему запускаются на системном Chrome.
      executablePath: undefined,
      args: [`--app=${url}`, '--test-type', '--no-first-run', '--no-default-browser-check', ...winArgs],
      // 'about:blank' — стартовый URL, который Playwright сам добавляет persistent-
      // контексту: вместе с --app он даёт второе обычное окно (см. closeStrayControlPages).
      // Без него Chromium открывает только окно панели; проверено: Playwright всё
      // равно видит страницу панели и контекст отдаёт (pages=1, url=панель).
      ignoreDefaultArgs: ['--enable-automation', 'about:blank'],
      viewport: null,
    }
  );
  return context;
}

module.exports = { start, openControlWindow };
